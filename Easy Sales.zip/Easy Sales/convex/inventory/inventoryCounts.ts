import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { inventoryCountStatus, inventoryCountType } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { isLowStock, MAX_ADJUSTMENT_LINES, stockQtyError } from "../lib/stock";
import { formatCountNumber, MAX_COUNT_LINES, MAX_COUNT_NOTES, statusAfterSave } from "../lib/inventoryCounts";

type CountLine = Doc<"inventoryCounts">["lines"][number];
type AdjustmentLine = Doc<"stockAdjustments">["lines"][number];

const lineInput = v.object({ stockLevelId: v.id("stockLevels"), counted: v.union(v.number(), v.null()) });

function bad(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

async function getOwnedCount(ctx: MutationCtx, id: Id<"inventoryCounts">, ownerId: Id<"users">) {
  const count = await ctx.db.get("inventoryCounts", id);
  if (!count || count.ownerId !== ownerId) throw new ConvexError({ code: "NOT_FOUND", message: "Inventory count not found" });
  return count;
}

/** A count that can still be edited; a full count can't take extra items. */
async function getOpenCount(
  ctx: MutationCtx,
  id: Id<"inventoryCounts">,
  ownerId: Id<"users">,
  input: { stockLevelId: Id<"stockLevels"> }[],
) {
  const count = await getOwnedCount(ctx, id, ownerId);
  if (count.status === "completed") bad("This count is already completed");
  if (count.type === "full") {
    const original = new Set(count.lines.map((l) => l.stockLevelId));
    // Removing is allowed so an item that stopped tracking stock can be dropped
    if (input.some((l) => !original.has(l.stockLevelId))) bad("Items can't be added to a full count");
  }
  return count;
}

async function nextNumber(ctx: MutationCtx, ownerId: Id<"users">): Promise<number> {
  const counter = await ctx.db
    .query("inventoryCountCounters")
    .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
    .unique();
  const next = (counter?.lastNumber ?? 0) + 1;
  if (counter) await ctx.db.patch("inventoryCountCounters", counter._id, { lastNumber: next });
  else await ctx.db.insert("inventoryCountCounters", { ownerId, lastNumber: next });
  return next;
}

function checkNotes(notes: string): string {
  const trimmed = notes.trim();
  if (trimmed.length > MAX_COUNT_NOTES) bad(`Notes can be up to ${MAX_COUNT_NOTES} characters`);
  return trimmed;
}

/** Builds count lines from the picked stock levels, keeping counts already entered. */
async function buildLines(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  input: { stockLevelId: Id<"stockLevels">; counted: number | null }[],
): Promise<CountLine[]> {
  if (input.length === 0) bad("Add at least one item to count");
  if (input.length > MAX_COUNT_LINES) bad(`Up to ${MAX_COUNT_LINES} items per count`);
  if (new Set(input.map((l) => l.stockLevelId)).size !== input.length) bad("Each item can only be listed once");
  const lines: CountLine[] = [];
  for (const l of input) {
    if (l.counted !== null) {
      const error = stockQtyError(l.counted);
      if (error) bad(error === "Stock can't be negative" ? "Counted stock can't be negative" : error);
    }
    const level = await ctx.db.get("stockLevels", l.stockLevelId);
    if (!level || level.ownerId !== ownerId) {
      throw new ConvexError({ code: "NOT_FOUND", message: "An item no longer tracks stock. Remove it and try again." });
    }
    lines.push({
      stockLevelId: level._id,
      itemId: level.itemId,
      itemName: level.itemName,
      variantName: level.variantName,
      counted: l.counted,
      expected: null,
      costCents: null,
    });
  }
  return lines;
}

export const list = query({
  args: { paginationOpts: paginationOptsValidator, status: v.optional(inventoryCountStatus) },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return { page: [], isDone: true, continueCursor: "" };
    const { status } = args;
    const base = status
      ? ctx.db
          .query("inventoryCounts")
          .withIndex("by_owner_and_status_and_number", (q) => q.eq("ownerId", user._id).eq("status", status))
      : ctx.db.query("inventoryCounts").withIndex("by_owner_and_number", (q) => q.eq("ownerId", user._id));
    const result = await base.order("desc").paginate(args.paginationOpts);
    // The list only needs a summary, not up to 1000 lines per row
    return {
      ...result,
      page: result.page.map(({ lines, ...c }) => ({
        ...c,
        itemCount: lines.length,
        countedCount: lines.filter((l) => l.counted !== null).length,
      })),
    };
  },
});

/** One count. Open counts show live expected stock; completed ones show it as it was. Null for a bad or foreign id. */
export const get = query({
  args: { id: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const id = ctx.db.normalizeId("inventoryCounts", args.id);
    if (!user || !id) return null;
    const count = await ctx.db.get("inventoryCounts", id);
    if (!count || count.ownerId !== user._id) return null;
    if (count.status === "completed") return count;
    const levels = await Promise.all(count.lines.map((l) => ctx.db.get("stockLevels", l.stockLevelId)));
    return {
      ...count,
      lines: count.lines.map((l, i) => ({
        ...l,
        expected: levels[i]?.inStock ?? null,
        costCents: levels[i]?.lastCostCents ?? 0,
      })),
    };
  },
});

export const create = mutation({
  args: {
    type: inventoryCountType,
    notes: v.string(),
    // Ignored for a full count, which takes every tracked item
    stockLevelIds: v.array(v.id("stockLevels")),
  },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const notes = checkNotes(args.notes);
    let ids = args.stockLevelIds;
    if (args.type === "full") {
      const levels = await ctx.db
        .query("stockLevels")
        .withIndex("by_owner_and_itemName", (q) => q.eq("ownerId", user._id))
        .take(MAX_COUNT_LINES + 1);
      if (levels.length > MAX_COUNT_LINES) bad(`A full count can cover up to ${MAX_COUNT_LINES} items. Use partial counts instead.`);
      if (levels.length === 0) bad("No items track stock yet. Turn on \"Track stock\" for your items first.");
      ids = levels.map((l) => l._id);
    }
    const lines = await buildLines(ctx, user._id, ids.map((stockLevelId) => ({ stockLevelId, counted: null })));
    return await ctx.db.insert("inventoryCounts", {
      ownerId: user._id,
      number: await nextNumber(ctx, user._id),
      type: args.type,
      status: "pending",
      notes,
      lines,
      createdAt: new Date().toISOString(),
      completedAt: null,
    });
  },
});

/** Saves counted numbers (and, for partial counts, the item list) without touching stock. */
export const save = mutation({
  args: { id: v.id("inventoryCounts"), notes: v.string(), lines: v.array(lineInput) },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const count = await getOpenCount(ctx, args.id, user._id, args.lines);
    const lines = await buildLines(ctx, user._id, args.lines);
    await ctx.db.patch("inventoryCounts", count._id, { notes: checkNotes(args.notes), lines, status: statusAfterSave(lines) });
    return null;
  },
});

/** Sets stock to the counted numbers. Uncounted items keep their stock. */
export const complete = mutation({
  args: { id: v.id("inventoryCounts"), notes: v.string(), lines: v.array(lineInput) },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "items");
    const count = await getOpenCount(ctx, args.id, user._id, args.lines);
    const lines = await buildLines(ctx, user._id, args.lines);
    if (lines.every((l) => l.counted === null)) bad("Enter the counted stock for at least one item");

    const done: CountLine[] = [];
    const log: AdjustmentLine[] = [];
    for (const line of lines) {
      const level = await ctx.db.get("stockLevels", line.stockLevelId);
      // buildLines already checked ownership
      if (!level) continue;
      done.push({ ...line, expected: level.inStock, costCents: level.lastCostCents ?? 0 });
      if (line.counted === null || line.counted === level.inStock) continue;
      await ctx.db.patch("stockLevels", level._id, {
        inStock: line.counted,
        isLow: isLowStock(line.counted, level.lowStock),
      });
      log.push({
        itemId: level.itemId,
        itemName: level.itemName,
        variantName: level.variantName,
        change: line.counted - level.inStock,
        inStockAfter: line.counted,
      });
    }
    const now = new Date().toISOString();
    const note = `Inventory count ${formatCountNumber(count.number)}`;
    // History entries hold up to MAX_ADJUSTMENT_LINES lines each
    for (let i = 0; i < log.length; i += MAX_ADJUSTMENT_LINES) {
      await ctx.db.insert("stockAdjustments", {
        ownerId: user._id,
        createdAt: now,
        reason: "recount",
        note,
        lines: log.slice(i, i + MAX_ADJUSTMENT_LINES),
        employeeName: staff.name,
      });
    }
    await ctx.db.patch("inventoryCounts", count._id, {
      notes: checkNotes(args.notes),
      lines: done,
      status: "completed",
      completedAt: now,
    });
    return null;
  },
});

/** Completed counts stay as a record; open ones can be deleted. */
export const remove = mutation({
  args: { id: v.id("inventoryCounts") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const count = await getOwnedCount(ctx, args.id, user._id);
    if (count.status === "completed") bad("Completed counts can't be deleted");
    await ctx.db.delete("inventoryCounts", count._id);
    return null;
  },
});
