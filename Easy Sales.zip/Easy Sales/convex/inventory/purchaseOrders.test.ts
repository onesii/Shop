import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";
import { poTotal, purchaseOrderError, statusAfterReceive, suggestedQty } from "../lib/purchaseOrders";

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  const soda = await asUser.mutation(api.catalog.items.create, {
    name: "Soda",
    categoryId: null,
    priceCents: 5000,
    color: "red",
    variants: [],
    stock: [{ variantName: null, inStock: 2, lowStock: 5 }],
  });
  const [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
  const supplierId = await asUser.mutation(api.inventory.suppliers.create, {
    name: "Jelly Traders",
    contact: "",
    email: "",
    phone: "",
    address: "",
    note: "",
  });
  const base = {
    supplierId,
    orderedOn: "2026-11-20",
    expectedOn: null,
    notes: "",
    additionalCosts: [{ name: "Delivery", amountCents: 20000 }],
    lines: [{ stockLevelId: level._id, quantity: 10, costCents: 3000 }],
  };
  return { t, asUser, soda, level, supplierId, base };
}

describe("purchase order rules", () => {
  it("totals lines and additional costs in cents", () => {
    expect(poTotal([{ quantity: 3, costCents: 1250 }, { quantity: 2, costCents: 100 }], [{ amountCents: 500 }])).toBe(4450);
  });

  it("moves from pending to partial to closed", () => {
    expect(statusAfterReceive([{ quantity: 5, receivedQty: 0 }])).toBe("pending");
    expect(statusAfterReceive([{ quantity: 5, receivedQty: 2 }, { quantity: 1, receivedQty: 1 }])).toBe("partial");
    expect(statusAfterReceive([{ quantity: 5, receivedQty: 5 }, { quantity: 1, receivedQty: 1 }])).toBe("closed");
  });

  it("rejects bad dates, quantities and costs", () => {
    const ok = { orderedOn: "2026-11-20", expectedOn: null, notes: "", lines: [{ quantity: 1, costCents: 0 }], additionalCosts: [] };
    expect(purchaseOrderError(ok)).toBeNull();
    expect(purchaseOrderError({ ...ok, orderedOn: "2026-02-30" })).toMatch(/date/);
    expect(purchaseOrderError({ ...ok, expectedOn: "2026-11-19" })).toMatch(/before/);
    expect(purchaseOrderError({ ...ok, lines: [] })).toMatch(/at least one/);
    expect(purchaseOrderError({ ...ok, lines: [{ quantity: 1.5, costCents: 0 }] })).toMatch(/whole/);
    expect(purchaseOrderError({ ...ok, lines: [{ quantity: 1, costCents: -1 }] })).toMatch(/cost/);
    expect(purchaseOrderError({ ...ok, additionalCosts: [{ name: " ", amountCents: 1 }] })).toMatch(/blank/);
  });

  it("suggests enough to reach twice the low stock level", () => {
    expect(suggestedQty(2, 5)).toBe(8);
    expect(suggestedQty(-3, null)).toBe(4);
    expect(suggestedQty(20, 5)).toBe(1);
  });
});

describe("purchase orders", () => {
  it("numbers orders, computes the total on the server and lists them", async () => {
    const { asUser, base } = await setup();
    const id = await asUser.mutation(api.inventory.purchaseOrders.save, { ...base, send: true });
    const po = await asUser.query(api.inventory.purchaseOrders.get, { id });
    expect(po?.number).toBe(1);
    expect(po?.status).toBe("pending");
    expect(po?.totalCents).toBe(10 * 3000 + 20000);
    const incoming = await asUser.query(api.inventory.purchaseOrders.incoming, {});
    expect(Object.values(incoming)).toEqual([10]);
  });

  it("receives part, then the rest, adding stock and closing the order", async () => {
    const { asUser, soda, base } = await setup();
    const id = await asUser.mutation(api.inventory.purchaseOrders.save, { ...base, send: true });
    await asUser.mutation(api.inventory.purchaseOrders.receive, { id, quantities: [4] });
    let [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    expect(level.inStock).toBe(6);
    expect(level.lastCostCents).toBe(3000);
    expect((await asUser.query(api.inventory.purchaseOrders.get, { id }))?.status).toBe("partial");

    await expect(asUser.mutation(api.inventory.purchaseOrders.receive, { id, quantities: [7] })).rejects.toThrow(/Only 6/);
    await asUser.mutation(api.inventory.purchaseOrders.receive, { id, quantities: [6] });
    [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    expect(level.inStock).toBe(12);
    expect(level.isLow).toBe(false);
    expect((await asUser.query(api.inventory.purchaseOrders.get, { id }))?.status).toBe("closed");
    await expect(asUser.mutation(api.inventory.purchaseOrders.remove, { id })).rejects.toThrow(/received/);
  });

  it("can't receive a draft, and other stores can't see or change orders", async () => {
    const { t, asUser, base } = await setup();
    const id = await asUser.mutation(api.inventory.purchaseOrders.save, { ...base, send: false });
    await expect(asUser.mutation(api.inventory.purchaseOrders.receive, { id, quantities: [1] })).rejects.toThrow(/Create/);

    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    expect(await other.query(api.inventory.purchaseOrders.get, { id })).toBeNull();
    await expect(other.mutation(api.inventory.purchaseOrders.remove, { id })).rejects.toThrow(/not found/);
    await expect(
      other.mutation(api.inventory.purchaseOrders.save, { ...base, send: true }),
    ).rejects.toThrow(/not found/i);
  });
});
