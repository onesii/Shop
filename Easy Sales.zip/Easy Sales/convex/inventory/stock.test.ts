import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
  const soda = await asUser.mutation(api.catalog.items.create, {
    name: "Soda",
    categoryId: null,
    priceCents: 5000,
    color: "red",
    variants: [],
    stock: [{ variantName: null, inStock: 10, lowStock: 3 }],
  });
  return { t, asUser, soda };
}

const sodaLine = (itemId: Awaited<ReturnType<typeof setup>>["soda"], quantity: number) => ({
  itemId,
  name: "Soda",
  variantName: null,
  priceCents: 5000,
  quantity,
});

describe("stock", () => {
  it("goes down on sales, back up on refunds, and flags low stock", async () => {
    const { asUser, soda } = await setup();
    // Same item on two lines is totalled
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [sodaLine(soda, 4), { ...sodaLine(soda, 3), priceCents: 4000 }],
      paymentMethod: "card",
      tenderedCents: 0,
    });
    let [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    expect(level.inStock).toBe(3);
    expect(level.isLow).toBe(true);
    expect(await asUser.query(api.inventory.stock.lowCount, {})).toBe(1);

    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [2, 0] });
    [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    expect(level.inStock).toBe(5);
    expect(level.isLow).toBe(false);
  });

  it("applies receive, loss and recount adjustments and logs them", async () => {
    const { asUser, soda } = await setup();
    const [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    const adjust = (reason: "receive" | "loss" | "recount", quantity: number) =>
      asUser.mutation(api.inventory.stock.adjust, { reason, lines: [{ stockLevelId: level._id, quantity }] });

    await adjust("receive", 5);
    await adjust("loss", 2);
    let [after] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    expect(after.inStock).toBe(13);
    await adjust("recount", 0);
    [after] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    expect(after.inStock).toBe(0);

    const history = await asUser.query(api.inventory.stock.history, {
      paginationOpts: { numItems: 10, cursor: null },
    });
    expect(history.page.map((h) => h.reason)).toEqual(["recount", "loss", "receive", "edit"]);
    expect(history.page[0].lines[0].change).toBe(-13);
  });

  it("rejects bad quantities and other stores' stock", async () => {
    const { t, asUser, soda } = await setup();
    const [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    await expect(
      asUser.mutation(api.inventory.stock.adjust, { reason: "receive", lines: [{ stockLevelId: level._id, quantity: 1.5 }] }),
    ).rejects.toThrow();
    await expect(
      asUser.mutation(api.inventory.stock.adjust, { reason: "loss", lines: [{ stockLevelId: level._id, quantity: -1 }] }),
    ).rejects.toThrow();

    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    await expect(
      other.mutation(api.inventory.stock.adjust, { reason: "loss", lines: [{ stockLevelId: level._id, quantity: 1 }] }),
    ).rejects.toThrow();
    // Selling someone else's item id must not touch their stock
    await other.mutation(api.sales.shifts.open, { startingCashCents: 0 });
    await other.mutation(api.sales.receipts.charge, { lines: [sodaLine(soda, 5)], paymentMethod: "card", tenderedCents: 0 });
    const [still] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    expect(still.inStock).toBe(10);
  });

  it("tracks per variant and stops tracking when turned off", async () => {
    const { asUser } = await setup();
    const fields = { name: "Juice", categoryId: null, priceCents: null, color: "orange" as const };
    const variants = [
      { name: "Small", priceCents: 100 },
      { name: "Large", priceCents: 200 },
    ];
    const juice = await asUser.mutation(api.catalog.items.create, {
      ...fields,
      variants,
      stock: [
        { variantName: "Small", inStock: 4, lowStock: null },
        { variantName: "Large", inStock: 0, lowStock: null },
      ],
    });
    const levels = await asUser.query(api.inventory.stock.forItem, { itemId: juice });
    expect(levels.map((l) => [l.variantName, l.inStock, l.isLow])).toEqual(
      expect.arrayContaining([
        ["Small", 4, false],
        ["Large", 0, true],
      ]),
    );
    // Editing without stock keeps it; null stops tracking
    await asUser.mutation(api.catalog.items.update, { id: juice, ...fields, name: "Fresh juice", variants });
    const renamed = await asUser.query(api.inventory.stock.forItem, { itemId: juice });
    expect(renamed.every((l) => l.itemName === "Fresh juice")).toBe(true);
    await asUser.mutation(api.catalog.items.update, { id: juice, ...fields, variants, stock: null });
    expect(await asUser.query(api.inventory.stock.forItem, { itemId: juice })).toEqual([]);
  });

  it("logs sales and refunds in history and filters by reason and date", async () => {
    const { asUser, soda } = await setup();
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [sodaLine(soda, 2), { ...sodaLine(soda, 1), priceCents: 4000 }, { ...sodaLine(soda, 1), itemId: null, name: "Custom" }],
      paymentMethod: "card",
      tenderedCents: 0,
    });
    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1, 0, 0] });
    const page = (args: { reason?: "sale" | "refund"; startIso?: string; endIso?: string }) =>
      asUser.query(api.inventory.stock.history, { ...args, paginationOpts: { numItems: 10, cursor: null } });

    const all = await page({});
    expect(all.page.map((h) => h.reason)).toEqual(["refund", "sale", "edit"]);
    // Same item on two lines is one history line; the untracked line is skipped
    expect(all.page[1].lines).toEqual([expect.objectContaining({ change: -3, inStockAfter: 7 })]);
    expect(all.page[1].note).toBe(`Receipt #${sale.number}`);
    expect(all.page[1].employeeName).toBeTruthy();
    expect(all.page[0].lines[0]).toEqual(expect.objectContaining({ change: 1, inStockAfter: 8 }));

    expect((await page({ reason: "sale" })).page).toHaveLength(1);
    expect((await page({ startIso: "2000-01-01T00:00:00.000Z", endIso: "2000-01-02T00:00:00.000Z" })).page).toEqual([]);
  });

  it("values stock at cost and retail", async () => {
    const { asUser, soda } = await setup();
    const [level] = await asUser.query(api.inventory.stock.forItem, { itemId: soda });
    const before = await asUser.query(api.inventory.stock.valuation, {});
    expect(before?.rows[0]).toEqual(expect.objectContaining({ inStock: 10, costCents: null, priceCents: 5000 }));
    await asUser.mutation(api.inventory.stock.adjust, { reason: "receive", lines: [{ stockLevelId: level._id, quantity: 1 }] });
    expect((await asUser.query(api.inventory.stock.valuation, {}))?.rows[0].inStock).toBe(11);
  });
});
