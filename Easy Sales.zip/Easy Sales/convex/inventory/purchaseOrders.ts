import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { additionalCostValidator, purchaseOrderStatus } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { isLowStock, MAX_STOCK_QTY } from "../lib/stock";
import {
  formatPoNumber,
  MAX_PO_LINES,
  poTotal,
  purchaseOrderError,
  statusAfterReceive,
} from "../lib/purchaseOrders";

type PoLine = Doc<"purchaseOrders">["lines"][number];
type AdjustmentLine = Doc<"stockAdjustments">["lines"][number];

// Open orders scanned to show the "Incoming" column
const OPEN_ORDERS_LIMIT = 200;

function bad(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

async function getOwnedPo(ctx: MutationCtx, id: Id<"purchaseOrders">, ownerId: Id<"users">) {
  const po = await ctx.db.get("purchaseOrders", id);
  if (!po || po.ownerId !== ownerId) throw new ConvexError({ code: "NOT_FOUND", message: "Purchase order not found" });
  return po;
}

async function nextNumber(ctx: MutationCtx, ownerId: Id<"users">): Promise<number> {
  const counter = await ctx.db
    .query("purchaseOrderCounters")
    .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
    .unique();
  const next = (counter?.lastNumber ?? 0) + 1;
  if (counter) await ctx.db.patch("purchaseOrderCounters", counter._id, { lastNumber: next });
  else await ctx.db.insert("purchaseOrderCounters", { ownerId, lastNumber: next });
  return next;
}

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    status: v.optional(purchaseOrderStatus),
    supplierId: v.optional(v.id("suppliers")),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return { page: [], isDone: true, continueCursor: "" };
    const { status, supplierId } = args;
    if (supplierId) {
      const q = ctx.db
        .query("purchaseOrders")
        .withIndex("by_owner_and_supplierId_and_number", (q) => q.eq("ownerId", user._id).eq("supplierId", supplierId))
        .order("desc");
      return await (status ? q.filter((f) => f.eq(f.field("status"), status)) : q).paginate(args.paginationOpts);
    }
    if (status) {
      return await ctx.db
        .query("purchaseOrders")
        .withIndex("by_owner_and_status_and_number", (q) => q.eq("ownerId", user._id).eq("status", status))
        .order("desc")
        .paginate(args.paginationOpts);
    }
    return await ctx.db
      .query("purchaseOrders")
      .withIndex("by_owner_and_number", (q) => q.eq("ownerId", user._id))
      .order("desc")
      .paginate(args.paginationOpts);
  },
});

/** One purchase order with each line's current stock. Null for a bad or foreign id. */
export const get = query({
  args: { id: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const id = ctx.db.normalizeId("purchaseOrders", args.id);
    if (!user || !id) return null;
    const po = await ctx.db.get("purchaseOrders", id);
    if (!po || po.ownerId !== user._id) return null;
    const levels = await Promise.all(po.lines.map((l) => ctx.db.get("stockLevels", l.stockLevelId)));
    return {
      ...po,
      lines: po.lines.map((l, i) => ({ ...l, inStock: levels[i]?.inStock ?? null, lowStock: levels[i]?.lowStock ?? null })),
    };
  },
});

/** Units ordered but not yet received, per stock level, across open orders. */
export const incoming = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return {};
    const out: Record<string, number> = {};
    for (const status of ["pending", "partial"] as const) {
      const orders = await ctx.db
        .query("purchaseOrders")
        .withIndex("by_owner_and_status_and_number", (q) => q.eq("ownerId", user._id).eq("status", status))
        .order("desc")
        .take(OPEN_ORDERS_LIMIT);
      for (const po of orders) {
        for (const l of po.lines) {
          const left = Math.max(0, l.quantity - l.receivedQty);
          if (left > 0) out[l.stockLevelId] = (out[l.stockLevelId] ?? 0) + left;
        }
      }
    }
    return out;
  },
});

const saveArgs = {
  id: v.optional(v.id("purchaseOrders")),
  supplierId: v.id("suppliers"),
  orderedOn: v.string(),
  expectedOn: v.union(v.string(), v.null()),
  notes: v.string(),
  lines: v.array(v.object({ stockLevelId: v.id("stockLevels"), quantity: v.number(), costCents: v.number() })),
  additionalCosts: v.array(additionalCostValidator),
  /** false = Save as draft, true = Create (ordered, waiting to be received) */
  send: v.boolean(),
};

/** Creates a purchase order, or edits one that hasn't received anything yet. */
export const save = mutation({
  args: saveArgs,
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const notes = args.notes.trim();
    const additionalCosts = args.additionalCosts.map((c) => ({ name: c.name.trim(), amountCents: c.amountCents }));
    const error = purchaseOrderError({ ...args, notes, additionalCosts });
    if (error) bad(error);
    if (new Set(args.lines.map((l) => l.stockLevelId)).size !== args.lines.length) {
      bad("Each item can only be listed once");
    }
    const supplier = await ctx.db.get("suppliers", args.supplierId);
    if (!supplier || supplier.ownerId !== user._id) throw new ConvexError({ code: "NOT_FOUND", message: "Supplier not found" });

    const lines: PoLine[] = [];
    for (const l of args.lines) {
      const level = await ctx.db.get("stockLevels", l.stockLevelId);
      if (!level || level.ownerId !== user._id) {
        throw new ConvexError({ code: "NOT_FOUND", message: "An item no longer tracks stock. Remove it and try again." });
      }
      lines.push({
        stockLevelId: level._id,
        itemId: level.itemId,
        itemName: level.itemName,
        variantName: level.variantName,
        quantity: l.quantity,
        receivedQty: 0,
        costCents: l.costCents,
      });
    }
    const fields = {
      supplierId: supplier._id,
      supplierName: supplier.name,
      status: args.send ? ("pending" as const) : ("draft" as const),
      orderedOn: args.orderedOn,
      expectedOn: args.expectedOn,
      notes,
      lines,
      additionalCosts,
      totalCents: poTotal(lines, additionalCosts),
      orderedQty: lines.reduce((n, l) => n + l.quantity, 0),
      receivedQty: 0,
    };
    if (args.id) {
      const po = await getOwnedPo(ctx, args.id, user._id);
      if (po.receivedQty > 0 || po.status === "closed") bad("Items were already received, so this order can't be edited");
      // An ordered PO can't go back to draft
      await ctx.db.patch("purchaseOrders", po._id, { ...fields, status: po.status === "pending" ? "pending" : fields.status });
      return po._id;
    }
    return await ctx.db.insert("purchaseOrders", {
      ownerId: user._id,
      number: await nextNumber(ctx, user._id),
      createdAt: new Date().toISOString(),
      ...fields,
    });
  },
});

/** Adds received units to stock. Quantities are per line, in order. */
export const receive = mutation({
  args: { id: v.id("purchaseOrders"), quantities: v.array(v.number()) },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "items");
    const po = await getOwnedPo(ctx, args.id, user._id);
    if (po.status === "draft") bad("Create the purchase order before receiving items");
    if (po.status === "closed") bad("This purchase order is already fully received");
    if (args.quantities.length !== po.lines.length || args.quantities.length > MAX_PO_LINES) bad("Quantities don't match the order");

    const lines: PoLine[] = [];
    const log: AdjustmentLine[] = [];
    for (const [i, line] of po.lines.entries()) {
      const qty = args.quantities[i];
      if (!Number.isInteger(qty) || qty < 0 || qty > MAX_STOCK_QTY) bad("Enter whole numbers to receive");
      if (qty > line.quantity - line.receivedQty) bad(`Only ${line.quantity - line.receivedQty} more ${line.itemName} to receive`);
      lines.push({ ...line, receivedQty: line.receivedQty + qty });
      if (qty === 0) continue;
      const level = await ctx.db.get("stockLevels", line.stockLevelId);
      // An item that stopped tracking stock is still marked received, but has no count to add to
      if (!level || level.ownerId !== user._id) continue;
      const inStock = level.inStock + qty;
      await ctx.db.patch("stockLevels", level._id, {
        inStock,
        isLow: isLowStock(inStock, level.lowStock),
        lastCostCents: line.costCents,
      });
      log.push({ itemId: level.itemId, itemName: level.itemName, variantName: level.variantName, change: qty, inStockAfter: inStock });
    }
    if (log.length === 0) bad("Enter how many items arrived");
    await ctx.db.insert("stockAdjustments", {
      ownerId: user._id,
      createdAt: new Date().toISOString(),
      reason: "receive",
      note: `Purchase order ${formatPoNumber(po.number)}`,
      lines: log,
      employeeName: staff.name,
    });
    await ctx.db.patch("purchaseOrders", po._id, {
      lines,
      status: statusAfterReceive(lines),
      receivedQty: lines.reduce((n, l) => n + l.receivedQty, 0),
    });
    return null;
  },
});

/** Only orders that haven't received anything can be deleted. */
export const remove = mutation({
  args: { id: v.id("purchaseOrders") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const po = await getOwnedPo(ctx, args.id, user._id);
    if (po.receivedQty > 0) bad("Items were already received, so this order can't be deleted");
    await ctx.db.delete("purchaseOrders", po._id);
    return null;
  },
});
