import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import type { Infer } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { stockInputValidator, stockReason } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { retailPrice } from "../lib/valuation";
import { roundQty } from "../lib/quantity";
import {
  isLowStock,
  MAX_ADJUSTMENT_LINES,
  stockAfter,
  stockQtyError,
  type StockReason,
} from "../lib/stock";

export type StockInput = Infer<typeof stockInputValidator>;
type AdjustmentLine = Doc<"stockAdjustments">["lines"][number];

// Upper bound for the non-paginated pickers (adjust dialog, item list badges)
const ALL_LIMIT = 1000;
const LOW_COUNT_LIMIT = 100;

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

function checkQty(qty: number, opts?: { allowNegative?: boolean }): void {
  const error = stockQtyError(qty, opts);
  if (error) badRequest(error);
}

async function levelsForItem(ctx: MutationCtx, itemId: Id<"items">): Promise<Doc<"stockLevels">[]> {
  // One row per variant, bounded by MAX_VARIANTS
  return await ctx.db
    .query("stockLevels")
    .withIndex("by_item_and_variant", (q) => q.eq("itemId", itemId))
    .take(50);
}

async function recordAdjustment(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  reason: StockReason,
  note: string | null,
  lines: AdjustmentLine[],
  employeeName: string,
): Promise<void> {
  if (lines.length === 0) return;
  await ctx.db.insert("stockAdjustments", {
    ownerId,
    createdAt: new Date().toISOString(),
    reason,
    note,
    lines,
    employeeName,
  });
}

/**
 * Applies the stock settings from the item form.
 * `stock` null turns tracking off; an array sets one level per variant (or one for the item).
 */
export async function syncItemStock(
  ctx: MutationCtx,
  item: Doc<"items">,
  stock: StockInput[] | null,
  employeeName: string,
): Promise<void> {
  const existing = await levelsForItem(ctx, item._id);
  if (stock === null) {
    for (const level of existing) await ctx.db.delete("stockLevels", level._id);
    return;
  }
  // Set: two variants with the same name share one stock count
  const names: (string | null)[] =
    item.variants.length > 0 ? [...new Set(item.variants.map((x) => x.name))] : [null];
  const byName = new Map(stock.map((s) => [s.variantName?.trim() ?? null, s]));
  if (byName.size !== stock.length) badRequest("Each variant can only have one stock count");
  for (const key of byName.keys()) {
    if (!names.includes(key)) badRequest("Stock was entered for a variant that doesn't exist");
  }

  const lines: AdjustmentLine[] = [];
  for (const variantName of names) {
    const input = byName.get(variantName);
    const inStock = input?.inStock ?? 0;
    const lowStock = input?.lowStock ?? null;
    checkQty(inStock, { allowNegative: true });
    if (lowStock !== null) checkQty(lowStock);
    const level = existing.find((l) => l.variantName === variantName);
    const fields = {
      itemName: item.name,
      inStock,
      lowStock,
      isLow: isLowStock(inStock, lowStock),
    };
    const before = level?.inStock ?? 0;
    if (level) await ctx.db.patch("stockLevels", level._id, fields);
    else await ctx.db.insert("stockLevels", { ownerId: item.ownerId, itemId: item._id, variantName, ...fields });
    if (inStock !== before || !level) {
      lines.push({ itemId: item._id, itemName: item.name, variantName, change: inStock - before, inStockAfter: inStock });
    }
  }
  // Variants that were removed or renamed no longer have stock
  for (const level of existing) {
    if (!names.includes(level.variantName)) await ctx.db.delete("stockLevels", level._id);
  }
  await recordAdjustment(ctx, item.ownerId, "edit", null, lines, employeeName);
}

/** Keeps the copied item name in sync after a rename (tracking unchanged). */
export async function renameItemStock(ctx: MutationCtx, item: Doc<"items">): Promise<void> {
  for (const level of await levelsForItem(ctx, item._id)) {
    if (level.itemName !== item.name) await ctx.db.patch("stockLevels", level._id, { itemName: item.name });
  }
}

export async function deleteItemStock(ctx: MutationCtx, itemId: Id<"items">): Promise<void> {
  for (const level of await levelsForItem(ctx, itemId)) await ctx.db.delete("stockLevels", level._id);
}

type SoldLine = { itemId: Id<"items"> | null; variantName: string | null; quantity: number };

/**
 * Sales take stock out, refunds put it back. Untracked items are skipped.
 * Each receipt that touches tracked stock gets one inventory history entry.
 */
export async function applySaleStock(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  lines: SoldLine[],
  kind: "sale" | "refund",
  meta: { receiptNumber: string; employeeName: string },
): Promise<void> {
  const sign = kind === "sale" ? -1 : 1;
  // The same item can appear on several lines (e.g. different prices), so total them first
  const totals = new Map<string, { itemId: Id<"items">; variantName: string | null; quantity: number }>();
  for (const l of lines) {
    if (!l.itemId) continue;
    const key = `${l.itemId}|${l.variantName ?? ""}`;
    const cur = totals.get(key);
    if (cur) cur.quantity = roundQty(cur.quantity + l.quantity);
    else totals.set(key, { itemId: l.itemId, variantName: l.variantName, quantity: l.quantity });
  }
  const log: AdjustmentLine[] = [];
  for (const t of totals.values()) {
    const level = await ctx.db
      .query("stockLevels")
      .withIndex("by_item_and_variant", (q) => q.eq("itemId", t.itemId).eq("variantName", t.variantName))
      .unique();
    // Item ids come from the client, so never touch another store's stock
    if (!level || level.ownerId !== ownerId) continue;
    const inStock = roundQty(level.inStock + sign * t.quantity);
    await ctx.db.patch("stockLevels", level._id, { inStock, isLow: isLowStock(inStock, level.lowStock) });
    log.push({
      itemId: level.itemId,
      itemName: level.itemName,
      variantName: level.variantName,
      change: sign * t.quantity,
      inStockAfter: inStock,
    });
  }
  await recordAdjustment(ctx, ownerId, kind, `Receipt #${meta.receiptNumber}`, log, meta.employeeName);
}

/** Stock levels of one item, for the item form. */
export const forItem = query({
  args: { itemId: v.id("items") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const levels = await ctx.db
      .query("stockLevels")
      .withIndex("by_item_and_variant", (q) => q.eq("itemId", args.itemId))
      .take(50);
    return levels.filter((l) => l.ownerId === user._id);
  },
});

/** Stock levels page by page, A to Z, optionally only items that are low or out. */
export const list = query({
  args: { paginationOpts: paginationOptsValidator, lowOnly: v.boolean() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return { page: [], isDone: true, continueCursor: "" };
    const base = args.lowOnly
      ? ctx.db
          .query("stockLevels")
          .withIndex("by_owner_and_isLow_and_itemName", (q) => q.eq("ownerId", user._id).eq("isLow", true))
      : ctx.db.query("stockLevels").withIndex("by_owner_and_itemName", (q) => q.eq("ownerId", user._id));
    return await base.paginate(args.paginationOpts);
  },
});

/** Every tracked level (bounded), for the adjust dialog and the item list. */
export const listAll = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("stockLevels")
      .withIndex("by_owner_and_itemName", (q) => q.eq("ownerId", user._id))
      .take(ALL_LIMIT);
  },
});

/** Number of low or out of stock levels, capped for the alert badge ("100+"). */
export const lowCount = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return 0;
    const rows = await ctx.db
      .query("stockLevels")
      .withIndex("by_owner_and_isLow_and_itemName", (q) => q.eq("ownerId", user._id).eq("isLow", true))
      .take(LOW_COUNT_LIMIT);
    return rows.length;
  },
});

export const adjust = mutation({
  args: {
    reason: v.union(v.literal("receive"), v.literal("loss"), v.literal("damage"), v.literal("recount")),
    note: v.optional(v.string()),
    lines: v.array(v.object({ stockLevelId: v.id("stockLevels"), quantity: v.number() })),
  },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "items");
    if (args.lines.length === 0) badRequest("Add at least one item");
    if (args.lines.length > MAX_ADJUSTMENT_LINES) badRequest(`Up to ${MAX_ADJUSTMENT_LINES} items at a time`);
    if (new Set(args.lines.map((l) => l.stockLevelId)).size !== args.lines.length) {
      badRequest("Each item can only be listed once");
    }
    const note = args.note?.trim().slice(0, 500) || null;
    const out: AdjustmentLine[] = [];
    for (const line of args.lines) {
      checkQty(line.quantity);
      if (args.reason !== "recount" && line.quantity === 0) badRequest("Enter a quantity for every item");
      const level = await ctx.db.get("stockLevels", line.stockLevelId);
      if (!level || level.ownerId !== user._id) {
        throw new ConvexError({ code: "NOT_FOUND", message: "An item is no longer tracked. Remove it and try again." });
      }
      const inStock = stockAfter(args.reason, level.inStock, line.quantity);
      checkQty(inStock, { allowNegative: true });
      await ctx.db.patch("stockLevels", level._id, { inStock, isLow: isLowStock(inStock, level.lowStock) });
      out.push({
        itemId: level.itemId,
        itemName: level.itemName,
        variantName: level.variantName,
        change: inStock - level.inStock,
        inStockAfter: inStock,
      });
    }
    await recordAdjustment(ctx, user._id, args.reason, note, out, staff.name);
    return null;
  },
});

/** Stock changes, newest first, optionally limited to a reason and a time range [startIso, endIso). */
export const history = query({
  args: {
    paginationOpts: paginationOptsValidator,
    reason: v.optional(stockReason),
    startIso: v.optional(v.string()),
    endIso: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return { page: [], isDone: true, continueCursor: "" };
    const { reason, startIso, endIso } = args;
    const base = reason
      ? ctx.db.query("stockAdjustments").withIndex("by_owner_and_reason_and_createdAt", (q) => {
          const r = q.eq("ownerId", user._id).eq("reason", reason);
          const s = startIso ? r.gte("createdAt", startIso) : r;
          return endIso ? s.lt("createdAt", endIso) : s;
        })
      : ctx.db.query("stockAdjustments").withIndex("by_owner_and_createdAt", (q) => {
          const r = q.eq("ownerId", user._id);
          const s = startIso ? r.gte("createdAt", startIso) : r;
          return endIso ? s.lt("createdAt", endIso) : s;
        });
    return await base.order("desc").paginate(args.paginationOpts);
  },
});

/** Value of the stock on hand at cost and at retail price, per tracked item (bounded). */
export const valuation = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return null;
    const levels = await ctx.db
      .query("stockLevels")
      .withIndex("by_owner_and_itemName", (q) => q.eq("ownerId", user._id))
      .take(ALL_LIMIT + 1);
    // Variants share one item, so look each item up once
    const itemIds = [...new Set(levels.slice(0, ALL_LIMIT).map((l) => l.itemId))];
    const items = await Promise.all(itemIds.map((id) => ctx.db.get("items", id)));
    const byId = new Map(items.flatMap((i) => (i ? [[i._id, i] as const] : [])));
    const rows = levels.slice(0, ALL_LIMIT).map((level) => ({
      stockLevelId: level._id,
      itemName: level.itemName,
      variantName: level.variantName,
      inStock: level.inStock,
      costCents: level.lastCostCents ?? null,
      priceCents: retailPrice(byId.get(level.itemId), level.variantName),
    }));
    return { rows, truncated: levels.length > ALL_LIMIT };
  },
});
