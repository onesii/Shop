import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { MAX_SUPPLIERS } from "../lib/purchaseOrders";

const fields = {
  name: v.string(),
  contact: v.string(),
  email: v.string(),
  phone: v.string(),
  address: v.string(),
  note: v.string(),
};

type SupplierFields = { name: string; contact: string; email: string; phone: string; address: string; note: string };

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function bad(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

function clean(a: SupplierFields): SupplierFields {
  const out = {
    name: a.name.trim(),
    contact: a.contact.trim(),
    email: a.email.trim(),
    phone: a.phone.trim(),
    address: a.address.trim(),
    note: a.note.trim(),
  };
  if (!out.name) bad("Supplier name cannot be blank");
  if (out.name.length > 64) bad("Supplier name is too long");
  if (out.email && !EMAIL.test(out.email)) bad("Enter a valid email");
  if (out.contact.length > 64 || out.phone.length > 32 || out.email.length > 100) bad("A field is too long");
  if (out.address.length > 300 || out.note.length > 500) bad("A field is too long");
  return out;
}

async function getOwned(ctx: MutationCtx, id: Id<"suppliers">, ownerId: Id<"users">): Promise<Doc<"suppliers">> {
  const s = await ctx.db.get("suppliers", id);
  if (!s || s.ownerId !== ownerId) throw new ConvexError({ code: "NOT_FOUND", message: "Supplier not found" });
  return s;
}

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("suppliers")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_SUPPLIERS);
  },
});

export const create = mutation({
  args: fields,
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const existing = await ctx.db
      .query("suppliers")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_SUPPLIERS);
    if (existing.length >= MAX_SUPPLIERS) bad(`Up to ${MAX_SUPPLIERS} suppliers allowed`);
    return await ctx.db.insert("suppliers", { ownerId: user._id, ...clean(args) });
  },
});

export const update = mutation({
  args: { id: v.id("suppliers"), ...fields },
  handler: async (ctx, { id, ...rest }) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwned(ctx, id, user._id);
    await ctx.db.patch("suppliers", id, clean(rest));
    return null;
  },
});

/** Past purchase orders keep the supplier's name, so deleting is safe. */
export const remove = mutation({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwned(ctx, args.id, user._id);
    for (const status of ["pending", "partial"] as const) {
      const open = await ctx.db
        .query("purchaseOrders")
        .withIndex("by_owner_and_status_and_number", (q) => q.eq("ownerId", user._id).eq("status", status))
        .take(200);
      if (open.some((po) => po.supplierId === args.id)) {
        bad("This supplier has open purchase orders. Receive or delete them first.");
      }
    }
    await ctx.db.delete("suppliers", args.id);
    return null;
  },
});
