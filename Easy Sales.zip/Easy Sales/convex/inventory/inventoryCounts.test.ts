import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";
import { countTotals, formatCountNumber, statusAfterSave } from "../lib/inventoryCounts";

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  const makeItem = async (name: string, inStock: number) => {
    const itemId = await asUser.mutation(api.catalog.items.create, {
      name,
      categoryId: null,
      priceCents: 5000,
      color: "red",
      variants: [],
      stock: [{ variantName: null, inStock, lowStock: 5 }],
    });
    const [level] = await asUser.query(api.inventory.stock.forItem, { itemId });
    return { itemId, level };
  };
  const soda = await makeItem("Soda", 10);
  const chips = await makeItem("Chips", 4);
  return { t, asUser, soda, chips };
}

describe("inventory count rules", () => {
  it("formats numbers and tracks progress", () => {
    expect(formatCountNumber(1)).toBe("IC1001");
    expect(statusAfterSave([{ counted: null }])).toBe("pending");
    expect(statusAfterSave([{ counted: null }, { counted: 0 }])).toBe("in_progress");
  });

  it("totals differences and their cost, skipping uncounted items", () => {
    expect(
      countTotals([
        { counted: 8, expected: 10, costCents: 300 },
        { counted: 5, expected: 4, costCents: 100 },
        { counted: null, expected: 7, costCents: 999 },
      ]),
    ).toEqual({ counted: 2, differenceQty: -1, costDifferenceCents: -500 });
  });
});

describe("inventory counts", () => {
  it("saves progress without touching stock, then completes and sets stock", async () => {
    const { asUser, soda, chips } = await setup();
    const id = await asUser.mutation(api.inventory.inventoryCounts.create, {
      type: "partial",
      notes: "",
      stockLevelIds: [soda.level._id, chips.level._id],
    });
    await asUser.mutation(api.inventory.inventoryCounts.save, {
      id,
      notes: "",
      lines: [
        { stockLevelId: soda.level._id, counted: 7 },
        { stockLevelId: chips.level._id, counted: null },
      ],
    });
    let count = await asUser.query(api.inventory.inventoryCounts.get, { id });
    expect(count?.status).toBe("in_progress");
    expect(count?.lines[0].expected).toBe(10);
    expect((await asUser.query(api.inventory.stock.forItem, { itemId: soda.itemId }))[0].inStock).toBe(10);

    await asUser.mutation(api.inventory.inventoryCounts.complete, {
      id,
      notes: "Night count",
      lines: [
        { stockLevelId: soda.level._id, counted: 7 },
        { stockLevelId: chips.level._id, counted: null },
      ],
    });
    expect((await asUser.query(api.inventory.stock.forItem, { itemId: soda.itemId }))[0].inStock).toBe(7);
    // Not counted, so unchanged
    expect((await asUser.query(api.inventory.stock.forItem, { itemId: chips.itemId }))[0].inStock).toBe(4);

    count = await asUser.query(api.inventory.inventoryCounts.get, { id });
    expect(count?.status).toBe("completed");
    // Expected is frozen at completion, even if stock changes later
    expect(count?.lines[0].expected).toBe(10);

    const history = await asUser.query(api.inventory.stock.history, { paginationOpts: { numItems: 5, cursor: null } });
    expect(history.page[0].reason).toBe("recount");
    expect(history.page[0].note).toBe("Inventory count IC1001");
    expect(history.page[0].lines).toHaveLength(1);

    await expect(asUser.mutation(api.inventory.inventoryCounts.remove, { id })).rejects.toThrow(/Completed/);
    await expect(
      asUser.mutation(api.inventory.inventoryCounts.complete, { id, notes: "", lines: [{ stockLevelId: soda.level._id, counted: 1 }] }),
    ).rejects.toThrow(/already completed/);
  });

  it("full counts take every tracked item and can't add more", async () => {
    const { asUser, soda } = await setup();
    const id = await asUser.mutation(api.inventory.inventoryCounts.create, { type: "full", notes: "", stockLevelIds: [] });
    const count = await asUser.query(api.inventory.inventoryCounts.get, { id });
    expect(count?.lines.map((l) => l.itemName).sort()).toEqual(["Chips", "Soda"]);
    await expect(
      asUser.mutation(api.inventory.inventoryCounts.complete, {
        id,
        notes: "",
        lines: (count?.lines ?? []).map((l) => ({ stockLevelId: l.stockLevelId, counted: null })),
      }),
    ).rejects.toThrow(/at least one/);
    await expect(
      asUser.mutation(api.inventory.inventoryCounts.save, { id, notes: "", lines: [{ stockLevelId: soda.level._id, counted: -1 }] }),
    ).rejects.toThrow(/negative/);
  });

  it("other stores can't see or change counts", async () => {
    const { t, asUser, soda } = await setup();
    const id = await asUser.mutation(api.inventory.inventoryCounts.create, {
      type: "partial",
      notes: "",
      stockLevelIds: [soda.level._id],
    });
    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    expect(await other.query(api.inventory.inventoryCounts.get, { id })).toBeNull();
    await expect(other.mutation(api.inventory.inventoryCounts.remove, { id })).rejects.toThrow(/not found/);
    await expect(
      other.mutation(api.inventory.inventoryCounts.create, { type: "partial", notes: "", stockLevelIds: [soda.level._id] }),
    ).rejects.toThrow(/no longer tracks/);
  });
});
