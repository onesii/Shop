import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getAccount, getMembership, requireUser } from "./auth";
import { DEFAULT_RIGHTS, permissionsFor, type AccessRights, type Permission, type Role } from "./access";

type Ctx = QueryCtx | MutationCtx;

/** The person using the POS right now. employeeId is null only before the owner row exists. */
export type Staff = {
  employeeId: Id<"employees"> | null;
  name: string;
  role: Role;
  permissions: Permission[];
};

export async function findOwnerEmployee(ctx: Ctx, ownerId: Id<"users">): Promise<Doc<"employees"> | null> {
  return await ctx.db
    .query("employees")
    .withIndex("by_owner_and_role", (q) => q.eq("ownerId", ownerId).eq("role", "owner"))
    .first();
}

/** The owner always has an employee row, so timecards and reports can refer to them. */
export async function ensureOwnerEmployee(ctx: MutationCtx, user: Doc<"users">): Promise<Doc<"employees">> {
  const existing = await findOwnerEmployee(ctx, user._id);
  if (existing) return existing;
  const id = await ctx.db.insert("employees", {
    ownerId: user._id,
    name: user.name?.trim() || "Owner",
    email: user.email ?? null,
    phone: null,
    role: "owner",
    pinHash: null,
  });
  const created = await ctx.db.get("employees", id);
  if (!created) throw new ConvexError({ code: "NOT_FOUND", message: "Could not set up the owner" });
  return created;
}

/** True when the store has managers or cashiers, so the POS needs a PIN to unlock. */
export async function hasStaff(ctx: Ctx, ownerId: Id<"users">): Promise<boolean> {
  for (const role of ["manager", "cashier"] as const) {
    const one = await ctx.db
      .query("employees")
      .withIndex("by_owner_and_role", (q) => q.eq("ownerId", ownerId).eq("role", role))
      .first();
    if (one) return true;
  }
  return false;
}

export async function loadRights(ctx: Ctx, ownerId: Id<"users">): Promise<AccessRights> {
  const row = await ctx.db
    .query("accessRights")
    .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
    .unique();
  return row ? { manager: row.manager, cashier: row.cashier } : DEFAULT_RIGHTS;
}

export async function findSession(ctx: Ctx, ownerId: Id<"users">): Promise<Doc<"posSessions"> | null> {
  return await ctx.db
    .query("posSessions")
    .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
    .unique();
}

function toStaff(e: Doc<"employees">, rights: AccessRights): Staff {
  return { employeeId: e._id, name: e.name, role: e.role, permissions: permissionsFor(e.role, rights) };
}

/** Who is unlocked, or null when the POS is locked and waiting for a PIN. */
export async function currentStaff(ctx: Ctx, user: Doc<"users">): Promise<Staff | null> {
  const rights = await loadRights(ctx, user._id);
  // Staff signed in on their own account are always themselves, no PIN needed
  const account = await getAccount(ctx);
  const member = account && account._id !== user._id ? await getMembership(ctx, account) : null;
  if (member) return member.ownerId === user._id ? toStaff(member, rights) : null;
  if (!(await hasStaff(ctx, user._id))) {
    // Single-person store: the owner is always on the till
    const owner = await findOwnerEmployee(ctx, user._id);
    if (owner) return toStaff(owner, rights);
    return { employeeId: null, name: user.name ?? "Owner", role: "owner", permissions: permissionsFor("owner", rights) };
  }
  const session = await findSession(ctx, user._id);
  if (!session?.employeeId) return null;
  const employee = await ctx.db.get("employees", session.employeeId);
  if (!employee || employee.ownerId !== user._id) return null;
  return toStaff(employee, rights);
}

/** True when the signed-in account is an invited staff member rather than the store owner. */
export async function isMemberAccount(ctx: Ctx): Promise<boolean> {
  const account = await getAccount(ctx);
  return account ? (await getMembership(ctx, account)) !== null : false;
}

/** Signed-in account plus the unlocked employee, optionally checking a permission. */
export async function requireStaff(
  ctx: Ctx,
  permission?: Permission,
): Promise<{ user: Doc<"users">; staff: Staff }> {
  const user = await requireUser(ctx);
  const staff = await currentStaff(ctx, user);
  if (!staff) {
    throw new ConvexError({ code: "FORBIDDEN", message: "The POS is locked. Enter your PIN to continue." });
  }
  if (permission && !staff.permissions.includes(permission)) {
    throw new ConvexError({ code: "FORBIDDEN", message: "You don't have access to do this. Ask the owner." });
  }
  return { user, staff };
}

/** For queries: true when the unlocked employee has the permission. */
export async function staffCan(ctx: Ctx, user: Doc<"users">, permission: Permission): Promise<boolean> {
  const staff = await currentStaff(ctx, user);
  return staff?.permissions.includes(permission) ?? false;
}

/**
 * Employee stamp for receipts, shifts and report buckets. The owner is stored without an id,
 * which matches every record made before employees existed.
 */
export function employeeStamp(staff: Staff): { employeeId?: Id<"employees">; employeeName: string } {
  return staff.role === "owner" || !staff.employeeId
    ? { employeeName: staff.name }
    : { employeeId: staff.employeeId, employeeName: staff.name };
}

/**
 * Matcher for a report's employee filter. Records without an employee id belong to the owner.
 * Returns null when no filter is applied.
 */
export async function employeeMatcher(
  ctx: Ctx,
  ownerId: Id<"users">,
  employeeIds: (Id<"employees"> | "owner")[] | undefined,
): Promise<{ ids: (Id<"employees"> | undefined)[]; matches: (id: Id<"employees"> | undefined) => boolean } | null> {
  if (!employeeIds) return null;
  const owner = await findOwnerEmployee(ctx, ownerId);
  const ids = employeeIds.map((id) => (id === "owner" || (owner && id === owner._id) ? undefined : id));
  const set = new Set(ids);
  return { ids, matches: (id) => set.has(id) };
}
