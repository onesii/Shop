// Ticket line quantities, shared by the backend and the frontend.
// Quantities can have up to 3 decimals (e.g. 2.250 kg), like the original app.

export const MAX_LINE_QTY = 100_000;
export const MAX_LINE_COMMENT = 100;

/** Rounds to 3 decimals so repeated adding/subtracting never drifts (0.1 + 0.2). */
export function roundQty(qty: number): number {
  return Math.round(qty * 1000) / 1000;
}

export function isValidQuantity(qty: number): boolean {
  return Number.isFinite(qty) && qty > 0 && qty <= MAX_LINE_QTY && roundQty(qty) === qty;
}

/** Line amount in whole cents. */
export function lineTotalCents(priceCents: number, quantity: number): number {
  return Math.round(priceCents * quantity);
}

export function sumLineTotals(lines: { priceCents: number; quantity: number }[]): number {
  return lines.reduce((s, l) => s + lineTotalCents(l.priceCents, l.quantity), 0);
}

/** "2" for whole numbers, otherwise up to 3 decimals ("2.5", "0.125"). */
export function formatQty(qty: number): string {
  const r = roundQty(qty);
  return Number.isInteger(r) ? String(r) : r.toFixed(3).replace(/0+$/, "");
}

/** Unit a weight item is priced in (price is per kg or per gram). */
export type WeightUnit = "kg" | "g";
export const WEIGHT_UNITS: readonly WeightUnit[] = ["kg", "g"];

const GRAMS_PER_UNIT: Record<WeightUnit, number> = { kg: 1000, g: 1 };

/** Converts a weight between kg and g, rounded to 3 decimals. */
export function convertWeight(qty: number, from: WeightUnit, to: WeightUnit): number {
  return roundQty((qty * GRAMS_PER_UNIT[from]) / GRAMS_PER_UNIT[to]);
}

/** "2.5 kg", "250 g", or just "2" for items sold by count. */
export function formatQtyWithUnit(qty: number, unit: WeightUnit | undefined): string {
  return unit ? `${formatQty(qty)} ${unit}` : formatQty(qty);
}

/** The unit a weight item is sold in (older weight items are kg), undefined for items sold by count. */
export function itemUnit(item: { soldBy?: "each" | "weight"; weightUnit?: WeightUnit }): WeightUnit | undefined {
  return item.soldBy === "weight" ? (item.weightUnit ?? "kg") : undefined;
}
