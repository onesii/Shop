import { describe, expect, it } from "vitest";
import { afterFailedPin, cleanPermissions, isPinLocked, isValidPin, MAX_FAILED_PINS, permissionsFor, PERMISSIONS } from "./access";
import { formatHours, timecardError, workedMinutes } from "./timecards";

describe("access", () => {
  it("gives the owner every permission regardless of rights", () => {
    expect(permissionsFor("owner", { manager: [], cashier: [] })).toEqual([...PERMISSIONS]);
  });

  it("gives other roles only their configured rights", () => {
    expect(permissionsFor("cashier", { manager: ["reports"], cashier: ["refunds"] })).toEqual(["refunds"]);
  });

  it("drops unknown and repeated permissions", () => {
    expect(cleanPermissions(["reports", "hack", "reports", "refunds"])).toEqual(["refunds", "reports"]);
  });

  it("accepts only 4-digit PINs", () => {
    expect(isValidPin("1234")).toBe(true);
    expect(isValidPin("123")).toBe(false);
    expect(isValidPin("12a4")).toBe(false);
  });

  it("locks after the maximum wrong PINs and unlocks after the pause", () => {
    let state = { failedAttempts: 0, lockedUntil: null as string | null };
    for (let i = 0; i < MAX_FAILED_PINS; i++) state = afterFailedPin(state.failedAttempts, 0);
    expect(state.lockedUntil).not.toBeNull();
    expect(isPinLocked(state.lockedUntil, 1000)).toBe(true);
    expect(isPinLocked(state.lockedUntil, 60_000)).toBe(false);
  });
});

describe("timecards", () => {
  const now = Date.parse("2026-11-06T12:00:00.000Z");

  it("validates clock in and out", () => {
    expect(timecardError("2026-11-06T08:00:00.000Z", "2026-11-06T11:00:00.000Z", now)).toBeNull();
    expect(timecardError("2026-11-06T08:00:00.000Z", null, now)).toBeNull();
    expect(timecardError("2026-11-06T13:00:00.000Z", null, now)).toMatch(/future/);
    expect(timecardError("2026-11-06T08:00:00.000Z", "2026-11-06T07:00:00.000Z", now)).toMatch(/after/);
    expect(timecardError("2026-11-04T08:00:00.000Z", "2026-11-06T09:00:00.000Z", now)).toMatch(/24 hours/);
  });

  it("counts worked minutes of closed cards only", () => {
    expect(workedMinutes("2026-11-06T08:00:00.000Z", "2026-11-06T10:05:00.000Z")).toBe(125);
    expect(workedMinutes("2026-11-06T08:00:00.000Z", null)).toBe(0);
    expect(formatHours(125)).toBe("2:05");
  });
});
