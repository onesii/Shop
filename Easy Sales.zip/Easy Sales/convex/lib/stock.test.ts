import { describe, expect, it } from "vitest";
import { stockAfter, stockQtyError, stockStatus } from "./stock";

describe("stock math", () => {
  it("classifies out, low and ok", () => {
    expect(stockStatus(0, 5)).toBe("out");
    expect(stockStatus(-2, null)).toBe("out");
    expect(stockStatus(5, 5)).toBe("low");
    expect(stockStatus(6, 5)).toBe("ok");
    expect(stockStatus(1, null)).toBe("ok");
  });

  it("applies each adjustment reason", () => {
    expect(stockAfter("receive", 3, 2)).toBe(5);
    expect(stockAfter("loss", 3, 5)).toBe(-2);
    expect(stockAfter("damage", 3, 1)).toBe(2);
    expect(stockAfter("recount", 3, 9)).toBe(9);
  });

  it("validates quantities", () => {
    expect(stockQtyError(1.5)).not.toBeNull();
    expect(stockQtyError(-1)).not.toBeNull();
    expect(stockQtyError(-1, { allowNegative: true })).toBeNull();
    expect(stockQtyError(2_000_000)).not.toBeNull();
    expect(stockQtyError(0)).toBeNull();
  });
});
