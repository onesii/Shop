// Pure helpers for splitting a receipt into report rows. Shared by the
// write-time aggregation and its tests.

/** Splits `totalCents` across lines in proportion to their amounts; rounding goes to the last line. */
export function allocateProportionally(lineAmounts: number[], totalCents: number): number[] {
  const sum = lineAmounts.reduce((s, a) => s + a, 0);
  if (sum <= 0 || totalCents === 0) return lineAmounts.map(() => 0);
  let allocated = 0;
  return lineAmounts.map((amount, i) => {
    if (i === lineAmounts.length - 1) return totalCents - allocated;
    const share = Math.round((totalCents * amount) / sum);
    allocated += share;
    return share;
  });
}

/** Stable key for an item + variant; custom (non-catalog) lines are keyed by name. */
export function itemKey(line: { itemId: string | null; name: string; variantName: string | null }): string {
  const base = line.itemId ?? `custom:${line.name}`;
  return `${base}|${line.variantName ?? ""}`;
}
