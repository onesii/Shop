import { ConvexError } from "convex/values";

export const MAX_MODIFIERS = 200;
export const MAX_MODIFIER_OPTIONS = 50;
const MAX_NAME = 60;
const MAX_PRICE_CENTS = 100_000_000; // KSh 1,000,000

export type ModifierOption = { name: string; priceCents: number };

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

/** Trims and checks a modifier before saving. Throws a friendly error on bad input. */
export function validateModifier(
  name: string,
  options: ModifierOption[],
): { name: string; options: ModifierOption[] } {
  const trimmed = name.trim();
  if (!trimmed) badRequest("Modifier name cannot be blank");
  if (trimmed.length > MAX_NAME) badRequest("Modifier name is too long");
  if (options.length === 0) badRequest("Add at least one option");
  if (options.length > MAX_MODIFIER_OPTIONS) badRequest(`A modifier can have up to ${MAX_MODIFIER_OPTIONS} options`);
  const cleaned = options.map((o) => {
    const optionName = o.name.trim();
    if (!optionName) badRequest("Option name cannot be blank");
    if (optionName.length > MAX_NAME) badRequest("Option name is too long");
    if (!Number.isInteger(o.priceCents) || o.priceCents < 0 || o.priceCents > MAX_PRICE_CENTS) {
      badRequest("Enter a valid option price");
    }
    return { name: optionName, priceCents: o.priceCents };
  });
  return { name: trimmed, options: cleaned };
}
