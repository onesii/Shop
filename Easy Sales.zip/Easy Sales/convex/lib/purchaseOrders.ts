// Pure purchase order rules shared by the backend and the frontend.
import { MAX_STOCK_QTY } from "./stock";

export type PoStatus = "draft" | "pending" | "partial" | "closed";

export const MAX_PO_LINES = 200;
export const MAX_ADDITIONAL_COSTS = 10;
export const MAX_PO_NOTES = 500;
export const MAX_SUPPLIERS = 500;
// KSh 100,000,000 per unit keeps typos out of the totals
export const MAX_COST_CENTS = 10_000_000_000;

export const PO_STATUS_LABELS: Record<PoStatus, string> = {
  draft: "Draft",
  pending: "Pending",
  partial: "Partially received",
  closed: "Closed",
};

export function formatPoNumber(n: number): string {
  return `PO${String(n).padStart(4, "0")}`;
}

type CostLine = { quantity: number; costCents: number };
type ReceiveLine = { quantity: number; receivedQty: number };

export function lineAmount(line: CostLine): number {
  return line.quantity * line.costCents;
}

export function poTotal(lines: CostLine[], additional: { amountCents: number }[]): number {
  return lines.reduce((n, l) => n + lineAmount(l), 0) + additional.reduce((n, c) => n + c.amountCents, 0);
}

/** Pending until something arrives, closed once every line is fully received. */
export function statusAfterReceive(lines: ReceiveLine[]): PoStatus {
  const received = lines.reduce((n, l) => n + l.receivedQty, 0);
  if (received === 0) return "pending";
  return lines.every((l) => l.receivedQty >= l.quantity) ? "closed" : "partial";
}

/** Autofill quantity for a low item: enough to reach twice its low stock level (at least 1). */
export function suggestedQty(inStock: number, lowStock: number | null): number {
  const target = lowStock !== null && lowStock > 0 ? lowStock * 2 : 1;
  return Math.max(1, target - inStock);
}

const DAY = /^\d{4}-\d{2}-\d{2}$/;

export function isCalendarDay(s: string): boolean {
  if (!DAY.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().startsWith(s);
}

type Draft = {
  orderedOn: string;
  expectedOn: string | null;
  notes: string;
  lines: CostLine[];
  additionalCosts: { name: string; amountCents: number }[];
};

/** Returns the first problem with a purchase order, or null when it can be saved. */
export function purchaseOrderError(po: Draft): string | null {
  if (!isCalendarDay(po.orderedOn)) return "Enter a valid purchase order date";
  if (po.expectedOn !== null) {
    if (!isCalendarDay(po.expectedOn)) return "Enter a valid expected date";
    if (po.expectedOn < po.orderedOn) return "Expected date can't be before the purchase order date";
  }
  if (po.notes.length > MAX_PO_NOTES) return `Notes can be up to ${MAX_PO_NOTES} characters`;
  if (po.lines.length === 0) return "Add at least one item";
  if (po.lines.length > MAX_PO_LINES) return `Up to ${MAX_PO_LINES} items per purchase order`;
  for (const l of po.lines) {
    if (!Number.isInteger(l.quantity) || l.quantity < 1) return "Quantity must be a whole number of at least 1";
    if (l.quantity > MAX_STOCK_QTY) return "That quantity is too large";
    if (!Number.isInteger(l.costCents) || l.costCents < 0 || l.costCents > MAX_COST_CENTS) {
      return "Enter a valid purchase cost";
    }
  }
  if (po.additionalCosts.length > MAX_ADDITIONAL_COSTS) return `Up to ${MAX_ADDITIONAL_COSTS} additional costs`;
  for (const c of po.additionalCosts) {
    if (!c.name.trim()) return "Additional cost name cannot be blank";
    if (!Number.isInteger(c.amountCents) || c.amountCents < 0 || c.amountCents > MAX_COST_CENTS) {
      return "Enter a valid additional cost amount";
    }
  }
  return null;
}
