import { describe, expect, it } from "vitest";
import { retailPrice, rowValue, valuationTotals } from "./valuation";

describe("valuation", () => {
  it("uses the variant price, falling back to the item price", () => {
    const item = { priceCents: 1000, variants: [{ name: "Large", priceCents: 1500 }, { name: "Open", priceCents: null }] };
    expect(retailPrice(item, "Large")).toBe(1500);
    expect(retailPrice(item, "Open")).toBeNull();
    expect(retailPrice(item, "Gone")).toBe(1000);
    expect(retailPrice(item, null)).toBe(1000);
    expect(retailPrice(undefined, null)).toBeNull();
  });

  it("values a row and ignores negative stock", () => {
    expect(rowValue({ inStock: 4, costCents: 600, priceCents: 1000 })).toEqual({
      inventoryCents: 2400,
      retailCents: 4000,
      profitCents: 1600,
      marginPct: 40,
    });
    expect(rowValue({ inStock: -3, costCents: 600, priceCents: 1000 }).inventoryCents).toBe(0);
    expect(rowValue({ inStock: 2, costCents: null, priceCents: null }).marginPct).toBeNull();
  });

  it("totals rows and computes the overall margin", () => {
    const t = valuationTotals([
      { inStock: 4, costCents: 600, priceCents: 1000 },
      { inStock: 1, costCents: null, priceCents: 1000 },
    ]);
    expect(t).toEqual({ inventoryCents: 2400, retailCents: 5000, profitCents: 2600, marginPct: 52 });
  });
});
