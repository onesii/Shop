import { describe, expect, it } from "vitest";
import { MAX_OFFLINE_AGE_MS, saleTime } from "./saleTime";

const NOW = Date.parse("2026-11-21T10:00:00.000Z");

describe("saleTime", () => {
  it("uses now when the device sent no time", () => {
    expect(saleTime(undefined, NOW)).toBe("2026-11-21T10:00:00.000Z");
  });

  it("keeps a believable offline sale time", () => {
    expect(saleTime("2026-11-21T07:30:00.000Z", NOW)).toBe("2026-11-21T07:30:00.000Z");
  });

  it("ignores times in the future, too old, or unreadable", () => {
    expect(saleTime("2026-11-21T11:00:00.000Z", NOW)).toBe("2026-11-21T10:00:00.000Z");
    expect(saleTime(new Date(NOW - MAX_OFFLINE_AGE_MS - 1000).toISOString(), NOW)).toBe(
      "2026-11-21T10:00:00.000Z",
    );
    expect(saleTime("yesterday", NOW)).toBe("2026-11-21T10:00:00.000Z");
  });
});
