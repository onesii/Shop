// Pure timecard helpers, shared with the frontend.

export const MAX_SHIFT_MS = 24 * 60 * 60 * 1000;

/** Error message for a timecard, or null when it is valid. */
export function timecardError(clockIn: string, clockOut: string | null, nowMs: number): string | null {
  const start = Date.parse(clockIn);
  if (Number.isNaN(start)) return "Enter a valid clock in time";
  if (start > nowMs) return "Clock in can't be in the future";
  if (clockOut === null) return null;
  const end = Date.parse(clockOut);
  if (Number.isNaN(end)) return "Enter a valid clock out time";
  if (end <= start) return "Clock out must be after clock in";
  if (end > nowMs) return "Clock out can't be in the future";
  if (end - start > MAX_SHIFT_MS) return "A timecard can be at most 24 hours";
  return null;
}

/** Worked minutes of a closed timecard; open ones count as 0 until clocked out. */
export function workedMinutes(clockIn: string, clockOut: string | null): number {
  if (clockOut === null) return 0;
  return Math.max(0, Math.round((Date.parse(clockOut) - Date.parse(clockIn)) / 60_000));
}

/** e.g. 125 -> "2:05" */
export function formatHours(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}:${String(m).padStart(2, "0")}`;
}
