import { describe, expect, it } from "vitest";
import { computeDiscounts, computeTotals, proportionalDiscounts } from "./discounts";
import { allocateProportionally, itemKey } from "./reportMath";

describe("discounts", () => {
  it("applies percent and fixed discounts to the subtotal", () => {
    const { lines, discountCents } = computeDiscounts(10000, [
      { name: "10%", type: "percent", value: 1000 },
      { name: "KSh20", type: "amount", value: 2000 },
    ]);
    expect(lines.map((l) => l.amountCents)).toEqual([1000, 2000]);
    expect(discountCents).toBe(3000);
  });

  it("never discounts below zero", () => {
    const { discountCents } = computeDiscounts(1500, [{ name: "Big", type: "amount", value: 5000 }]);
    expect(discountCents).toBe(1500);
  });

  it("taxes the discounted amount", () => {
    const totals = computeTotals(
      10000,
      [{ name: "Half", type: "percent", value: 5000 }],
      [{ name: "Levy", rateBps: 1000, type: "added" }],
    );
    expect(totals.taxes[0].amountCents).toBe(500);
    expect(totals.totalCents).toBe(5500);
  });

  it("gives back a proportional share on partial refunds", () => {
    const share = proportionalDiscounts(
      [{ name: "10%", type: "percent", value: 1000, amountCents: 2000 }],
      20000,
      5000,
    );
    expect(share.discountCents).toBe(500);
  });
});

describe("report math", () => {
  it("allocates without losing cents", () => {
    const parts = allocateProportionally([1000, 1000, 1000], 100);
    expect(parts.reduce((s, p) => s + p, 0)).toBe(100);
  });

  it("keys custom items by name and variants separately", () => {
    expect(itemKey({ itemId: null, name: "Bag", variantName: null })).toBe("custom:Bag|");
    expect(itemKey({ itemId: "abc", name: "Soda", variantName: "Large" })).toBe("abc|Large");
  });
});
