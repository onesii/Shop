import { ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { Doc } from "../_generated/dataModel";

type Ctx = QueryCtx | MutationCtx;

/** The signed-in account's own row, or null if signed out / not yet synced. */
export async function getAccount(ctx: Ctx): Promise<Doc<"users"> | null> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) return null;
  return await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
}

/** The employee row this account joined through an invite, if any. */
export async function getMembership(ctx: Ctx, account: Doc<"users">): Promise<Doc<"employees"> | null> {
  const member = await ctx.db
    .query("employees")
    .withIndex("by_accountId", (q) => q.eq("accountId", account._id))
    .first();
  return member && member.role !== "owner" ? member : null;
}

/**
 * The store owner's user row. Staff who joined a store by invite get the owner's row,
 * so every store query and mutation works on the shared store data.
 */
export async function getCurrentUser(ctx: Ctx): Promise<Doc<"users"> | null> {
  const account = await getAccount(ctx);
  if (!account) return null;
  const member = await getMembership(ctx, account);
  if (!member) return account;
  return (await ctx.db.get("users", member.ownerId)) ?? account;
}

export async function requireUser(ctx: Ctx): Promise<Doc<"users">> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({
      code: "UNAUTHENTICATED",
      message: "Please sign in to continue",
    });
  }
  const user = await getCurrentUser(ctx);
  if (!user) {
    throw new ConvexError({
      code: "NOT_FOUND",
      message: "Account not found. Please sign in again.",
    });
  }
  return user;
}
