// Pure discount + tax math shared by the backend (charge/refund) and the frontend (ticket totals).
import { computeTaxes, type TaxLine, type TaxRule } from "./taxes";

export type DiscountType = "percent" | "amount";
/** percent: value in basis points (1000 = 10%); amount: value in cents. */
export type DiscountRule = { name: string; type: DiscountType; value: number };
export type DiscountLine = DiscountRule & { amountCents: number };

export const MAX_TICKET_DISCOUNTS = 10;
export const MAX_PERCENT_BPS = 10000;

/** Whole-ticket discounts. Percentages apply to the subtotal; the total never goes below zero. */
export function computeDiscounts(
  subtotalCents: number,
  rules: DiscountRule[],
): { lines: DiscountLine[]; discountCents: number } {
  let remaining = subtotalCents;
  const lines = rules.map((r) => {
    const raw = r.type === "percent" ? Math.round((subtotalCents * r.value) / 10000) : r.value;
    const amountCents = Math.min(raw, remaining);
    remaining -= amountCents;
    return { ...r, amountCents };
  });
  return { lines, discountCents: subtotalCents - remaining };
}

export type TicketTotals = {
  subtotalCents: number;
  discounts: DiscountLine[];
  discountCents: number;
  taxes: TaxLine[];
  totalCents: number;
};

/** Discounts first, then taxes on the discounted amount. */
export function computeTotals(
  subtotalCents: number,
  discountRules: DiscountRule[],
  taxRules: TaxRule[],
): TicketTotals {
  const { lines: discounts, discountCents } = computeDiscounts(subtotalCents, discountRules);
  const { lines: taxes, totalCents } = computeTaxes(subtotalCents - discountCents, taxRules);
  return { subtotalCents, discounts, discountCents, taxes, totalCents };
}

/** Share of a sale's discounts that belongs to a partial refund, line by line. */
export function proportionalDiscounts(
  saleDiscounts: DiscountLine[],
  saleSubtotalCents: number,
  refundSubtotalCents: number,
): { lines: DiscountLine[]; discountCents: number } {
  if (saleSubtotalCents <= 0) return { lines: [], discountCents: 0 };
  const lines = saleDiscounts.map((d) => ({
    ...d,
    amountCents: Math.round((d.amountCents * refundSubtotalCents) / saleSubtotalCents),
  }));
  return { lines, discountCents: lines.reduce((s, d) => s + d.amountCents, 0) };
}
