import { describe, expect, it } from "vitest";
import {
  convertWeight,
  formatQty,
  formatQtyWithUnit,
  isValidQuantity,
  itemUnit,
  lineTotalCents,
  roundQty,
  sumLineTotals,
} from "./quantity";

describe("quantity", () => {
  it("accepts up to 3 decimals and rejects zero, negatives and more precision", () => {
    expect(isValidQuantity(1)).toBe(true);
    expect(isValidQuantity(2.25)).toBe(true);
    expect(isValidQuantity(0.125)).toBe(true);
    expect(isValidQuantity(0.1 + 0.2)).toBe(false);
    expect(isValidQuantity(roundQty(0.1 + 0.2))).toBe(true);
    expect(isValidQuantity(1.2345)).toBe(false);
    expect(isValidQuantity(0)).toBe(false);
    expect(isValidQuantity(-1)).toBe(false);
    expect(isValidQuantity(Number.NaN)).toBe(false);
    expect(isValidQuantity(1_000_000)).toBe(false);
  });

  it("rounds line totals to whole cents", () => {
    expect(lineTotalCents(23000, 2)).toBe(46000);
    expect(lineTotalCents(333, 1.5)).toBe(500);
    expect(sumLineTotals([{ priceCents: 333, quantity: 1.5 }, { priceCents: 100, quantity: 2 }])).toBe(700);
  });

  it("formats quantities without trailing zeros", () => {
    expect(formatQty(2)).toBe("2");
    expect(formatQty(2.5)).toBe("2.5");
    expect(formatQty(0.125)).toBe("0.125");
  });

  it("converts between kg and g", () => {
    expect(convertWeight(250, "g", "kg")).toBe(0.25);
    expect(convertWeight(1.5, "kg", "g")).toBe(1500);
    expect(convertWeight(2, "kg", "kg")).toBe(2);
    expect(convertWeight(1, "g", "kg")).toBe(0.001);
  });

  it("formats quantities with their unit", () => {
    expect(formatQtyWithUnit(0.25, "kg")).toBe("0.25 kg");
    expect(formatQtyWithUnit(250, "g")).toBe("250 g");
    expect(formatQtyWithUnit(2, undefined)).toBe("2");
  });

  it("finds the unit of an item (old weight items are kg)", () => {
    expect(itemUnit({ soldBy: "weight" })).toBe("kg");
    expect(itemUnit({ soldBy: "weight", weightUnit: "g" })).toBe("g");
    expect(itemUnit({ soldBy: "each", weightUnit: "g" })).toBeUndefined();
    expect(itemUnit({})).toBeUndefined();
  });
});
