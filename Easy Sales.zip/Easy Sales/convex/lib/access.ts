// Pure access-control helpers, shared with the frontend.

// Keep in sync with the `permission` validator in schema.ts
export const PERMISSIONS = [
  "refunds",
  "discounts",
  "items",
  "customers",
  "reports",
  "employees",
  "settings",
] as const;

export type Permission = (typeof PERMISSIONS)[number];
export type Role = "owner" | "manager" | "cashier";
export type StaffRole = Exclude<Role, "owner">;
export type AccessRights = Record<StaffRole, Permission[]>;

export const DEFAULT_RIGHTS: AccessRights = {
  manager: ["refunds", "discounts", "items", "customers", "reports"],
  cashier: ["discounts", "customers"],
};

// Wrong PINs before the lock screen pauses, and for how long
export const MAX_FAILED_PINS = 5;
export const PIN_LOCK_MS = 30_000;

/** The owner can always do everything; other roles get their access rights. */
export function permissionsFor(role: Role, rights: AccessRights): Permission[] {
  if (role === "owner") return [...PERMISSIONS];
  return PERMISSIONS.filter((p) => rights[role].includes(p));
}

/** Removes unknown and repeated entries, keeping the canonical order. */
export function cleanPermissions(list: readonly string[]): Permission[] {
  return PERMISSIONS.filter((p) => list.includes(p));
}

export function isValidPin(pin: string): boolean {
  return /^\d{4}$/.test(pin);
}

/** Salted with the account id so the same PIN differs between stores. */
export async function hashPin(ownerId: string, pin: string): Promise<string> {
  const data = new TextEncoder().encode(`${ownerId}:${pin}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

/** Throttle state after a wrong PIN. */
export function afterFailedPin(
  failedAttempts: number,
  nowMs: number,
): { failedAttempts: number; lockedUntil: string | null } {
  const next = failedAttempts + 1;
  if (next >= MAX_FAILED_PINS) {
    return { failedAttempts: 0, lockedUntil: new Date(nowMs + PIN_LOCK_MS).toISOString() };
  }
  return { failedAttempts: next, lockedUntil: null };
}

export function isPinLocked(lockedUntil: string | null, nowMs: number): boolean {
  return lockedUntil !== null && Date.parse(lockedUntil) > nowMs;
}
