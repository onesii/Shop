// Pure inventory count rules shared by the backend and the frontend.

export type CountStatus = "pending" | "in_progress" | "completed";
export type CountType = "partial" | "full";

// Matches the tracked-items picker limit, so a full count covers every item
export const MAX_COUNT_LINES = 1000;
export const MAX_COUNT_NOTES = 500;

export const COUNT_STATUS_LABELS: Record<CountStatus, string> = {
  pending: "Pending",
  in_progress: "In progress",
  completed: "Completed",
};

export const COUNT_TYPE_LABELS: Record<CountType, string> = {
  partial: "Partial",
  full: "Full",
};

/** IC1001, IC1002... like Loyverse. */
export function formatCountNumber(n: number): string {
  return `IC${1000 + n}`;
}

type CountLine = { counted: number | null; expected: number | null; costCents: number | null };

/** Counted minus expected, or null when the item wasn't counted. */
export function lineDifference(counted: number | null, expected: number): number | null {
  return counted === null ? null : counted - expected;
}

/** Pending until a number is entered, then in progress. */
export function statusAfterSave(lines: { counted: number | null }[]): CountStatus {
  return lines.some((l) => l.counted !== null) ? "in_progress" : "pending";
}

/** Totals for a completed count; uncounted lines are left out. */
export function countTotals(lines: CountLine[]): { counted: number; differenceQty: number; costDifferenceCents: number } {
  let counted = 0;
  let differenceQty = 0;
  let costDifferenceCents = 0;
  for (const l of lines) {
    if (l.counted === null || l.expected === null) continue;
    counted++;
    const diff = l.counted - l.expected;
    differenceQty += diff;
    costDifferenceCents += diff * (l.costCents ?? 0);
  }
  return { counted, differenceQty, costDifferenceCents };
}
