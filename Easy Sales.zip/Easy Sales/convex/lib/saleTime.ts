// Offline sales keep the time they were rung up, within limits, so a wrong
// device clock can't put receipts far in the past or future.
export const MAX_OFFLINE_AGE_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_CLOCK_AHEAD_MS = 5 * 60 * 1000;
export const MAX_CLIENT_ID = 64;

/** The receipt time: the device's sale time when believable, otherwise now. */
export function saleTime(soldAt: string | undefined, now: number): string {
  if (!soldAt) return new Date(now).toISOString();
  const t = Date.parse(soldAt);
  if (Number.isNaN(t) || t > now + MAX_CLOCK_AHEAD_MS || t < now - MAX_OFFLINE_AGE_MS) {
    return new Date(now).toISOString();
  }
  return new Date(t).toISOString();
}
