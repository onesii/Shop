// Pure tax math shared by the backend (charge/refund) and the frontend (ticket totals).
// Rates are basis points (1600 = 16%) so they stay integers.

export type TaxType = "included" | "added";
export type TaxRule = { name: string; rateBps: number; type: TaxType };
export type TaxLine = TaxRule & { amountCents: number };

export const MAX_RATE_BPS = 10000;

/**
 * "included" taxes are already inside item prices (e.g. Kenyan VAT); "added"
 * taxes are charged on top. Both are computed on the price net of included tax,
 * so mixing the two never taxes a tax.
 */
export function computeTaxes(
  subtotalCents: number,
  rules: TaxRule[],
): { lines: TaxLine[]; totalCents: number } {
  const includedBps = rules
    .filter((r) => r.type === "included")
    .reduce((s, r) => s + r.rateBps, 0);
  const base = (subtotalCents * 10000) / (10000 + includedBps);
  const lines = rules.map((r) => ({
    ...r,
    amountCents: Math.round((base * r.rateBps) / 10000),
  }));
  const addedCents = lines
    .filter((l) => l.type === "added")
    .reduce((s, l) => s + l.amountCents, 0);
  return { lines, totalCents: subtotalCents + addedCents };
}

/** "16" -> 1600, "7.5" -> 750. Returns NaN when invalid or out of range. */
export function parseRateBps(input: string): number {
  const cleaned = input.replace(/[%\s]/g, "");
  if (!/^\d+(\.\d{0,2})?$/.test(cleaned)) return Number.NaN;
  const bps = Math.round(Number(cleaned) * 100);
  return bps > MAX_RATE_BPS ? Number.NaN : bps;
}

/** 1600 -> "16%", 750 -> "7.5%". */
export function formatRate(rateBps: number): string {
  return `${Number((rateBps / 100).toFixed(2))}%`;
}
