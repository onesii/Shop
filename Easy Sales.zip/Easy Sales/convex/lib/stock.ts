// Pure stock math shared by the backend and the frontend.

export type StockReason = "receive" | "loss" | "damage" | "recount" | "edit" | "sale" | "refund";
export type ManualStockReason = Exclude<StockReason, "edit" | "sale" | "refund">;
export const STOCK_REASONS: StockReason[] = ["sale", "refund", "receive", "recount", "loss", "damage", "edit"];
export type StockStatus = "out" | "low" | "ok";

export const MAX_ADJUSTMENT_LINES = 100;
// Keeps typos like 1e9 out of the stock count
export const MAX_STOCK_QTY = 1_000_000;

export function stockStatus(inStock: number, lowStock: number | null): StockStatus {
  if (inStock <= 0) return "out";
  if (lowStock !== null && inStock <= lowStock) return "low";
  return "ok";
}

export function isLowStock(inStock: number, lowStock: number | null): boolean {
  return stockStatus(inStock, lowStock) !== "ok";
}

/** Stock after an adjustment. Receive adds, loss/damage remove, recount and edit set the count. */
export function stockAfter(reason: StockReason, current: number, quantity: number): number {
  switch (reason) {
    case "receive":
    case "refund":
      return current + quantity;
    case "loss":
    case "damage":
    case "sale":
      return current - quantity;
    case "recount":
    case "edit":
      return quantity;
  }
}

/** Returns an error message, or null when the quantity is a valid whole number in range. */
export function stockQtyError(qty: number, { allowNegative = false } = {}): string | null {
  if (!Number.isInteger(qty)) return "Stock must be a whole number";
  if (!allowNegative && qty < 0) return "Stock can't be negative";
  if (Math.abs(qty) > MAX_STOCK_QTY) return "That stock number is too large";
  return null;
}
