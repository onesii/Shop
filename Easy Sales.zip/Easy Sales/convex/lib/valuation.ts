// Inventory valuation math shared by the backend and the frontend.

type PricedItem = { priceCents: number | null; variants: { name: string; priceCents: number | null }[] };

/** Selling price of a stock row: the variant's price, else the item's. null = price set at sale. */
export function retailPrice(item: PricedItem | undefined, variantName: string | null): number | null {
  if (!item) return null;
  if (variantName !== null) {
    const variant = item.variants.find((v) => v.name === variantName);
    if (variant) return variant.priceCents;
  }
  return item.priceCents;
}

export type ValuationRow = { inStock: number; costCents: number | null; priceCents: number | null };

export type RowValue = {
  inventoryCents: number;
  retailCents: number;
  profitCents: number;
  /** Percent of retail value, null when there is no retail value */
  marginPct: number | null;
};

/** Stock below zero is worth nothing, so it never lowers the totals. */
export function rowValue(r: ValuationRow): RowValue {
  const qty = Math.max(0, r.inStock);
  const inventoryCents = qty * (r.costCents ?? 0);
  const retailCents = qty * (r.priceCents ?? 0);
  const profitCents = retailCents - inventoryCents;
  return { inventoryCents, retailCents, profitCents, marginPct: marginOf(profitCents, retailCents) };
}

export function marginOf(profitCents: number, retailCents: number): number | null {
  return retailCents > 0 ? (profitCents / retailCents) * 100 : null;
}

export function valuationTotals(rows: ValuationRow[]): RowValue {
  let inventoryCents = 0;
  let retailCents = 0;
  for (const r of rows) {
    const v = rowValue(r);
    inventoryCents += v.inventoryCents;
    retailCents += v.retailCents;
  }
  const profitCents = retailCents - inventoryCents;
  return { inventoryCents, retailCents, profitCents, marginPct: marginOf(profitCents, retailCents) };
}
