import { describe, expect, it } from "vitest";
import { computeTaxes, formatRate, parseRateBps } from "./taxes";

const VAT = { name: "VAT", rateBps: 1600, type: "included" as const };
const LEVY = { name: "Levy", rateBps: 200, type: "added" as const };

describe("computeTaxes", () => {
  it("does not change the total for included tax", () => {
    const r = computeTaxes(11600, [VAT]);
    expect(r.totalCents).toBe(11600);
    expect(r.lines[0].amountCents).toBe(1600);
  });

  it("adds added tax on top", () => {
    const r = computeTaxes(10000, [LEVY]);
    expect(r.totalCents).toBe(10200);
  });

  it("computes added tax on the price net of included tax", () => {
    const r = computeTaxes(11600, [VAT, LEVY]);
    expect(r.lines.map((l) => l.amountCents)).toEqual([1600, 200]);
    expect(r.totalCents).toBe(11800);
  });

  it("returns the subtotal when there are no taxes", () => {
    expect(computeTaxes(500, []).totalCents).toBe(500);
  });
});

describe("rate helpers", () => {
  it("parses and formats percentages", () => {
    expect(parseRateBps("16")).toBe(1600);
    expect(parseRateBps("7.5%")).toBe(750);
    expect(parseRateBps("101")).toBeNaN();
    expect(parseRateBps("abc")).toBeNaN();
    expect(formatRate(750)).toBe("7.5%");
  });
});
