// Shared by the settings mutation and the settings forms
export const SETTINGS_LIMITS = {
  storeName: 60,
  posName: 30,
  receiptHeader: 500,
  receiptFooter: 500,
  taxName: 30,
};
