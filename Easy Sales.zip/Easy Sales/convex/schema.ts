import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export const itemColor = v.union(
  v.literal("gray"),
  v.literal("red"),
  v.literal("pink"),
  v.literal("orange"),
  v.literal("yellow"),
  v.literal("green"),
  v.literal("blue"),
  v.literal("purple"),
);

// Prices are stored in cents (integer) to avoid floating point rounding issues.
export const soldBy = v.union(v.literal("each"), v.literal("weight"));
// Unit a weight item is priced and sold in
export const weightUnit = v.union(v.literal("kg"), v.literal("g"));

export const variantValidator = v.object({
  name: v.string(),
  priceCents: v.union(v.number(), v.null()),
});

export const paymentMethod = v.union(
  v.literal("cash"),
  v.literal("card"),
  v.literal("mpesa"),
);

// Payment totals per method in a sales hour bucket
export const paymentTotals = v.object({
  salesCount: v.number(),
  salesCents: v.number(),
  refundsCount: v.number(),
  refundsCents: v.number(),
});

export const receiptLineValidator = v.object({
  itemId: v.union(v.id("items"), v.null()),
  name: v.string(),
  variantName: v.union(v.string(), v.null()),
  priceCents: v.number(),
  quantity: v.number(), // up to 3 decimals, e.g. 2.25 kg
  comment: v.optional(v.string()),
  unit: v.optional(weightUnit), // set for weight items
});

export const taxType = v.union(v.literal("included"), v.literal("added"));

export const taxSettingValidator = v.object({
  name: v.string(),
  rateBps: v.number(), // basis points, 1600 = 16%
  type: taxType,
  enabled: v.boolean(),
});

// Tax snapshot stored on each receipt so history is not affected by later edits
export const receiptTaxValidator = v.object({
  name: v.string(),
  rateBps: v.number(),
  type: taxType,
  amountCents: v.number(),
});

// percent: value in basis points (1000 = 10%); amount: value in cents
export const discountType = v.union(v.literal("percent"), v.literal("amount"));

// Discount snapshot stored on each receipt
export const receiptDiscountValidator = v.object({
  name: v.string(),
  type: discountType,
  value: v.number(),
  amountCents: v.number(),
});

// "edit" is recorded automatically when stock is changed from the item form
export const stockReason = v.union(
  v.literal("receive"),
  v.literal("loss"),
  v.literal("damage"),
  v.literal("recount"),
  v.literal("edit"),
  v.literal("sale"),
  v.literal("refund"),
);

// Stock settings sent with an item save; variantName null = item without variants
export const stockInputValidator = v.object({
  variantName: v.union(v.string(), v.null()),
  inStock: v.number(),
  lowStock: v.union(v.number(), v.null()),
});

export const stockAdjustmentLineValidator = v.object({
  itemId: v.id("items"),
  itemName: v.string(),
  variantName: v.union(v.string(), v.null()),
  change: v.number(),
  inStockAfter: v.number(),
});

// draft = saved but not sent; pending = ordered, nothing received; partial = some received
export const purchaseOrderStatus = v.union(
  v.literal("draft"),
  v.literal("pending"),
  v.literal("partial"),
  v.literal("closed"),
);

export const purchaseOrderLineValidator = v.object({
  stockLevelId: v.id("stockLevels"),
  itemId: v.id("items"),
  itemName: v.string(),
  variantName: v.union(v.string(), v.null()),
  quantity: v.number(), // whole units ordered
  receivedQty: v.number(),
  costCents: v.number(), // purchase cost per unit
});

export const additionalCostValidator = v.object({
  name: v.string(),
  amountCents: v.number(),
});

// pending = created, nothing counted; in_progress = some counts saved
export const inventoryCountStatus = v.union(v.literal("pending"), v.literal("in_progress"), v.literal("completed"));
export const inventoryCountType = v.union(v.literal("partial"), v.literal("full"));

export const inventoryCountLineValidator = v.object({
  stockLevelId: v.id("stockLevels"),
  itemId: v.id("items"),
  itemName: v.string(),
  variantName: v.union(v.string(), v.null()),
  counted: v.union(v.number(), v.null()), // null = not counted yet
  // Filled in when the count is completed (stock and cost at that moment)
  expected: v.union(v.number(), v.null()),
  costCents: v.union(v.number(), v.null()),
});

export const modifierOptionValidator = v.object({
  name: v.string(),
  priceCents: v.number(), // extra charge, 0 = free
});

export const employeeRole = v.union(v.literal("owner"), v.literal("manager"), v.literal("cashier"));

// Keep in sync with PERMISSIONS in lib/access.ts
export const permission = v.union(
  v.literal("refunds"),
  v.literal("discounts"),
  v.literal("items"),
  v.literal("customers"),
  v.literal("reports"),
  v.literal("employees"),
  v.literal("settings"),
);

export const openTicketLineValidator = v.object({
  itemId: v.id("items"),
  name: v.string(),
  variantName: v.union(v.string(), v.null()),
  priceCents: v.number(),
  quantity: v.number(),
  color: itemColor,
  comment: v.optional(v.string()),
  unit: v.optional(weightUnit),
});

export default defineSchema({
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
  }).index("by_token", ["tokenIdentifier"]),

  categories: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    color: itemColor,
  }).index("by_owner_and_name", ["ownerId", "name"]),

  items: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    categoryId: v.union(v.id("categories"), v.null()),
    // null = price is entered at the time of sale
    priceCents: v.union(v.number(), v.null()),
    color: itemColor,
    // Small, bounded list of options (e.g. Small / Large)
    variants: v.array(variantValidator),
    // "weight" items ask for a quantity (e.g. 2.250 kg) when tapped; missing = "each"
    soldBy: v.optional(soldBy),
    // Weight items only: price is per kg or per gram; missing = "kg"
    weightUnit: v.optional(weightUnit),
  })
    .index("by_owner_and_name", ["ownerId", "name"])
    .index("by_owner_and_category", ["ownerId", "categoryId"])
    .searchIndex("search_name", {
      searchField: "name",
      filterFields: ["ownerId"],
    }),

  // One row per owner; low-churn counter for sequential receipt numbers
  receiptCounters: defineTable({
    ownerId: v.id("users"),
    lastNumber: v.number(),
  }).index("by_owner", ["ownerId"]),

  receipts: defineTable({
    ownerId: v.id("users"),
    number: v.string(), // e.g. "1-1004"
    kind: v.union(v.literal("sale"), v.literal("refund")),
    createdAt: v.string(), // ISO 8601 UTC
    // Lines are bounded by MAX_LINES in the mutation
    lines: v.array(receiptLineValidator),
    totalCents: v.number(),
    paymentMethod: paymentMethod,
    tenderedCents: v.number(),
    changeCents: v.number(),
    // Sale receipts: total already refunded. Refund receipts: the sale it refunds.
    refundedCents: v.number(),
    refundOf: v.union(v.id("receipts"), v.null()),
    mpesaReference: v.union(v.string(), v.null()),
    // Shift the receipt was rung up in (older receipts have none)
    shiftId: v.optional(v.id("shifts")),
    // Settings snapshot at the time of sale (older receipts have none)
    subtotalCents: v.optional(v.number()),
    taxes: v.optional(v.array(receiptTaxValidator)),
    // Whole-ticket discounts (older receipts have none)
    discounts: v.optional(v.array(receiptDiscountValidator)),
    discountCents: v.optional(v.number()),
    storeName: v.optional(v.string()),
    posName: v.optional(v.string()),
    receiptFooter: v.optional(v.string()),
    receiptHeader: v.optional(v.string()),
    // Missing = shown (older receipts)
    showCustomerInfo: v.optional(v.boolean()),
    showComments: v.optional(v.boolean()),
    // UTC minute of the day (0-1439), used by the receipts report's time-of-day filter
    minuteOfDay: v.optional(v.number()),
    // Customer on the sale; the name is a snapshot so receipts survive edits and deletes
    customerId: v.optional(v.id("customers")),
    customerName: v.optional(v.string()),
    // Who rang it up; older receipts have none and belong to the owner
    employeeId: v.optional(v.id("employees")),
    employeeName: v.optional(v.string()),
    // Id the device gave the sale, so a sale rung up offline is only saved once when it syncs
    clientId: v.optional(v.string()),
  })
    .index("by_owner_and_createdAt", ["ownerId", "createdAt"])
    .index("by_refundOf", ["refundOf"])
    .index("by_owner_and_clientId", ["ownerId", "clientId"]),

  // Cash drawer sessions. Totals are kept up to date by the charge/refund
  // mutations so the shift screen never has to scan receipts.
  shifts: defineTable({
    ownerId: v.id("users"),
    number: v.number(),
    status: v.union(v.literal("open"), v.literal("closed")),
    openedAt: v.string(), // ISO 8601 UTC
    closedAt: v.union(v.string(), v.null()),
    startingCashCents: v.number(),
    grossSalesCents: v.number(),
    refundsCents: v.number(),
    cashPaymentsCents: v.number(),
    cashRefundsCents: v.number(),
    cardCents: v.number(),
    mpesaCents: v.number(),
    paidInCents: v.number(),
    paidOutCents: v.number(),
    // Counted at close
    actualCashCents: v.union(v.number(), v.null()),
    // Who opened it; older shifts have none and belong to the owner
    employeeId: v.optional(v.id("employees")),
    employeeName: v.optional(v.string()),
  })
    .index("by_owner_and_status", ["ownerId", "status"])
    .index("by_owner_and_number", ["ownerId", "number"])
    .index("by_owner_and_openedAt", ["ownerId", "openedAt"]),

  // Pay in / pay out entries for a shift
  cashMovements: defineTable({
    shiftId: v.id("shifts"),
    kind: v.union(v.literal("in"), v.literal("out")),
    amountCents: v.number(),
    comment: v.union(v.string(), v.null()),
    createdAt: v.string(), // ISO 8601 UTC
  }).index("by_shift", ["shiftId"]),

  // Sales totals per UTC hour, kept up to date by charge/refund so reports
  // never scan receipts. Hourly buckets let the client group by local day.
  salesHours: defineTable({
    ownerId: v.id("users"),
    hour: v.string(), // ISO 8601 UTC, start of hour e.g. "2026-10-22T14:00:00.000Z"
    grossSalesCents: v.number(),
    refundsCents: v.number(),
    salesCount: v.number(),
    refundsCount: v.number(),
    // Older buckets have none. Gross sales include discounts; net = gross - refunds - discounts.
    discountsCents: v.optional(v.number()),
    // Per payment method totals (older buckets have none)
    payments: v.optional(
      v.object({ cash: paymentTotals, card: paymentTotals, mpesa: paymentTotals }),
    ),
    // One bucket per employee per hour; older buckets have none and belong to the owner
    employeeId: v.optional(v.id("employees")),
  }).index("by_owner_and_hour_and_employeeId", ["ownerId", "hour", "employeeId"]),

  // Per item (and variant) sales per UTC hour, kept up to date by charge/refund.
  // Amounts are before tax; net = gross - refunds - discounts.
  itemSalesHours: defineTable({
    ownerId: v.id("users"),
    hour: v.string(), // ISO 8601 UTC, start of hour
    itemKey: v.string(), // itemId|variant, or custom:name|variant for items not in the catalog
    itemId: v.union(v.id("items"), v.null()),
    name: v.string(),
    variantName: v.union(v.string(), v.null()),
    categoryId: v.union(v.id("categories"), v.null()),
    itemsSold: v.number(),
    itemsRefunded: v.number(),
    grossSalesCents: v.number(),
    refundsCents: v.number(),
    discountsCents: v.number(),
    employeeId: v.optional(v.id("employees")),
  }).index("by_owner_and_hour_and_itemKey_and_employeeId", ["ownerId", "hour", "itemKey", "employeeId"]),

  // Per discount (by name) per UTC hour, kept up to date by charge/refund.
  // Refunds give back their share, so amountCents is the net amount discounted.
  discountSalesHours: defineTable({
    ownerId: v.id("users"),
    hour: v.string(), // ISO 8601 UTC, start of hour
    name: v.string(),
    timesApplied: v.number(),
    amountCents: v.number(),
    employeeId: v.optional(v.id("employees")),
  }).index("by_owner_and_hour_and_name_and_employeeId", ["ownerId", "hour", "name", "employeeId"]),

  // Staff who use the POS. The account holder is the single "owner" row.
  employees: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    email: v.union(v.string(), v.null()),
    phone: v.union(v.string(), v.null()),
    role: employeeRole,
    // SHA-256 of owner + PIN; null until set (only the owner can be without one)
    pinHash: v.union(v.string(), v.null()),
    // Staff account that accepted an invite and signs in on its own device
    accountId: v.optional(v.id("users")),
  })
    .index("by_owner_and_name", ["ownerId", "name"])
    .index("by_owner_and_role", ["ownerId", "role"])
    .index("by_owner_and_pinHash", ["ownerId", "pinHash"])
    .index("by_accountId", ["accountId"]),

  // One-time links the owner shares so an employee can join from their own account
  staffInvites: defineTable({
    ownerId: v.id("users"),
    employeeId: v.id("employees"),
    token: v.string(),
    expiresAt: v.string(), // ISO 8601 UTC
  })
    .index("by_token", ["token"])
    .index("by_employee", ["employeeId"]),

  // What managers and cashiers may do. One row per owner; missing = defaults.
  accessRights: defineTable({
    ownerId: v.id("users"),
    manager: v.array(permission),
    cashier: v.array(permission),
  }).index("by_owner", ["ownerId"]),

  // Who is unlocked on the POS (one per account, like the single open shift), plus wrong-PIN throttling
  posSessions: defineTable({
    ownerId: v.id("users"),
    employeeId: v.union(v.id("employees"), v.null()),
    failedAttempts: v.number(),
    lockedUntil: v.union(v.string(), v.null()), // ISO 8601 UTC
  }).index("by_owner", ["ownerId"]),

  timecards: defineTable({
    ownerId: v.id("users"),
    employeeId: v.id("employees"),
    employeeName: v.string(), // snapshot so history survives deletes
    clockIn: v.string(), // ISO 8601 UTC
    clockOut: v.union(v.string(), v.null()),
  })
    .index("by_owner_and_clockIn", ["ownerId", "clockIn"])
    .index("by_employee_and_clockOut", ["employeeId", "clockOut"]),

  // Visits and total spent are kept up to date by charge/refund
  customers: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    phone: v.union(v.string(), v.null()),
    email: v.union(v.string(), v.null()),
    note: v.union(v.string(), v.null()),
    // name + phone + email, so one search box finds any of them
    searchText: v.string(),
    visits: v.number(),
    totalSpentCents: v.number(),
    lastVisitAt: v.union(v.string(), v.null()), // ISO 8601 UTC
  })
    .index("by_owner_and_name", ["ownerId", "name"])
    .searchIndex("search_text", { searchField: "searchText", filterFields: ["ownerId"] }),

  // One row per tracked item (or variant). Kept apart from items because it changes on
  // every sale. itemName is a copy so lists sort by name without loading items.
  stockLevels: defineTable({
    ownerId: v.id("users"),
    itemId: v.id("items"),
    itemName: v.string(),
    variantName: v.union(v.string(), v.null()),
    inStock: v.number(), // whole units, can go below zero if sold while out
    lowStock: v.union(v.number(), v.null()),
    // Out of stock or at/below the low stock level; kept up to date on every write
    isLow: v.boolean(),
    // Purchase cost from the latest purchase order, used as the default on the next one
    lastCostCents: v.optional(v.number()),
  })
    .index("by_item_and_variant", ["itemId", "variantName"])
    .index("by_owner_and_itemName", ["ownerId", "itemName"])
    .index("by_owner_and_isLow_and_itemName", ["ownerId", "isLow", "itemName"]),

  stockAdjustments: defineTable({
    ownerId: v.id("users"),
    createdAt: v.string(), // ISO 8601 UTC
    reason: stockReason,
    note: v.union(v.string(), v.null()),
    // Bounded by MAX_ADJUSTMENT_LINES (sales: bounded by receipt lines)
    lines: v.array(stockAdjustmentLineValidator),
    // Who made the change; missing on entries made before this was recorded
    employeeName: v.optional(v.string()),
  })
    .index("by_owner_and_createdAt", ["ownerId", "createdAt"])
    .index("by_owner_and_reason_and_createdAt", ["ownerId", "reason", "createdAt"]),

  suppliers: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    contact: v.string(),
    email: v.string(),
    phone: v.string(),
    address: v.string(),
    note: v.string(),
  }).index("by_owner_and_name", ["ownerId", "name"]),

  // One row per owner; low-churn counter for PO numbers (PO0001, PO0002...)
  purchaseOrderCounters: defineTable({
    ownerId: v.id("users"),
    lastNumber: v.number(),
  }).index("by_owner", ["ownerId"]),

  purchaseOrders: defineTable({
    ownerId: v.id("users"),
    number: v.number(),
    supplierId: v.id("suppliers"),
    supplierName: v.string(), // copy, so the list survives a deleted supplier
    status: purchaseOrderStatus,
    orderedOn: v.string(), // YYYY-MM-DD, store's local calendar day
    expectedOn: v.union(v.string(), v.null()), // YYYY-MM-DD
    notes: v.string(),
    // Bounded by MAX_PO_LINES / MAX_ADDITIONAL_COSTS
    lines: v.array(purchaseOrderLineValidator),
    additionalCosts: v.array(additionalCostValidator),
    totalCents: v.number(),
    orderedQty: v.number(),
    receivedQty: v.number(),
    createdAt: v.string(), // ISO 8601 UTC
  })
    .index("by_owner_and_number", ["ownerId", "number"])
    .index("by_owner_and_status_and_number", ["ownerId", "status", "number"])
    .index("by_owner_and_supplierId_and_number", ["ownerId", "supplierId", "number"]),

  inventoryCountCounters: defineTable({
    ownerId: v.id("users"),
    lastNumber: v.number(),
  }).index("by_owner", ["ownerId"]),

  inventoryCounts: defineTable({
    ownerId: v.id("users"),
    number: v.number(),
    type: inventoryCountType,
    status: inventoryCountStatus,
    notes: v.string(),
    // Bounded by MAX_COUNT_LINES
    lines: v.array(inventoryCountLineValidator),
    createdAt: v.string(), // ISO 8601 UTC
    completedAt: v.union(v.string(), v.null()), // ISO 8601 UTC
  })
    .index("by_owner_and_number", ["ownerId", "number"])
    .index("by_owner_and_status_and_number", ["ownerId", "status", "number"]),

  discounts: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    type: discountType,
    value: v.number(),
  }).index("by_owner_and_name", ["ownerId", "name"]),

  // Option groups like "Grain base" with an extra price per option.
  // Options are a small, bounded list (MAX_MODIFIER_OPTIONS), kept in display order.
  modifiers: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    options: v.array(modifierOptionValidator),
  }).index("by_owner_and_name", ["ownerId", "name"]),

  // Kitchen/bar routing: a printer in a group only gets order lines from these categories.
  // Printers themselves are set up per device (browser storage), not here.
  printerGroups: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    categoryIds: v.array(v.id("categories")), // bounded by MAX_CATEGORIES_PER_GROUP
  }).index("by_owner_and_name", ["ownerId", "name"]),

  // One row per owner. Taxes are a small, bounded list (MAX_TAXES).
  settings: defineTable({
    ownerId: v.id("users"),
    storeName: v.string(),
    posName: v.string(),
    receiptFooter: v.string(),
    // Receipt settings added later; missing = empty header, show everything
    receiptHeader: v.optional(v.string()),
    showCustomerInfo: v.optional(v.boolean()),
    showComments: v.optional(v.boolean()),
    taxes: v.array(taxSettingValidator),
  }).index("by_owner", ["ownerId"]),

  // Saved, unpaid tickets (e.g. a table order) that can be reopened later
  openTickets: defineTable({
    ownerId: v.id("users"),
    name: v.string(),
    comment: v.union(v.string(), v.null()),
    // Bounded by MAX_LINES in the mutation
    lines: v.array(openTicketLineValidator),
    // Bounded by MAX_TICKET_DISCOUNTS
    discountIds: v.optional(v.array(v.id("discounts"))),
    customerId: v.optional(v.id("customers")),
    customerName: v.optional(v.string()),
    totalCents: v.number(),
    updatedAt: v.string(), // ISO 8601 UTC
  }).index("by_owner_and_updatedAt", ["ownerId", "updatedAt"]),
});
