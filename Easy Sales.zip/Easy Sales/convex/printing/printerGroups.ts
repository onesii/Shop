import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";

const MAX_GROUPS = 50;
const MAX_CATEGORIES_PER_GROUP = 200;

async function getOwnedGroup(
  ctx: MutationCtx,
  id: Id<"printerGroups">,
  owner: Doc<"users">,
): Promise<Doc<"printerGroups">> {
  const group = await ctx.db.get("printerGroups", id);
  if (!group || group.ownerId !== owner._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Printer group not found" });
  }
  return group;
}

/** Trims the name and keeps only this store's categories, without repeats. */
async function validate(
  ctx: MutationCtx,
  owner: Doc<"users">,
  name: string,
  categoryIds: Id<"categories">[],
): Promise<{ name: string; categoryIds: Id<"categories">[] }> {
  const trimmed = name.trim();
  if (!trimmed) throw new ConvexError({ code: "BAD_REQUEST", message: "Group name cannot be blank" });
  if (trimmed.length > 40) throw new ConvexError({ code: "BAD_REQUEST", message: "Group name is too long" });
  const unique = [...new Set(categoryIds)];
  if (unique.length > MAX_CATEGORIES_PER_GROUP) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Too many categories" });
  }
  for (const id of unique) {
    const category = await ctx.db.get("categories", id);
    if (!category || category.ownerId !== owner._id) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Category not found" });
    }
  }
  return { name: trimmed, categoryIds: unique };
}

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("printerGroups")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_GROUPS);
  },
});

const fields = { name: v.string(), categoryIds: v.array(v.id("categories")) };

export const create = mutation({
  args: fields,
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "settings");
    const existing = await ctx.db
      .query("printerGroups")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_GROUPS);
    if (existing.length >= MAX_GROUPS) {
      throw new ConvexError({ code: "BAD_REQUEST", message: `Up to ${MAX_GROUPS} printer groups allowed` });
    }
    const clean = await validate(ctx, user, args.name, args.categoryIds);
    return await ctx.db.insert("printerGroups", { ownerId: user._id, ...clean });
  },
});

export const update = mutation({
  args: { id: v.id("printerGroups"), ...fields },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "settings");
    await getOwnedGroup(ctx, args.id, user);
    const clean = await validate(ctx, user, args.name, args.categoryIds);
    await ctx.db.patch("printerGroups", args.id, clean);
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("printerGroups") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "settings");
    await getOwnedGroup(ctx, args.id, user);
    await ctx.db.delete("printerGroups", args.id);
    return null;
  },
});
