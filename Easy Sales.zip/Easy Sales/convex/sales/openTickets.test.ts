import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1", name: "Jane" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
  const itemId = await t.run(async (ctx) => {
    const user = await ctx.db.query("users").first();
    if (!user) throw new Error("no user");
    return await ctx.db.insert("items", {
      ownerId: user._id,
      name: "Soda",
      categoryId: null,
      priceCents: 5000,
      color: "red",
      variants: [],
    });
  });
  const lines = [
    { itemId, name: "Soda", variantName: null, priceCents: 5000, quantity: 2, color: "red" as const },
  ];
  return { t, asUser, lines };
}

describe("open tickets", () => {
  it("saves, updates in place and lists tickets", async () => {
    const { asUser, lines } = await setup();
    const id = await asUser.mutation(api.sales.openTickets.save, { name: " Table 4 ", lines });
    const updated = await asUser.mutation(api.sales.openTickets.save, {
      id,
      name: "Table 4",
      lines: [{ ...lines[0], quantity: 3 }],
    });
    expect(updated).toBe(id);
    const list = await asUser.query(api.sales.openTickets.list, {});
    expect(list).toHaveLength(1);
    expect(list[0].name).toBe("Table 4");
    expect(list[0].totalCents).toBe(15000);
  });

  it("rejects empty tickets and blank names", async () => {
    const { asUser, lines } = await setup();
    await expect(asUser.mutation(api.sales.openTickets.save, { name: "A", lines: [] })).rejects.toThrow();
    await expect(asUser.mutation(api.sales.openTickets.save, { name: "  ", lines })).rejects.toThrow();
  });

  it("removes the ticket when it is charged", async () => {
    const { asUser, lines } = await setup();
    const id = await asUser.mutation(api.sales.openTickets.save, { name: "Table 1", lines });
    await asUser.mutation(api.sales.receipts.charge, {
      lines: lines.map(({ color: _color, ...l }) => l),
      paymentMethod: "card",
      tenderedCents: 0,
      openTicketId: id,
    });
    expect(await asUser.query(api.sales.openTickets.list, {})).toHaveLength(0);
  });

  it("keeps tickets private to their owner", async () => {
    const { t, asUser, lines } = await setup();
    const id = await asUser.mutation(api.sales.openTickets.save, { name: "Mine", lines });
    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    expect(await other.query(api.sales.openTickets.list, {})).toHaveLength(0);
    await expect(other.mutation(api.sales.openTickets.remove, { id })).rejects.toThrow();
  });
});
