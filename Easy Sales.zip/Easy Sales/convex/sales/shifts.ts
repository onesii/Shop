import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { employeeStamp, requireStaff } from "../lib/staff";

const MAX_MOVEMENTS = 200;

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

function validAmount(cents: number): boolean {
  return Number.isInteger(cents) && cents >= 0;
}

export function expectedCashCents(s: Doc<"shifts">): number {
  return (
    s.startingCashCents + s.cashPaymentsCents - s.cashRefundsCents + s.paidInCents - s.paidOutCents
  );
}

export async function findOpenShift(
  ctx: QueryCtx | MutationCtx,
  ownerId: Id<"users">,
): Promise<Doc<"shifts"> | null> {
  return await ctx.db
    .query("shifts")
    .withIndex("by_owner_and_status", (q) => q.eq("ownerId", ownerId).eq("status", "open"))
    .first();
}

/** Used by charge/refund: sales can only be rung up during an open shift. */
export async function requireOpenShift(
  ctx: MutationCtx,
  ownerId: Id<"users">,
): Promise<Doc<"shifts">> {
  const shift = await findOpenShift(ctx, ownerId);
  if (!shift) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Open a shift before making sales" });
  }
  return shift;
}

async function requireOwnOpenShift(
  ctx: MutationCtx,
  id: Id<"shifts">,
  owner: Doc<"users">,
): Promise<Doc<"shifts">> {
  const shift = await ctx.db.get("shifts", id);
  if (!shift || shift.ownerId !== owner._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Shift not found" });
  }
  if (shift.status !== "open") badRequest("This shift is already closed");
  return shift;
}

export const current = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return null;
    const shift = await findOpenShift(ctx, user._id);
    if (!shift) return null;
    const movements = await ctx.db
      .query("cashMovements")
      .withIndex("by_shift", (q) => q.eq("shiftId", shift._id))
      .order("desc")
      .take(MAX_MOVEMENTS);
    return { shift, movements, expectedCashCents: expectedCashCents(shift) };
  },
});

export const open = mutation({
  args: { startingCashCents: v.number() },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx);
    if (!validAmount(args.startingCashCents)) badRequest("Invalid starting cash");
    if (await findOpenShift(ctx, user._id)) badRequest("A shift is already open");
    const last = await ctx.db
      .query("shifts")
      .withIndex("by_owner_and_number", (q) => q.eq("ownerId", user._id))
      .order("desc")
      .first();
    return await ctx.db.insert("shifts", {
      ownerId: user._id,
      number: (last?.number ?? 0) + 1,
      status: "open",
      openedAt: new Date().toISOString(),
      closedAt: null,
      startingCashCents: args.startingCashCents,
      grossSalesCents: 0,
      refundsCents: 0,
      cashPaymentsCents: 0,
      cashRefundsCents: 0,
      cardCents: 0,
      mpesaCents: 0,
      paidInCents: 0,
      paidOutCents: 0,
      actualCashCents: null,
      ...employeeStamp(staff),
    });
  },
});

export const addCashMovement = mutation({
  args: {
    shiftId: v.id("shifts"),
    kind: v.union(v.literal("in"), v.literal("out")),
    amountCents: v.number(),
    comment: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx);
    const shift = await requireOwnOpenShift(ctx, args.shiftId, user);
    if (!validAmount(args.amountCents) || args.amountCents === 0) badRequest("Enter an amount");
    if (args.kind === "out" && args.amountCents > expectedCashCents(shift)) {
      badRequest("Not enough cash in the drawer");
    }
    await ctx.db.insert("cashMovements", {
      shiftId: shift._id,
      kind: args.kind,
      amountCents: args.amountCents,
      comment: args.comment?.trim() || null,
      createdAt: new Date().toISOString(),
    });
    await ctx.db.patch(
      "shifts",
      shift._id,
      args.kind === "in"
        ? { paidInCents: shift.paidInCents + args.amountCents }
        : { paidOutCents: shift.paidOutCents + args.amountCents },
    );
    return null;
  },
});

export const close = mutation({
  args: { shiftId: v.id("shifts"), actualCashCents: v.number() },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx);
    const shift = await requireOwnOpenShift(ctx, args.shiftId, user);
    if (!validAmount(args.actualCashCents)) badRequest("Invalid cash amount");
    await ctx.db.patch("shifts", shift._id, {
      status: "closed",
      closedAt: new Date().toISOString(),
      actualCashCents: args.actualCashCents,
    });
    return { differenceCents: args.actualCashCents - expectedCashCents(shift) };
  },
});
