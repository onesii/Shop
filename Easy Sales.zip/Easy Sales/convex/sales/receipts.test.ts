import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const LINES = [
  { itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 3 },
  { itemId: null, name: "Burger", variantName: "Large", priceCents: 35000, quantity: 1 },
];

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1", name: "Jane" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
  return { t, asUser };
}

describe("charge", () => {
  it("computes total and change server-side and numbers receipts", async () => {
    const { asUser } = await setup();
    const first = await asUser.mutation(api.sales.receipts.charge, {
      lines: LINES,
      paymentMethod: "cash",
      tenderedCents: 100000,
    });
    expect(first.totalCents).toBe(50000);
    expect(first.changeCents).toBe(50000);
    expect(first.number).toBe("1-1001");

    const second = await asUser.mutation(api.sales.receipts.charge, {
      lines: LINES,
      paymentMethod: "card",
      tenderedCents: 0,
    });
    expect(second.changeCents).toBe(0);
    expect(second.number).toBe("1-1002");
  });

  it("saves a retried offline sale only once and keeps its sale time", async () => {
    const { asUser } = await setup();
    const soldAt = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const args = { lines: LINES, paymentMethod: "card" as const, tenderedCents: 0, clientId: "sale-abc", soldAt };
    const first = await asUser.mutation(api.sales.receipts.charge, args);
    const retry = await asUser.mutation(api.sales.receipts.charge, args);
    expect(retry.id).toBe(first.id);
    expect(retry.number).toBe(first.number);
    const detail = await asUser.query(api.sales.receipts.get, { id: first.id });
    expect(detail?.receipt.createdAt).toBe(soldAt);
    const next = await asUser.mutation(api.sales.receipts.charge, { ...args, clientId: "sale-def" });
    expect(next.number).not.toBe(first.number);
  });

  it("rejects cash below the total", async () => {
    const { asUser } = await setup();
    await expect(
      asUser.mutation(api.sales.receipts.charge, {
        lines: LINES,
        paymentMethod: "cash",
        tenderedCents: 1000,
      }),
    ).rejects.toThrow();
  });
});

describe("refund", () => {
  it("allows partial refunds but never more than was sold", async () => {
    const { asUser } = await setup();
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: LINES,
      paymentMethod: "mpesa",
      tenderedCents: 0,
    });
    await asUser.mutation(api.sales.receipts.refund, {
      receiptId: sale.id,
      quantities: [2, 0],
    });
    const detail = await asUser.query(api.sales.receipts.get, { id: sale.id });
    expect(detail?.receipt.refundedCents).toBe(10000);
    expect(detail?.refundedByLine).toEqual([2, 0]);

    await expect(
      asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [2, 0] }),
    ).rejects.toThrow();
  });

  it("blocks refunding another user's receipt", async () => {
    const { t, asUser } = await setup();
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: LINES,
      paymentMethod: "card",
      tenderedCents: 0,
    });
    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    await expect(
      other.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1, 0] }),
    ).rejects.toThrow();
  });
});
