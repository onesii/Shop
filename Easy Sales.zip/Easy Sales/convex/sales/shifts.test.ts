import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const LINE = { itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 2 };

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  return { t, asUser };
}

describe("shifts", () => {
  it("blocks sales while no shift is open", async () => {
    const { asUser } = await setup();
    await expect(
      asUser.mutation(api.sales.receipts.charge, {
        lines: [LINE],
        paymentMethod: "card",
        tenderedCents: 0,
      }),
    ).rejects.toThrow();
  });

  it("allows only one open shift at a time", async () => {
    const { asUser } = await setup();
    await asUser.mutation(api.sales.shifts.open, { startingCashCents: 1000 });
    await expect(
      asUser.mutation(api.sales.shifts.open, { startingCashCents: 1000 }),
    ).rejects.toThrow();
  });

  it("tracks expected cash from sales, refunds and pay in/out", async () => {
    const { asUser } = await setup();
    const shiftId = await asUser.mutation(api.sales.shifts.open, { startingCashCents: 100000 });

    const cashSale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "cash",
      tenderedCents: 20000, // change is not counted as drawer cash
    });
    await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "mpesa",
      tenderedCents: 0,
    });
    await asUser.mutation(api.sales.receipts.refund, {
      receiptId: cashSale.id,
      quantities: [1],
    });
    await asUser.mutation(api.sales.shifts.addCashMovement, {
      shiftId,
      kind: "in",
      amountCents: 3000,
    });
    await asUser.mutation(api.sales.shifts.addCashMovement, {
      shiftId,
      kind: "out",
      amountCents: 1000,
      comment: "Milk",
    });

    const current = await asUser.query(api.sales.shifts.current, {});
    // 1000.00 + 100.00 cash sale - 50.00 refund + 30.00 in - 10.00 out
    expect(current?.expectedCashCents).toBe(107000);
    expect(current?.shift.grossSalesCents).toBe(20000);
    expect(current?.shift.refundsCents).toBe(5000);
    expect(current?.shift.mpesaCents).toBe(10000);
    expect(current?.movements).toHaveLength(2);

    const { differenceCents } = await asUser.mutation(api.sales.shifts.close, {
      shiftId,
      actualCashCents: 106500,
    });
    expect(differenceCents).toBe(-500);
    expect(await asUser.query(api.sales.shifts.current, {})).toBeNull();
  });

  it("rejects paying out more than is in the drawer", async () => {
    const { asUser } = await setup();
    const shiftId = await asUser.mutation(api.sales.shifts.open, { startingCashCents: 1000 });
    await expect(
      asUser.mutation(api.sales.shifts.addCashMovement, { shiftId, kind: "out", amountCents: 5000 }),
    ).rejects.toThrow();
  });

  it("keeps shifts private to their owner", async () => {
    const { t, asUser } = await setup();
    const shiftId = await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    await expect(
      other.mutation(api.sales.shifts.close, { shiftId, actualCashCents: 0 }),
    ).rejects.toThrow();
  });
});
