import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { openTicketLineValidator } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { MAX_TICKET_DISCOUNTS } from "../lib/discounts";
import { findOwnedCustomer } from "../customers";
import { isValidQuantity, MAX_LINE_COMMENT, sumLineTotals } from "../lib/quantity";

const MAX_LINES = 200;
const MAX_OPEN_TICKETS = 200;

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

/** Returns the ticket if it exists and belongs to the user, otherwise null. */
export async function findOwnedTicket(
  ctx: MutationCtx,
  id: Id<"openTickets">,
  owner: Doc<"users">,
): Promise<Doc<"openTickets"> | null> {
  const ticket = await ctx.db.get("openTickets", id);
  return ticket && ticket.ownerId === owner._id ? ticket : null;
}

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("openTickets")
      .withIndex("by_owner_and_updatedAt", (q) => q.eq("ownerId", user._id))
      .order("desc")
      .take(MAX_OPEN_TICKETS);
  },
});

export const save = mutation({
  args: {
    // Present when re-saving a ticket that was reopened
    id: v.optional(v.id("openTickets")),
    name: v.string(),
    comment: v.optional(v.string()),
    lines: v.array(openTicketLineValidator),
    discountIds: v.optional(v.array(v.id("discounts"))),
    customerId: v.optional(v.id("customers")),
  },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx);
    const name = args.name.trim();
    if (!name) badRequest("Give the ticket a name");
    if (name.length > 60) badRequest("Name is too long");
    if (args.lines.length === 0) badRequest("The ticket is empty");
    if (args.lines.length > MAX_LINES) badRequest(`Up to ${MAX_LINES} lines per ticket`);
    if ((args.discountIds?.length ?? 0) > MAX_TICKET_DISCOUNTS) badRequest("Too many discounts");
    for (const l of args.lines) {
      if (!isValidQuantity(l.quantity)) badRequest("Invalid quantity");
      if (!Number.isInteger(l.priceCents) || l.priceCents < 0) badRequest("Invalid price");
      if ((l.comment?.length ?? 0) > MAX_LINE_COMMENT) badRequest("Comment is too long");
    }

    const customer = args.customerId ? await findOwnedCustomer(ctx, args.customerId, user._id) : null;
    const fields = {
      name,
      comment: args.comment?.trim() || null,
      lines: args.lines,
      discountIds: args.discountIds ?? [],
      customerId: customer?._id,
      customerName: customer?.name,
      // Before discounts and taxes; the list only shows it as a guide
      totalCents: sumLineTotals(args.lines),
      updatedAt: new Date().toISOString(),
    };

    // If the ticket was removed elsewhere meanwhile, save it as a new one
    const existing = args.id ? await findOwnedTicket(ctx, args.id, user) : null;
    if (existing) {
      await ctx.db.patch("openTickets", existing._id, fields);
      return existing._id;
    }
    return await ctx.db.insert("openTickets", { ownerId: user._id, ...fields });
  },
});

export const remove = mutation({
  args: { id: v.id("openTickets") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx);
    const ticket = await findOwnedTicket(ctx, args.id, user);
    if (!ticket) throw new ConvexError({ code: "NOT_FOUND", message: "Ticket not found" });
    await ctx.db.delete("openTickets", ticket._id);
    return null;
  },
});
