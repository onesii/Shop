import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { paymentMethod, receiptLineValidator } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { employeeStamp, requireStaff } from "../lib/staff";
import { findOwnedTicket } from "./openTickets";
import { requireOpenShift } from "./shifts";
import { minuteOfDay, recordSalesHour } from "../reports/aggregate";
import { loadSettings, receiptSnapshot } from "../settings";
import { findOwnedCustomer, recordCustomerVisit } from "../customers";
import { computeTaxes } from "../lib/taxes";
import { applySaleStock } from "../inventory/stock";
import { isValidQuantity, MAX_LINE_COMMENT, roundQty, sumLineTotals } from "../lib/quantity";
import { MAX_CLIENT_ID, saleTime } from "../lib/saleTime";
import {
  computeTotals,
  MAX_TICKET_DISCOUNTS,
  proportionalDiscounts,
  type DiscountRule,
} from "../lib/discounts";

const MAX_LINES = 200;
const FIRST_RECEIPT = 1000;

type Line = Doc<"receipts">["lines"][number];

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

function sumLines(lines: Line[]): number {
  return sumLineTotals(lines);
}

function sameLine(a: Line, b: Line): boolean {
  return (
    a.itemId === b.itemId &&
    a.name === b.name &&
    a.variantName === b.variantName &&
    a.priceCents === b.priceCents
  );
}

/** Quantity of `line` already refunded across the given refund receipts. */
function refundedQuantity(line: Line, refunds: Doc<"receipts">[]): number {
  return refunds
    .flatMap((r) => r.lines)
    .filter((l) => sameLine(l, line))
    .reduce((s, l) => roundQty(s + l.quantity), 0);
}

function validateLines(lines: Line[]): void {
  if (lines.length === 0) badRequest("The ticket is empty");
  if (lines.length > MAX_LINES) badRequest(`Up to ${MAX_LINES} lines per ticket`);
  for (const l of lines) {
    if (!isValidQuantity(l.quantity)) badRequest("Invalid quantity");
    if (!Number.isInteger(l.priceCents) || l.priceCents < 0) badRequest("Invalid price");
    if ((l.comment?.length ?? 0) > MAX_LINE_COMMENT) badRequest("Comment is too long");
  }
}

async function nextReceiptNumber(ctx: MutationCtx, ownerId: Id<"users">): Promise<string> {
  const counter = await ctx.db
    .query("receiptCounters")
    .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
    .unique();
  const next = (counter?.lastNumber ?? FIRST_RECEIPT) + 1;
  if (counter) await ctx.db.patch("receiptCounters", counter._id, { lastNumber: next });
  else await ctx.db.insert("receiptCounters", { ownerId, lastNumber: next });
  return `1-${next}`;
}

/** Adds a sale (positive) or refund (negative) to the shift's running totals. */
async function recordOnShift(
  ctx: MutationCtx,
  shift: Doc<"shifts">,
  method: Doc<"receipts">["paymentMethod"],
  amountCents: number,
): Promise<void> {
  const isRefund = amountCents < 0;
  const abs = Math.abs(amountCents);
  await ctx.db.patch("shifts", shift._id, {
    grossSalesCents: shift.grossSalesCents + (isRefund ? 0 : abs),
    refundsCents: shift.refundsCents + (isRefund ? abs : 0),
    cashPaymentsCents: shift.cashPaymentsCents + (method === "cash" && !isRefund ? abs : 0),
    cashRefundsCents: shift.cashRefundsCents + (method === "cash" && isRefund ? abs : 0),
    cardCents: shift.cardCents + (method === "card" ? amountCents : 0),
    mpesaCents: shift.mpesaCents + (method === "mpesa" ? amountCents : 0),
  });
}

async function getOwnedReceipt(
  ctx: MutationCtx,
  id: Id<"receipts">,
  owner: Doc<"users">,
): Promise<Doc<"receipts">> {
  const receipt = await ctx.db.get("receipts", id);
  if (!receipt || receipt.ownerId !== owner._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Receipt not found" });
  }
  return receipt;
}

/** Loads the owner's discounts by id, in the order given. Unknown ids are rejected. */
async function loadDiscountRules(
  ctx: MutationCtx,
  ids: Id<"discounts">[],
  owner: Doc<"users">,
): Promise<DiscountRule[]> {
  if (ids.length > MAX_TICKET_DISCOUNTS) badRequest(`Up to ${MAX_TICKET_DISCOUNTS} discounts per ticket`);
  if (new Set(ids).size !== ids.length) badRequest("A discount can only be applied once");
  const rules: DiscountRule[] = [];
  for (const id of ids) {
    const d = await ctx.db.get("discounts", id);
    if (!d || d.ownerId !== owner._id) {
      throw new ConvexError({ code: "NOT_FOUND", message: "A discount was deleted. Remove it from the ticket." });
    }
    rules.push({ name: d.name, type: d.type, value: d.value });
  }
  return rules;
}

export const charge = mutation({
  args: {
    lines: v.array(receiptLineValidator),
    discountIds: v.optional(v.array(v.id("discounts"))),
    paymentMethod,
    tenderedCents: v.number(),
    mpesaReference: v.optional(v.string()),
    // Saved ticket being paid; it is removed from open tickets on success
    openTicketId: v.optional(v.id("openTickets")),
    customerId: v.optional(v.id("customers")),
    // Set by the device for every sale; a retry with the same id returns the saved receipt
    clientId: v.optional(v.string()),
    // When the sale was rung up (sales made offline sync later)
    soldAt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx);
    if (args.clientId !== undefined && (args.clientId.length === 0 || args.clientId.length > MAX_CLIENT_ID)) {
      badRequest("Invalid sale id");
    }
    const clientId = args.clientId;
    if (clientId) {
      const existing = await ctx.db
        .query("receipts")
        .withIndex("by_owner_and_clientId", (q) => q.eq("ownerId", user._id).eq("clientId", clientId))
        .first();
      if (existing) {
        return {
          id: existing._id,
          number: existing.number,
          totalCents: existing.totalCents,
          changeCents: existing.changeCents,
        };
      }
    }
    if ((args.discountIds?.length ?? 0) > 0 && !staff.permissions.includes("discounts")) {
      throw new ConvexError({ code: "FORBIDDEN", message: "You don't have access to apply discounts" });
    }
    validateLines(args.lines);
    const settings = await loadSettings(ctx, user._id);
    const discountRules = await loadDiscountRules(ctx, args.discountIds ?? [], user);
    const taxRules = settings.taxes
      .filter((t) => t.enabled)
      .map(({ name, rateBps, type }) => ({ name, rateBps, type }));
    const { subtotalCents, discounts, discountCents, taxes, totalCents } = computeTotals(
      sumLines(args.lines),
      discountRules,
      taxRules,
    );
    // Only cash can be over-tendered; card and M-Pesa are charged exactly
    const tenderedCents = args.paymentMethod === "cash" ? args.tenderedCents : totalCents;
    if (!Number.isInteger(tenderedCents) || tenderedCents < totalCents) {
      badRequest("Amount received is less than the total");
    }
    const shift = await requireOpenShift(ctx, user._id);
    const customer = args.customerId ? await findOwnedCustomer(ctx, args.customerId, user._id) : null;
    if (args.customerId && !customer) {
      throw new ConvexError({ code: "NOT_FOUND", message: "That customer was deleted. Remove them from the ticket." });
    }
    if (args.openTicketId) {
      const ticket = await findOwnedTicket(ctx, args.openTicketId, user);
      if (ticket) await ctx.db.delete("openTickets", ticket._id);
    }
    const number = await nextReceiptNumber(ctx, user._id);
    const createdAt = saleTime(args.soldAt, Date.now());
    const stamp = employeeStamp(staff);
    const id = await ctx.db.insert("receipts", {
      ownerId: user._id,
      number,
      kind: "sale",
      createdAt,
      ...(clientId ? { clientId } : {}),
      lines: args.lines,
      totalCents,
      paymentMethod: args.paymentMethod,
      tenderedCents,
      changeCents: tenderedCents - totalCents,
      refundedCents: 0,
      refundOf: null,
      mpesaReference: args.mpesaReference?.trim() || null,
      shiftId: shift._id,
      subtotalCents,
      taxes,
      discounts,
      discountCents,
      ...receiptSnapshot(settings),
      minuteOfDay: minuteOfDay(createdAt),
      ...(customer ? { customerId: customer._id, customerName: customer.name } : {}),
      ...stamp,
    });
    if (customer) await recordCustomerVisit(ctx, customer, totalCents, createdAt);
    await applySaleStock(ctx, user._id, args.lines, "sale", { receiptNumber: number, employeeName: staff.name });
    await recordOnShift(ctx, shift, args.paymentMethod, totalCents);
    await recordSalesHour(ctx, user._id, {
      createdAt,
      kind: "sale",
      totalCents,
      discountCents,
      discounts,
      lines: args.lines,
      paymentMethod: args.paymentMethod,
      employeeId: stamp.employeeId,
    });
    return { id, number, totalCents, changeCents: tenderedCents - totalCents };
  },
});

export const list = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return { page: [], isDone: true, continueCursor: "" };
    return await ctx.db
      .query("receipts")
      .withIndex("by_owner_and_createdAt", (q) => q.eq("ownerId", user._id))
      .order("desc")
      .paginate(args.paginationOpts);
  },
});

export const get = query({
  args: { id: v.id("receipts") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return null;
    const receipt = await ctx.db.get("receipts", args.id);
    if (!receipt || receipt.ownerId !== user._id) return null;
    const related =
      receipt.kind === "sale"
        ? await ctx.db
            .query("receipts")
            .withIndex("by_refundOf", (q) => q.eq("refundOf", receipt._id))
            .take(50)
        : [];
    const original = receipt.refundOf ? await ctx.db.get("receipts", receipt.refundOf) : null;
    // Quantity already refunded per original line index
    const refundedByLine = receipt.lines.map((line) => refundedQuantity(line, related));
    return {
      receipt,
      refunds: related.map((r) => ({ _id: r._id, number: r.number, totalCents: r.totalCents })),
      original: original ? { _id: original._id, number: original.number } : null,
      refundedByLine,
    };
  },
});

export const refund = mutation({
  args: {
    receiptId: v.id("receipts"),
    // Quantity to refund for each line of the original receipt (same order)
    quantities: v.array(v.number()),
  },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "refunds");
    const sale = await getOwnedReceipt(ctx, args.receiptId, user);
    if (sale.kind !== "sale") badRequest("Only sales can be refunded");
    if (args.quantities.length !== sale.lines.length) badRequest("Invalid refund");

    const previous = await ctx.db
      .query("receipts")
      .withIndex("by_refundOf", (q) => q.eq("refundOf", sale._id))
      .take(50);

    const lines: Line[] = [];
    sale.lines.forEach((line, i) => {
      const qty = args.quantities[i];
      if (qty === 0) return;
      const already = refundedQuantity(line, previous);
      if (!isValidQuantity(qty) || qty > roundQty(line.quantity - already)) {
        badRequest(`Cannot refund that many of ${line.name}`);
      }
      lines.push({ ...line, quantity: qty });
    });
    validateLines(lines);

    const shift = await requireOpenShift(ctx, user._id);
    const subtotalCents = sumLines(lines);
    // Refund the same share of the sale's discounts, then tax with the sale's rules
    const share = proportionalDiscounts(
      sale.discounts ?? [],
      sale.subtotalCents ?? sumLines(sale.lines),
      subtotalCents,
    );
    const saleRules = (sale.taxes ?? []).map(({ name, rateBps, type }) => ({ name, rateBps, type }));
    const computed = computeTaxes(subtotalCents - share.discountCents, saleRules);
    const refundsEverything = sale.lines.every(
      (line, i) => roundQty(refundedQuantity(line, previous) + args.quantities[i]) === line.quantity,
    );
    // Closing out the sale returns exactly what is left, so rounding never leaves a cent behind
    const totalCents = refundsEverything ? sale.totalCents - sale.refundedCents : computed.totalCents;
    const discountCents = refundsEverything
      ? (sale.discountCents ?? 0) - previous.reduce((s, r) => s + (r.discountCents ?? 0), 0)
      : share.discountCents;
    const number = await nextReceiptNumber(ctx, user._id);
    const createdAt = new Date().toISOString();
    const stamp = employeeStamp(staff);
    const id = await ctx.db.insert("receipts", {
      ownerId: user._id,
      number,
      kind: "refund",
      createdAt,
      lines,
      totalCents,
      paymentMethod: sale.paymentMethod,
      tenderedCents: totalCents,
      changeCents: 0,
      refundedCents: 0,
      refundOf: sale._id,
      mpesaReference: null,
      shiftId: shift._id,
      subtotalCents,
      taxes: computed.lines,
      discounts: share.lines,
      discountCents,
      storeName: sale.storeName,
      posName: sale.posName,
      receiptFooter: sale.receiptFooter,
      receiptHeader: sale.receiptHeader,
      showCustomerInfo: sale.showCustomerInfo,
      showComments: sale.showComments,
      minuteOfDay: minuteOfDay(createdAt),
      ...(sale.customerId ? { customerId: sale.customerId, customerName: sale.customerName } : {}),
      ...stamp,
    });
    // The customer may have been deleted since; then there is nothing to update
    const customer = sale.customerId ? await findOwnedCustomer(ctx, sale.customerId, user._id) : null;
    if (customer) await recordCustomerVisit(ctx, customer, -totalCents, createdAt);
    await ctx.db.patch("receipts", sale._id, { refundedCents: sale.refundedCents + totalCents });
    await applySaleStock(ctx, user._id, lines, "refund", { receiptNumber: number, employeeName: staff.name });
    await recordOnShift(ctx, shift, sale.paymentMethod, -totalCents);
    await recordSalesHour(ctx, user._id, {
      createdAt,
      kind: "refund",
      totalCents,
      discountCents,
      discounts: share.lines,
      lines,
      paymentMethod: sale.paymentMethod,
      employeeId: stamp.employeeId,
    });
    return id;
  },
});
