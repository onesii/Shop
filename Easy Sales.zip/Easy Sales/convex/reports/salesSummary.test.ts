import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const LINE = { itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 2 };

describe("sales summary", () => {
  it("aggregates sales and refunds into hourly buckets for the owner only", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
    await asUser.mutation(api.users.updateCurrentUser, {});
    await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });

    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "card",
      tenderedCents: 0,
    });
    await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "cash",
      tenderedCents: 10000,
    });
    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1] });

    const now = Date.now();
    const range = {
      startIso: new Date(now - 2 * 3600_000).toISOString(),
      endIso: new Date(now + 2 * 3600_000).toISOString(),
    };
    const rows = await asUser.query(api.reports.salesSummary.hourly, range);
    const sum = (k: "grossSalesCents" | "refundsCents") => rows.reduce((s, r) => s + r[k], 0);
    expect(sum("grossSalesCents")).toBe(20000);
    expect(sum("refundsCents")).toBe(5000);

    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    expect(await other.query(api.reports.salesSummary.hourly, range)).toEqual([]);
  });

  it("rejects ranges longer than a year", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
    await asUser.mutation(api.users.updateCurrentUser, {});
    await expect(
      asUser.query(api.reports.salesSummary.hourly, {
        startIso: "2024-01-01T00:00:00.000Z",
        endIso: "2026-01-01T00:00:00.000Z",
      }),
    ).rejects.toThrow();
  });
});
