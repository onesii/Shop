import { v } from "convex/values";
import { query } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { employeeMatcher, staffCan } from "../lib/staff";
import { employeeFilter, validateRange } from "./range";

const hourArgs = {
  startIso: v.string(),
  endIso: v.string(),
  employeeIds: employeeFilter,
};

/**
 * Hourly sales buckets in [startIso, endIso). There can be one row per employee per hour;
 * the client groups them into local days.
 */
export const hourly = query({
  args: hourArgs,
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "reports"))) return [];
    const rows = await ctx.db
      .query("salesHours")
      .withIndex("by_owner_and_hour_and_employeeId", (q) =>
        q.eq("ownerId", user._id).gte("hour", args.startIso).lt("hour", args.endIso),
      )
      .collect();
    const match = await employeeMatcher(ctx, user._id, args.employeeIds);
    return rows
      .filter((r) => !match || match.matches(r.employeeId))
      .map((r) => ({
        hour: r.hour,
        employeeId: r.employeeId ?? null,
        grossSalesCents: r.grossSalesCents,
        refundsCents: r.refundsCents,
        salesCount: r.salesCount,
        refundsCount: r.refundsCount,
        discountsCents: r.discountsCents ?? 0,
      }));
  },
});

export type HourlyRow = {
  hour: string;
  employeeId: Id<"employees"> | null;
  grossSalesCents: number;
  refundsCents: number;
  salesCount: number;
  refundsCount: number;
  discountsCents: number;
};
