import { v } from "convex/values";
import { internalMutation } from "../_generated/server";
import { internal } from "../_generated/api";
import { minuteOfDay, recordSalesHour } from "./aggregate";

const BATCH = 200;

/**
 * One-off rebuild of all report buckets from existing receipts.
 * "clear" deletes sales hours, "clearItems" item hours, "clearDiscounts" discount hours, then "fill"
 * re-adds every receipt. Each run handles one bounded batch and schedules the next.
 */
export const rebuildSalesHours = internalMutation({
  args: {
    phase: v.union(
      v.literal("clear"),
      v.literal("clearItems"),
      v.literal("clearDiscounts"),
      v.literal("fill"),
    ),
    cursor: v.union(v.string(), v.null()),
  },
  handler: async (ctx, args): Promise<null> => {
    if (args.phase === "clear") {
      const rows = await ctx.db.query("salesHours").take(BATCH);
      for (const r of rows) await ctx.db.delete("salesHours", r._id);
      await ctx.scheduler.runAfter(0, internal.reports.backfill.rebuildSalesHours, {
        phase: rows.length < BATCH ? "clearItems" : "clear",
        cursor: null,
      });
      return null;
    }
    if (args.phase === "clearItems") {
      const rows = await ctx.db.query("itemSalesHours").take(BATCH);
      for (const r of rows) await ctx.db.delete("itemSalesHours", r._id);
      await ctx.scheduler.runAfter(0, internal.reports.backfill.rebuildSalesHours, {
        phase: rows.length < BATCH ? "clearDiscounts" : "clearItems",
        cursor: null,
      });
      return null;
    }
    if (args.phase === "clearDiscounts") {
      const rows = await ctx.db.query("discountSalesHours").take(BATCH);
      for (const r of rows) await ctx.db.delete("discountSalesHours", r._id);
      await ctx.scheduler.runAfter(0, internal.reports.backfill.rebuildSalesHours, {
        phase: rows.length < BATCH ? "fill" : "clearDiscounts",
        cursor: null,
      });
      return null;
    }
    // Smaller pages: each receipt writes one row per line
    const result = await ctx.db
      .query("receipts")
      .paginate({ numItems: 50, cursor: args.cursor });
    for (const r of result.page) {
      await recordSalesHour(ctx, r.ownerId, r);
      if (r.minuteOfDay === undefined) {
        await ctx.db.patch("receipts", r._id, { minuteOfDay: minuteOfDay(r.createdAt) });
      }
    }
    if (!result.isDone) {
      await ctx.scheduler.runAfter(0, internal.reports.backfill.rebuildSalesHours, {
        phase: "fill",
        cursor: result.continueCursor,
      });
    }
    return null;
  },
});
