import { v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { query } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import type { FilterBuilder } from "convex/server";
import type { DataModel } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { employeeMatcher, staffCan } from "../lib/staff";
import { employeeFilter, validateRange } from "./range";

const EMPTY_PAGE = { page: [], isDone: true, continueCursor: "" };

/** Filter expression matching any of the given employee ids (undefined = the owner). */
type EmployeeTable = DataModel["receipts" | "shifts"];

export function anyEmployee(
  q: FilterBuilder<EmployeeTable>,
  ids: (Id<"employees"> | undefined)[],
) {
  if (ids.length === 0) return q.eq(true, false);
  return q.or(...ids.map((id) => q.eq(q.field("employeeId"), id)));
}

/**
 * Receipts created in [startIso, endIso), newest first. The optional window is
 * in UTC minutes of the day (end exclusive) and may wrap past midnight.
 */
export const list = query({
  args: {
    startIso: v.string(),
    endIso: v.string(),
    minuteStart: v.optional(v.number()),
    minuteEnd: v.optional(v.number()),
    employeeIds: employeeFilter,
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "reports"))) return EMPTY_PAGE;
    const { minuteStart, minuteEnd } = args;
    const match = await employeeMatcher(ctx, user._id, args.employeeIds);
    const base = ctx.db
      .query("receipts")
      .withIndex("by_owner_and_createdAt", (q) =>
        q.eq("ownerId", user._id).gte("createdAt", args.startIso).lt("createdAt", args.endIso),
      )
      .order("desc");
    // Filter before paginating so a page is never emptied afterwards
    const byTime =
      minuteStart === undefined || minuteEnd === undefined
        ? base
        : base.filter((q) =>
            minuteStart < minuteEnd
              ? q.and(q.gte(q.field("minuteOfDay"), minuteStart), q.lt(q.field("minuteOfDay"), minuteEnd))
              : q.or(q.gte(q.field("minuteOfDay"), minuteStart), q.lt(q.field("minuteOfDay"), minuteEnd)),
          );
    const filtered = match ? byTime.filter((q) => anyEmployee(q, match.ids)) : byTime;
    return await filtered.paginate(args.paginationOpts);
  },
});
