import { query } from "../_generated/server";
import type { QueryCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { employeeMatcher, staffCan } from "../lib/staff";
import { hourFilter, rangeArgs, validateRange, type RangeArgs } from "./range";

// Item rows grow with items x hours; cap the scan and tell the client when it was cut short
const MAX_ITEM_ROWS = 10000;
const MAX_CATEGORIES = 200;

const PAYMENT_METHODS = ["cash", "card", "mpesa"] as const;

type Money = { grossSalesCents: number; refundsCents: number; discountsCents: number };

const net = (m: Money) => m.grossSalesCents - m.refundsCents - m.discountsCents;

async function itemRows(
  ctx: QueryCtx,
  ownerId: Id<"users">,
  args: RangeArgs,
): Promise<{ rows: Doc<"itemSalesHours">[]; truncated: boolean }> {
  const rows = await ctx.db
    .query("itemSalesHours")
    .withIndex("by_owner_and_hour_and_itemKey_and_employeeId", (q) =>
      q.eq("ownerId", ownerId).gte("hour", args.startIso).lt("hour", args.endIso),
    )
    .take(MAX_ITEM_ROWS + 1);
  const keep = hourFilter(args);
  const match = await employeeMatcher(ctx, ownerId, args.employeeIds);
  return {
    rows: rows
      .slice(0, MAX_ITEM_ROWS)
      .filter((r) => keep(r.hour) && (!match || match.matches(r.employeeId))),
    truncated: rows.length > MAX_ITEM_ROWS,
  };
}

/** Sales by item and variant, best sellers first. Amounts are before tax. */
export const byItem = query({
  args: rangeArgs,
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "reports"))) return { items: [], truncated: false };
    const { rows, truncated } = await itemRows(ctx, user._id, args);

    const byKey = new Map<
      string,
      {
        itemKey: string;
        itemId: Id<"items"> | null;
        name: string;
        variantName: string | null;
        categoryId: Id<"categories"> | null;
        itemsSold: number;
        itemsRefunded: number;
      } & Money
    >();
    for (const r of rows) {
      const cur = byKey.get(r.itemKey);
      if (!cur) {
        byKey.set(r.itemKey, {
          itemKey: r.itemKey,
          itemId: r.itemId,
          name: r.name,
          variantName: r.variantName,
          categoryId: r.categoryId,
          itemsSold: r.itemsSold,
          itemsRefunded: r.itemsRefunded,
          grossSalesCents: r.grossSalesCents,
          refundsCents: r.refundsCents,
          discountsCents: r.discountsCents,
        });
        continue;
      }
      cur.itemsSold += r.itemsSold;
      cur.itemsRefunded += r.itemsRefunded;
      cur.grossSalesCents += r.grossSalesCents;
      cur.refundsCents += r.refundsCents;
      cur.discountsCents += r.discountsCents;
    }
    const items = [...byKey.values()]
      .map((i) => ({ ...i, netSalesCents: net(i) }))
      .sort((a, b) => b.netSalesCents - a.netSalesCents);
    return { items, truncated };
  },
});

/** Sales grouped by the item's category at the time of sale. */
export const byCategory = query({
  args: rangeArgs,
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "reports"))) return { categories: [], truncated: false };
    const { rows, truncated } = await itemRows(ctx, user._id, args);
    const categoryDocs = await ctx.db
      .query("categories")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_CATEGORIES);
    const names = new Map(categoryDocs.map((c) => [c._id, c.name]));

    const byCat = new Map<string, { categoryId: Id<"categories"> | null; itemsSold: number } & Money>();
    for (const r of rows) {
      const key = r.categoryId ?? "none";
      const cur = byCat.get(key) ?? {
        categoryId: r.categoryId,
        itemsSold: 0,
        grossSalesCents: 0,
        refundsCents: 0,
        discountsCents: 0,
      };
      cur.itemsSold += r.itemsSold - r.itemsRefunded;
      cur.grossSalesCents += r.grossSalesCents;
      cur.refundsCents += r.refundsCents;
      cur.discountsCents += r.discountsCents;
      byCat.set(key, cur);
    }
    const categories = [...byCat.values()]
      .map((c) => ({
        ...c,
        // Deleted categories fall back to "No category"
        name: c.categoryId ? (names.get(c.categoryId) ?? "No category") : "No category",
        netSalesCents: net(c),
      }))
      .sort((a, b) => b.netSalesCents - a.netSalesCents);
    return { categories, truncated };
  },
});

/** Sales and refunds per payment method. Amounts are what customers actually paid (after tax). */
export const byPaymentType = query({
  args: rangeArgs,
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "reports"))) return [];
    const rows = await ctx.db
      .query("salesHours")
      .withIndex("by_owner_and_hour_and_employeeId", (q) =>
        q.eq("ownerId", user._id).gte("hour", args.startIso).lt("hour", args.endIso),
      )
      .collect();
    const hourOk = hourFilter(args);
    const match = await employeeMatcher(ctx, user._id, args.employeeIds);
    const keep = (r: Doc<"salesHours">) => hourOk(r.hour) && (!match || match.matches(r.employeeId));
    return PAYMENT_METHODS.map((method) => {
      const t = { salesCount: 0, salesCents: 0, refundsCount: 0, refundsCents: 0 };
      for (const r of rows) {
        const p = r.payments?.[method];
        if (!p || !keep(r)) continue;
        t.salesCount += p.salesCount;
        t.salesCents += p.salesCents;
        t.refundsCount += p.refundsCount;
        t.refundsCents += p.refundsCents;
      }
      return { method, ...t, netCents: t.salesCents - t.refundsCents };
    });
  },
});

const MAX_DISCOUNT_ROWS = 5000;

/** Discounts given, grouped by discount name. Amounts are net of refunds. */
export const byDiscount = query({
  args: rangeArgs,
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "reports"))) return { discounts: [], truncated: false };
    const rows = await ctx.db
      .query("discountSalesHours")
      .withIndex("by_owner_and_hour_and_name_and_employeeId", (q) =>
        q.eq("ownerId", user._id).gte("hour", args.startIso).lt("hour", args.endIso),
      )
      .take(MAX_DISCOUNT_ROWS + 1);
    const hourOk = hourFilter(args);
    const match = await employeeMatcher(ctx, user._id, args.employeeIds);
    const byName = new Map<string, { name: string; timesApplied: number; amountCents: number }>();
    for (const r of rows.slice(0, MAX_DISCOUNT_ROWS)) {
      if (!hourOk(r.hour) || (match && !match.matches(r.employeeId))) continue;
      const cur = byName.get(r.name) ?? { name: r.name, timesApplied: 0, amountCents: 0 };
      cur.timesApplied += r.timesApplied;
      cur.amountCents += r.amountCents;
      byName.set(r.name, cur);
    }
    const discounts = [...byName.values()].sort((a, b) => b.amountCents - a.amountCents);
    return { discounts, truncated: rows.length > MAX_DISCOUNT_ROWS };
  },
});
