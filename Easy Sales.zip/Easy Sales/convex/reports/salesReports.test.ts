import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const RANGE = { startIso: "2000-01-01T00:00:00.000Z", endIso: "2000-12-31T00:00:00.000Z" };

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
  const drinks = await asUser.mutation(api.catalog.categories.create, { name: "Drinks", color: "blue" });
  const soda = await asUser.mutation(api.catalog.items.create, {
    name: "Soda",
    categoryId: drinks,
    priceCents: 5000,
    color: "red",
    variants: [],
  });
  return { t, asUser, soda };
}

// Reports use the current hour, so query a range around now
function nowRange() {
  const now = Date.now();
  return {
    startIso: new Date(now - 2 * 3600_000).toISOString(),
    endIso: new Date(now + 2 * 3600_000).toISOString(),
  };
}

describe("sales reports", () => {
  it("totals items, categories and payment types including discounts and refunds", async () => {
    const { asUser, soda } = await setup();
    const tenOff = await asUser.mutation(api.catalog.discounts.create, {
      name: "Ten off",
      type: "percent",
      value: 1000,
    });
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [
        { itemId: soda, name: "Soda", variantName: null, priceCents: 5000, quantity: 2 },
        { itemId: null, name: "Bag", variantName: null, priceCents: 10000, quantity: 1 },
      ],
      discountIds: [tenOff],
      paymentMethod: "cash",
      tenderedCents: 20000,
    });
    // 20,000 subtotal - 10% = 18,000 (no taxes configured)
    expect(sale.totalCents).toBe(18000);

    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1, 0] });

    const range = nowRange();
    const { items } = await asUser.query(api.reports.salesReports.byItem, range);
    const sodaRow = items.find((i) => i.name === "Soda");
    expect(sodaRow).toMatchObject({
      itemsSold: 2,
      itemsRefunded: 1,
      grossSalesCents: 10000,
      refundsCents: 5000,
      discountsCents: 500, // 1,000 given on the sale, 500 returned with the refund
      netSalesCents: 4500,
    });

    const { categories } = await asUser.query(api.reports.salesReports.byCategory, range);
    expect(categories.find((c) => c.name === "Drinks")?.netSalesCents).toBe(4500);
    expect(categories.find((c) => c.name === "No category")?.netSalesCents).toBe(9000);

    const payments = await asUser.query(api.reports.salesReports.byPaymentType, range);
    const cash = payments.find((p) => p.method === "cash");
    expect(cash).toMatchObject({ salesCount: 1, salesCents: 18000, refundsCount: 1, refundsCents: 4500 });
    expect(cash?.netCents).toBe(13500);

    const hours = await asUser.query(api.reports.salesSummary.hourly, range);
    const total = hours.reduce((s, h) => s + h.grossSalesCents - h.refundsCents - h.discountsCents, 0);
    expect(total).toBe(13500);
  });

  it("only returns the signed-in owner's data", async () => {
    const { t, asUser, soda } = await setup();
    await asUser.mutation(api.sales.receipts.charge, {
      lines: [{ itemId: soda, name: "Soda", variantName: null, priceCents: 5000, quantity: 1 }],
      paymentMethod: "card",
      tenderedCents: 0,
    });
    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    const { items } = await other.query(api.reports.salesReports.byItem, nowRange());
    expect(items).toEqual([]);
  });

  it("rejects ranges longer than a year", async () => {
    const { asUser } = await setup();
    await expect(
      asUser.query(api.reports.salesReports.byItem, {
        startIso: RANGE.startIso,
        endIso: "2002-01-01T00:00:00.000Z",
      }),
    ).rejects.toThrow();
  });
});
