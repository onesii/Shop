import { v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { query } from "../_generated/server";
import { getCurrentUser } from "../lib/auth";
import { employeeMatcher, staffCan } from "../lib/staff";
import { expectedCashCents } from "../sales/shifts";
import { employeeFilter, validateRange } from "./range";
import { anyEmployee } from "./receiptsReport";

/** Shifts opened in [startIso, endIso), newest first, with their expected cash. */
export const list = query({
  args: {
    startIso: v.string(),
    endIso: v.string(),
    employeeIds: employeeFilter,
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "reports"))) return { page: [], isDone: true, continueCursor: "" };
    const match = await employeeMatcher(ctx, user._id, args.employeeIds);
    const base = ctx.db
      .query("shifts")
      .withIndex("by_owner_and_openedAt", (q) =>
        q.eq("ownerId", user._id).gte("openedAt", args.startIso).lt("openedAt", args.endIso),
      )
      .order("desc");
    const results = await (match ? base.filter((q) => anyEmployee(q, match.ids)) : base).paginate(
      args.paginationOpts,
    );
    return {
      ...results,
      page: results.page.map((s) => ({ ...s, expectedCashCents: expectedCashCents(s) })),
    };
  },
});
