import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { allocateProportionally, itemKey } from "../lib/reportMath";
import { lineTotalCents, roundQty } from "../lib/quantity";

type PaymentMethod = Doc<"receipts">["paymentMethod"];
type PaymentTotals = NonNullable<Doc<"salesHours">["payments"]>;

type ReportedReceipt = Pick<
  Doc<"receipts">,
  "createdAt" | "kind" | "totalCents" | "discountCents" | "discounts" | "lines" | "paymentMethod" | "employeeId"
>;

const EMPTY_PAYMENT = { salesCount: 0, salesCents: 0, refundsCount: 0, refundsCents: 0 };

/** Start of the UTC hour containing the given ISO timestamp. */
export function hourKey(iso: string): string {
  const d = new Date(iso);
  d.setUTCMinutes(0, 0, 0);
  return d.toISOString();
}

function addPayment(
  current: PaymentTotals | undefined,
  method: PaymentMethod,
  isSale: boolean,
  amountCents: number,
): PaymentTotals {
  const base = current ?? { cash: EMPTY_PAYMENT, card: EMPTY_PAYMENT, mpesa: EMPTY_PAYMENT };
  const m = base[method];
  return {
    ...base,
    [method]: {
      salesCount: m.salesCount + (isSale ? 1 : 0),
      salesCents: m.salesCents + (isSale ? amountCents : 0),
      refundsCount: m.refundsCount + (isSale ? 0 : 1),
      refundsCents: m.refundsCents + (isSale ? 0 : amountCents),
    },
  };
}

/** Adds a sale or refund receipt to its hourly sales bucket (totals and payment types). */
async function recordHourTotals(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  hour: string,
  receipt: ReportedReceipt,
): Promise<void> {
  const isSale = receipt.kind === "sale";
  // Gross is before discounts, refunds give back their share of the discount
  const discount = receipt.discountCents ?? 0;
  const gross = isSale ? receipt.totalCents + discount : 0;
  const refunds = isSale ? 0 : receipt.totalCents + discount;
  const discounts = isSale ? discount : -discount;
  const bucket = await ctx.db
    .query("salesHours")
    .withIndex("by_owner_and_hour_and_employeeId", (q) =>
      q.eq("ownerId", ownerId).eq("hour", hour).eq("employeeId", receipt.employeeId),
    )
    .unique();
  const payments = addPayment(bucket?.payments, receipt.paymentMethod, isSale, receipt.totalCents);
  if (!bucket) {
    await ctx.db.insert("salesHours", {
      ownerId,
      hour,
      grossSalesCents: gross,
      refundsCents: refunds,
      discountsCents: discounts,
      salesCount: isSale ? 1 : 0,
      refundsCount: isSale ? 0 : 1,
      payments,
      ...(receipt.employeeId ? { employeeId: receipt.employeeId } : {}),
    });
    return;
  }
  await ctx.db.patch("salesHours", bucket._id, {
    grossSalesCents: bucket.grossSalesCents + gross,
    refundsCents: bucket.refundsCents + refunds,
    discountsCents: (bucket.discountsCents ?? 0) + discounts,
    salesCount: bucket.salesCount + (isSale ? 1 : 0),
    refundsCount: bucket.refundsCount + (isSale ? 0 : 1),
    payments,
  });
}

/** Adds each line of the receipt to its item's hourly bucket. Lines are bounded (MAX_LINES). */
async function recordItemHours(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  hour: string,
  receipt: ReportedReceipt,
): Promise<void> {
  const isSale = receipt.kind === "sale";
  const amounts = receipt.lines.map((l) => lineTotalCents(l.priceCents, l.quantity));
  const lineDiscounts = allocateProportionally(amounts, receipt.discountCents ?? 0);
  // Category is looked up once per item, at the time of sale
  const categories = new Map<Id<"items">, Id<"categories"> | null>();

  for (const [i, line] of receipt.lines.entries()) {
    const key = itemKey(line);
    let categoryId: Id<"categories"> | null = null;
    if (line.itemId) {
      if (!categories.has(line.itemId)) {
        const item = await ctx.db.get("items", line.itemId);
        categories.set(line.itemId, item?.categoryId ?? null);
      }
      categoryId = categories.get(line.itemId) ?? null;
    }
    const delta = {
      itemsSold: isSale ? line.quantity : 0,
      itemsRefunded: isSale ? 0 : line.quantity,
      grossSalesCents: isSale ? amounts[i] : 0,
      refundsCents: isSale ? 0 : amounts[i],
      discountsCents: isSale ? lineDiscounts[i] : -lineDiscounts[i],
    };
    const row = await ctx.db
      .query("itemSalesHours")
      .withIndex("by_owner_and_hour_and_itemKey_and_employeeId", (q) =>
        q.eq("ownerId", ownerId).eq("hour", hour).eq("itemKey", key).eq("employeeId", receipt.employeeId),
      )
      .unique();
    if (!row) {
      await ctx.db.insert("itemSalesHours", {
        ownerId,
        hour,
        itemKey: key,
        itemId: line.itemId,
        name: line.name,
        variantName: line.variantName,
        categoryId,
        ...delta,
        ...(receipt.employeeId ? { employeeId: receipt.employeeId } : {}),
      });
      continue;
    }
    await ctx.db.patch("itemSalesHours", row._id, {
      itemsSold: roundQty(row.itemsSold + delta.itemsSold),
      itemsRefunded: roundQty(row.itemsRefunded + delta.itemsRefunded),
      grossSalesCents: row.grossSalesCents + delta.grossSalesCents,
      refundsCents: row.refundsCents + delta.refundsCents,
      discountsCents: row.discountsCents + delta.discountsCents,
    });
  }
}

/** Adds each ticket discount to its hourly bucket; refunds give back their share. */
async function recordDiscountHours(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  hour: string,
  receipt: ReportedReceipt,
): Promise<void> {
  const isSale = receipt.kind === "sale";
  // Bounded by MAX_TICKET_DISCOUNTS
  for (const d of receipt.discounts ?? []) {
    if (d.amountCents === 0 && !isSale) continue;
    const delta = { timesApplied: isSale ? 1 : 0, amountCents: isSale ? d.amountCents : -d.amountCents };
    const row = await ctx.db
      .query("discountSalesHours")
      .withIndex("by_owner_and_hour_and_name_and_employeeId", (q) =>
        q.eq("ownerId", ownerId).eq("hour", hour).eq("name", d.name).eq("employeeId", receipt.employeeId),
      )
      .unique();
    if (!row) {
      await ctx.db.insert("discountSalesHours", {
        ownerId,
        hour,
        name: d.name,
        ...delta,
        ...(receipt.employeeId ? { employeeId: receipt.employeeId } : {}),
      });
      continue;
    }
    await ctx.db.patch("discountSalesHours", row._id, {
      timesApplied: row.timesApplied + delta.timesApplied,
      amountCents: row.amountCents + delta.amountCents,
    });
  }
}

/** Write-time report aggregation for a new sale or refund receipt. */
export async function recordSalesHour(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  receipt: ReportedReceipt,
): Promise<void> {
  const hour = hourKey(receipt.createdAt);
  await recordHourTotals(ctx, ownerId, hour, receipt);
  await recordItemHours(ctx, ownerId, hour, receipt);
  await recordDiscountHours(ctx, ownerId, hour, receipt);
}

/** UTC minute of the day, stored on receipts for the time-of-day filter. */
export function minuteOfDay(iso: string): number {
  const d = new Date(iso);
  return d.getUTCHours() * 60 + d.getUTCMinutes();
}
