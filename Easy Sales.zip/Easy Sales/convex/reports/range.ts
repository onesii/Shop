import { ConvexError, v } from "convex/values";
import type { Id } from "../_generated/dataModel";

// "owner" stands for the account holder, who may not have an employee row yet
export type EmployeeFilterId = Id<"employees"> | "owner";

/** Report employee filter; omitted = all employees. */
export const employeeFilter = v.optional(v.array(v.union(v.id("employees"), v.literal("owner"))));

// One year of hourly buckets stays well inside Convex's per-query read limits
export const MAX_RANGE_MS = 367 * 24 * 60 * 60 * 1000;

export const rangeArgs = {
  startIso: v.string(),
  endIso: v.string(),
  // Optional local hour window (0-24, end exclusive) with the device's UTC offset in minutes
  hourStart: v.optional(v.number()),
  hourEnd: v.optional(v.number()),
  timezoneOffsetMinutes: v.optional(v.number()),
  employeeIds: employeeFilter,
};

export type RangeArgs = {
  startIso: string;
  endIso: string;
  hourStart?: number;
  hourEnd?: number;
  timezoneOffsetMinutes?: number;
  employeeIds?: EmployeeFilterId[];
};

export const MAX_EMPLOYEE_FILTER = 100;

export function validateRange(args: { startIso: string; endIso: string; employeeIds?: unknown[] }): void {
  if ((args.employeeIds?.length ?? 0) > MAX_EMPLOYEE_FILTER) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Too many employees selected" });
  }
  const start = Date.parse(args.startIso);
  const end = Date.parse(args.endIso);
  if (Number.isNaN(start) || Number.isNaN(end) || end <= start || end - start > MAX_RANGE_MS) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Choose a range of up to one year" });
  }
}

/** Filter for the optional local hour window; offset matches Date.getTimezoneOffset(). */
export function hourFilter(args: RangeArgs): (iso: string) => boolean {
  const startH = args.hourStart ?? 0;
  const endH = args.hourEnd ?? 24;
  if (startH <= 0 && endH >= 24) return () => true;
  const offsetMs = (args.timezoneOffsetMinutes ?? 0) * 60 * 1000;
  return (iso) => {
    const localHour = new Date(Date.parse(iso) - offsetMs).getUTCHours();
    return localHour >= startH && localHour < endH;
  };
}
