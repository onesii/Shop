import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const LINE = { itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 2 };
const PAGE = { numItems: 50, cursor: null };

function nowRange() {
  const now = Date.now();
  return {
    startIso: new Date(now - 2 * 3600_000).toISOString(),
    endIso: new Date(now + 2 * 3600_000).toISOString(),
  };
}

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  await asUser.mutation(api.sales.shifts.open, { startingCashCents: 1000 });
  return { t, asUser };
}

describe("receipts, discounts and shifts reports", () => {
  it("nets refunded discounts and lists receipts in range", async () => {
    const { asUser } = await setup();
    const tenOff = await asUser.mutation(api.catalog.discounts.create, {
      name: "Ten off",
      type: "percent",
      value: 1000,
    });
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      discountIds: [tenOff],
      paymentMethod: "card",
      tenderedCents: 0,
    });
    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1] });

    const range = nowRange();
    const { discounts } = await asUser.query(api.reports.salesReports.byDiscount, range);
    // 1,000 discounted on the sale, half returned with the refund
    expect(discounts).toEqual([{ name: "Ten off", timesApplied: 1, amountCents: 500 }]);

    const receipts = await asUser.query(api.reports.receiptsReport.list, { ...range, paginationOpts: PAGE });
    expect(receipts.page.map((r) => r.kind)).toEqual(["refund", "sale"]);

    const old = await asUser.query(api.reports.receiptsReport.list, {
      startIso: "2000-01-01T00:00:00.000Z",
      endIso: "2000-02-01T00:00:00.000Z",
      paginationOpts: PAGE,
    });
    expect(old.page).toEqual([]);

    // A time-of-day window that excludes the current minute returns nothing
    const now = new Date();
    const minute = now.getUTCHours() * 60 + now.getUTCMinutes();
    const outside = await asUser.query(api.reports.receiptsReport.list, {
      ...range,
      minuteStart: (minute + 120) % 1440,
      minuteEnd: (minute + 180) % 1440,
      paginationOpts: PAGE,
    });
    expect(outside.page).toEqual([]);
    const inside = await asUser.query(api.reports.receiptsReport.list, {
      ...range,
      minuteStart: (minute + 1380) % 1440,
      minuteEnd: (minute + 60) % 1440,
      paginationOpts: PAGE,
    });
    expect(inside.page).toHaveLength(2);
  });

  it("lists shifts with expected cash, owner only", async () => {
    const { t, asUser } = await setup();
    await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "cash",
      tenderedCents: 10000,
    });
    const range = nowRange();
    const shifts = await asUser.query(api.reports.shiftsReport.list, { ...range, paginationOpts: PAGE });
    expect(shifts.page).toHaveLength(1);
    expect(shifts.page[0].expectedCashCents).toBe(11000);

    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    const theirs = await other.query(api.reports.shiftsReport.list, { ...range, paginationOpts: PAGE });
    expect(theirs.page).toEqual([]);
  });
});
