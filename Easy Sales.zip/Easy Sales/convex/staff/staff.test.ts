import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const LINE = { itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 1 };

function nowRange() {
  const now = Date.now();
  return {
    startIso: new Date(now - 2 * 3600_000).toISOString(),
    endIso: new Date(now + 2 * 3600_000).toISOString(),
  };
}

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|owner", name: "Wanjiku" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  return { t, asUser };
}

/** Owner sets a PIN and adds a cashier; the owner stays unlocked. */
async function withCashier() {
  const ctx = await setup();
  await ctx.asUser.mutation(api.staff.employees.update, { id: "owner", name: "Wanjiku", pin: "1111" });
  const cashierId = await ctx.asUser.mutation(api.staff.employees.create, {
    name: "Otieno",
    role: "cashier",
    pin: "2222",
  });
  return { ...ctx, cashierId };
}

describe("employees and access", () => {
  it("lets a single-person store work without a PIN", async () => {
    const { asUser } = await setup();
    const current = await asUser.query(api.staff.session.current, {});
    expect(current?.staff?.role).toBe("owner");
    expect(current?.canLock).toBe(false);
    await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
  });

  it("requires the owner's PIN before adding staff", async () => {
    const { asUser } = await setup();
    await expect(
      asUser.mutation(api.staff.employees.create, { name: "Otieno", role: "cashier", pin: "2222" }),
    ).rejects.toThrow(/PIN/);
  });

  it("rejects a PIN another employee already uses", async () => {
    const { asUser } = await withCashier();
    await expect(
      asUser.mutation(api.staff.employees.create, { name: "Achieng", role: "cashier", pin: "2222" }),
    ).rejects.toThrow(/already uses/);
  });

  it("locks the POS and unlocks only with a valid PIN", async () => {
    const { asUser } = await withCashier();
    await asUser.mutation(api.staff.session.lock, {});
    expect((await asUser.query(api.staff.session.current, {}))?.staff).toBeNull();
    await expect(asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 })).rejects.toThrow(/locked/);

    expect(await asUser.mutation(api.staff.session.unlock, { pin: "9999" })).toEqual({ ok: false, message: "Wrong PIN" });
    const ok = await asUser.mutation(api.staff.session.unlock, { pin: "2222" });
    expect(ok).toEqual({ ok: true, name: "Otieno" });
    expect((await asUser.query(api.staff.session.current, {}))?.staff?.role).toBe("cashier");
  });

  it("pauses unlocking after too many wrong PINs", async () => {
    const { asUser } = await withCashier();
    await asUser.mutation(api.staff.session.lock, {});
    for (let i = 0; i < 5; i++) await asUser.mutation(api.staff.session.unlock, { pin: "0000" });
    const res = await asUser.mutation(api.staff.session.unlock, { pin: "2222" });
    expect(res.ok).toBe(false);
  });

  it("enforces access rights for a cashier", async () => {
    const { asUser } = await withCashier();
    await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
    await asUser.mutation(api.staff.session.lock, {});
    await asUser.mutation(api.staff.session.unlock, { pin: "2222" });

    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "card",
      tenderedCents: 0,
    });
    // Cashiers can't refund, edit items, change settings, see reports or manage staff by default
    await expect(asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1] })).rejects.toThrow(
      /access/,
    );
    await expect(
      asUser.mutation(api.catalog.categories.create, { name: "Drinks", color: "blue" }),
    ).rejects.toThrow(/access/);
    await expect(
      asUser.mutation(api.staff.employees.create, { name: "X", role: "cashier", pin: "3333" }),
    ).rejects.toThrow(/access/);
    await expect(asUser.mutation(api.staff.accessRights.update, { manager: [], cashier: ["refunds"] })).rejects.toThrow();
    expect(await asUser.query(api.reports.salesSummary.hourly, nowRange())).toEqual([]);

    // The owner grants refunds; now it works
    await asUser.mutation(api.staff.session.unlock, { pin: "1111" });
    await asUser.mutation(api.staff.accessRights.update, { manager: [], cashier: ["refunds"] });
    await asUser.mutation(api.staff.session.unlock, { pin: "2222" });
    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1] });
  });

  it("stamps sales with the employee and filters reports by employee", async () => {
    const { asUser, cashierId } = await withCashier();
    await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
    // Owner sells one
    await asUser.mutation(api.sales.receipts.charge, { lines: [LINE], paymentMethod: "card", tenderedCents: 0 });
    // Cashier sells two
    await asUser.mutation(api.staff.session.unlock, { pin: "2222" });
    for (let i = 0; i < 2; i++) {
      await asUser.mutation(api.sales.receipts.charge, { lines: [LINE], paymentMethod: "card", tenderedCents: 0 });
    }
    await asUser.mutation(api.staff.session.unlock, { pin: "1111" });

    const range = nowRange();
    const sum = (rows: { grossSalesCents: number }[]) => rows.reduce((s, r) => s + r.grossSalesCents, 0);
    expect(sum(await asUser.query(api.reports.salesSummary.hourly, range))).toBe(15000);
    expect(sum(await asUser.query(api.reports.salesSummary.hourly, { ...range, employeeIds: [cashierId] }))).toBe(10000);
    expect(sum(await asUser.query(api.reports.salesSummary.hourly, { ...range, employeeIds: ["owner"] }))).toBe(5000);

    const page = { numItems: 50, cursor: null };
    const theirs = await asUser.query(api.reports.receiptsReport.list, {
      ...range,
      employeeIds: [cashierId],
      paginationOpts: page,
    });
    expect(theirs.page).toHaveLength(2);
    expect(theirs.page.every((r) => r.employeeName === "Otieno")).toBe(true);
    const { items } = await asUser.query(api.reports.salesReports.byItem, { ...range, employeeIds: ["owner"] });
    expect(items[0]?.itemsSold).toBe(1);
  });

  it("tracks clock in and out on timecards", async () => {
    const { asUser } = await withCashier();
    await asUser.mutation(api.staff.session.unlock, { pin: "2222" });
    await asUser.mutation(api.staff.timecards.clockIn, {});
    await expect(asUser.mutation(api.staff.timecards.clockIn, {})).rejects.toThrow(/already/);
    expect((await asUser.query(api.staff.timecards.myStatus, {}))?.clockedInAt).not.toBeNull();
    await asUser.mutation(api.staff.timecards.clockOut, {});

    await asUser.mutation(api.staff.session.unlock, { pin: "1111" });
    const cards = await asUser.query(api.staff.timecards.list, {
      ...nowRange(),
      paginationOpts: { numItems: 50, cursor: null },
    });
    expect(cards.page).toHaveLength(1);
    expect(cards.page[0].employeeName).toBe("Otieno");
  });

  it("keeps employees private to their store", async () => {
    const { t, cashierId } = await withCashier();
    const other = t.withIdentity({ tokenIdentifier: "test|other" });
    await other.mutation(api.users.updateCurrentUser, {});
    await expect(other.mutation(api.staff.employees.remove, { id: cashierId })).rejects.toThrow();
    // The other store's owner never sees these employees
    const list = await other.query(api.staff.employees.list, {});
    expect(list.map((e) => e.role)).toEqual(["owner"]);
  });
});
