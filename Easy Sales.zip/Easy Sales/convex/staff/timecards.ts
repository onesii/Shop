import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "../_generated/server";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { timecardError, workedMinutes } from "../lib/timecards";
import {
  currentStaff,
  ensureOwnerEmployee,
  findOwnerEmployee,
  requireStaff,
  staffCan,
  type Staff,
} from "../lib/staff";
import { employeeFilter, validateRange } from "../reports/range";

const EMPTY_PAGE = { page: [], isDone: true, continueCursor: "" };
// Bounded scan for the total hours report
const MAX_TOTAL_ROWS = 5000;

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

async function staffEmployee(ctx: MutationCtx, user: Doc<"users">, staff: Staff): Promise<Doc<"employees">> {
  if (staff.employeeId) {
    const e = await ctx.db.get("employees", staff.employeeId);
    if (e) return e;
  }
  return await ensureOwnerEmployee(ctx, user);
}

async function openCard(ctx: MutationCtx, employeeId: Id<"employees">): Promise<Doc<"timecards"> | null> {
  return await ctx.db
    .query("timecards")
    .withIndex("by_employee_and_clockOut", (q) => q.eq("employeeId", employeeId).eq("clockOut", null))
    .first();
}

/** Clock-in state of the person on the POS. */
export const myStatus = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return null;
    const staff = await currentStaff(ctx, user);
    if (!staff) return null;
    const employeeId = staff.employeeId ?? (await findOwnerEmployee(ctx, user._id))?._id;
    if (!employeeId) return { clockedInAt: null };
    const open = await ctx.db
      .query("timecards")
      .withIndex("by_employee_and_clockOut", (q) => q.eq("employeeId", employeeId).eq("clockOut", null))
      .first();
    return { clockedInAt: open?.clockIn ?? null };
  },
});

export const clockIn = mutation({
  args: {},
  handler: async (ctx) => {
    const { user, staff } = await requireStaff(ctx);
    const employee = await staffEmployee(ctx, user, staff);
    if (await openCard(ctx, employee._id)) badRequest("You are already clocked in");
    await ctx.db.insert("timecards", {
      ownerId: user._id,
      employeeId: employee._id,
      employeeName: employee.name,
      clockIn: new Date().toISOString(),
      clockOut: null,
    });
    return null;
  },
});

export const clockOut = mutation({
  args: {},
  handler: async (ctx) => {
    const { user, staff } = await requireStaff(ctx);
    const employee = await staffEmployee(ctx, user, staff);
    const card = await openCard(ctx, employee._id);
    if (!card) badRequest("You are not clocked in");
    const clockOut = new Date().toISOString();
    await ctx.db.patch("timecards", card._id, { clockOut });
    return { minutes: workedMinutes(card.clockIn, clockOut) };
  },
});

async function resolveFilter(
  ctx: QueryCtx,
  ownerId: Id<"users">,
  ids: (Id<"employees"> | "owner")[] | undefined,
): Promise<Set<Id<"employees">> | null> {
  if (!ids) return null;
  const owner = await findOwnerEmployee(ctx, ownerId);
  return new Set(ids.flatMap((id) => (id === "owner" ? (owner ? [owner._id] : []) : [id])));
}

/** Timecards with clock in inside [startIso, endIso), newest first. */
export const list = query({
  args: {
    startIso: v.string(),
    endIso: v.string(),
    employeeIds: employeeFilter,
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "employees"))) return EMPTY_PAGE;
    const filter = await resolveFilter(ctx, user._id, args.employeeIds);
    const base = ctx.db
      .query("timecards")
      .withIndex("by_owner_and_clockIn", (q) =>
        q.eq("ownerId", user._id).gte("clockIn", args.startIso).lt("clockIn", args.endIso),
      )
      .order("desc");
    const ids = filter ? [...filter] : null;
    const filtered = ids
      ? base.filter((q) => (ids.length === 0 ? false : q.or(...ids.map((id) => q.eq(q.field("employeeId"), id)))))
      : base;
    return await filtered.paginate(args.paginationOpts);
  },
});

/** Hours worked per employee in the range (closed timecards only). */
export const totals = query({
  args: { startIso: v.string(), endIso: v.string(), employeeIds: employeeFilter },
  handler: async (ctx, args) => {
    validateRange(args);
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "employees"))) return { rows: [], truncated: false };
    const filter = await resolveFilter(ctx, user._id, args.employeeIds);
    const cards = await ctx.db
      .query("timecards")
      .withIndex("by_owner_and_clockIn", (q) =>
        q.eq("ownerId", user._id).gte("clockIn", args.startIso).lt("clockIn", args.endIso),
      )
      .take(MAX_TOTAL_ROWS + 1);
    const byEmployee = new Map<Id<"employees">, { employeeId: Id<"employees">; name: string; minutes: number; cards: number }>();
    for (const c of cards.slice(0, MAX_TOTAL_ROWS)) {
      if (filter && !filter.has(c.employeeId)) continue;
      const cur = byEmployee.get(c.employeeId) ?? { employeeId: c.employeeId, name: c.employeeName, minutes: 0, cards: 0 };
      cur.minutes += workedMinutes(c.clockIn, c.clockOut);
      cur.cards += 1;
      byEmployee.set(c.employeeId, cur);
    }
    const rows = [...byEmployee.values()].sort((a, b) => b.minutes - a.minutes);
    return { rows, truncated: cards.length > MAX_TOTAL_ROWS };
  },
});

function checkCard(clockIn: string, clockOut: string | null): void {
  const error = timecardError(clockIn, clockOut, Date.now());
  if (error) badRequest(error);
}

export const create = mutation({
  args: { employeeId: v.union(v.id("employees"), v.literal("owner")), clockIn: v.string(), clockOut: v.string() },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "employees");
    const employee =
      args.employeeId === "owner" ? await ensureOwnerEmployee(ctx, user) : await ctx.db.get("employees", args.employeeId);
    if (!employee || employee.ownerId !== user._id) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Employee not found" });
    }
    checkCard(args.clockIn, args.clockOut);
    return await ctx.db.insert("timecards", {
      ownerId: user._id,
      employeeId: employee._id,
      employeeName: employee.name,
      clockIn: new Date(args.clockIn).toISOString(),
      clockOut: new Date(args.clockOut).toISOString(),
    });
  },
});

async function getOwnedCard(ctx: MutationCtx, id: Id<"timecards">, ownerId: Id<"users">): Promise<Doc<"timecards">> {
  const card = await ctx.db.get("timecards", id);
  if (!card || card.ownerId !== ownerId) throw new ConvexError({ code: "NOT_FOUND", message: "Timecard not found" });
  return card;
}

export const update = mutation({
  args: { id: v.id("timecards"), clockIn: v.string(), clockOut: v.union(v.string(), v.null()) },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "employees");
    await getOwnedCard(ctx, args.id, user._id);
    checkCard(args.clockIn, args.clockOut);
    await ctx.db.patch("timecards", args.id, {
      clockIn: new Date(args.clockIn).toISOString(),
      clockOut: args.clockOut === null ? null : new Date(args.clockOut).toISOString(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("timecards") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "employees");
    await getOwnedCard(ctx, args.id, user._id);
    await ctx.db.delete("timecards", args.id);
    return null;
  },
});
