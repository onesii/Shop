import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const LINE = { itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 1 };

/** Owner with a PIN and one cashier, plus a separate account for the cashier's own device. */
async function setup() {
  const t = convexTest(schema, modules);
  const owner = t.withIdentity({ tokenIdentifier: "test|owner", name: "Wanjiku" });
  await owner.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.employees.update, { id: "owner", name: "Wanjiku", pin: "1111" });
  const cashierId = await owner.mutation(api.staff.employees.create, { name: "Otieno", role: "cashier", pin: "2222" });
  const phone = t.withIdentity({ tokenIdentifier: "test|otieno", name: "Otieno O." });
  await phone.mutation(api.users.updateCurrentUser, {});
  return { t, owner, phone, cashierId };
}

async function join() {
  const ctx = await setup();
  const { token } = await ctx.owner.mutation(api.staff.invites.create, { employeeId: ctx.cashierId });
  await ctx.phone.mutation(api.staff.invites.accept, { token });
  return { ...ctx, token };
}

describe("staff invites", () => {
  it("shows invite details before sign-in and rejects unknown links", async () => {
    const { t, owner, cashierId } = await setup();
    const { token } = await owner.mutation(api.staff.invites.create, { employeeId: cashierId });
    expect(await t.query(api.staff.invites.preview, { token })).toMatchObject({ employeeName: "Otieno", role: "cashier" });
    expect(await t.query(api.staff.invites.preview, { token: "nope" })).toBeNull();
  });

  it("lets the invited account work in the owner's store as that employee", async () => {
    const { owner, phone } = await join();
    const current = await phone.query(api.staff.session.current, {});
    expect(current?.staff).toMatchObject({ name: "Otieno", role: "cashier" });
    expect(current?.canLock).toBe(false);

    // Sales from the phone land in the owner's store under the cashier
    await phone.mutation(api.sales.shifts.open, { startingCashCents: 0 });
    await phone.mutation(api.sales.receipts.charge, { lines: [LINE], paymentMethod: "card", tenderedCents: 0 });
    const now = Date.now();
    const list = await owner.query(api.reports.receiptsReport.list, {
      startIso: new Date(now - 3600_000).toISOString(),
      endIso: new Date(now + 3600_000).toISOString(),
      paginationOpts: { numItems: 10, cursor: null },
    });
    expect(list.page.map((r) => r.employeeName)).toEqual(["Otieno"]);
  });

  it("keeps cashier access rights on their own device", async () => {
    const { phone } = await join();
    await expect(phone.mutation(api.catalog.categories.create, { name: "Drinks", color: "blue" })).rejects.toThrow(/access/);
    await expect(
      phone.mutation(api.settings.update, { storeName: "X", posName: "POS 1", receiptFooter: "", taxes: [] }),
    ).rejects.toThrow(/access/);
    // Locking from the phone must not lock the shop's register
    await phone.mutation(api.staff.session.lock, {});
  });

  it("uses each link once and stops access after disconnect", async () => {
    const { t, owner, phone, cashierId, token } = await join();
    const other = t.withIdentity({ tokenIdentifier: "test|stranger" });
    await other.mutation(api.users.updateCurrentUser, {});
    await expect(other.mutation(api.staff.invites.accept, { token })).rejects.toThrow(/expired/);

    await owner.mutation(api.staff.invites.disconnect, { employeeId: cashierId });
    // Back to their own empty store, with no access to the owner's data
    const current = await phone.query(api.staff.session.current, {});
    expect(current?.staff?.role).toBe("owner");
    expect((await phone.query(api.staff.employees.list, {})).map((e) => e.name)).toEqual(["Otieno O."]);
  });

  it("only lets people with employee access create invites", async () => {
    const { phone, cashierId } = await join();
    await expect(phone.mutation(api.staff.invites.create, { employeeId: cashierId })).rejects.toThrow();
  });
});
