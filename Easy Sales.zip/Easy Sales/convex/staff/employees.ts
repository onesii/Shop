import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getCurrentUser } from "../lib/auth";
import { hashPin, isValidPin } from "../lib/access";
import {
  currentStaff,
  ensureOwnerEmployee,
  findOwnerEmployee,
  findSession,
  requireStaff,
  staffCan,
} from "../lib/staff";

const MAX_EMPLOYEES = 200;

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

type ContactFields = { name: string; email?: string; phone?: string };

function cleanContact(args: ContactFields) {
  const name = args.name.trim();
  if (!name) badRequest("Name is required");
  if (name.length > 60) badRequest("Name is too long");
  const email = args.email?.trim().toLowerCase() || null;
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) badRequest("Enter a valid email");
  const phone = args.phone?.trim() || null;
  if (phone && !/^[+\d][\d\s-]{5,19}$/.test(phone)) badRequest("Enter a valid phone number");
  return { name, email, phone };
}

/** Hashes a new PIN and makes sure no other employee in the store uses it. */
async function newPinHash(
  ctx: MutationCtx,
  ownerId: Id<"users">,
  pin: string,
  self: Id<"employees"> | null,
): Promise<string> {
  if (!isValidPin(pin)) badRequest("The PIN must be 4 digits");
  const hash = await hashPin(ownerId, pin);
  const clash = await ctx.db
    .query("employees")
    .withIndex("by_owner_and_pinHash", (q) => q.eq("ownerId", ownerId).eq("pinHash", hash))
    .first();
  if (clash && clash._id !== self) {
    throw new ConvexError({ code: "CONFLICT", message: "Another employee already uses this PIN" });
  }
  return hash;
}

async function getOwnedEmployee(
  ctx: MutationCtx,
  id: Id<"employees">,
  ownerId: Id<"users">,
): Promise<Doc<"employees">> {
  const employee = await ctx.db.get("employees", id);
  if (!employee || employee.ownerId !== ownerId) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Employee not found" });
  }
  return employee;
}

const staffRole = v.union(v.literal("manager"), v.literal("cashier"));

/** Employee list without PINs. "owner" stands in for the owner's row until it exists. */
export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const allowed = (await staffCan(ctx, user, "employees")) || (await staffCan(ctx, user, "reports"));
    if (!allowed) return [];
    const rows = await ctx.db
      .query("employees")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_EMPLOYEES);
    const out = rows.map((e) => ({
      _id: e._id as Id<"employees"> | "owner",
      name: e.name,
      email: e.email,
      phone: e.phone,
      role: e.role,
      hasPin: e.pinHash !== null,
      joined: e.accountId !== undefined,
    }));
    if (!rows.some((e) => e.role === "owner")) {
      out.unshift({
        _id: "owner",
        name: user.name ?? "Owner",
        email: user.email ?? null,
        phone: null,
        role: "owner",
        hasPin: false,
        joined: false,
      });
    }
    // Owner first, then A to Z
    return out.sort((a, b) => (a.role === "owner" ? -1 : b.role === "owner" ? 1 : a.name.localeCompare(b.name)));
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    role: staffRole,
    pin: v.string(),
  },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "employees");
    const owner = await ensureOwnerEmployee(ctx, user);
    // Without an owner PIN the owner could be locked out once staff exist
    if (!owner.pinHash) badRequest("Set your own PIN first, so you can unlock the POS");
    if (args.role === "manager" && staff.role !== "owner") badRequest("Only the owner can add managers");
    const contact = cleanContact(args);
    const pinHash = await newPinHash(ctx, user._id, args.pin, null);
    const id = await ctx.db.insert("employees", { ownerId: user._id, ...contact, role: args.role, pinHash });
    // Whoever added the first employee stays unlocked instead of being locked out
    const session = await findSession(ctx, user._id);
    const unlockedId = staff.employeeId ?? owner._id;
    if (!session) {
      await ctx.db.insert("posSessions", { ownerId: user._id, employeeId: unlockedId, failedAttempts: 0, lockedUntil: null });
    } else if (!session.employeeId) {
      await ctx.db.patch("posSessions", session._id, { employeeId: unlockedId });
    }
    return id;
  },
});

export const update = mutation({
  args: {
    id: v.union(v.id("employees"), v.literal("owner")),
    name: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    // Ignored for the owner
    role: v.optional(staffRole),
    // Omitted = keep the current PIN
    pin: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "employees");
    const employee =
      args.id === "owner" ? await ensureOwnerEmployee(ctx, user) : await getOwnedEmployee(ctx, args.id, user._id);
    if (employee.role === "owner" && staff.role !== "owner") badRequest("Only the owner can edit the owner");
    if (staff.role !== "owner" && (employee.role === "manager" || args.role === "manager")) {
      badRequest("Only the owner can change managers");
    }
    const contact = cleanContact(args);
    const pinHash = args.pin === undefined ? employee.pinHash : await newPinHash(ctx, user._id, args.pin, employee._id);
    const role = employee.role === "owner" ? "owner" : (args.role ?? employee.role);
    await ctx.db.patch("employees", employee._id, { ...contact, role, pinHash });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("employees") },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "employees");
    const employee = await getOwnedEmployee(ctx, args.id, user._id);
    if (employee.role === "owner") badRequest("The owner can't be removed");
    if (employee.role === "manager" && staff.role !== "owner") badRequest("Only the owner can remove managers");
    if (employee._id === staff.employeeId) badRequest("You can't remove yourself");
    // Close any running timecard; receipts, shifts and timecards keep the name snapshot
    const open = await ctx.db
      .query("timecards")
      .withIndex("by_employee_and_clockOut", (q) => q.eq("employeeId", employee._id).eq("clockOut", null))
      .take(10);
    const now = new Date().toISOString();
    for (const t of open) await ctx.db.patch("timecards", t._id, { clockOut: now });
    const session = await findSession(ctx, user._id);
    if (session?.employeeId === employee._id) {
      await ctx.db.patch("posSessions", session._id, { employeeId: null });
    }
    const invites = await ctx.db
      .query("staffInvites")
      .withIndex("by_employee", (q) => q.eq("employeeId", employee._id))
      .take(20);
    for (const i of invites) await ctx.db.delete("staffInvites", i._id);
    await ctx.db.delete("employees", employee._id);
    return null;
  },
});

/** Whether the owner still needs to set a PIN (shown on the employee list). */
export const ownerNeedsPin = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return false;
    const staff = await currentStaff(ctx, user);
    if (staff?.role !== "owner") return false;
    const owner = await findOwnerEmployee(ctx, user._id);
    return !owner?.pinHash;
  },
});
