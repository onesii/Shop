import { v } from "convex/values";
import { mutation, query } from "../_generated/server";
import { getCurrentUser } from "../lib/auth";
import { cleanPermissions, DEFAULT_RIGHTS } from "../lib/access";
import { permission } from "../schema";
import { loadRights, requireStaff } from "../lib/staff";
import { ConvexError } from "convex/values";

export const get = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return DEFAULT_RIGHTS;
    return await loadRights(ctx, user._id);
  },
});

/** Only the owner decides what managers and cashiers may do. */
export const update = mutation({
  args: { manager: v.array(permission), cashier: v.array(permission) },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx);
    if (staff.role !== "owner") {
      throw new ConvexError({ code: "FORBIDDEN", message: "Only the owner can change access rights" });
    }
    const values = { manager: cleanPermissions(args.manager), cashier: cleanPermissions(args.cashier) };
    const existing = await ctx.db
      .query("accessRights")
      .withIndex("by_owner", (q) => q.eq("ownerId", user._id))
      .unique();
    if (existing) await ctx.db.patch("accessRights", existing._id, values);
    else await ctx.db.insert("accessRights", { ownerId: user._id, ...values });
    return null;
  },
});
