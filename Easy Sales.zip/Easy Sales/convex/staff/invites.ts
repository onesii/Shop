import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { getAccount, getCurrentUser, getMembership } from "../lib/auth";
import { loadSettings } from "../settings";
import { requireStaff, staffCan } from "../lib/staff";

const INVITE_DAYS = 7;

function randomToken(): string {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

async function deleteInvites(ctx: MutationCtx, employeeId: Id<"employees">) {
  const rows = await ctx.db
    .query("staffInvites")
    .withIndex("by_employee", (q) => q.eq("employeeId", employeeId))
    .take(20);
  for (const r of rows) await ctx.db.delete("staffInvites", r._id);
}

/** Who may invite or disconnect this employee: managers only by the owner. */
async function requireInviteAccess(ctx: MutationCtx, employeeId: Id<"employees">): Promise<Doc<"employees">> {
  const { user, staff } = await requireStaff(ctx, "employees");
  const employee = await ctx.db.get("employees", employeeId);
  if (!employee || employee.ownerId !== user._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Employee not found" });
  }
  if (employee.role === "owner") {
    throw new ConvexError({ code: "BAD_REQUEST", message: "The owner already has access" });
  }
  if (employee.role === "manager" && staff.role !== "owner") {
    throw new ConvexError({ code: "FORBIDDEN", message: "Only the owner can invite managers" });
  }
  return employee;
}

/** Creates (or replaces) the employee's invite link. Returns the token for the link. */
export const create = mutation({
  args: { employeeId: v.id("employees") },
  handler: async (ctx, args) => {
    const employee = await requireInviteAccess(ctx, args.employeeId);
    if (employee.accountId) {
      throw new ConvexError({ code: "CONFLICT", message: "This employee already joined with their own account" });
    }
    await deleteInvites(ctx, employee._id);
    const token = randomToken();
    const expiresAt = new Date(Date.now() + INVITE_DAYS * 86_400_000).toISOString();
    await ctx.db.insert("staffInvites", { ownerId: employee.ownerId, employeeId: employee._id, token, expiresAt });
    return { token, expiresAt };
  },
});

/** Cancels the invite and signs the employee's own account out of the store. */
export const disconnect = mutation({
  args: { employeeId: v.id("employees") },
  handler: async (ctx, args) => {
    const employee = await requireInviteAccess(ctx, args.employeeId);
    await deleteInvites(ctx, employee._id);
    if (employee.accountId) await ctx.db.patch("employees", employee._id, { accountId: undefined });
    return null;
  },
});

/** The current invite for an employee, for the edit dialog. */
export const forEmployee = query({
  args: { employeeId: v.id("employees") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user || !(await staffCan(ctx, user, "employees"))) return null;
    const employee = await ctx.db.get("employees", args.employeeId);
    if (!employee || employee.ownerId !== user._id) return null;
    const invite = await ctx.db
      .query("staffInvites")
      .withIndex("by_employee", (q) => q.eq("employeeId", employee._id))
      .first();
    return {
      joined: employee.accountId !== undefined,
      invite: invite && invite.expiresAt > new Date().toISOString() ? { token: invite.token, expiresAt: invite.expiresAt } : null,
    };
  },
});

/** Public details for the join page. Works signed out so the employee sees what they're joining. */
export const preview = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const invite = await ctx.db
      .query("staffInvites")
      .withIndex("by_token", (q) => q.eq("token", args.token))
      .unique();
    if (!invite || invite.expiresAt <= new Date().toISOString()) return null;
    const employee = await ctx.db.get("employees", invite.employeeId);
    if (!employee) return null;
    const settings = await loadSettings(ctx, invite.ownerId);
    return { storeName: settings.storeName || "the store", employeeName: employee.name, role: employee.role };
  },
});

export const accept = mutation({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const account = await getAccount(ctx);
    if (!account) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Please sign in to continue" });
    const invite = await ctx.db
      .query("staffInvites")
      .withIndex("by_token", (q) => q.eq("token", args.token))
      .unique();
    if (!invite || invite.expiresAt <= new Date().toISOString()) {
      throw new ConvexError({ code: "NOT_FOUND", message: "This invite link has expired. Ask for a new one." });
    }
    if (invite.ownerId === account._id) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "This is your own store. Send the link to your employee." });
    }
    if (await getMembership(ctx, account)) {
      throw new ConvexError({ code: "CONFLICT", message: "This account already belongs to a store" });
    }
    const employee = await ctx.db.get("employees", invite.employeeId);
    if (!employee) throw new ConvexError({ code: "NOT_FOUND", message: "This invite is no longer valid" });
    await ctx.db.patch("employees", employee._id, { accountId: account._id });
    await ctx.db.delete("staffInvites", invite._id);
    return { name: employee.name };
  },
});

/** Lets invited staff leave the store from their own account. */
export const leave = mutation({
  args: {},
  handler: async (ctx) => {
    const account = await getAccount(ctx);
    if (!account) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Please sign in to continue" });
    const member = await getMembership(ctx, account);
    if (member) await ctx.db.patch("employees", member._id, { accountId: undefined });
    return null;
  },
});
