import { v } from "convex/values";
import { mutation, query } from "../_generated/server";
import { getCurrentUser, requireUser } from "../lib/auth";
import { afterFailedPin, hashPin, isPinLocked, isValidPin } from "../lib/access";
import { currentStaff, findSession, hasStaff, isMemberAccount } from "../lib/staff";

/** Who is on the POS. `locked` means a PIN is needed before anything else. */
export const current = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return null;
    const staff = await currentStaff(ctx, user);
    // Staff on their own account have nothing to lock; locking would lock the shop's register
    const member = await isMemberAccount(ctx);
    const canLock = !member && (await hasStaff(ctx, user._id));
    const session = staff ? null : await findSession(ctx, user._id);
    return { staff, canLock, isMember: member, lockedUntil: session?.lockedUntil ?? null };
  },
});

export const unlock = mutation({
  args: { pin: v.string() },
  handler: async (ctx, args): Promise<{ ok: true; name: string } | { ok: false; message: string }> => {
    const user = await requireUser(ctx);
    if (await isMemberAccount(ctx)) return { ok: false, message: "You're already signed in as yourself" };
    const now = Date.now();
    const session =
      (await findSession(ctx, user._id)) ??
      (await ctx.db.get(
        "posSessions",
        await ctx.db.insert("posSessions", { ownerId: user._id, employeeId: null, failedAttempts: 0, lockedUntil: null }),
      ));
    if (!session) return { ok: false, message: "Please try again" };
    if (isPinLocked(session.lockedUntil, now)) {
      return { ok: false, message: "Too many wrong PINs. Wait a moment and try again." };
    }
    // Wrong PINs are returned, not thrown, so the attempt counter is saved
    const hash = isValidPin(args.pin) ? await hashPin(user._id, args.pin) : null;
    const employee = hash
      ? await ctx.db
          .query("employees")
          .withIndex("by_owner_and_pinHash", (q) => q.eq("ownerId", user._id).eq("pinHash", hash))
          .first()
      : null;
    if (!employee) {
      await ctx.db.patch("posSessions", session._id, afterFailedPin(session.failedAttempts, now));
      return { ok: false, message: "Wrong PIN" };
    }
    await ctx.db.patch("posSessions", session._id, { employeeId: employee._id, failedAttempts: 0, lockedUntil: null });
    return { ok: true, name: employee.name };
  },
});

export const lock = mutation({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    if (await isMemberAccount(ctx)) return null;
    const session = await findSession(ctx, user._id);
    if (session) await ctx.db.patch("posSessions", session._id, { employeeId: null });
    return null;
  },
});
