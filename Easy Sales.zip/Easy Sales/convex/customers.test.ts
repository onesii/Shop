import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const LINE = { itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 2 };

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
  return { t, asUser };
}

describe("customers", () => {
  it("tracks visits and total spent, net of refunds", async () => {
    const { asUser } = await setup();
    const id = await asUser.mutation(api.customers.create, { name: " Wanjiku ", phone: "0712 345 678" });
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "card",
      tenderedCents: 0,
      customerId: id,
    });
    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1] });

    const customer = await asUser.query(api.customers.get, { id });
    expect(customer).toMatchObject({ name: "Wanjiku", visits: 1, totalSpentCents: 5000 });
    expect(customer?.lastVisitAt).not.toBeNull();

    const receipt = await asUser.query(api.sales.receipts.get, { id: sale.id });
    expect(receipt?.receipt.customerName).toBe("Wanjiku");
    expect(receipt?.refunds).toHaveLength(1);
  });

  it("keeps the name on receipts after the customer is deleted", async () => {
    const { asUser } = await setup();
    const id = await asUser.mutation(api.customers.create, { name: "Otieno" });
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: [LINE],
      paymentMethod: "cash",
      tenderedCents: 10000,
      customerId: id,
    });
    await asUser.mutation(api.customers.remove, { id });
    // Refunding still works without the customer
    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [2] });
    const receipt = await asUser.query(api.sales.receipts.get, { id: sale.id });
    expect(receipt?.receipt.customerName).toBe("Otieno");
    await expect(
      asUser.mutation(api.sales.receipts.charge, {
        lines: [LINE],
        paymentMethod: "cash",
        tenderedCents: 10000,
        customerId: id,
      }),
    ).rejects.toThrow(/deleted/);
  });

  it("rejects bad input and other owners' customers", async () => {
    const { t, asUser } = await setup();
    await expect(asUser.mutation(api.customers.create, { name: "  " })).rejects.toThrow(/Name/);
    await expect(asUser.mutation(api.customers.create, { name: "A", email: "nope" })).rejects.toThrow(/email/);
    const id = await asUser.mutation(api.customers.create, { name: "Akinyi", email: "Akinyi@Example.com" });
    expect((await asUser.query(api.customers.get, { id }))?.email).toBe("akinyi@example.com");

    const other = t.withIdentity({ tokenIdentifier: "test|user2" });
    await other.mutation(api.users.updateCurrentUser, {});
    expect(await other.query(api.customers.get, { id })).toBeNull();
    await expect(other.mutation(api.customers.remove, { id })).rejects.toThrow(/not found/);
    const page = await other.query(api.customers.list, { paginationOpts: { numItems: 10, cursor: null } });
    expect(page.page).toEqual([]);
  });
});
