import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { taxSettingValidator } from "./schema";
import { getCurrentUser } from "./lib/auth";
import { requireStaff } from "./lib/staff";
import { MAX_RATE_BPS } from "./lib/taxes";
import { SETTINGS_LIMITS } from "./lib/settingsLimits";

const MAX_TAXES = 10;

export type StoreSettings = {
  storeName: string;
  posName: string;
  receiptHeader: string;
  receiptFooter: string;
  showCustomerInfo: boolean;
  showComments: boolean;
  taxes: { name: string; rateBps: number; type: "included" | "added"; enabled: boolean }[];
};

export const DEFAULT_SETTINGS: StoreSettings = {
  storeName: "",
  posName: "POS 1",
  receiptHeader: "",
  receiptFooter: "",
  showCustomerInfo: true,
  showComments: true,
  taxes: [],
};

export async function loadSettings(
  ctx: QueryCtx | MutationCtx,
  ownerId: Id<"users">,
): Promise<StoreSettings> {
  const row = await ctx.db
    .query("settings")
    .withIndex("by_owner", (q) => q.eq("ownerId", ownerId))
    .unique();
  if (!row) return DEFAULT_SETTINGS;
  return {
    storeName: row.storeName,
    posName: row.posName,
    receiptHeader: row.receiptHeader ?? "",
    receiptFooter: row.receiptFooter,
    showCustomerInfo: row.showCustomerInfo ?? true,
    showComments: row.showComments ?? true,
    taxes: row.taxes,
  };
}

/** Receipt fields copied onto each receipt, so later edits don't change old receipts. */
export function receiptSnapshot(s: StoreSettings) {
  return {
    storeName: s.storeName,
    posName: s.posName,
    receiptHeader: s.receiptHeader,
    receiptFooter: s.receiptFooter,
    showCustomerInfo: s.showCustomerInfo,
    showComments: s.showComments,
  };
}

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

export const get = query({
  args: {},
  handler: async (ctx): Promise<StoreSettings> => {
    const user = await getCurrentUser(ctx);
    if (!user) return DEFAULT_SETTINGS;
    return await loadSettings(ctx, user._id);
  },
});

export const update = mutation({
  args: {
    storeName: v.string(),
    posName: v.string(),
    receiptFooter: v.string(),
    // Optional so older callers keep the saved values
    receiptHeader: v.optional(v.string()),
    showCustomerInfo: v.optional(v.boolean()),
    showComments: v.optional(v.boolean()),
    taxes: v.array(taxSettingValidator),
  },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "settings");
    const current = await loadSettings(ctx, user._id);
    const storeName = args.storeName.trim();
    const posName = args.posName.trim();
    const receiptFooter = args.receiptFooter.trim();
    const receiptHeader = (args.receiptHeader ?? current.receiptHeader).trim();
    if (storeName.length > SETTINGS_LIMITS.storeName) badRequest("Store name is too long");
    if (!posName) badRequest("POS name is required");
    if (posName.length > SETTINGS_LIMITS.posName) badRequest("POS name is too long");
    if (receiptHeader.length > SETTINGS_LIMITS.receiptHeader) badRequest("Receipt header is too long");
    if (receiptFooter.length > SETTINGS_LIMITS.receiptFooter) badRequest("Receipt footer is too long");
    if (args.taxes.length > MAX_TAXES) badRequest(`Up to ${MAX_TAXES} taxes`);
    const taxes = args.taxes.map((t) => {
      const name = t.name.trim();
      if (!name || name.length > SETTINGS_LIMITS.taxName) badRequest("Each tax needs a short name");
      if (!Number.isInteger(t.rateBps) || t.rateBps < 0 || t.rateBps > MAX_RATE_BPS) {
        badRequest(`Invalid rate for ${name}`);
      }
      return { ...t, name };
    });

    const values = {
      storeName,
      posName,
      receiptHeader,
      receiptFooter,
      showCustomerInfo: args.showCustomerInfo ?? current.showCustomerInfo,
      showComments: args.showComments ?? current.showComments,
      taxes,
    };
    const existing = await ctx.db
      .query("settings")
      .withIndex("by_owner", (q) => q.eq("ownerId", user._id))
      .unique();
    if (existing) await ctx.db.patch("settings", existing._id, values);
    else await ctx.db.insert("settings", { ownerId: user._id, ...values });
    return null;
  },
});
