import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const LINES = [{ itemId: null, name: "Soda", variantName: null, priceCents: 10000, quantity: 1 }];

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  await asUser.mutation(api.sales.shifts.open, { startingCashCents: 0 });
  return asUser;
}

const BASE = { storeName: "Shop", posName: "Till 2", receiptFooter: "Asante!" };

describe("settings", () => {
  it("applies enabled taxes and snapshots settings on the receipt", async () => {
    const asUser = await setup();
    await asUser.mutation(api.settings.update, {
      ...BASE,
      taxes: [
        { name: "Levy", rateBps: 500, type: "added", enabled: true },
        { name: "Off", rateBps: 1000, type: "added", enabled: false },
      ],
    });
    const sale = await asUser.mutation(api.sales.receipts.charge, {
      lines: LINES,
      paymentMethod: "card",
      tenderedCents: 0,
    });
    expect(sale.totalCents).toBe(10500);
    const detail = await asUser.query(api.sales.receipts.get, { id: sale.id });
    expect(detail?.receipt.posName).toBe("Till 2");
    expect(detail?.receipt.taxes).toHaveLength(1);
    // Receipt options default to shown when never set
    expect(detail?.receipt.showCustomerInfo).toBe(true);

    // Full refund returns exactly what was paid, tax included
    await asUser.mutation(api.sales.receipts.refund, { receiptId: sale.id, quantities: [1] });
    const after = await asUser.query(api.sales.receipts.get, { id: sale.id });
    expect(after?.receipt.refundedCents).toBe(10500);
  });

  it("saves receipt options and keeps them when a later save omits them", async () => {
    const asUser = await setup();
    await asUser.mutation(api.settings.update, {
      ...BASE,
      receiptHeader: "  contact us: 0726250239 ",
      showCustomerInfo: false,
      showComments: false,
      taxes: [],
    });
    await asUser.mutation(api.settings.update, { ...BASE, taxes: [] });
    const s = await asUser.query(api.settings.get, {});
    expect(s.receiptHeader).toBe("contact us: 0726250239");
    expect(s.showCustomerInfo).toBe(false);
    expect(s.showComments).toBe(false);
    await expect(
      asUser.mutation(api.settings.update, { ...BASE, receiptHeader: "x".repeat(501), taxes: [] }),
    ).rejects.toThrow();
  });

  it("rejects an empty POS name and out-of-range rates", async () => {
    const asUser = await setup();
    await expect(
      asUser.mutation(api.settings.update, { ...BASE, posName: " ", taxes: [] }),
    ).rejects.toThrow();
    await expect(
      asUser.mutation(api.settings.update, {
        ...BASE,
        taxes: [{ name: "X", rateBps: 20000, type: "added", enabled: true }],
      }),
    ).rejects.toThrow();
  });
});
