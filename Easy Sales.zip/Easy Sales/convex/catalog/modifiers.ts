import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { modifierOptionValidator } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { MAX_MODIFIERS, validateModifier } from "../lib/modifiers";

async function getOwnedModifier(
  ctx: MutationCtx,
  id: Id<"modifiers">,
  owner: Doc<"users">,
): Promise<Doc<"modifiers">> {
  const modifier = await ctx.db.get("modifiers", id);
  if (!modifier || modifier.ownerId !== owner._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Modifier not found" });
  }
  return modifier;
}

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("modifiers")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_MODIFIERS);
  },
});

/** Takes the id as a string from the URL; returns null when it's malformed or not ours. */
export const get = query({
  args: { id: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const id = ctx.db.normalizeId("modifiers", args.id);
    if (!user || !id) return null;
    const modifier = await ctx.db.get("modifiers", id);
    return modifier && modifier.ownerId === user._id ? modifier : null;
  },
});

const fields = { name: v.string(), options: v.array(modifierOptionValidator) };

export const create = mutation({
  args: fields,
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const clean = validateModifier(args.name, args.options);
    return await ctx.db.insert("modifiers", { ownerId: user._id, ...clean });
  },
});

export const update = mutation({
  args: { id: v.id("modifiers"), ...fields },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwnedModifier(ctx, args.id, user);
    const clean = validateModifier(args.name, args.options);
    await ctx.db.patch("modifiers", args.id, clean);
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("modifiers") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwnedModifier(ctx, args.id, user);
    await ctx.db.delete("modifiers", args.id);
    return null;
  },
});
