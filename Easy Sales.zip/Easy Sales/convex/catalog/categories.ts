import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { itemColor } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";

const MAX_CATEGORIES = 200;

async function getOwnedCategory(
  ctx: MutationCtx,
  id: Id<"categories">,
  owner: Doc<"users">,
): Promise<Doc<"categories">> {
  const category = await ctx.db.get("categories", id);
  if (!category || category.ownerId !== owner._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Category not found" });
  }
  return category;
}

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("categories")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_CATEGORIES);
  },
});

export const create = mutation({
  args: { name: v.string(), color: itemColor },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const name = args.name.trim();
    if (!name) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Name is required" });
    }
    return await ctx.db.insert("categories", {
      ownerId: user._id,
      name,
      color: args.color,
    });
  },
});

export const update = mutation({
  args: { id: v.id("categories"), name: v.string(), color: itemColor },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwnedCategory(ctx, args.id, user);
    const name = args.name.trim();
    if (!name) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Name is required" });
    }
    await ctx.db.patch("categories", args.id, { name, color: args.color });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("categories") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwnedCategory(ctx, args.id, user);
    // Stop routing order lines for this category in printer groups
    const groups = await ctx.db
      .query("printerGroups")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(50);
    for (const g of groups) {
      if (g.categoryIds.includes(args.id)) {
        await ctx.db.patch("printerGroups", g._id, { categoryIds: g.categoryIds.filter((c) => c !== args.id) });
      }
    }
    // Move this category's items to "No category"
    const items = await ctx.db
      .query("items")
      .withIndex("by_owner_and_category", (q) =>
        q.eq("ownerId", user._id).eq("categoryId", args.id),
      )
      .take(1000);
    for (const item of items) {
      await ctx.db.patch("items", item._id, { categoryId: null });
    }
    await ctx.db.delete("categories", args.id);
    return null;
  },
});
