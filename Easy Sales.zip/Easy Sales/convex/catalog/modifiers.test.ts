import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  const asOther = t.withIdentity({ tokenIdentifier: "test|user2" });
  await asOther.mutation(api.users.updateCurrentUser, {});
  return { asUser, asOther };
}

describe("modifiers", () => {
  it("trims names and keeps option order", async () => {
    const { asUser } = await setup();
    const id = await asUser.mutation(api.catalog.modifiers.create, {
      name: " Grain base ",
      options: [
        { name: " Rice ", priceCents: 0 },
        { name: "Ugali", priceCents: 5000 },
      ],
    });
    const saved = await asUser.query(api.catalog.modifiers.get, { id });
    expect(saved).toMatchObject({
      name: "Grain base",
      options: [{ name: "Rice", priceCents: 0 }, { name: "Ugali", priceCents: 5000 }],
    });
  });

  it("rejects blank names, blank options and negative prices", async () => {
    const { asUser } = await setup();
    const create = (name: string, options: { name: string; priceCents: number }[]) =>
      asUser.mutation(api.catalog.modifiers.create, { name, options });
    await expect(create("  ", [{ name: "A", priceCents: 0 }])).rejects.toThrow(/cannot be blank/);
    await expect(create("Size", [{ name: " ", priceCents: 0 }])).rejects.toThrow(/cannot be blank/);
    await expect(create("Size", [])).rejects.toThrow(/at least one option/);
    await expect(create("Size", [{ name: "A", priceCents: -1 }])).rejects.toThrow(/valid option price/);
  });

  it("hides and protects modifiers from other stores", async () => {
    const { asUser, asOther } = await setup();
    const id = await asUser.mutation(api.catalog.modifiers.create, {
      name: "Size",
      options: [{ name: "Large", priceCents: 2000 }],
    });
    expect(await asOther.query(api.catalog.modifiers.get, { id })).toBeNull();
    expect(await asOther.query(api.catalog.modifiers.get, { id: "not-an-id" })).toBeNull();
    await expect(asOther.mutation(api.catalog.modifiers.remove, { id })).rejects.toThrow(/not found/);
    await asUser.mutation(api.catalog.modifiers.remove, { id });
    expect(await asUser.query(api.catalog.modifiers.list, {})).toHaveLength(0);
  });
});
