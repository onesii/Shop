import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { soldBy, stockInputValidator, variantValidator, weightUnit } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { stockQtyError } from "../lib/stock";
import { syncItemStock } from "../inventory/stock";
import { validateItem } from "./items";

export const MAX_IMPORT_BATCH = 50;
const MAX_NAME = 200;

const importItemValidator = v.object({
  // Row number in the file, so failures can be found in the spreadsheet
  sourceRow: v.number(),
  name: v.string(),
  category: v.union(v.string(), v.null()),
  soldBy,
  weightUnit: v.optional(weightUnit),
  priceCents: v.union(v.number(), v.null()),
  variants: v.array(variantValidator),
  // null = leave stock as it is (new items are not tracked)
  stock: v.union(v.array(stockInputValidator), v.null()),
});

type ImportItem = typeof importItemValidator.type;
type Failure = { sourceRow: number; name: string; reason: string };

/** Items A to Z with their stock levels, page by page, for the spreadsheet export. */
export const exportPage = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return { page: [], isDone: true, continueCursor: "" };
    const result = await ctx.db
      .query("items")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .paginate(args.paginationOpts);
    const page = await Promise.all(
      result.page.map(async (item) => ({
        item,
        // One level per variant, bounded by MAX_VARIANTS
        levels: await ctx.db
          .query("stockLevels")
          .withIndex("by_item_and_variant", (q) => q.eq("itemId", item._id))
          .take(50),
      })),
    );
    return { ...result, page };
  },
});

/** Problems that would otherwise surface halfway through the writes. */
function stockProblem(item: ImportItem): string | null {
  if (!item.stock) return null;
  const names: (string | null)[] = item.variants.length > 0 ? item.variants.map((x) => x.name.trim()) : [null];
  const seen = new Set<string | null>();
  for (const s of item.stock) {
    const key = s.variantName?.trim() ?? null;
    if (seen.has(key)) return "A variant is listed twice";
    seen.add(key);
    if (!names.includes(key)) return "Stock was entered for a variant that doesn't exist";
    const err = stockQtyError(s.inStock, { allowNegative: true }) ?? (s.lowStock === null ? null : stockQtyError(s.lowStock));
    if (err) return err;
  }
  return null;
}

/** Finds a category by name, creating it the first time it is seen. */
async function categoryId(
  ctx: MutationCtx,
  owner: Doc<"users">,
  name: string | null,
  cache: Map<string, Id<"categories">>,
): Promise<Id<"categories"> | null> {
  const trimmed = name?.trim().slice(0, MAX_NAME);
  if (!trimmed) return null;
  const key = trimmed.toLowerCase();
  const cached = cache.get(key);
  if (cached) return cached;
  const existing = await ctx.db
    .query("categories")
    .withIndex("by_owner_and_name", (q) => q.eq("ownerId", owner._id).eq("name", trimmed))
    .first();
  const id = existing?._id ?? (await ctx.db.insert("categories", { ownerId: owner._id, name: trimmed, color: "gray" }));
  cache.set(key, id);
  return id;
}

/**
 * Imports one batch of items from a spreadsheet. An item whose name already exists
 * is updated; otherwise it is created. Bad rows are reported, the rest are saved.
 */
export const importBatch = mutation({
  args: { items: v.array(importItemValidator) },
  handler: async (ctx, args) => {
    const { user, staff } = await requireStaff(ctx, "items");
    if (args.items.length > MAX_IMPORT_BATCH) {
      throw new ConvexError({ code: "BAD_REQUEST", message: `Import at most ${MAX_IMPORT_BATCH} items at a time` });
    }
    const categories = new Map<string, Id<"categories">>();
    const failures: Failure[] = [];
    let created = 0;
    let updated = 0;

    for (const item of args.items) {
      const name = item.name.trim();
      const fail = (reason: string) => failures.push({ sourceRow: item.sourceRow, name, reason });
      if (!name) {
        fail("Name is required");
        continue;
      }
      if (name.length > MAX_NAME) {
        fail("Name is too long");
        continue;
      }
      const problem = stockProblem(item);
      if (problem) {
        fail(problem);
        continue;
      }
      try {
        const input = {
          name,
          categoryId: await categoryId(ctx, user, item.category, categories),
          priceCents: item.variants.length > 0 ? null : item.priceCents,
          color: "gray" as const,
          variants: item.variants,
          soldBy: item.soldBy,
          weightUnit: item.weightUnit,
        };
        // Reads only, so a rejected item leaves nothing half-saved
        const data = await validateItem(ctx, user, input);
        const existing = await ctx.db
          .query("items")
          .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id).eq("name", data.name))
          .first();
        let id: Id<"items">;
        if (existing) {
          // Keep the colour the owner picked
          await ctx.db.patch("items", existing._id, { ...data, color: existing.color });
          id = existing._id;
          updated += 1;
        } else {
          id = await ctx.db.insert("items", { ownerId: user._id, ...data });
          created += 1;
        }
        const saved = await ctx.db.get("items", id);
        if (saved && item.stock) await syncItemStock(ctx, saved, item.stock, staff.name);
      } catch (err) {
        if (!(err instanceof ConvexError)) throw err;
        const data: unknown = err.data;
        fail(typeof data === "object" && data && "message" in data && typeof data.message === "string" ? data.message : "Invalid item");
      }
    }
    return { created, updated, failures };
  },
});
