import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { itemColor, soldBy, stockInputValidator, variantValidator, weightUnit } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { deleteItemStock, renameItemStock, syncItemStock } from "../inventory/stock";

const LIST_LIMIT = 500;
export const MAX_VARIANTS = 20;

const itemFields = {
  name: v.string(),
  categoryId: v.union(v.id("categories"), v.null()),
  priceCents: v.union(v.number(), v.null()),
  color: itemColor,
  variants: v.array(variantValidator),
  soldBy: v.optional(soldBy),
  weightUnit: v.optional(weightUnit),
};

// Omitted: leave stock as is. null: stop tracking. Array: track with these counts.
const stockArg = { stock: v.optional(v.union(v.array(stockInputValidator), v.null())) };

type ItemInput = {
  name: string;
  categoryId: Id<"categories"> | null;
  priceCents: number | null;
  color: Doc<"items">["color"];
  variants: Doc<"items">["variants"];
  soldBy?: Doc<"items">["soldBy"];
  weightUnit?: Doc<"items">["weightUnit"];
};

export async function validateItem(
  ctx: MutationCtx,
  owner: Doc<"users">,
  input: ItemInput,
): Promise<ItemInput> {
  const name = input.name.trim();
  if (!name) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Name is required" });
  }
  if (input.variants.length > MAX_VARIANTS) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: `Up to ${MAX_VARIANTS} variants allowed`,
    });
  }
  const prices = [input.priceCents, ...input.variants.map((x) => x.priceCents)];
  if (prices.some((p) => p !== null && (p < 0 || !Number.isInteger(p)))) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Invalid price" });
  }
  if (input.categoryId) {
    const category = await ctx.db.get("categories", input.categoryId);
    if (!category || category.ownerId !== owner._id) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Category not found" });
    }
  }
  return {
    ...input,
    // A unit only makes sense for weight items
    weightUnit: input.soldBy === "weight" ? (input.weightUnit ?? "kg") : undefined,
    name,
    variants: input.variants
      .map((x) => ({ name: x.name.trim(), priceCents: x.priceCents }))
      .filter((x) => x.name.length > 0),
  };
}

async function getOwnedItem(
  ctx: MutationCtx,
  id: Id<"items">,
  owner: Doc<"users">,
): Promise<Doc<"items">> {
  const item = await ctx.db.get("items", id);
  if (!item || item.ownerId !== owner._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Item not found" });
  }
  return item;
}

export const list = query({
  args: {
    search: v.optional(v.string()),
    categoryId: v.optional(v.union(v.id("categories"), v.null())),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const search = args.search?.trim();
    if (search) {
      const results = await ctx.db
        .query("items")
        .withSearchIndex("search_name", (q) =>
          q.search("name", search).eq("ownerId", user._id),
        )
        .take(100);
      return args.categoryId === undefined
        ? results
        : results.filter((x) => x.categoryId === args.categoryId);
    }
    const categoryId = args.categoryId;
    if (categoryId !== undefined) {
      return await ctx.db
        .query("items")
        .withIndex("by_owner_and_category", (q) =>
          q.eq("ownerId", user._id).eq("categoryId", categoryId),
        )
        .take(LIST_LIMIT);
    }
    return await ctx.db
      .query("items")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(LIST_LIMIT);
  },
});

/** One item by id, for editing a ticket line. null if missing or not the user's. */
export const get = query({
  args: { id: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    const id = ctx.db.normalizeId("items", args.id);
    if (!user || !id) return null;
    const item = await ctx.db.get("items", id);
    return item && item.ownerId === user._id ? item : null;
  },
});

export const create = mutation({
  args: { ...itemFields, ...stockArg },
  handler: async (ctx, { stock, ...rest }) => {
    const { user, staff } = await requireStaff(ctx, "items");
    const data = await validateItem(ctx, user, rest);
    const id = await ctx.db.insert("items", { ownerId: user._id, ...data });
    const item = await ctx.db.get("items", id);
    if (item && stock) await syncItemStock(ctx, item, stock, staff.name);
    return id;
  },
});

export const update = mutation({
  args: { id: v.id("items"), ...itemFields, ...stockArg },
  handler: async (ctx, { id, stock, ...rest }) => {
    const { user, staff } = await requireStaff(ctx, "items");
    await getOwnedItem(ctx, id, user);
    const data = await validateItem(ctx, user, rest);
    await ctx.db.patch("items", id, data);
    const item = await getOwnedItem(ctx, id, user);
    if (stock === undefined) await renameItemStock(ctx, item);
    else await syncItemStock(ctx, item, stock, staff.name);
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("items") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwnedItem(ctx, args.id, user);
    await deleteItemStock(ctx, args.id);
    await ctx.db.delete("items", args.id);
    return null;
  },
});
