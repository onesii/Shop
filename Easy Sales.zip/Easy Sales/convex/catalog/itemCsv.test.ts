import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const base = { category: null, soldBy: "each" as const, priceCents: 1000, variants: [], stock: null };

async function setup() {
  const t = convexTest(schema, modules);
  const asUser = t.withIdentity({ tokenIdentifier: "test|user1" });
  await asUser.mutation(api.users.updateCurrentUser, {});
  return asUser;
}

describe("item import", () => {
  it("adds new items, updates same-name items and creates categories once", async () => {
    const asUser = await setup();
    await asUser.mutation(api.catalog.items.create, {
      name: "Soda",
      categoryId: null,
      priceCents: 500,
      color: "red",
      variants: [],
    });
    const result = await asUser.mutation(api.catalog.itemCsv.importBatch, {
      items: [
        { ...base, sourceRow: 2, name: "Soda", category: "Drinks", priceCents: 6000 },
        { ...base, sourceRow: 3, name: "Juice", category: "Drinks", stock: [{ variantName: null, inStock: 12, lowStock: 3 }] },
        { ...base, sourceRow: 4, name: "Sugar", soldBy: "weight", weightUnit: "g", priceCents: 20 },
      ],
    });
    expect(result).toEqual({ created: 2, updated: 1, failures: [] });

    const items = await asUser.query(api.catalog.items.list, {});
    const soda = items.find((i) => i.name === "Soda");
    // Price updated, colour kept
    expect(soda).toMatchObject({ priceCents: 6000, color: "red" });
    expect(items.find((i) => i.name === "Sugar")).toMatchObject({ soldBy: "weight", weightUnit: "g" });
    const categories = await asUser.query(api.catalog.categories.list, {});
    expect(categories.map((c) => c.name)).toEqual(["Drinks"]);
    const levels = await asUser.query(api.inventory.stock.listAll, {});
    expect(levels).toMatchObject([{ itemName: "Juice", inStock: 12, lowStock: 3 }]);
  });

  it("skips invalid rows without saving anything for them", async () => {
    const asUser = await setup();
    const result = await asUser.mutation(api.catalog.itemCsv.importBatch, {
      items: [
        { ...base, sourceRow: 2, name: "  " },
        { ...base, sourceRow: 3, name: "Cake", priceCents: -5 },
        { ...base, sourceRow: 4, name: "Tea", stock: [{ variantName: "Large", inStock: 1, lowStock: null }] },
        { ...base, sourceRow: 5, name: "Milk" },
      ],
    });
    expect(result.created).toBe(1);
    expect(result.failures.map((f) => [f.sourceRow, f.reason])).toEqual([
      [2, "Name is required"],
      [3, "Invalid price"],
      [4, "Stock was entered for a variant that doesn't exist"],
    ]);
    const items = await asUser.query(api.catalog.items.list, {});
    expect(items.map((i) => i.name)).toEqual(["Milk"]);
  });

  it("rejects oversized batches", async () => {
    const asUser = await setup();
    const items = Array.from({ length: 51 }, (_, i) => ({ ...base, sourceRow: i + 2, name: `Item ${i}` }));
    await expect(asUser.mutation(api.catalog.itemCsv.importBatch, { items })).rejects.toThrow(/at most 50/);
  });
});
