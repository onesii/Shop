import { ConvexError, v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { discountType } from "../schema";
import { getCurrentUser } from "../lib/auth";
import { requireStaff } from "../lib/staff";
import { MAX_PERCENT_BPS, type DiscountType } from "../lib/discounts";

const MAX_DISCOUNTS = 200;

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

function validate(name: string, type: DiscountType, value: number): string {
  const trimmed = name.trim();
  if (!trimmed) badRequest("Name is required");
  if (trimmed.length > 60) badRequest("Name is too long");
  if (!Number.isInteger(value) || value <= 0) badRequest("Enter a discount value");
  if (type === "percent" && value > MAX_PERCENT_BPS) badRequest("A discount can't be over 100%");
  return trimmed;
}

async function getOwnedDiscount(
  ctx: MutationCtx,
  id: Id<"discounts">,
  owner: Doc<"users">,
): Promise<Doc<"discounts">> {
  const discount = await ctx.db.get("discounts", id);
  if (!discount || discount.ownerId !== owner._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Discount not found" });
  }
  return discount;
}

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("discounts")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .take(MAX_DISCOUNTS);
  },
});

const fields = { name: v.string(), type: discountType, value: v.number() };

export const create = mutation({
  args: fields,
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    const name = validate(args.name, args.type, args.value);
    return await ctx.db.insert("discounts", {
      ownerId: user._id,
      name,
      type: args.type,
      value: args.value,
    });
  },
});

export const update = mutation({
  args: { id: v.id("discounts"), ...fields },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwnedDiscount(ctx, args.id, user);
    const name = validate(args.name, args.type, args.value);
    await ctx.db.patch("discounts", args.id, { name, type: args.type, value: args.value });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("discounts") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "items");
    await getOwnedDiscount(ctx, args.id, user);
    await ctx.db.delete("discounts", args.id);
    return null;
  },
});
