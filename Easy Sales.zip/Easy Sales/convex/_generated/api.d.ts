/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as catalog_categories from "../catalog/categories.js";
import type * as catalog_discounts from "../catalog/discounts.js";
import type * as catalog_itemCsv from "../catalog/itemCsv.js";
import type * as catalog_items from "../catalog/items.js";
import type * as catalog_modifiers from "../catalog/modifiers.js";
import type * as customers from "../customers.js";
import type * as inventory_inventoryCounts from "../inventory/inventoryCounts.js";
import type * as inventory_purchaseOrders from "../inventory/purchaseOrders.js";
import type * as inventory_stock from "../inventory/stock.js";
import type * as inventory_suppliers from "../inventory/suppliers.js";
import type * as lib_access from "../lib/access.js";
import type * as lib_auth from "../lib/auth.js";
import type * as lib_discounts from "../lib/discounts.js";
import type * as lib_inventoryCounts from "../lib/inventoryCounts.js";
import type * as lib_modifiers from "../lib/modifiers.js";
import type * as lib_purchaseOrders from "../lib/purchaseOrders.js";
import type * as lib_quantity from "../lib/quantity.js";
import type * as lib_reportMath from "../lib/reportMath.js";
import type * as lib_saleTime from "../lib/saleTime.js";
import type * as lib_settingsLimits from "../lib/settingsLimits.js";
import type * as lib_staff from "../lib/staff.js";
import type * as lib_stock from "../lib/stock.js";
import type * as lib_taxes from "../lib/taxes.js";
import type * as lib_timecards from "../lib/timecards.js";
import type * as lib_valuation from "../lib/valuation.js";
import type * as printing_printerGroups from "../printing/printerGroups.js";
import type * as reports_aggregate from "../reports/aggregate.js";
import type * as reports_backfill from "../reports/backfill.js";
import type * as reports_range from "../reports/range.js";
import type * as reports_receiptsReport from "../reports/receiptsReport.js";
import type * as reports_salesReports from "../reports/salesReports.js";
import type * as reports_salesSummary from "../reports/salesSummary.js";
import type * as reports_shiftsReport from "../reports/shiftsReport.js";
import type * as sales_openTickets from "../sales/openTickets.js";
import type * as sales_receipts from "../sales/receipts.js";
import type * as sales_shifts from "../sales/shifts.js";
import type * as settings from "../settings.js";
import type * as staff_accessRights from "../staff/accessRights.js";
import type * as staff_employees from "../staff/employees.js";
import type * as staff_invites from "../staff/invites.js";
import type * as staff_session from "../staff/session.js";
import type * as staff_timecards from "../staff/timecards.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  "catalog/categories": typeof catalog_categories;
  "catalog/discounts": typeof catalog_discounts;
  "catalog/itemCsv": typeof catalog_itemCsv;
  "catalog/items": typeof catalog_items;
  "catalog/modifiers": typeof catalog_modifiers;
  customers: typeof customers;
  "inventory/inventoryCounts": typeof inventory_inventoryCounts;
  "inventory/purchaseOrders": typeof inventory_purchaseOrders;
  "inventory/stock": typeof inventory_stock;
  "inventory/suppliers": typeof inventory_suppliers;
  "lib/access": typeof lib_access;
  "lib/auth": typeof lib_auth;
  "lib/discounts": typeof lib_discounts;
  "lib/inventoryCounts": typeof lib_inventoryCounts;
  "lib/modifiers": typeof lib_modifiers;
  "lib/purchaseOrders": typeof lib_purchaseOrders;
  "lib/quantity": typeof lib_quantity;
  "lib/reportMath": typeof lib_reportMath;
  "lib/saleTime": typeof lib_saleTime;
  "lib/settingsLimits": typeof lib_settingsLimits;
  "lib/staff": typeof lib_staff;
  "lib/stock": typeof lib_stock;
  "lib/taxes": typeof lib_taxes;
  "lib/timecards": typeof lib_timecards;
  "lib/valuation": typeof lib_valuation;
  "printing/printerGroups": typeof printing_printerGroups;
  "reports/aggregate": typeof reports_aggregate;
  "reports/backfill": typeof reports_backfill;
  "reports/range": typeof reports_range;
  "reports/receiptsReport": typeof reports_receiptsReport;
  "reports/salesReports": typeof reports_salesReports;
  "reports/salesSummary": typeof reports_salesSummary;
  "reports/shiftsReport": typeof reports_shiftsReport;
  "sales/openTickets": typeof sales_openTickets;
  "sales/receipts": typeof sales_receipts;
  "sales/shifts": typeof sales_shifts;
  settings: typeof settings;
  "staff/accessRights": typeof staff_accessRights;
  "staff/employees": typeof staff_employees;
  "staff/invites": typeof staff_invites;
  "staff/session": typeof staff_session;
  "staff/timecards": typeof staff_timecards;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
