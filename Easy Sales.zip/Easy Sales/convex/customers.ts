import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { getCurrentUser } from "./lib/auth";
import { requireStaff } from "./lib/staff";

const SEARCH_LIMIT = 30;
const EMPTY_PAGE = { page: [], isDone: true, continueCursor: "" };

function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}

type Fields = { name: string; phone?: string; email?: string; note?: string };

function clean(args: Fields) {
  const name = args.name.trim();
  if (!name) badRequest("Name is required");
  if (name.length > 80) badRequest("Name is too long");
  const phone = args.phone?.trim() || null;
  if (phone && !/^[+\d][\d\s-]{5,19}$/.test(phone)) badRequest("Enter a valid phone number");
  const email = args.email?.trim().toLowerCase() || null;
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) badRequest("Enter a valid email");
  const note = args.note?.trim() || null;
  if (note && note.length > 500) badRequest("Note is too long");
  return { name, phone, email, note, searchText: [name, phone, email].filter(Boolean).join(" ") };
}

/** Returns the customer if it belongs to the owner, otherwise null. */
export async function findOwnedCustomer(
  ctx: QueryCtx | MutationCtx,
  id: Id<"customers">,
  ownerId: Id<"users">,
): Promise<Doc<"customers"> | null> {
  const customer = await ctx.db.get("customers", id);
  return customer && customer.ownerId === ownerId ? customer : null;
}

/** Adds a sale (positive) or refund (negative) to the customer's totals. */
export async function recordCustomerVisit(
  ctx: MutationCtx,
  customer: Doc<"customers">,
  amountCents: number,
  at: string,
): Promise<void> {
  const isSale = amountCents >= 0;
  await ctx.db.patch("customers", customer._id, {
    visits: customer.visits + (isSale ? 1 : 0),
    totalSpentCents: customer.totalSpentCents + amountCents,
    lastVisitAt: isSale ? at : customer.lastVisitAt,
  });
}

/** Alphabetical list, or search results by name, phone or email. */
export const list = query({
  args: { search: v.optional(v.string()), paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return EMPTY_PAGE;
    const search = args.search?.trim();
    if (search) {
      return await ctx.db
        .query("customers")
        .withSearchIndex("search_text", (q) => q.search("searchText", search).eq("ownerId", user._id))
        .paginate(args.paginationOpts);
    }
    return await ctx.db
      .query("customers")
      .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
      .paginate(args.paginationOpts);
  },
});

/** Small search used by the POS customer picker. */
export const search = query({
  args: { search: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const search = args.search.trim();
    if (!search) {
      return await ctx.db
        .query("customers")
        .withIndex("by_owner_and_name", (q) => q.eq("ownerId", user._id))
        .take(SEARCH_LIMIT);
    }
    return await ctx.db
      .query("customers")
      .withSearchIndex("search_text", (q) => q.search("searchText", search).eq("ownerId", user._id))
      .take(SEARCH_LIMIT);
  },
});

export const get = query({
  args: { id: v.id("customers") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return null;
    return await findOwnedCustomer(ctx, args.id, user._id);
  },
});

const fields = {
  name: v.string(),
  phone: v.optional(v.string()),
  email: v.optional(v.string()),
  note: v.optional(v.string()),
};

export const create = mutation({
  args: fields,
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "customers");
    return await ctx.db.insert("customers", {
      ownerId: user._id,
      ...clean(args),
      visits: 0,
      totalSpentCents: 0,
      lastVisitAt: null,
    });
  },
});

export const update = mutation({
  args: { id: v.id("customers"), ...fields },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "customers");
    const customer = await findOwnedCustomer(ctx, args.id, user._id);
    if (!customer) throw new ConvexError({ code: "NOT_FOUND", message: "Customer not found" });
    const { id, ...rest } = args;
    await ctx.db.patch("customers", id, clean(rest));
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("customers") },
  handler: async (ctx, args) => {
    const { user } = await requireStaff(ctx, "customers");
    const customer = await findOwnedCustomer(ctx, args.id, user._id);
    if (!customer) throw new ConvexError({ code: "NOT_FOUND", message: "Customer not found" });
    // Receipts keep the name snapshot, so past sales still show who bought
    await ctx.db.delete("customers", customer._id);
    return null;
  },
});
