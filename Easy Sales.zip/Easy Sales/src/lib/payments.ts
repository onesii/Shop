import { Banknote, CreditCard, Smartphone, type LucideIcon } from "lucide-react";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";

export type PaymentMethod = Doc<"receipts">["paymentMethod"];

export const PAYMENT_METHODS: Record<PaymentMethod, { label: string; icon: LucideIcon }> = {
  cash: { label: "Cash", icon: Banknote },
  card: { label: "Card", icon: CreditCard },
  mpesa: { label: "M-Pesa", icon: Smartphone },
};

/** Suggested cash amounts: exact, then the next round notes above the total. */
export function quickCashAmounts(totalCents: number): number[] {
  const steps = [5000, 10000, 20000, 50000, 100000]; // KSh 50, 100, 200, 500, 1000
  const amounts = new Set<number>([totalCents]);
  for (const step of steps) {
    const rounded = Math.ceil(totalCents / step) * step;
    if (rounded > totalCents) amounts.add(rounded);
    if (amounts.size >= 4) break;
  }
  return [...amounts].sort((a, b) => a - b);
}
