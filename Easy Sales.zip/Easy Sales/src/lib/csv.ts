import Papa from "papaparse";

/** Downloads rows as a UTF-8 CSV that opens cleanly in Excel. */
export function downloadCsv(filename: string, rows: Record<string, string | number>[], columns?: string[]): void {
  const csv = Papa.unparse(rows, columns ? { columns } : undefined);
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
