// Encodes receipt lines as ESC/POS commands, understood by almost every
// thermal receipt printer (Bluetooth, network and USB).
import type { PrintLine } from "./receipt-layout.ts";

const ESC = 0x1b;
const GS = 0x1d;

/** Thermal printers use a single-byte code page; keep to plain ASCII. */
export function toAscii(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\x20-\x7e]/g, "?");
}

export function encodeEscPos(lines: PrintLine[]): Uint8Array<ArrayBuffer> {
  const bytes: number[] = [ESC, 0x40]; // initialise
  for (const line of lines) {
    bytes.push(ESC, 0x61, line.align === "center" ? 1 : 0);
    bytes.push(ESC, 0x45, line.bold ? 1 : 0);
    bytes.push(GS, 0x21, line.big ? 0x11 : 0x00);
    for (const ch of toAscii(line.text)) bytes.push(ch.charCodeAt(0));
    bytes.push(0x0a);
  }
  bytes.push(ESC, 0x61, 0, ESC, 0x45, 0, GS, 0x21, 0);
  bytes.push(ESC, 0x64, 4); // feed so the receipt clears the cutter
  bytes.push(GS, 0x56, 0x42, 0); // partial cut (ignored by printers without a cutter)
  return new Uint8Array(bytes);
}
