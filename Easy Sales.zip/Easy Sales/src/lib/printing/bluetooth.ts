/// <reference types="web-bluetooth" />
// Direct Bluetooth (BLE) printing from Chrome on Android and desktop.
import { isNativeApp } from "./platform.ts";

// GATT services used by common thermal printer brands (generic, Xprinter, MTP, etc.)
const PRINTER_SERVICES = [
  "000018f0-0000-1000-8000-00805f9b34fb",
  "e7810a71-73ae-499d-8c15-faa9aef0c3f2",
  "49535343-fe7d-4ae5-8fa9-9fafd205e455",
  "0000ff00-0000-1000-8000-00805f9b34fb",
  "0000ffe0-0000-1000-8000-00805f9b34fb",
  "0000fee7-0000-1000-8000-00805f9b34fb",
  "0000ae30-0000-1000-8000-00805f9b34fb",
];
const CHUNK_SIZE = 180;

// Devices picked this session; Chrome only remembers them across reloads via getDevices()
const devices = new Map<string, BluetoothDevice>();

export function bluetoothSupported(): boolean {
  return typeof navigator !== "undefined" && "bluetooth" in navigator;
}

/** Opens Chrome's device picker. Must be called from a tap. */
export async function pickBluetoothPrinter(): Promise<{ id: string; name: string }> {
  const device = await navigator.bluetooth.requestDevice({
    acceptAllDevices: true,
    optionalServices: PRINTER_SERVICES,
  });
  devices.set(device.id, device);
  return { id: device.id, name: device.name ?? "Bluetooth printer" };
}

async function findDevice(id: string): Promise<BluetoothDevice | null> {
  const cached = devices.get(id);
  if (cached) return cached;
  if (typeof navigator.bluetooth.getDevices !== "function") return null;
  const known = (await navigator.bluetooth.getDevices()).find((d) => d.id === id) ?? null;
  if (known) devices.set(id, known);
  return known;
}

async function writableCharacteristic(
  server: BluetoothRemoteGATTServer,
): Promise<BluetoothRemoteGATTCharacteristic | null> {
  for (const service of await server.getPrimaryServices()) {
    for (const ch of await service.getCharacteristics()) {
      if (ch.properties.writeWithoutResponse || ch.properties.write) return ch;
    }
  }
  return null;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function printBluetooth(deviceId: string, bytes: Uint8Array<ArrayBuffer>): Promise<void> {
  if (!bluetoothSupported()) {
    throw new Error(
      isNativeApp()
        ? "The store app can't use Bluetooth. Install the app from Chrome (Add to Home screen) to print over Bluetooth."
        : "This browser can't use Bluetooth printers. Open the app in Google Chrome.",
    );
  }
  const device = await findDevice(deviceId);
  if (!device?.gatt) {
    throw new Error("Bluetooth printer not connected. Open the printer in Settings and tap Search again.");
  }
  const server = device.gatt.connected ? device.gatt : await device.gatt.connect();
  const ch = await writableCharacteristic(server);
  if (!ch) throw new Error(`${device.name ?? "This device"} doesn't look like a receipt printer`);
  for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
    const chunk = bytes.slice(i, i + CHUNK_SIZE);
    if (ch.properties.writeWithoutResponse) {
      await ch.writeValueWithoutResponse(chunk);
      await sleep(20); // give small printer buffers time to drain
    } else {
      await ch.writeValueWithResponse(chunk);
    }
  }
}
