// Printer models offered in the "Printer model" dropdown (same list as the original app).
// All hardware models speak ESC/POS; the model sets the paper width and which
// connections it supports.
import type { PaperWidth } from "./receipt-layout.ts";

/** How a model is reached. "builtin" is the printer inside a Sunmi terminal. */
export type ModelInterface = "ethernet" | "bluetooth" | "usb" | "builtin";

type ModelKind = "printer" | "none" | "dialog" | "display";

export type PrinterModel = {
  id: string;
  label: string;
  paperWidth: PaperWidth;
  interfaces: readonly ModelInterface[];
  kind: ModelKind;
};

const ANY: readonly ModelInterface[] = ["ethernet", "bluetooth", "usb"];

export const PRINTER_MODELS = [
  { id: "none", label: "No printer", paperWidth: 80, interfaces: [], kind: "none" },
  { id: "star-tsp654ii", label: "Star TSP654IIBI (Bluetooth)", paperWidth: 80, interfaces: ["bluetooth"], kind: "printer" },
  { id: "star-tsp143iiilan", label: "Star TSP143IIILAN (Ethernet)", paperWidth: 80, interfaces: ["ethernet"], kind: "printer" },
  { id: "star-mpop", label: "Star mPOP (Bluetooth)", paperWidth: 58, interfaces: ["bluetooth"], kind: "printer" },
  { id: "star-mc-print3", label: "Star mC-Print3", paperWidth: 80, interfaces: ANY, kind: "printer" },
  { id: "epson-tm-t20ii", label: "Epson TM-T20II (Ethernet)", paperWidth: 80, interfaces: ["ethernet"], kind: "printer" },
  { id: "epson-tm-t88v", label: "Epson TM-T88V (Ethernet)", paperWidth: 80, interfaces: ["ethernet"], kind: "printer" },
  { id: "epson-tm-m30", label: "Epson TM-m30", paperWidth: 80, interfaces: ANY, kind: "printer" },
  { id: "sunmi", label: "Sunmi", paperWidth: 58, interfaces: ["builtin"], kind: "printer" },
  { id: "posiflex-6900", label: "Posiflex 6900", paperWidth: 80, interfaces: ["ethernet", "usb"], kind: "printer" },
  { id: "xprinter-xp-q800", label: "XPrinter XP-Q800", paperWidth: 80, interfaces: ANY, kind: "printer" },
  { id: "gp-58130iic", label: "GP-58130IIC", paperWidth: 58, interfaces: ["bluetooth", "usb"], kind: "printer" },
  { id: "gp-u80300i", label: "GP-U80300I", paperWidth: 80, interfaces: ["ethernet", "usb"], kind: "printer" },
  { id: "gp-l80250i", label: "GP-L80250I", paperWidth: 80, interfaces: ["ethernet", "usb"], kind: "printer" },
  { id: "other", label: "Other model", paperWidth: 80, interfaces: ANY, kind: "printer" },
  { id: "kitchen-display", label: "Kitchen display", paperWidth: 80, interfaces: [], kind: "display" },
  { id: "system", label: "Print dialog (AirPrint)", paperWidth: 80, interfaces: [], kind: "dialog" },
] as const satisfies readonly PrinterModel[];

export type PrinterModelId = (typeof PRINTER_MODELS)[number]["id"];

export const DEFAULT_MODEL: PrinterModelId = "epson-tm-m30";

const OTHER_58_IDS = new Set(["epson-tm-m10", "xprinter-58", "other-58"]);

// Models from the earlier, shorter list
const LEGACY_IDS: Record<string, PrinterModelId> = {
  "epson-tm-t20": "epson-tm-t20ii",
  "epson-tm-t82": "other",
  "epson-tm-t88": "epson-tm-t88v",
  "star-tsp100": "star-tsp143iiilan",
  "xprinter-80": "xprinter-xp-q800",
  "other-80": "other",
};

/** True for retired 58 mm models, so their printers keep printing narrow receipts. */
export function wasNarrowModel(id: string): boolean {
  return OTHER_58_IDS.has(id);
}

type Model = (typeof PRINTER_MODELS)[number];

const OTHER: Model = PRINTER_MODELS.find((m) => m.id === "other") ?? PRINTER_MODELS[0];

/** Looks up a model; unknown or retired ids (e.g. the old 58 mm "other") become "Other model". */
export function findModel(id: string): Model {
  const mapped = LEGACY_IDS[id] ?? id;
  return PRINTER_MODELS.find((m) => m.id === mapped) ?? OTHER;
}

/** True for models that send paper receipts to a printer (not "No printer" or a screen). */
export function printsOnPaper(model: PrinterModel): boolean {
  return model.kind === "printer" || model.kind === "dialog";
}
