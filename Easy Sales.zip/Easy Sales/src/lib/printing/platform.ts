export type Platform = "ios" | "android" | "other";

export function detectPlatform(): Platform {
  if (typeof navigator === "undefined") return "other";
  const ua = navigator.userAgent;
  // iPadOS reports itself as a Mac, so also check for touch support
  if (/iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) {
    return "ios";
  }
  if (/Android/.test(ua)) return "android";
  return "other";
}

/**
 * True inside the Hercules Android/iOS store app. Its built-in browser (WebView) has no
 * Bluetooth, USB or print window, so only Wi-Fi printers work there. Installing from
 * Chrome (Add to Home screen) keeps Bluetooth and USB.
 */
export function isNativeApp(): boolean {
  return typeof navigator !== "undefined" && navigator.userAgent.includes("HerculesNative");
}

export const BLUEFY_URL = "https://apps.apple.com/app/bluefy-web-ble-browser/id1492822055";
