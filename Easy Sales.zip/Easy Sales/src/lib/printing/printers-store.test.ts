import { beforeEach, describe, expect, it } from "vitest";
import { getPrinters, isValidIp, newPrinter } from "./printers-store.ts";
import { buildOrderLines, columns } from "./receipt-layout.ts";
import { canPrint, usesDialog } from "./print.ts";
import { eposEnvelope, eposError, eposUrl } from "./network.ts";
import { orderTicketsFor, type RoutableOrder } from "./order-routing.ts";

describe("printer storage", () => {
  beforeEach(() => localStorage.clear());

  it("upgrades printers saved before models, USB and order printing existed", () => {
    localStorage.setItem(
      "pos.printers.v1",
      JSON.stringify([
        {
          id: "a",
          name: "Counter",
          interface: "bluetooth",
          paperWidth: 80,
          printReceipts: true,
          autoPrint: true,
          bluetoothDeviceId: "bt1",
          bluetoothDeviceName: "MTP-II",
        },
        {
          id: "b",
          name: "Dialog",
          interface: "system",
          paperWidth: 58,
          printReceipts: true,
          autoPrint: false,
          bluetoothDeviceId: null,
          bluetoothDeviceName: null,
        },
      ]),
    );
    const [bt, dialog] = getPrinters();
    expect(bt).toMatchObject({
      model: "other",
      printOrders: false,
      ipAddress: "",
      usbDevice: null,
      printSingleItem: false,
      groupIdentical: false,
      groupIds: [],
    });
    expect(usesDialog(bt)).toBe(false);
    expect(dialog.model).toBe("system");
    expect(usesDialog(dialog)).toBe(true);
  });

  it("maps retired models and keeps 58 mm paper for narrow ones", () => {
    const base = {
      name: "P",
      interface: "ethernet",
      paperWidth: 80,
      printReceipts: true,
      autoPrint: false,
      bluetoothDeviceId: null,
      bluetoothDeviceName: null,
    };
    localStorage.setItem(
      "pos.printers.v1",
      JSON.stringify([
        { ...base, id: "a", model: "epson-tm-t88" },
        { ...base, id: "b", model: "other-58", paperWidth: 58 },
      ]),
    );
    const [a, b] = getPrinters();
    expect(a).toMatchObject({ model: "epson-tm-t88v", paperWidth: 80 });
    expect(b).toMatchObject({ model: "other", paperWidth: 58 });
  });

  it("never prints on No printer or Kitchen display", () => {
    expect(canPrint({ ...newPrinter(), model: "none" })).toBe(false);
    expect(canPrint({ ...newPrinter(), model: "kitchen-display" })).toBe(false);
    expect(canPrint(newPrinter())).toBe(true);
  });

  it("validates IPv4 addresses", () => {
    expect(isValidIp("192.168.1.50")).toBe(true);
    expect(isValidIp(" 10.0.0.1 ")).toBe(true);
    expect(isValidIp("192.168.1")).toBe(false);
    expect(isValidIp("256.1.1.1")).toBe(false);
    expect(isValidIp("")).toBe(false);
  });
});

describe("order tickets", () => {
  it("prints big quantities and names without prices, wrapped to half width", () => {
    const lines = buildOrderLines(
      {
        name: "Table 4",
        comment: "No onions",
        lines: [{ name: "Chicken burger deluxe", variantName: "Large", quantity: 2 }],
      },
      58,
      new Date("2026-11-06T12:00:00"),
    );
    const text = lines.map((l) => l.text);
    expect(text[0]).toBe("Table 4");
    expect(text.join(" ")).toContain("2 x Chicken");
    expect(text.join(" ")).not.toContain("KSh");
    expect(text.at(-1)).toBe("No onions");
    for (const l of lines.filter((x) => x.big)) {
      expect(l.text.length).toBeLessThanOrEqual(columns(58) / 2);
    }
  });
});

describe("order routing", () => {
  const order: RoutableOrder = {
    name: "Table 2",
    comment: null,
    lines: [
      { name: "Burger", variantName: null, quantity: 1, categoryId: "food" },
      { name: "Soda", variantName: null, quantity: 2, categoryId: "drinks" },
      { name: "Burger", variantName: null, quantity: 2, categoryId: "food" },
      { name: "Open price", variantName: null, quantity: 1, categoryId: null },
    ],
  };
  const groups = [
    { id: "kitchen", categoryIds: ["food"] },
    { id: "bar", categoryIds: ["drinks"] },
  ];
  const settings = { groupIds: [], printSingleItem: false, groupIdentical: false, paperWidth: 80 as const };
  const text = (tickets: { text: string }[][]) => tickets.map((t) => t.map((l) => l.text).join("\n"));

  it("sends a printer in no group the whole order", () => {
    const tickets = orderTicketsFor(order, settings, groups);
    expect(tickets).toHaveLength(1);
    expect(text(tickets)[0]).toContain("Soda");
    expect(text(tickets)[0]).toContain("Open price");
  });

  it("only sends a group's categories, and nothing when none match", () => {
    const bar = orderTicketsFor(order, { ...settings, groupIds: ["bar"] }, groups);
    expect(text(bar)[0]).toContain("2 x Soda");
    expect(text(bar)[0]).not.toContain("Burger");
    const empty = orderTicketsFor({ ...order, lines: [order.lines[0]] }, { ...settings, groupIds: ["bar"] }, groups);
    expect(empty).toHaveLength(0);
  });

  it("ignores groups that were deleted", () => {
    expect(orderTicketsFor(order, { ...settings, groupIds: ["gone"] }, groups)).toHaveLength(1);
  });

  it("groups identical items and prints one ticket per item", () => {
    const kitchen = { ...settings, groupIds: ["kitchen"], groupIdentical: true, printSingleItem: true };
    const tickets = orderTicketsFor(order, kitchen, groups);
    expect(tickets).toHaveLength(1);
    expect(text(tickets)[0]).toContain("3 x Burger");
    const separate = orderTicketsFor(order, { ...kitchen, groupIdentical: false }, groups);
    expect(separate).toHaveLength(2);
  });
});

describe("Wi-Fi printing (Epson ePOS-Print)", () => {
  it("wraps ESC/POS bytes as hex in an ePOS envelope", () => {
    const xml = eposEnvelope(new Uint8Array([0x1b, 0x40, 0x41]));
    expect(xml).toContain("<command>1b4041</command>");
    expect(xml).toContain("http://www.epson-pos.com/schemas/2011/03/epos-print");
    expect(eposUrl(" 192.168.0.102 ", true)).toBe(
      "https://192.168.0.102/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000",
    );
  });

  it("reads success and printer errors from the reply", () => {
    expect(eposError('<response success="true" code="" status="1"/>')).toBeNull();
    expect(eposError('<response success="false" code="EPTR_REC_EMPTY"/>')).toBe("The printer is out of paper");
    expect(eposError('<response success="false" code="WEIRD"/>')).toBe("Printer error: WEIRD");
    expect(eposError("<html>not a printer</html>")).toBe("The printer sent an unexpected reply");
  });
});
