/// <reference types="w3c-web-usb" />
// Direct USB printing through WebUSB (Chrome on Android and desktop).
import type { UsbDeviceRef } from "./printers-store.ts";

const PRINTER_CLASS = 7;
const CHUNK_SIZE = 4096;

export function usbSupported(): boolean {
  return typeof navigator !== "undefined" && "usb" in navigator;
}

/** Opens Chrome's USB device picker. Must be called from a tap. */
export async function pickUsbPrinter(): Promise<UsbDeviceRef> {
  // No filter: many cheap printers report a vendor class instead of the printer class
  const device = await navigator.usb.requestDevice({ filters: [] });
  return {
    vendorId: device.vendorId,
    productId: device.productId,
    serialNumber: device.serialNumber ?? null,
    name: device.productName || "USB printer",
  };
}

async function findDevice(ref: UsbDeviceRef): Promise<USBDevice | null> {
  const devices = await navigator.usb.getDevices();
  return (
    devices.find(
      (d) =>
        d.vendorId === ref.vendorId &&
        d.productId === ref.productId &&
        (ref.serialNumber === null || d.serialNumber === ref.serialNumber),
    ) ?? null
  );
}

type Target = { interfaceNumber: number; alternate: number; endpoint: number; isPrinter: boolean };

/** Finds a bulk OUT endpoint, preferring an interface of the printer class. */
function findTarget(config: USBConfiguration): Target | null {
  let best: Target | null = null;
  for (const iface of config.interfaces) {
    for (const alt of iface.alternates) {
      const ep = alt.endpoints.find((e) => e.direction === "out" && e.type === "bulk");
      if (!ep) continue;
      const isPrinter = alt.interfaceClass === PRINTER_CLASS;
      if (!best || (isPrinter && !best.isPrinter)) {
        best = {
          interfaceNumber: iface.interfaceNumber,
          alternate: alt.alternateSetting,
          endpoint: ep.endpointNumber,
          isPrinter,
        };
      }
    }
  }
  return best;
}

export async function printUsb(ref: UsbDeviceRef, bytes: Uint8Array<ArrayBuffer>): Promise<void> {
  if (!usbSupported()) throw new Error("This browser can't use USB printers. Open the app in Google Chrome.");
  const device = await findDevice(ref);
  if (!device) {
    throw new Error("USB printer not found. Plug it in, open the printer in Settings and tap Search again.");
  }
  try {
    if (!device.opened) await device.open();
    if (device.configuration === null) await device.selectConfiguration(1);
    const config = device.configuration;
    const target = config ? findTarget(config) : null;
    if (!target) throw new Error(`${ref.name} doesn't look like a receipt printer`);
    const iface = config?.interfaces.find((i) => i.interfaceNumber === target.interfaceNumber);
    if (!iface?.claimed) await device.claimInterface(target.interfaceNumber);
    if (target.alternate !== 0) await device.selectAlternateInterface(target.interfaceNumber, target.alternate);
    for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
      await device.transferOut(target.endpoint, bytes.slice(i, i + CHUNK_SIZE));
    }
  } catch (err) {
    // Usually a computer's printer driver holding the device
    if (err instanceof DOMException && (err.name === "SecurityError" || err.name === "NetworkError")) {
      throw new Error("The USB printer is busy or blocked. On a computer, its printer driver may be using it.", {
        cause: err,
      });
    }
    throw err;
  }
}
