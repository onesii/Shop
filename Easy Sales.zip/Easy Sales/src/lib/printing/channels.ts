// The system print dialog, used by the "Print dialog (AirPrint)" model.
import { columns, type PaperWidth, type PrintLine } from "./receipt-layout.ts";

const escapeHtml = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/** Prints through the device's own print window, sized for receipt paper. */
export function printWithDialog(lines: PrintLine[], width: PaperWidth): Promise<void> {
  const cols = columns(width);
  const body = lines
    .map((l) => {
      const style = [
        `text-align:${l.align}`,
        l.bold ? "font-weight:700" : "",
        l.big ? "font-size:2em" : "",
      ].join(";");
      return `<div style="${style}">${escapeHtml(l.text) || "&nbsp;"}</div>`;
    })
    .join("");
  const html = `<!doctype html><html><head><style>
    @page { size: ${width}mm auto; margin: 2mm; }
    body { margin: 0; font-family: "Courier New", monospace; white-space: pre;
      font-size: calc((${width}mm - 4mm) / ${cols} * 1.65); color: #000; }
  </style></head><body>${body}</body></html>`;

  return new Promise((resolve) => {
    const frame = document.createElement("iframe");
    frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
    frame.srcdoc = html;
    frame.onload = () => {
      const win = frame.contentWindow;
      const done = () => {
        frame.remove();
        resolve();
      };
      if (!win) return done();
      win.addEventListener("afterprint", () => setTimeout(done, 100));
      win.focus();
      win.print();
      // Some browsers never fire afterprint; clean up anyway
      setTimeout(done, 60_000);
    };
    document.body.appendChild(frame);
  });
}
