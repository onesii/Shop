import { describe, expect, it } from "vitest";
import { buildReceiptLines, columns, twoColumn, wrapText, type PrintableReceipt } from "./receipt-layout.ts";
import { encodeEscPos, toAscii } from "./escpos.ts";

const RECEIPT: PrintableReceipt = {
  number: "1-1001",
  kind: "sale",
  createdAt: "2026-10-23T10:00:00.000Z",
  lines: [
    { itemId: null, name: "Chicken burger with extra long name", variantName: "Large", priceCents: 45000, quantity: 2 },
  ],
  totalCents: 90000,
  paymentMethod: "cash",
  tenderedCents: 100000,
  changeCents: 10000,
  mpesaReference: null,
  subtotalCents: 90000,
  taxes: [{ name: "VAT", rateBps: 1600, type: "included", amountCents: 12414 }],
  storeName: "Mama Njeri",
  posName: "POS 1",
  receiptFooter: "Asante!",
};

describe("text layout", () => {
  it("never exceeds the paper width", () => {
    for (const width of [58, 80] as const) {
      const cols = columns(width);
      for (const line of buildReceiptLines(RECEIPT, width)) {
        expect(line.text.length).toBeLessThanOrEqual(line.big ? cols / 2 : cols);
      }
    }
  });

  it("right-aligns values and wraps long names", () => {
    const [first, second] = twoColumn("Chicken burger with extra long name", "KSh900.00", 32);
    expect(first).toHaveLength(32);
    expect(first.endsWith("KSh900.00")).toBe(true);
    expect(second).toBeDefined();
  });

  it("hard-breaks words longer than a line", () => {
    expect(wrapText("x".repeat(70), 32)).toEqual(["x".repeat(32), "x".repeat(32), "x".repeat(6)]);
  });

  it("includes totals, change, taxes and footer", () => {
    const text = buildReceiptLines(RECEIPT, 58).map((l) => l.text).join("\n");
    expect(text).toContain("KSh900.00");
    expect(text).toContain("Change");
    expect(text).toContain("VAT 16% (incl.)");
    expect(text).toContain("Asante!");
  });

  it("prints the header and hides customer info and comments when turned off", () => {
    const withExtras: PrintableReceipt = {
      ...RECEIPT,
      receiptHeader: "contact us: 0726250239",
      customerName: "Jane",
      lines: [{ ...RECEIPT.lines[0], comment: "No onions" }],
    };
    const shown = buildReceiptLines(withExtras, 58).map((l) => l.text).join("\n");
    expect(shown).toContain("contact us: 0726250239");
    expect(shown).toContain("Customer: Jane");
    expect(shown).toContain("No onions");

    const hidden = buildReceiptLines({ ...withExtras, showCustomerInfo: false, showComments: false }, 58)
      .map((l) => l.text)
      .join("\n");
    expect(hidden).not.toContain("Jane");
    expect(hidden).not.toContain("No onions");
  });
});

describe("ESC/POS encoding", () => {
  it("initialises, prints ASCII only and cuts", () => {
    const bytes = encodeEscPos([{ text: "Café", align: "left", bold: false, big: false }]);
    expect([...bytes.slice(0, 2)]).toEqual([0x1b, 0x40]);
    expect([...bytes.slice(-4)]).toEqual([0x1d, 0x56, 0x42, 0]);
    expect(bytes.every((b) => b < 0x80)).toBe(true);
    expect(toAscii("Café ✓")).toBe("Cafe ?");
  });
});
