// Printers are set up per device (like Loyverse): a Bluetooth pairing, USB cable
// or Wi-Fi network belongs to the tablet, not to the account.
import { useSyncExternalStore } from "react";
import { z } from "zod";
import { DEFAULT_MODEL, findModel, wasNarrowModel, type PrinterModelId } from "./models.ts";

const STORAGE_KEY = "pos.printers.v1";

const usbDeviceSchema = z.object({
  vendorId: z.number(),
  productId: z.number(),
  serialNumber: z.string().nullable(),
  name: z.string(),
});

// Fields added after the first version are optional here and filled in by normalize()
const storedSchema = z.object({
  id: z.string(),
  name: z.string(),
  interface: z.enum(["bluetooth", "ethernet", "usb", "builtin", "system"]),
  model: z.string().optional(),
  paperWidth: z.union([z.literal(58), z.literal(80)]),
  ipAddress: z.string().optional(),
  printReceipts: z.boolean(),
  printOrders: z.boolean().optional(),
  autoPrint: z.boolean(),
  printSingleItem: z.boolean().optional(),
  groupIdentical: z.boolean().optional(),
  // Printer group ids (from the database); empty = gets every order line
  groupIds: z.array(z.string()).optional(),
  bluetoothDeviceId: z.string().nullable(),
  bluetoothDeviceName: z.string().nullable(),
  usbDevice: usbDeviceSchema.nullable().optional(),
});

type StoredPrinter = z.infer<typeof storedSchema>;

export type UsbDeviceRef = z.infer<typeof usbDeviceSchema>;
export type PrinterInterface = StoredPrinter["interface"];
/** Interfaces offered in the Interface dropdown; "system" comes from the print dialog model. */
export type HardwareInterface = Exclude<PrinterInterface, "system">;

type Filled = "model" | "ipAddress" | "printOrders" | "usbDevice" | "printSingleItem" | "groupIdentical" | "groupIds";

export type PrinterConfig = Omit<StoredPrinter, Filled> & {
  model: PrinterModelId;
  ipAddress: string;
  printOrders: boolean;
  printSingleItem: boolean;
  groupIdentical: boolean;
  groupIds: string[];
  usbDevice: UsbDeviceRef | null;
};

function normalize(p: StoredPrinter): PrinterConfig {
  const model = p.model ? findModel(p.model) : findModel(p.interface === "system" ? "system" : "other");
  // Retired 58 mm models map to "Other model"; keep their narrow paper
  const paperWidth = p.model && wasNarrowModel(p.model) ? 58 : p.model ? model.paperWidth : p.paperWidth;
  return {
    ...p,
    model: model.id,
    paperWidth,
    ipAddress: p.ipAddress ?? "",
    printOrders: p.printOrders ?? false,
    printSingleItem: p.printSingleItem ?? false,
    groupIdentical: p.groupIdentical ?? false,
    groupIds: p.groupIds ?? [],
    usbDevice: p.usbDevice ?? null,
  };
}

const EMPTY: PrinterConfig[] = [];
const listeners = new Set<() => void>();
let cachedRaw: string | null | undefined;
let cached: PrinterConfig[] = EMPTY;

function readRaw(): string | null {
  try {
    return localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

function parse(raw: string | null): PrinterConfig[] {
  if (!raw) return EMPTY;
  try {
    const result = z.array(storedSchema).safeParse(JSON.parse(raw));
    return result.success ? result.data.map(normalize) : EMPTY;
  } catch {
    return EMPTY;
  }
}

/** Stable snapshot: only re-parses when the stored string changes. */
export function getPrinters(): PrinterConfig[] {
  const raw = readRaw();
  if (raw !== cachedRaw) {
    cachedRaw = raw;
    cached = parse(raw);
  }
  return cached;
}

function write(list: PrinterConfig[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  window.addEventListener("storage", listener);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", listener);
  };
}

export function usePrinters(): PrinterConfig[] {
  return useSyncExternalStore(subscribe, getPrinters, () => EMPTY);
}

export function savePrinter(printer: PrinterConfig) {
  const list = getPrinters();
  const exists = list.some((p) => p.id === printer.id);
  write(exists ? list.map((p) => (p.id === printer.id ? printer : p)) : [...list, printer]);
}

export function deletePrinter(id: string) {
  write(getPrinters().filter((p) => p.id !== id));
}

export function newPrinter(): PrinterConfig {
  const model = findModel(DEFAULT_MODEL);
  return {
    id: crypto.randomUUID(),
    name: "",
    interface: "ethernet",
    model: model.id,
    paperWidth: model.paperWidth,
    ipAddress: "",
    printReceipts: true,
    printOrders: false,
    autoPrint: false,
    printSingleItem: false,
    groupIdentical: false,
    groupIds: [],
    bluetoothDeviceId: null,
    bluetoothDeviceName: null,
    usbDevice: null,
  };
}

const IPV4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;

export function isValidIp(ip: string): boolean {
  return IPV4.test(ip.trim());
}
