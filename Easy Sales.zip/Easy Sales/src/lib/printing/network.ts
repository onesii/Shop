// Direct Wi-Fi/Ethernet printing to Epson TM printers (TM-m30, TM-T20II, TM-T88V...)
// through their built-in ePOS-Print web service. The receipt is sent as raw ESC/POS
// bytes inside a <command> element, so it prints the same as Bluetooth and USB.

const TIMEOUT_MS = 15_000;

export function eposUrl(ip: string, secure: boolean): string {
  return `${secure ? "https" : "http"}://${ip.trim()}/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000`;
}

/** The printer's own settings page; opening it once lets the phone trust its certificate. */
export function printerPageUrl(ip: string): string {
  return `https://${ip.trim()}/`;
}

export function eposEnvelope(bytes: Uint8Array): string {
  let hex = "";
  for (const b of bytes) hex += b.toString(16).padStart(2, "0");
  return (
    '<?xml version="1.0" encoding="utf-8"?>' +
    '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body>' +
    `<epos-print xmlns="http://www.epson-pos.com/schemas/2011/03/epos-print"><command>${hex}</command></epos-print>` +
    "</s:Body></s:Envelope>"
  );
}

const PRINTER_ERRORS: Record<string, string> = {
  EPTR_COVER_OPEN: "The printer cover is open",
  EPTR_REC_EMPTY: "The printer is out of paper",
  EPTR_AUTOCUTTER: "The paper cutter is jammed",
  EPTR_MECHANICAL: "The printer has a mechanical error",
  EPTR_UNRECOVERABLE: "The printer has an error. Turn it off and on again",
  DeviceNotFound: "The printer's ePOS-Print service is off. Turn on ePOS-Print in the printer's settings",
  EX_TIMEOUT: "The printer took too long to answer",
  EX_BADPORT: "The printer's port is busy",
  SchemaError: "The printer didn't understand the receipt",
};

/** Reads the printer's reply. Returns an error message, or null when it printed. */
export function eposError(xml: string): string | null {
  const success = /success="(true|false)"/.exec(xml)?.[1];
  if (success === "true") return null;
  const code = /code="([^"]*)"/.exec(xml)?.[1] ?? "";
  if (!success) return "The printer sent an unexpected reply";
  return PRINTER_ERRORS[code] ?? (code ? `Printer error: ${code}` : "The printer couldn't print");
}

async function send(url: string, body: string): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "text/xml; charset=utf-8" },
      body,
      signal: controller.signal,
    });
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

/** Sends ESC/POS bytes straight to the printer at this IP address on the same Wi-Fi. */
export async function printNetwork(ip: string, bytes: Uint8Array): Promise<void> {
  const body = eposEnvelope(bytes);
  // The app is served over https, so the secure address is tried first; plain http
  // only works where the app's browser allows it.
  const urls = [eposUrl(ip, true), eposUrl(ip, false)];
  let reply: string | null = null;
  for (const url of urls) {
    try {
      reply = await send(url, body);
      break;
    } catch {
      // Try the next address
    }
  }
  if (reply === null) {
    throw new Error(
      `Couldn't reach the printer at ${ip}. Check it's on and on the same Wi-Fi, then tap "Open printer page" once and allow it.`,
    );
  }
  const error = eposError(reply);
  if (error) throw new Error(error);
}
