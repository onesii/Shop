// Pure receipt layout shared by the thermal printer encoder and the print-dialog
// renderer, so every printer type prints the same receipt.
import { format } from "date-fns";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { formatRate } from "@/convex/lib/taxes.ts";
import { formatKsh } from "@/lib/money.ts";
import { formatQtyWithUnit, lineTotalCents, type WeightUnit } from "@/convex/lib/quantity.ts";

export type PaperWidth = 58 | 80;
export type PrintLine = { text: string; align: "left" | "center"; bold: boolean; big: boolean };

export type PrintableReceipt = Pick<
  Doc<"receipts">,
  | "number"
  | "kind"
  | "createdAt"
  | "lines"
  | "totalCents"
  | "paymentMethod"
  | "tenderedCents"
  | "changeCents"
  | "mpesaReference"
  | "subtotalCents"
  | "taxes"
  | "discounts"
  | "storeName"
  | "posName"
  | "receiptFooter"
  | "receiptHeader"
  | "showCustomerInfo"
  | "showComments"
  | "customerName"
>;

const PAYMENT_LABELS: Record<PrintableReceipt["paymentMethod"], string> = {
  cash: "Cash",
  card: "Card",
  mpesa: "M-Pesa",
};

/** Characters per line in the printer's standard font. */
export function columns(width: PaperWidth): number {
  return width === 58 ? 32 : 48;
}

/** Word-wraps text; words longer than a line are hard-broken. */
export function wrapText(text: string, cols: number): string[] {
  const out: string[] = [];
  for (const paragraph of text.split("\n")) {
    let line = "";
    for (const word of paragraph.split(/\s+/).filter(Boolean)) {
      let w = word;
      while (w.length > cols) {
        if (line) out.push(line);
        out.push(w.slice(0, cols));
        w = w.slice(cols);
        line = "";
      }
      if (!line) line = w;
      else if (line.length + 1 + w.length <= cols) line += ` ${w}`;
      else {
        out.push(line);
        line = w;
      }
    }
    out.push(line);
  }
  return out;
}

/** Left text with a right-aligned value on the first line, e.g. "Total     KSh100.00". */
export function twoColumn(left: string, right: string, cols: number): string[] {
  const leftCols = Math.max(cols - right.length - 1, 8);
  const [first = "", ...rest] = wrapText(left, leftCols);
  const gap = Math.max(cols - first.length - right.length, 1);
  return [`${first}${" ".repeat(gap)}${right}`, ...rest];
}

const plain = (text: string, align: PrintLine["align"] = "left"): PrintLine => ({
  text,
  align,
  bold: false,
  big: false,
});

function rows(left: string, right: string, cols: number, bold = false): PrintLine[] {
  return twoColumn(left, right, cols).map((text) => ({ ...plain(text), bold }));
}

function centered(text: string, cols: number, style: Partial<PrintLine> = {}): PrintLine[] {
  // Double-size text takes two columns per character
  const width = style.big ? Math.floor(cols / 2) : cols;
  return wrapText(text, width).map((t) => ({ ...plain(t, "center"), ...style }));
}

export function buildReceiptLines(r: PrintableReceipt, width: PaperWidth): PrintLine[] {
  const cols = columns(width);
  const divider = plain("-".repeat(cols));
  const isRefund = r.kind === "refund";
  // Missing on older receipts, which always showed both
  const showCustomer = r.showCustomerInfo !== false;
  const showComments = r.showComments !== false;
  const out: PrintLine[] = [];

  if (r.storeName) out.push(...centered(r.storeName, cols, { bold: true, big: true }));
  if (r.receiptHeader) out.push(...centered(r.receiptHeader, cols));
  out.push(...centered(`${isRefund ? "-" : ""}${formatKsh(r.totalCents)}`, cols, { bold: true, big: true }));
  out.push(...centered(isRefund ? "Refund" : "Total", cols));
  out.push(divider);
  out.push(plain(`Receipt #${r.number}`));
  out.push(plain(format(new Date(r.createdAt), "dd/MM/yyyy HH:mm")));
  out.push(plain(`POS: ${r.posName ?? "POS 1"}`));
  if (showCustomer && r.customerName) out.push(...wrapText(`Customer: ${r.customerName}`, cols).map((t) => plain(t)));
  out.push(divider);

  for (const l of r.lines) {
    const name = l.variantName ? `${l.name} (${l.variantName})` : l.name;
    out.push(...rows(name, formatKsh(lineTotalCents(l.priceCents, l.quantity)), cols, true));
    out.push(plain(`  ${formatQtyWithUnit(l.quantity, l.unit)} x ${formatKsh(l.priceCents)}${l.unit ? `/${l.unit}` : ""}`));
    if (showComments && l.comment) out.push(...wrapText(l.comment, cols - 2).map((t) => plain(`  ${t}`)));
  }
  out.push(divider);

  const discounts = r.discounts ?? [];
  const taxes = r.taxes ?? [];
  if ((taxes.length > 0 || discounts.length > 0) && r.subtotalCents !== undefined) {
    out.push(...rows("Subtotal", formatKsh(r.subtotalCents), cols));
    for (const d of discounts) {
      const label = d.type === "percent" ? `${d.name} ${formatRate(d.value)}` : d.name;
      out.push(...rows(label, `-${formatKsh(d.amountCents)}`, cols));
    }
    for (const t of taxes) {
      const label = `${t.name} ${formatRate(t.rateBps)}${t.type === "included" ? " (incl.)" : ""}`;
      out.push(...rows(label, formatKsh(t.amountCents), cols));
    }
  }
  out.push(...rows("TOTAL", formatKsh(r.totalCents), cols, true));
  out.push(...rows(PAYMENT_LABELS[r.paymentMethod], formatKsh(r.tenderedCents), cols));
  if (r.changeCents > 0) out.push(...rows("Change", formatKsh(r.changeCents), cols));
  if (r.mpesaReference) out.push(...rows("M-Pesa code", r.mpesaReference, cols));

  if (r.receiptFooter) {
    out.push(divider);
    out.push(...centered(r.receiptFooter, cols));
  }
  return out;
}

export type PrintableBill = {
  name: string;
  storeName: string | null;
  lines: { name: string; variantName: string | null; priceCents: number; quantity: number; comment?: string; unit?: WeightUnit }[];
  subtotalCents: number;
  discounts: { name: string; type: "percent" | "amount"; value: number; amountCents: number }[];
  taxes: { name: string; rateBps: number; type: "included" | "added"; amountCents: number }[];
  totalCents: number;
};

/** Pre-payment bill for the customer to check: items and totals, no payment. */
export function buildBillLines(b: PrintableBill, width: PaperWidth, at = new Date()): PrintLine[] {
  const cols = columns(width);
  const divider = plain("-".repeat(cols));
  const out: PrintLine[] = [];
  if (b.storeName) out.push(...centered(b.storeName, cols, { bold: true, big: true }));
  out.push(...centered("BILL", cols, { bold: true }));
  out.push(...centered(b.name, cols));
  out.push(...centered(format(at, "dd/MM/yyyy HH:mm"), cols));
  out.push(divider);
  for (const l of b.lines) {
    const name = l.variantName ? `${l.name} (${l.variantName})` : l.name;
    out.push(...rows(name, formatKsh(lineTotalCents(l.priceCents, l.quantity)), cols, true));
    out.push(plain(`  ${formatQtyWithUnit(l.quantity, l.unit)} x ${formatKsh(l.priceCents)}${l.unit ? `/${l.unit}` : ""}`));
    if (l.comment) out.push(...wrapText(l.comment, cols - 2).map((t) => plain(`  ${t}`)));
  }
  out.push(divider);
  if (b.discounts.length > 0 || b.taxes.length > 0) {
    out.push(...rows("Subtotal", formatKsh(b.subtotalCents), cols));
    for (const d of b.discounts) {
      const label = d.type === "percent" ? `${d.name} ${formatRate(d.value)}` : d.name;
      out.push(...rows(label, `-${formatKsh(d.amountCents)}`, cols));
    }
    for (const t of b.taxes) {
      const label = `${t.name} ${formatRate(t.rateBps)}${t.type === "included" ? " (incl.)" : ""}`;
      out.push(...rows(label, formatKsh(t.amountCents), cols));
    }
  }
  out.push(...rows("TOTAL", formatKsh(b.totalCents), cols, true));
  return out;
}

export type OrderTicket = {
  name: string;
  comment: string | null;
  lines: { name: string; variantName: string | null; quantity: number; comment?: string; unit?: WeightUnit }[];
};

/** Kitchen order: large quantities and names, no prices. */
export function buildOrderLines(order: OrderTicket, width: PaperWidth, at = new Date()): PrintLine[] {
  const cols = columns(width);
  const half = Math.floor(cols / 2);
  const out: PrintLine[] = [
    ...centered(order.name, cols, { bold: true, big: true }),
    ...centered(format(at, "dd/MM/yyyy HH:mm"), cols),
    plain("-".repeat(cols)),
  ];
  for (const l of order.lines) {
    const name = l.variantName ? `${l.name} (${l.variantName})` : l.name;
    // Double-size text, so only half the columns fit
    out.push(...wrapText(`${formatQtyWithUnit(l.quantity, l.unit)} x ${name}`, half).map((text) => ({ ...plain(text), bold: true, big: true })));
    if (l.comment) out.push(...wrapText(l.comment, cols - 2).map((t) => plain(`  ${t}`)));
  }
  if (order.comment) {
    out.push(plain("-".repeat(cols)));
    out.push(...wrapText(order.comment, cols).map((t) => plain(t)));
  }
  return out;
}

export function buildTestLines(name: string, connection: string, width: PaperWidth): PrintLine[] {
  const cols = columns(width);
  const ruler = "1234567890".repeat(5).slice(0, cols);
  return [
    ...centered("Printer test", cols, { bold: true, big: true }),
    plain("-".repeat(cols)),
    ...rows("Printer", name || "Printer", cols),
    ...rows("Connection", connection, cols),
    ...rows("Paper", `${width}mm`, cols),
    plain(ruler),
    plain("-".repeat(cols)),
    ...centered("If you can read this, the printer works.", cols),
  ];
}
