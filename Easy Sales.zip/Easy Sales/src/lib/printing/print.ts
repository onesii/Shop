import { printBluetooth } from "./bluetooth.ts";
import { printWithDialog } from "./channels.ts";
import { encodeEscPos } from "./escpos.ts";
import { findModel, printsOnPaper } from "./models.ts";
import { printNetwork } from "./network.ts";
import type { HardwareInterface, PrinterConfig } from "./printers-store.ts";
import { printUsb } from "./usb.ts";
import {
  buildBillLines,
  buildReceiptLines,
  type PrintableBill,
  type PrintableReceipt,
  type PrintLine,
} from "./receipt-layout.ts";

export const INTERFACE_LABELS: Record<HardwareInterface, string> = {
  ethernet: "Ethernet",
  bluetooth: "Bluetooth",
  usb: "USB",
  builtin: "Built-in printer",
};

/** Printers set to the print dialog model (or saved before models existed) skip the hardware. */
export function usesDialog(printer: PrinterConfig): boolean {
  return printer.model === "system" || printer.interface === "system";
}

/** False for "No printer" and "Kitchen display", which never get paper. */
export function canPrint(printer: PrinterConfig): boolean {
  return printsOnPaper(findModel(printer.model));
}

export function connectionLabel(printer: PrinterConfig): string {
  if (usesDialog(printer) || printer.interface === "system") return "Print dialog";
  return INTERFACE_LABELS[printer.interface];
}

function concat(parts: Uint8Array<ArrayBuffer>[]): Uint8Array<ArrayBuffer> {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let offset = 0;
  for (const p of parts) {
    out.set(p, offset);
    offset += p.length;
  }
  return out;
}

/** Prints one or more tickets (each cut separately) in a single job. */
export async function printTickets(printer: PrinterConfig, tickets: PrintLine[][]): Promise<void> {
  if (tickets.length === 0) return;
  if (!canPrint(printer)) throw new Error("This printer model doesn't print on paper");
  if (usesDialog(printer)) return printWithDialog(tickets.flat(), printer.paperWidth);
  const bytes = concat(tickets.map(encodeEscPos));
  switch (printer.interface) {
    case "ethernet":
      return printNetwork(printer.ipAddress, bytes);
    case "builtin":
      throw new Error("The Sunmi built-in printer can't be reached from the app. Use a Bluetooth or Wi-Fi printer.");
    case "usb":
      if (!printer.usbDevice) throw new Error("No USB printer selected");
      return printUsb(printer.usbDevice, bytes);
    case "bluetooth":
      if (!printer.bluetoothDeviceId) throw new Error("No Bluetooth printer selected");
      return printBluetooth(printer.bluetoothDeviceId, bytes);
    case "system":
      return printWithDialog(tickets.flat(), printer.paperWidth);
  }
}

export function printLines(printer: PrinterConfig, lines: PrintLine[]): Promise<void> {
  return printTickets(printer, [lines]);
}

const FALLBACK: PrinterConfig = {
  id: "fallback",
  name: "Print dialog",
  interface: "system",
  model: "system",
  paperWidth: 80,
  ipAddress: "",
  printReceipts: true,
  printOrders: false,
  autoPrint: false,
  printSingleItem: false,
  groupIdentical: false,
  groupIds: [],
  bluetoothDeviceId: null,
  bluetoothDeviceName: null,
  usbDevice: null,
};

/** Sends each printer its own tickets. Returns error messages. */
async function printToEach(
  printers: PrinterConfig[],
  build: (p: PrinterConfig) => PrintLine[][],
): Promise<string[]> {
  const errors: string[] = [];
  for (const printer of printers.filter(canPrint)) {
    try {
      await printTickets(printer, build(printer));
    } catch (err) {
      const reason = err instanceof Error ? err.message : "Unknown error";
      errors.push(`${printer.name}: ${reason}`);
    }
  }
  return errors;
}

/** Prints to each printer; with no printers set up, falls back to the print dialog. */
export async function printReceipt(receipt: PrintableReceipt, printers: PrinterConfig[]): Promise<string[]> {
  const paper = printers.filter(canPrint);
  const targets = paper.length > 0 ? paper : [FALLBACK];
  return printToEach(targets, (p) => [buildReceiptLines(receipt, p.paperWidth)]);
}

/** Kitchen/bar order tickets go only to printers set to print orders. */
export async function printOrder(
  build: (p: PrinterConfig) => PrintLine[][],
  printers: PrinterConfig[],
): Promise<string[]> {
  return printToEach(printers, build);
}

/** Prints a pre-payment bill on the receipt printers (or the print dialog when none). */
export async function printBill(bill: PrintableBill, printers: PrinterConfig[]): Promise<string[]> {
  const paper = printers.filter(canPrint);
  const targets = paper.length > 0 ? paper : [FALLBACK];
  return printToEach(targets, (p) => [buildBillLines(bill, p.paperWidth)]);
}
