// Decides what each kitchen/bar printer gets for an order, following its
// printer groups and the "single item per ticket" / "group identical items" switches.
import { buildOrderLines, type OrderTicket, type PrintLine } from "./receipt-layout.ts";
import type { PrinterConfig } from "./printers-store.ts";

export type OrderLine = OrderTicket["lines"][number] & { categoryId: string | null };
export type RoutableOrder = Omit<OrderTicket, "lines"> & { lines: OrderLine[] };
export type GroupRef = { id: string; categoryIds: string[] };

type OrderSettings = Pick<PrinterConfig, "groupIds" | "printSingleItem" | "groupIdentical" | "paperWidth">;

/** Lines this printer handles. A printer in no group gets everything. */
export function linesForPrinter(lines: OrderLine[], printer: OrderSettings, groups: GroupRef[]): OrderLine[] {
  // Groups deleted since the printer was set up are ignored
  const mine = groups.filter((g) => printer.groupIds.includes(g.id));
  if (mine.length === 0) return lines;
  const categories = new Set(mine.flatMap((g) => g.categoryIds));
  return lines.filter((l) => l.categoryId !== null && categories.has(l.categoryId));
}

/** Merges lines for the same item and variant, adding up quantities. */
export function groupIdentical(lines: OrderLine[]): OrderLine[] {
  const merged = new Map<string, OrderLine>();
  for (const l of lines) {
    const key = `${l.name}|${l.variantName ?? ""}`;
    const prev = merged.get(key);
    merged.set(key, prev ? { ...prev, quantity: prev.quantity + l.quantity } : l);
  }
  return [...merged.values()];
}

/** Order tickets for one printer; empty when none of the order is for it. */
export function orderTicketsFor(
  order: RoutableOrder,
  printer: OrderSettings,
  groups: GroupRef[],
  at = new Date(),
): PrintLine[][] {
  let lines = linesForPrinter(order.lines, printer, groups);
  if (printer.groupIdentical) lines = groupIdentical(lines);
  if (lines.length === 0) return [];
  const chunks = printer.printSingleItem ? lines.map((l) => [l]) : [lines];
  return chunks.map((chunk) => buildOrderLines({ ...order, lines: chunk }, printer.paperWidth, at));
}
