import type { Doc } from "@/convex/_generated/dataModel.d.ts";

export type ItemColor = Doc<"items">["color"];

// Fixed swatch colors (same in light and dark mode, like printed labels)
export const ITEM_COLORS: Record<ItemColor, string> = {
  gray: "bg-[#9e9e9e]",
  red: "bg-[#e53935]",
  pink: "bg-[#ec407a]",
  orange: "bg-[#fb8c00]",
  yellow: "bg-[#fdd835]",
  green: "bg-[#43a047]",
  blue: "bg-[#1e88e5]",
  purple: "bg-[#8e24aa]",
};

export const ITEM_COLOR_KEYS = Object.keys(ITEM_COLORS) as ItemColor[];
