import { describe, expect, it } from "vitest";
import { quickCashAmounts } from "./payments.ts";

describe("quickCashAmounts", () => {
  it("starts with the exact total and adds round notes above it", () => {
    expect(quickCashAmounts(18500)).toEqual([18500, 20000, 50000, 100000]);
  });

  it("does not duplicate when the total is already round", () => {
    expect(quickCashAmounts(10000)).toEqual([10000, 20000, 50000, 100000]);
  });

  it("returns at most four suggestions", () => {
    expect(quickCashAmounts(1234).length).toBeLessThanOrEqual(4);
  });
});
