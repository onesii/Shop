// Items <-> spreadsheet rows. The layout follows Loyverse's item export, so a file
// exported there can be imported here: variant rows share one Handle.
import Papa from "papaparse";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { itemUnit, type WeightUnit } from "@/convex/lib/quantity.ts";
import { centsToInput, parseToCents } from "@/lib/money.ts";

export const MAX_IMPORT_FILE_BYTES = 5 * 1024 * 1024;
export const MAX_IMPORT_ROWS = 10_000;

const COL = {
  handle: "Handle",
  name: "Name",
  category: "Category",
  soldByWeight: "Sold by weight",
  unit: "Unit",
  optionName: "Option 1 name",
  optionValue: "Option 1 value",
  price: "Price",
  trackStock: "Track stock",
  inStock: "In stock",
  lowStock: "Low stock",
} as const;

type ExportEntry = { item: Doc<"items">; levels: Doc<"stockLevels">[] };
export type CsvRow = Record<string, string>;
export const ITEM_COLUMNS: string[] = Object.values(COL);

function handleOf(name: string): string {
  return name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "item";
}

/** One row per item, or one per variant (sharing the item's Handle). */
export function itemsToRows(entries: ExportEntry[], categoryName: (id: Doc<"items">["categoryId"]) => string): CsvRow[] {
  const used = new Set<string>();
  // Similar names ("Ajab 2kgs", "ajab-2kgs") must not share a Handle, or a re-import merges them
  const uniqueHandle = (name: string) => {
    const base = handleOf(name);
    let handle = base;
    for (let n = 2; used.has(handle); n++) handle = `${base}-${n}`;
    used.add(handle);
    return handle;
  };
  return entries.flatMap(({ item, levels }) => {
    const unit = itemUnit(item);
    const tracked = levels.length > 0;
    const handle = uniqueHandle(item.name);
    const level = (variant: string | null) => levels.find((l) => l.variantName === variant);
    const base = (priceCents: number | null, variant: string | null, first: boolean): CsvRow => {
      const l = level(variant);
      return {
        [COL.handle]: handle,
        [COL.name]: first ? item.name : "",
        [COL.category]: first ? categoryName(item.categoryId) : "",
        [COL.soldByWeight]: first ? (unit ? "Y" : "N") : "",
        [COL.unit]: first && unit ? unit : "",
        [COL.optionName]: variant !== null && first ? "Variant" : "",
        [COL.optionValue]: variant ?? "",
        [COL.price]: priceCents === null ? "" : centsToInput(priceCents),
        [COL.trackStock]: first ? (tracked ? "Y" : "N") : "",
        [COL.inStock]: l ? String(l.inStock) : "",
        [COL.lowStock]: l?.lowStock != null ? String(l.lowStock) : "",
      };
    };
    if (item.variants.length === 0) return [base(item.priceCents, null, true)];
    return item.variants.map((v, i) => base(v.priceCents, v.name, i === 0));
  });
}

export type ImportItem = {
  sourceRow: number;
  name: string;
  category: string | null;
  soldBy: "each" | "weight";
  weightUnit?: WeightUnit;
  priceCents: number | null;
  variants: { name: string; priceCents: number | null }[];
  stock: { variantName: string | null; inStock: number; lowStock: number | null }[] | null;
};
export type RowProblem = { sourceRow: number; name: string; reason: string };
export type ParsedImport = { items: ImportItem[]; problems: RowProblem[] };

const normalize = (h: string) => h.replace(/^\ufeff/, "").trim().toLowerCase();

/** Finds a column by exact name, or by prefix (Loyverse adds the store: "Price [Main]"). */
function findColumn(fields: string[], name: string): string | undefined {
  const key = name.toLowerCase();
  return fields.find((f) => f === key) ?? fields.find((f) => f.startsWith(`${key} [`) || f.startsWith(`${key}[`));
}

const yes = (s: string | undefined) => /^(y|yes|true|1)$/i.test(s?.trim() ?? "");

function parseNumber(text: string): number | null | "bad" {
  const t = text.replace(/[,\s]/g, "");
  if (t === "") return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : "bad";
}

type Group = { sourceRow: number; rows: { record: number; get: (c: string | undefined) => string }[] };

/** Builds one item from its group of rows, or returns why it can't be imported. */
function buildItem(group: Group, hasStockColumn: boolean): ImportItem | RowProblem {
  const first = group.rows[0];
  const name = first.get("name").trim();
  const problem = (reason: string): RowProblem => ({ sourceRow: group.sourceRow, name: name || "(no name)", reason });
  if (!name) return problem("Name is missing");

  const weight = yes(first.get("sold by weight"));
  const unitText = first.get("unit").trim().toLowerCase();
  const weightUnit: WeightUnit | undefined = weight ? (unitText === "g" || unitText.startsWith("gram") ? "g" : "kg") : undefined;

  const parsed: { variant: string | null; priceCents: number | null; inStock: number | null; lowStock: number | null }[] = [];
  for (const r of group.rows) {
    const priceText = r.get("price").trim();
    const priceCents = priceText === "" || /^variable$/i.test(priceText) ? null : parseToCents(priceText);
    if (priceCents !== null && Number.isNaN(priceCents)) return problem(`Row ${r.record}: price "${priceText}" is not a number`);
    const inStock = parseNumber(r.get("in stock"));
    const lowStock = parseNumber(r.get("low stock"));
    if (inStock === "bad" || lowStock === "bad") return problem(`Row ${r.record}: stock is not a number`);
    const variant = r.get("option 1 value").trim() || null;
    parsed.push({ variant, priceCents, inStock, lowStock });
  }

  const variantRows = parsed.filter((p) => p.variant !== null);
  if (variantRows.length > 0 && variantRows.length !== parsed.length) {
    return problem("Some rows of this item have a variant and some don't");
  }
  const names = variantRows.map((p) => p.variant);
  if (new Set(names).size !== names.length) return problem("A variant is listed twice");

  const trackColumn = first.get("track stock").trim();
  const track = trackColumn ? yes(trackColumn) : hasStockColumn && parsed.some((p) => p.inStock !== null);
  return {
    sourceRow: group.sourceRow,
    name,
    category: first.get("category").trim() || null,
    soldBy: weight ? "weight" : "each",
    ...(weightUnit ? { weightUnit } : {}),
    priceCents: variantRows.length > 0 ? null : parsed[0].priceCents,
    variants: variantRows.map((p) => ({ name: p.variant ?? "", priceCents: p.priceCents })),
    // Stock counts are whole numbers; round the odd decimal from other systems
    stock: track
      ? parsed.map((p) => ({
          variantName: p.variant,
          inStock: Math.round(p.inStock ?? 0),
          lowStock: p.lowStock === null ? null : Math.round(p.lowStock),
        }))
      : null,
  };
}

/** Parses CSV text into items to import, plus rows that can't be imported. */
export function parseItemsCsv(text: string): ParsedImport | { fileError: string } {
  const result = Papa.parse<Record<string, string>>(text, {
    header: true,
    skipEmptyLines: "greedy",
    dynamicTyping: false,
    transformHeader: normalize,
  });
  const fileError = result.errors.find((e) => e.type !== "FieldMismatch");
  if (fileError) return { fileError: `The file couldn't be read: ${fileError.message}` };
  const fields = result.meta.fields ?? [];
  const nameCol = findColumn(fields, "name");
  if (!nameCol) return { fileError: 'The file needs a "Name" column' };
  if (result.data.length > MAX_IMPORT_ROWS) return { fileError: `Import up to ${MAX_IMPORT_ROWS.toLocaleString()} rows at a time` };

  const cols: Record<string, string | undefined> = {
    name: nameCol,
    handle: findColumn(fields, "handle"),
    category: findColumn(fields, "category"),
    "sold by weight": findColumn(fields, "sold by weight"),
    unit: findColumn(fields, "unit"),
    "option 1 value": findColumn(fields, "option 1 value"),
    price: findColumn(fields, "price") ?? findColumn(fields, "default price"),
    "track stock": findColumn(fields, "track stock"),
    "in stock": findColumn(fields, "in stock"),
    "low stock": findColumn(fields, "low stock"),
  };
  const mismatched = new Set(result.errors.map((e) => e.row));
  const problems: RowProblem[] = [];
  const groups = new Map<string, Group>();

  result.data.forEach((raw, index) => {
    // Data record number, counting the header as record 1 like a spreadsheet row
    const record = index + 2;
    const get = (c: string | undefined) => (c ? (raw[cols[c] ?? ""] ?? "") : "");
    if (mismatched.has(index)) {
      problems.push({ sourceRow: record, name: get("name") || "(unknown)", reason: "Row has the wrong number of columns" });
      return;
    }
    const handle = get("handle").trim().toLowerCase();
    const name = get("name").trim();
    // Variant rows share their item's Handle (and often have no Name)
    const key = handle || (name ? `name:${name.toLowerCase()}` : null);
    if (!key) {
      problems.push({ sourceRow: record, name: "(no name)", reason: "Name is missing" });
      return;
    }
    const group = groups.get(key);
    if (group) group.rows.push({ record, get });
    else groups.set(key, { sourceRow: record, rows: [{ record, get }] });
  });

  const items: ImportItem[] = [];
  const hasStockColumn = cols["in stock"] !== undefined;
  for (const group of groups.values()) {
    const built = buildItem(group, hasStockColumn);
    if ("reason" in built) problems.push(built);
    else items.push(built);
  }
  problems.sort((a, b) => a.sourceRow - b.sourceRow);
  return { items, problems };
}
