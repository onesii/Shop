export type InstallPlatform = "ios" | "android" | "samsung" | "in-app" | "desktop";

const IN_APP_BROWSER = /FBAN|FBAV|Instagram|Line\/|TikTok|musical_ly|Snapchat|LinkedInApp|Twitter/i;

/** Works out which install steps to show, from the browser's user agent. */
export function detectPlatform(userAgent: string, maxTouchPoints = 0): InstallPlatform {
  if (IN_APP_BROWSER.test(userAgent)) return "in-app";
  // iPadOS reports itself as a Mac, so touch support tells them apart
  const isIos = /iPhone|iPad|iPod/i.test(userAgent) || (/Macintosh/i.test(userAgent) && maxTouchPoints > 1);
  if (isIos) return "ios";
  if (/SamsungBrowser/i.test(userAgent)) return "samsung";
  if (/Android/i.test(userAgent)) return "android";
  return "desktop";
}

export const INSTALL_STEPS: Record<InstallPlatform, string[]> = {
  ios: [
    "Open this page in Safari.",
    "Tap Share. On newer iPhones and iPads it is inside the \"...\" menu next to the address bar.",
    "Tap \"Add to Home Screen\", then \"Add\".",
  ],
  android: [
    "Open this page in Chrome.",
    "Tap the menu (three dots) at the top right.",
    "Tap \"Install app\" or \"Add to Home screen\".",
  ],
  samsung: [
    "Samsung Internet can't install this app safely.",
    "Open this page in Chrome instead.",
    "Tap the menu (three dots), then \"Install app\".",
  ],
  "in-app": [
    "This browser can't install apps.",
    "Open the menu and choose \"Open in browser\" (Safari or Chrome).",
    "Then come back to this screen and tap Install app.",
  ],
  desktop: [
    "Open this page in Chrome or Edge.",
    "Click the install icon at the right of the address bar.",
    "Click \"Install\".",
  ],
};
