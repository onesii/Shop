import { describe, expect, it } from "vitest";
import { centsToInput, formatKsh, parseToCents } from "./money.ts";

describe("money helpers", () => {
  it("formats cents as KSh with thousands separators", () => {
    expect(formatKsh(190000)).toBe("KSh1,900.00");
    expect(formatKsh(3550)).toBe("KSh35.50");
  });

  it("parses typed prices into cents without float drift", () => {
    expect(parseToCents("1,900.50")).toBe(190050);
    expect(parseToCents("0.29")).toBe(29);
    expect(parseToCents("150")).toBe(15000);
  });

  it("returns null for empty and NaN for invalid input", () => {
    expect(parseToCents("")).toBeNull();
    expect(parseToCents("abc")).toBeNaN();
    expect(parseToCents("1.234")).toBeNaN();
  });

  it("round-trips through the edit input", () => {
    expect(parseToCents(centsToInput(22500))).toBe(22500);
    expect(centsToInput(null)).toBe("");
  });
});
