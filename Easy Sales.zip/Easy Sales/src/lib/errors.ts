import { ConvexError } from "convex/values";

/** Pulls the friendly message out of a ConvexError, with a fallback. */
export function convexMessage(err: unknown, fallback: string): string {
  if (err instanceof ConvexError) {
    return (err.data as { message?: string }).message ?? fallback;
  }
  return fallback;
}
