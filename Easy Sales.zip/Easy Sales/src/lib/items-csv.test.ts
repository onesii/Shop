import { describe, expect, it } from "vitest";
import Papa from "papaparse";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { ITEM_COLUMNS, itemsToRows, parseItemsCsv, type ParsedImport } from "./items-csv.ts";

function parse(text: string): ParsedImport {
  const r = parseItemsCsv(text);
  if ("fileError" in r) throw new Error(r.fileError);
  return r;
}

const item = (over: Partial<Doc<"items">>): Doc<"items"> => ({
  _id: "i1" as Id<"items">,
  _creationTime: 0,
  ownerId: "u1" as Id<"users">,
  name: "Soda",
  categoryId: null,
  priceCents: 6000,
  color: "gray",
  variants: [],
  ...over,
});

describe("parseItemsCsv", () => {
  it("reads a Loyverse export with variant rows and store columns", () => {
    const csv = [
      "Handle,SKU,Name,Category,Sold by weight,Option 1 name,Option 1 value,Price [Main],In stock [Main],Low stock [Main]",
      "ajab-1kg,1,ajab 1kg,Drinks,N,,,100,20,5",
      "amla,2,amla pwd,Spices,N,Size,Small,500,3,",
      "amla,3,,,,,Large,,7,",
      "rice,4,Rice,,Y,,,180,,",
    ].join("\n");
    const { items, problems } = parse(csv);
    expect(problems).toEqual([]);
    expect(items).toHaveLength(3);
    expect(items[0]).toMatchObject({
      name: "ajab 1kg",
      category: "Drinks",
      priceCents: 10000,
      stock: [{ variantName: null, inStock: 20, lowStock: 5 }],
    });
    expect(items[1]).toMatchObject({
      name: "amla pwd",
      priceCents: null,
      variants: [
        { name: "Small", priceCents: 50000 },
        { name: "Large", priceCents: null },
      ],
      stock: [
        { variantName: "Small", inStock: 3, lowStock: null },
        { variantName: "Large", inStock: 7, lowStock: null },
      ],
    });
    // Sold by weight defaults to kg; no stock numbers means stock isn't tracked
    expect(items[2]).toMatchObject({ soldBy: "weight", weightUnit: "kg", stock: null });
  });

  it("treats a blank or 'Variable' price as entered at the time of sale", () => {
    const { items } = parse("Name,Price\nFoil,\nCake,Variable");
    expect(items.map((i) => i.priceCents)).toEqual([null, null]);
  });

  it("reports bad rows with their spreadsheet row number and keeps the rest", () => {
    const { items, problems } = parse("Name,Price\nGood,10\nBad,ten\n,5");
    expect(items.map((i) => i.name)).toEqual(["Good"]);
    expect(problems).toEqual([
      { sourceRow: 3, name: "Bad", reason: 'Row 3: price "ten" is not a number' },
      { sourceRow: 4, name: "(no name)", reason: "Name is missing" },
    ]);
  });

  it("needs a Name column", () => {
    expect(parseItemsCsv("Title,Price\nSoda,10")).toEqual({ fileError: 'The file needs a "Name" column' });
  });

  it("round-trips its own export, including grams and Track stock", () => {
    const rows = itemsToRows(
      [
        { item: item({ name: "Sugar", soldBy: "weight", weightUnit: "g", priceCents: 20 }), levels: [] },
        {
          item: item({ name: "Shirt", priceCents: null, variants: [{ name: "S", priceCents: 800 }, { name: "L", priceCents: 900 }] }),
          levels: [],
        },
        // Two items named alike must keep separate Handles
        { item: item({ name: "sugar" }), levels: [] },
      ],
      () => "",
    );
    const { items, problems } = parse(Papa.unparse(rows, { columns: ITEM_COLUMNS }));
    expect(problems).toEqual([]);
    expect(items.map((i) => i.name)).toEqual(["Sugar", "Shirt", "sugar"]);
    expect(items[0]).toMatchObject({ soldBy: "weight", weightUnit: "g", priceCents: 20, stock: null });
    expect(items[1].variants).toEqual([
      { name: "S", priceCents: 800 },
      { name: "L", priceCents: 900 },
    ]);
  });
});
