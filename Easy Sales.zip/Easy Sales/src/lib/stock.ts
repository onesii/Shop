import type { ManualStockReason, StockReason, StockStatus } from "@/convex/lib/stock.ts";

export const REASON_LABELS: Record<StockReason, string> = {
  receive: "Receive items",
  loss: "Loss",
  damage: "Damage",
  recount: "Inventory count",
  edit: "Item edit",
  sale: "Sale",
  refund: "Refund",
};

export const MANUAL_REASONS: { value: ManualStockReason; label: string; hint: string }[] = [
  { value: "receive", label: REASON_LABELS.receive, hint: "Adds to stock" },
  { value: "loss", label: REASON_LABELS.loss, hint: "Removes from stock" },
  { value: "damage", label: REASON_LABELS.damage, hint: "Removes from stock" },
  { value: "recount", label: REASON_LABELS.recount, hint: "Sets the counted stock" },
];

export const STATUS_LABELS: Record<StockStatus, string> = {
  out: "Out of stock",
  low: "Low stock",
  ok: "In stock",
};

/** Parses a whole-number stock field. Empty gives `fallback`, anything else invalid gives NaN. */
export function parseStockInput(text: string, fallback: number | null): number | null {
  const t = text.trim();
  if (t === "") return fallback;
  return /^-?\d+$/.test(t) ? Number(t) : Number.NaN;
}

export function stockLabel(variantName: string | null, itemName: string): string {
  return variantName ? `${itemName} (${variantName})` : itemName;
}

/** Text being typed into the item form's stock fields. */
export type StockDraft = { inStock: string; lowStock: string };
export const EMPTY_STOCK: StockDraft = { inStock: "", lowStock: "" };
