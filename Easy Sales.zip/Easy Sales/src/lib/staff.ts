import type { Permission, Role } from "@/convex/lib/access.ts";

export const ROLE_LABELS: Record<Role, string> = {
  owner: "Owner",
  manager: "Manager",
  cashier: "Cashier",
};

export const PERMISSION_INFO: Record<Permission, { label: string; description: string }> = {
  refunds: { label: "Issue refunds", description: "Refund sales from the receipts screen" },
  discounts: { label: "Apply discounts", description: "Add discounts to a ticket at checkout" },
  items: { label: "Manage items and stock", description: "Edit items, categories, discounts and inventory" },
  customers: { label: "Manage customers", description: "Add, edit and delete customers" },
  reports: { label: "View reports", description: "See sales reports in the back office" },
  employees: { label: "Manage employees", description: "Add cashiers, edit timecards and see hours worked" },
  settings: { label: "Change settings", description: "Taxes, printers and store settings" },
};
