const formatter = new Intl.NumberFormat("en-KE", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/** Formats integer cents as "KSh1,900.00". */
export function formatKsh(cents: number): string {
  return `KSh${formatter.format(cents / 100)}`;
}

/** Parses "1,900.50" into cents. Returns null for empty input, NaN for invalid. */
export function parseToCents(input: string): number | null {
  const cleaned = input.replace(/[,\s]/g, "").replace(/^KSh/i, "");
  if (cleaned === "") return null;
  if (!/^\d+(\.\d{0,2})?$/.test(cleaned)) return Number.NaN;
  return Math.round(Number(cleaned) * 100);
}

/** Converts cents into a plain editable string, e.g. 190000 -> "1900.00". */
export function centsToInput(cents: number | null): string {
  return cents === null ? "" : (cents / 100).toFixed(2);
}
