import type { DiscountType } from "@/convex/lib/discounts.ts";
import { formatRate } from "@/convex/lib/taxes.ts";
import { formatKsh } from "./money.ts";

/** "10%" for percentages, "KSh50.00" for fixed amounts. */
export function formatDiscountValue(type: DiscountType, value: number): string {
  return type === "percent" ? formatRate(value) : formatKsh(value);
}
