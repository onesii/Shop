// Sales rung up without a connection wait here (on this device) until they reach
// the server. Each one carries the clientId the server uses to save it only once.
import { useSyncExternalStore } from "react";
import { z } from "zod";
import type { FunctionArgs } from "convex/server";
import type { api } from "@/convex/_generated/api.js";

export type ChargeArgs = FunctionArgs<typeof api.sales.receipts.charge>;

const STORAGE_KEY = "pos.offline-sales.v1";

const lineSchema = z.object({
  itemId: z.string().nullable(),
  name: z.string(),
  variantName: z.string().nullable(),
  priceCents: z.number(),
  quantity: z.number(),
  comment: z.string().optional(),
  unit: z.enum(["kg", "g"]).optional(),
});

const argsSchema = z.object({
  lines: z.array(lineSchema),
  discountIds: z.array(z.string()).optional(),
  paymentMethod: z.enum(["cash", "card", "mpesa"]),
  tenderedCents: z.number(),
  mpesaReference: z.string().optional(),
  openTicketId: z.string().optional(),
  customerId: z.string().optional(),
  clientId: z.string(),
  soldAt: z.string(),
});

const entrySchema = z.object({
  args: argsSchema,
  totalCents: z.number(),
  /** Set when the server refused the sale; it then waits for the cashier. */
  error: z.string().nullable(),
});

export type QueuedSale = Omit<z.infer<typeof entrySchema>, "args"> & {
  args: ChargeArgs & { clientId: string; soldAt: string };
};

const EMPTY: QueuedSale[] = [];
const listeners = new Set<() => void>();
let cachedRaw: string | null | undefined;
let cached: QueuedSale[] = EMPTY;

function readRaw(): string | null {
  try {
    return localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

function parse(raw: string | null): QueuedSale[] {
  if (!raw) return EMPTY;
  try {
    const result = z.array(entrySchema).safeParse(JSON.parse(raw));
    // Ids were valid when queued; the server checks them again on sync
    return result.success ? (result.data as QueuedSale[]) : EMPTY;
  } catch {
    return EMPTY;
  }
}

export function getQueuedSales(): QueuedSale[] {
  const raw = readRaw();
  if (raw !== cachedRaw) {
    cachedRaw = raw;
    cached = parse(raw);
  }
  return cached;
}

function write(list: QueuedSale[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  window.addEventListener("storage", listener);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", listener);
  };
}

export function useQueuedSales(): QueuedSale[] {
  return useSyncExternalStore(subscribe, getQueuedSales, () => EMPTY);
}

export function queueSale(sale: QueuedSale) {
  const list = getQueuedSales();
  if (list.some((s) => s.args.clientId === sale.args.clientId)) return;
  write([...list, sale]);
}

export function removeQueuedSale(clientId: string) {
  write(getQueuedSales().filter((s) => s.args.clientId !== clientId));
}

export function setQueuedSaleError(clientId: string, error: string | null) {
  write(getQueuedSales().map((s) => (s.args.clientId === clientId ? { ...s, error } : s)));
}
