import { beforeEach, describe, expect, it } from "vitest";
import { getQueuedSales, queueSale, removeQueuedSale, setQueuedSaleError, type QueuedSale } from "./sales-queue.ts";

function sale(clientId: string): QueuedSale {
  return {
    args: {
      lines: [{ itemId: null, name: "Soda", variantName: null, priceCents: 5000, quantity: 2 }],
      paymentMethod: "cash",
      tenderedCents: 10000,
      clientId,
      soldAt: "2026-11-21T10:00:00.000Z",
    },
    totalCents: 10000,
    error: null,
  };
}

describe("offline sales queue", () => {
  beforeEach(() => localStorage.clear());

  it("keeps sales in order and never queues the same sale twice", () => {
    queueSale(sale("a"));
    queueSale(sale("b"));
    queueSale(sale("a"));
    expect(getQueuedSales().map((s) => s.args.clientId)).toEqual(["a", "b"]);
  });

  it("marks and clears errors, and removes synced sales", () => {
    queueSale(sale("a"));
    setQueuedSaleError("a", "Open a shift");
    expect(getQueuedSales()[0].error).toBe("Open a shift");
    setQueuedSaleError("a", null);
    expect(getQueuedSales()[0].error).toBeNull();
    removeQueuedSale("a");
    expect(getQueuedSales()).toEqual([]);
  });

  it("ignores corrupt storage instead of crashing", () => {
    localStorage.setItem("pos.offline-sales.v1", "{not json");
    expect(getQueuedSales()).toEqual([]);
  });
});
