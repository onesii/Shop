import { useEffect, useRef, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { motion } from "motion/react";
import { ArrowLeft, CheckCircle2, CloudOff, Printer, ReceiptText } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { usePrintReceipt } from "@/hooks/use-print-receipt.ts";
import { useTicket } from "@/hooks/use-ticket.tsx";
import { useTicketTotals } from "@/hooks/use-ticket-totals.ts";
import { useOfflineSync } from "@/hooks/use-offline-sync.tsx";
import { CHARGE_TIMEOUT_MS, withTimeout } from "@/lib/offline/timeout.ts";
import { queueSale, type ChargeArgs } from "@/lib/offline/sales-queue.ts";
import type { PrintableReceipt } from "@/lib/printing/receipt-layout.ts";
import TaxBreakdown from "@/components/taxes/tax-breakdown.tsx";
import { formatKsh, parseToCents } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import { PAYMENT_METHODS, quickCashAmounts, type PaymentMethod } from "@/lib/payments.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";

/** A sale saved on the server, or one kept on this device until it syncs. */
type Done =
  | { mode: "online"; id: Id<"receipts">; number: string; totalCents: number; changeCents: number }
  | { mode: "offline"; receipt: PrintableReceipt };

function errorMessage(err: unknown): string {
  return convexMessage(err, "Payment failed");
}

export default function ChargePage() {
  const navigate = useNavigate();
  const { lines, saved, customer, clear } = useTicket();
  const { subtotalCents, discounts, appliedDiscounts, taxes, totalCents, ready } = useTicketTotals();
  const settings = useQuery(api.settings.get, {});
  const { online } = useOfflineSync();
  const charge = useMutation(api.sales.receipts.charge);
  const [cashText, setCashText] = useState("");
  const [mpesaRef, setMpesaRef] = useState("");
  const [busy, setBusy] = useState<PaymentMethod | null>(null);
  const [done, setDone] = useState<Done | null>(null);

  if (done) return <ChargeSuccess done={done} onNewSale={() => navigate("/")} />;
  if (lines.length === 0) return <Navigate to="/" replace />;

  const typedCash = parseToCents(cashText);
  const cashCents = typedCash === null ? totalCents : typedCash;
  const cashInvalid = Number.isNaN(cashCents) || cashCents < totalCents;

  // Same ticket, same receipt fields the server would store, for printing offline
  const offlineReceipt = (args: ChargeArgs & { soldAt: string }): PrintableReceipt => ({
    number: "Pending sync",
    kind: "sale",
    createdAt: args.soldAt,
    lines: args.lines,
    totalCents,
    paymentMethod: args.paymentMethod,
    tenderedCents: args.tenderedCents,
    changeCents: args.tenderedCents - totalCents,
    mpesaReference: args.mpesaReference?.trim() || null,
    subtotalCents,
    taxes,
    discounts,
    storeName: settings?.storeName,
    posName: settings?.posName,
    receiptHeader: settings?.receiptHeader,
    receiptFooter: settings?.receiptFooter,
    showCustomerInfo: settings?.showCustomerInfo,
    showComments: settings?.showComments,
    customerName: customer?.name,
  });

  const pay = async (method: PaymentMethod, tendered: number) => {
    const args = {
      lines: lines.map((l) => ({
        itemId: l.itemId,
        name: l.name,
        variantName: l.variantName,
        priceCents: l.priceCents,
        quantity: l.quantity,
        ...(l.comment ? { comment: l.comment } : {}),
        ...(l.unit ? { unit: l.unit } : {}),
      })),
      discountIds: appliedDiscounts.map((d) => d._id),
      paymentMethod: method,
      tenderedCents: method === "cash" ? tendered : totalCents,
      mpesaReference: method === "mpesa" ? mpesaRef : undefined,
      openTicketId: saved?.id,
      customerId: customer?.id,
      // The server saves a sale only once per id, so a retry never doubles it
      clientId: crypto.randomUUID(),
      soldAt: new Date().toISOString(),
    } satisfies ChargeArgs;

    const keepOffline = () => {
      queueSale({ args, totalCents, error: null });
      clear();
      setDone({ mode: "offline", receipt: offlineReceipt(args) });
    };

    if (!online) return keepOffline();
    setBusy(method);
    try {
      const result = await withTimeout(charge(args), CHARGE_TIMEOUT_MS);
      clear();
      setDone({ mode: "online", ...result });
    } catch (err) {
      // The server said no: show why. Anything else is a lost connection.
      if (err instanceof ConvexError) toast.error(errorMessage(err));
      else keepOffline();
    } finally {
      setBusy(null);
    }
  };

  return (
    <>
      <header className="sticky top-0 z-30 flex h-14 shrink-0 items-center gap-2 bg-secondary px-2 text-secondary-foreground shadow-md">
        <button
          type="button"
          aria-label="Back to sale"
          onClick={() => navigate("/")}
          className="flex size-10 cursor-pointer items-center justify-center rounded-full transition hover:bg-white/10"
        >
          <ArrowLeft className="size-6" />
        </button>
        <span className="pl-2 text-lg font-semibold">Charge</span>
      </header>

      <main className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-xl space-y-8 px-4 py-8">
          <div className="text-center">
            <p className="text-5xl font-bold tabular-nums tracking-tight">{formatKsh(totalCents)}</p>
            <p className="pt-2 text-sm text-muted-foreground">
              Total amount due{customer ? ` · ${customer.name}` : ""}
            </p>
            <TaxBreakdown
              subtotalCents={subtotalCents}
              taxes={taxes}
              discounts={discounts}
              className="mx-auto max-w-xs pt-4 text-left"
            />
          </div>

          {!online && (
            <p className="flex items-center gap-2 rounded-md bg-muted px-3 py-2 text-sm text-muted-foreground">
              <CloudOff className="size-4 shrink-0" />
              {"You're offline. The sale is saved on this device and sent when you're back online."}
            </p>
          )}

          {/* Cash */}
          <section className="space-y-3 rounded-md border bg-card p-4">
            <Label htmlFor="cash" className="text-muted-foreground">Cash received</Label>
            <Input
              id="cash"
              inputMode="decimal"
              value={cashText}
              onChange={(e) => setCashText(e.target.value)}
              placeholder={(totalCents / 100).toFixed(2)}
              className="h-12 border-0 border-b-2 border-primary rounded-none px-0 text-2xl font-semibold shadow-none focus-visible:ring-0"
            />
            <div className="flex flex-wrap gap-2">
              {quickCashAmounts(totalCents).map((amount) => (
                <Button
                  key={amount}
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => setCashText((amount / 100).toFixed(2))}
                >
                  {formatKsh(amount)}
                </Button>
              ))}
            </div>
            {!cashInvalid && cashCents > totalCents && (
              <p className="text-sm text-muted-foreground">
                Change: <span className="font-semibold text-foreground">{formatKsh(cashCents - totalCents)}</span>
              </p>
            )}
            {cashInvalid && <p className="text-sm text-destructive">Amount is less than the total</p>}
            <PayButton method="cash" busy={busy} disabled={!ready || cashInvalid} onClick={() => pay("cash", cashCents)} />
          </section>

          {/* Card */}
          <PayButton method="card" busy={busy} disabled={!ready} onClick={() => pay("card", totalCents)} />

          {/* M-Pesa */}
          <section className="space-y-3 rounded-md border bg-card p-4">
            <Label htmlFor="mpesa" className="text-muted-foreground">M-Pesa transaction code (optional)</Label>
            <Input
              id="mpesa"
              value={mpesaRef}
              onChange={(e) => setMpesaRef(e.target.value.toUpperCase())}
              placeholder="SJK4XXXXXX"
            />
            <PayButton method="mpesa" busy={busy} disabled={!ready} onClick={() => pay("mpesa", totalCents)} />
          </section>
        </div>
      </main>
    </>
  );
}

function PayButton({
  method,
  busy,
  disabled,
  onClick,
}: {
  method: PaymentMethod;
  busy: PaymentMethod | null;
  disabled?: boolean;
  onClick: () => void;
}) {
  const { label, icon: Icon } = PAYMENT_METHODS[method];
  return (
    <Button
      type="button"
      size="lg"
      disabled={disabled || busy !== null}
      onClick={onClick}
      className="h-14 w-full rounded-sm text-base font-semibold uppercase"
    >
      {busy === method ? <Spinner /> : <Icon className="size-5" />}
      {label}
    </Button>
  );
}

function ChargeSuccess({ done, onNewSale }: { done: Done; onNewSale: () => void }) {
  const navigate = useNavigate();
  const data = useQuery(api.sales.receipts.get, done.mode === "online" ? { id: done.id } : "skip");
  const { print, printing, hasAutoPrint } = usePrintReceipt();
  const autoPrinted = useRef(false);
  const receipt = done.mode === "offline" ? done.receipt : data?.receipt;
  const totalCents = done.mode === "offline" ? done.receipt.totalCents : done.totalCents;
  const changeCents = done.mode === "offline" ? done.receipt.changeCents : done.changeCents;

  // Auto print once, as soon as the receipt is ready
  useEffect(() => {
    if (!receipt || !hasAutoPrint || autoPrinted.current) return;
    autoPrinted.current = true;
    void print(receipt, true);
  }, [receipt, hasAutoPrint, print]);
  return (
    <main className="flex flex-1 items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="w-full max-w-md space-y-8 text-center"
      >
        <CheckCircle2 className="mx-auto size-16 text-primary" />
        <div className="grid grid-cols-2 divide-x rounded-md border bg-card py-6">
          <div>
            <p className="text-2xl font-bold tabular-nums">{formatKsh(totalCents)}</p>
            <p className="text-sm text-muted-foreground">Total paid</p>
          </div>
          <div>
            <p className="text-2xl font-bold tabular-nums">{formatKsh(changeCents)}</p>
            <p className="text-sm text-muted-foreground">Change</p>
          </div>
        </div>
        {done.mode === "online" ? (
          <p className="text-sm text-muted-foreground">Receipt #{done.number}</p>
        ) : (
          <p className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <CloudOff className="size-4" /> Saved offline. It syncs when you are back online.
          </p>
        )}
        <div className="space-y-3">
          <Button size="lg" className="h-14 w-full rounded-sm text-base font-semibold uppercase" onClick={onNewSale}>
            New sale
          </Button>
          <Button
            variant="secondary"
            className="h-12 w-full rounded-sm uppercase"
            disabled={!receipt || printing}
            onClick={() => receipt && void print(receipt)}
          >
            {printing ? <Spinner /> : <Printer className="size-4" />} Print receipt
          </Button>
          {done.mode === "online" && (
            <Button variant="ghost" className="w-full" onClick={() => navigate(`/receipts?id=${done.id}`)}>
              <ReceiptText className="size-4" /> View receipt
            </Button>
          )}
        </div>
      </motion.div>
    </main>
  );
}
