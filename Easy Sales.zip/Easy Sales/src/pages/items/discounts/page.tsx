import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { Plus, Tag } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import AppBar from "@/components/layout/app-bar.tsx";
import { formatDiscountValue } from "@/lib/discounts.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import DiscountFormDialog from "./_components/discount-form-dialog.tsx";

export default function DiscountsPage() {
  const navigate = useNavigate();
  const discounts = useQuery(api.catalog.discounts.list, {});
  const [editing, setEditing] = useState<Doc<"discounts"> | null>(null);
  const [formOpen, setFormOpen] = useState(false);

  const openForm = (discount: Doc<"discounts"> | null) => {
    setEditing(discount);
    setFormOpen(true);
  };

  return (
    <>
      <AppBar title="Discounts" onBack={() => navigate("/items")} />
      <main className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl pb-24">
          {discounts === undefined ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4 border-b px-4 py-3">
                <Skeleton className="size-10 rounded-full" />
                <Skeleton className="h-4 flex-1" />
                <Skeleton className="h-4 w-16" />
              </div>
            ))
          ) : discounts.length === 0 ? (
            <Empty className="pt-20">
              <EmptyHeader>
                <EmptyMedia variant="icon"><Tag /></EmptyMedia>
                <EmptyTitle>You have no discounts yet</EmptyTitle>
                <EmptyDescription>Create a percentage or KSh discount to apply at checkout</EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button size="sm" onClick={() => openForm(null)}>Create discount</Button>
              </EmptyContent>
            </Empty>
          ) : (
            discounts.map((d) => (
              <button
                key={d._id}
                type="button"
                onClick={() => openForm(d)}
                className="flex w-full cursor-pointer items-center gap-4 border-b bg-card px-4 py-2.5 text-left transition-colors hover:bg-muted active:bg-accent"
              >
                <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Tag className="size-5" />
                </span>
                <span className="min-w-0 flex-1 truncate font-medium">{d.name}</span>
                <span className="shrink-0 text-sm tabular-nums text-muted-foreground">
                  {formatDiscountValue(d.type, d.value)}
                </span>
              </button>
            ))
          )}
        </div>

        <Button
          size="icon"
          aria-label="Create discount"
          onClick={() => openForm(null)}
          className="fixed bottom-6 right-6 size-14 rounded-full shadow-lg"
        >
          <Plus className="size-6" />
        </Button>
      </main>

      <DiscountFormDialog open={formOpen} discount={editing} onClose={() => setFormOpen(false)} />
    </>
  );
}
