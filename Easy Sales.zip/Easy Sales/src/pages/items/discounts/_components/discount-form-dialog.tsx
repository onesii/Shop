import { useState } from "react";
import { useMutation } from "convex/react";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import type { DiscountType } from "@/convex/lib/discounts.ts";
import { parseRateBps } from "@/convex/lib/taxes.ts";
import { centsToInput, parseToCents } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";

type Props = { open: boolean; discount: Doc<"discounts"> | null; onClose: () => void };

export default function DiscountFormDialog({ open, discount, onClose }: Props) {
  // Keyed remount resets the form whenever a different discount is opened
  return open ? <DiscountForm key={discount?._id ?? "new"} discount={discount} onClose={onClose} /> : null;
}

function initialValue(discount: Doc<"discounts"> | null): string {
  if (!discount) return "";
  return discount.type === "percent" ? String(discount.value / 100) : centsToInput(discount.value);
}

/** Returns the stored value (bps or cents) or an error message. */
function parseValue(type: DiscountType, text: string): number | string {
  if (!text.trim()) return "Enter a value";
  if (type === "percent") {
    const bps = parseRateBps(text);
    return Number.isNaN(bps) || bps <= 0 ? "Enter a percentage between 0.01 and 100" : bps;
  }
  const cents = parseToCents(text);
  return cents === null || Number.isNaN(cents) || cents <= 0 ? "Enter an amount above 0" : cents;
}

function DiscountForm({ discount, onClose }: { discount: Doc<"discounts"> | null; onClose: () => void }) {
  const create = useMutation(api.catalog.discounts.create);
  const update = useMutation(api.catalog.discounts.update);
  const remove = useMutation(api.catalog.discounts.remove);
  const [name, setName] = useState(discount?.name ?? "");
  const [type, setType] = useState<DiscountType>(discount?.type ?? "percent");
  const [valueText, setValueText] = useState(initialValue(discount));
  const [busy, setBusy] = useState(false);

  const run = async (action: () => Promise<unknown>, success: string) => {
    setBusy(true);
    try {
      await action();
      toast.success(success);
      onClose();
    } catch (err) {
      toast.error(convexMessage(err, "Something went wrong"));
    } finally {
      setBusy(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Discount name is required");
    const value = parseValue(type, valueText);
    if (typeof value === "string") return toast.error(value);
    void run(
      () => (discount ? update({ id: discount._id, name, type, value }) : create({ name, type, value })),
      discount ? "Discount updated" : "Discount created",
    );
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <form onSubmit={handleSave} className="space-y-5">
          <DialogHeader>
            <DialogTitle>{discount ? "Edit discount" : "Create discount"}</DialogTitle>
            <DialogDescription>Applied to the whole ticket at the counter.</DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <Label htmlFor="discount-name">Name</Label>
            <Input
              id="discount-name"
              autoFocus
              maxLength={60}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Staff discount"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="discount-value">Value</Label>
            <div className="flex gap-2">
              <Input
                id="discount-value"
                inputMode="decimal"
                value={valueText}
                onChange={(e) => setValueText(e.target.value)}
                placeholder={type === "percent" ? "10" : "50.00"}
                className="flex-1"
              />
              {/* Segmented % / KSh toggle, like the original app */}
              <div className="flex overflow-hidden rounded-md border">
                {(["percent", "amount"] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setType(t)}
                    className={cn(
                      "cursor-pointer px-4 text-sm font-semibold transition-colors",
                      type === t ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted",
                    )}
                  >
                    {t === "percent" ? "%" : "KSh"}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            {discount ? (
              <Button
                type="button"
                variant="ghost"
                className="text-destructive"
                disabled={busy}
                onClick={() => void run(() => remove({ id: discount._id }), "Discount deleted")}
              >
                <Trash2 className="size-4" /> Delete
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={busy}>{busy ? "Saving..." : "Save"}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
