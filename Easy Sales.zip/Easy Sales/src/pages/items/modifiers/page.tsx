import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { FileCog, Plus, Search, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import AppBar, { AppBarIconButton } from "@/components/layout/app-bar.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";

export default function ModifiersPage() {
  const navigate = useNavigate();
  const modifiers = useQuery(api.catalog.modifiers.list, {});
  const [searching, setSearching] = useState(false);
  const [term, setTerm] = useState("");

  // The list is small and bounded, so searching it in the browser is fine
  const shown = useMemo(() => {
    const q = term.trim().toLowerCase();
    if (!modifiers || !q) return modifiers;
    return modifiers.filter(
      (m) => m.name.toLowerCase().includes(q) || m.options.some((o) => o.name.toLowerCase().includes(q)),
    );
  }, [modifiers, term]);

  const closeSearch = () => {
    setSearching(false);
    setTerm("");
  };

  return (
    <>
      <AppBar
        onBack={searching ? closeSearch : () => navigate("/items")}
        title={
          searching ? (
            <input
              autoFocus
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Search"
              className="w-full bg-transparent text-lg font-normal text-secondary-foreground outline-none placeholder:text-secondary-foreground/70"
            />
          ) : (
            "Modifiers"
          )
        }
        actions={
          searching ? (
            term && (
              <AppBarIconButton label="Clear search" onClick={() => setTerm("")}>
                <X className="size-6" />
              </AppBarIconButton>
            )
          ) : (
            <AppBarIconButton label="Search" onClick={() => setSearching(true)}>
              <Search className="size-6" />
            </AppBarIconButton>
          )
        }
      />
      <main className="min-h-0 flex-1 overflow-y-auto bg-card">
        <div className="mx-auto max-w-3xl pb-24">
          {shown === undefined ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-6 py-3">
                <Skeleton className="size-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
            ))
          ) : shown.length === 0 ? (
            term ? (
              <p className="pt-16 text-center text-muted-foreground">No modifiers found</p>
            ) : (
              <Empty className="pt-20">
                <EmptyHeader>
                  <EmptyMedia variant="icon"><FileCog /></EmptyMedia>
                  <EmptyTitle>You have no modifiers yet</EmptyTitle>
                  <EmptyDescription>Add options like sizes or extras, with or without an extra price</EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Button size="sm" onClick={() => navigate("/items/modifiers/new")}>Create modifier</Button>
                </EmptyContent>
              </Empty>
            )
          ) : (
            shown.map((m) => (
              <button
                key={m._id}
                type="button"
                onClick={() => navigate(`/items/modifiers/${m._id}`)}
                className="flex w-full cursor-pointer items-center gap-4 pl-6 text-left transition-colors hover:bg-muted active:bg-accent"
              >
                <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <FileCog className="size-5" />
                </span>
                <span className="min-w-0 flex-1 border-b py-3 pr-6">
                  <span className="block truncate">{m.name}</span>
                  <span className="block truncate text-sm text-muted-foreground">
                    {m.options.map((o) => o.name).join(", ")}
                  </span>
                </span>
              </button>
            ))
          )}
        </div>

        <Button
          size="icon"
          aria-label="Create modifier"
          onClick={() => navigate("/items/modifiers/new")}
          className="fixed bottom-6 right-6 size-14 rounded-full shadow-lg"
        >
          <Plus className="size-6" />
        </Button>
      </main>
    </>
  );
}
