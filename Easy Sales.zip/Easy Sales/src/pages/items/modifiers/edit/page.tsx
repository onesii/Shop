import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { DndContext, closestCenter, PointerSensor, TouchSensor, KeyboardSensor, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, arrayMove, sortableKeyboardCoordinates, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { restrictToVerticalAxis } from "@dnd-kit/modifiers";
import { FileCog, PlusCircle, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import AppBar from "@/components/layout/app-bar.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import { centsToInput, parseToCents } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import OptionRow, { type OptionDraft } from "../_components/option-row.tsx";

const MAX_OPTIONS = 50;
const BLANK = "This field cannot be blank";

export default function ModifierEditPage() {
  const navigate = useNavigate();
  const { id = "new" } = useParams();
  const isNew = id === "new";
  const existing = useQuery(api.catalog.modifiers.get, isNew ? "skip" : { id });
  const back = () => navigate("/items/modifiers");

  if (!isNew && existing === undefined) {
    return (
      <>
        <AppBar title="Edit modifier" onBack={back} />
        <div className="mx-auto w-full max-w-3xl space-y-4 p-4">
          <Skeleton className="h-64 w-full" />
        </div>
      </>
    );
  }
  if (!isNew && !existing) {
    return (
      <>
        <AppBar title="Modifier" onBack={back} />
        <Empty className="pt-20">
          <EmptyHeader>
            <EmptyMedia variant="icon"><FileCog /></EmptyMedia>
            <EmptyTitle>Modifier not found</EmptyTitle>
          </EmptyHeader>
        </Empty>
      </>
    );
  }
  return <ModifierForm key={id} modifier={existing ?? null} onDone={back} />;
}

const newOption = (): OptionDraft => ({ key: crypto.randomUUID(), name: "", price: "0.00" });

function toDrafts(m: Doc<"modifiers"> | null): OptionDraft[] {
  if (!m) return [newOption()];
  return m.options.map((o) => ({ key: crypto.randomUUID(), name: o.name, price: centsToInput(o.priceCents) }));
}

function priceError(price: string): string | null {
  const cents = parseToCents(price);
  return cents !== null && Number.isNaN(cents) ? "Enter a valid price" : null;
}

/** Spare rows the user added but left empty are dropped on save, as long as one real option remains. */
function isUntouched(o: OptionDraft): boolean {
  return !o.name.trim() && !parseToCents(o.price);
}

function ModifierForm({ modifier, onDone }: { modifier: Doc<"modifiers"> | null; onDone: () => void }) {
  const create = useMutation(api.catalog.modifiers.create);
  const update = useMutation(api.catalog.modifiers.update);
  const remove = useMutation(api.catalog.modifiers.remove);
  const [name, setName] = useState(modifier?.name ?? "");
  const [options, setOptions] = useState<OptionDraft[]>(() => toDrafts(modifier));
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 120, tolerance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const filled = options.filter((o) => !isUntouched(o));
  const kept = filled.length > 0 ? filled : options;
  const keptKeys = new Set(kept.map((o) => o.key));
  const nameError = submitted && !name.trim() ? BLANK : null;
  const optionNameError = (o: OptionDraft) => (submitted && keptKeys.has(o.key) && !o.name.trim() ? BLANK : null);
  const hasErrors = !name.trim() || kept.some((o) => !o.name.trim() || priceError(o.price));

  const patchOption = (key: string, patch: Partial<OptionDraft>) =>
    setOptions((list) => list.map((o) => (o.key === key ? { ...o, ...patch } : o)));

  const addOption = () => {
    if (options.length >= MAX_OPTIONS) return toast.error(`A modifier can have up to ${MAX_OPTIONS} options`);
    setOptions((list) => [...list, newOption()]);
  };

  const onDragEnd = ({ active, over }: DragEndEvent) => {
    if (!over || active.id === over.id) return;
    setOptions((list) => {
      const from = list.findIndex((o) => o.key === active.id);
      const to = list.findIndex((o) => o.key === over.id);
      return arrayMove(list, from, to);
    });
  };

  const save = async () => {
    setSubmitted(true);
    if (hasErrors) return;
    const payload = {
      name,
      options: kept.map((o) => ({ name: o.name, priceCents: parseToCents(o.price) ?? 0 })),
    };
    setSaving(true);
    try {
      if (modifier) await update({ id: modifier._id, ...payload });
      else await create(payload);
      toast.success("Modifier saved");
      onDone();
    } catch (err) {
      toast.error(convexMessage(err, "Could not save the modifier"));
      setSaving(false);
    }
  };

  const confirmRemove = async () => {
    if (!modifier) return;
    try {
      await remove({ id: modifier._id });
      toast.success("Modifier deleted");
      onDone();
    } catch (err) {
      toast.error(convexMessage(err, "Could not delete the modifier"));
    }
  };

  return (
    <>
      <AppBar
        title={modifier ? "Edit modifier" : "Create modifier"}
        onBack={onDone}
        actions={
          <Button
            variant="ghost"
            disabled={saving}
            onClick={save}
            className={cn(
              "font-semibold uppercase text-secondary-foreground hover:bg-white/10 hover:text-secondary-foreground",
              submitted && hasErrors && "opacity-60",
            )}
          >
            {saving && <Spinner />} Save
          </Button>
        }
      />
      <main className="min-h-0 flex-1 overflow-y-auto bg-muted/60">
        <div className="mx-auto w-full max-w-3xl space-y-4 p-4 pb-10">
          <section className="rounded-sm bg-card px-6 pb-4 pt-6 shadow-sm">
            <div>
              <label
                htmlFor="modifier-name"
                className={cn("block h-4 text-xs text-muted-foreground transition-opacity", !name && "opacity-0")}
              >
                Modifier name
              </label>
              <input
                id="modifier-name"
                maxLength={60}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Modifier name"
                className={cn(
                  "w-full border-0 border-b bg-transparent pb-2 pt-1 text-2xl outline-none transition-colors placeholder:text-muted-foreground",
                  nameError ? "border-destructive text-destructive placeholder:text-destructive" : "border-foreground/40 focus:border-primary",
                )}
              />
              {nameError && <p className="pt-2 text-xs text-destructive">{nameError}</p>}
            </div>

            <div className="pt-4">
              <DndContext sensors={sensors} collisionDetection={closestCenter} modifiers={[restrictToVerticalAxis]} onDragEnd={onDragEnd}>
                <SortableContext items={options.map((o) => o.key)} strategy={verticalListSortingStrategy}>
                  {options.map((o) => (
                    <OptionRow
                      key={o.key}
                      option={o}
                      nameError={optionNameError(o)}
                      priceError={submitted ? priceError(o.price) : null}
                      onChange={(patch) => patchOption(o.key, patch)}
                      onRemove={() => setOptions((list) => list.filter((x) => x.key !== o.key))}
                    />
                  ))}
                </SortableContext>
              </DndContext>
              {submitted && options.length === 0 && (
                <p className="py-2 text-xs text-destructive">Add at least one option</p>
              )}
            </div>

            <button
              type="button"
              onClick={addOption}
              className="mt-2 flex cursor-pointer items-center gap-3 rounded-sm py-2 pr-3 text-sm font-semibold uppercase text-primary transition-colors hover:bg-accent"
            >
              <PlusCircle className="size-6" /> Add option
            </button>
          </section>

          {modifier && (
            <button
              type="button"
              onClick={() => setConfirmDelete(true)}
              className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-sm bg-card py-4 text-sm font-medium uppercase shadow-sm transition-colors hover:bg-muted"
            >
              <Trash2 className="size-5 text-muted-foreground" /> Delete modifier
            </button>
          )}
        </div>
      </main>

      <Dialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete modifier?</DialogTitle>
            <DialogDescription>{modifier?.name ?? "This modifier"} and its options will be deleted.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmDelete(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmRemove}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
