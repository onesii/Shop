import { CSS } from "@dnd-kit/utilities";
import { useSortable } from "@dnd-kit/sortable";
import { Equal, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils.ts";

export type OptionDraft = { key: string; name: string; price: string };

type Props = {
  option: OptionDraft;
  nameError: string | null;
  priceError: string | null;
  onChange: (patch: Partial<OptionDraft>) => void;
  onRemove: () => void;
};

const UNDERLINE =
  "w-full border-0 border-b bg-transparent pb-1.5 text-base outline-none transition-colors placeholder:text-muted-foreground";

/** One draggable option row: handle, name, KSh price and delete, as in the original app. */
export default function OptionRow({ option, nameError, priceError, onChange, onRemove }: Props) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: option.key });

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={cn("flex items-start gap-3 bg-card py-2", isDragging && "relative z-10 shadow-md")}
    >
      <button
        type="button"
        aria-label="Drag to reorder"
        className="mt-6 flex size-8 shrink-0 cursor-grab touch-none items-center justify-center text-muted-foreground active:cursor-grabbing"
        {...attributes}
        {...listeners}
      >
        <Equal className="size-5" />
      </button>

      <div className="min-w-0 flex-1 pt-5 sm:pr-8">
        <input
          aria-label="Option name"
          maxLength={60}
          value={option.name}
          onChange={(e) => onChange({ name: e.target.value })}
          placeholder="Option name"
          className={cn(
            UNDERLINE,
            nameError ? "border-destructive text-destructive placeholder:text-destructive" : "border-foreground/40 focus:border-primary",
          )}
        />
        {nameError && <p className="pt-1 text-xs text-destructive">{nameError}</p>}
      </div>

      <div className="w-28 shrink-0 sm:w-auto sm:flex-1">
        <p className="text-xs text-muted-foreground">Price</p>
        <div
          className={cn(
            "flex items-baseline border-b pb-1.5 transition-colors focus-within:border-primary",
            priceError ? "border-destructive" : "border-foreground/40",
          )}
        >
          <span>KSh</span>
          <input
            aria-label="Option price"
            inputMode="decimal"
            maxLength={12}
            value={option.price}
            onChange={(e) => onChange({ price: e.target.value.replace(/[^\d.,]/g, "") })}
            onBlur={() => {
              const n = Number(option.price.replace(/,/g, ""));
              if (option.price && Number.isFinite(n)) onChange({ price: n.toFixed(2) });
            }}
            placeholder="0.00"
            className="min-w-0 flex-1 bg-transparent text-base outline-none"
          />
        </div>
        {priceError && <p className="pt-1 text-xs text-destructive">{priceError}</p>}
      </div>

      <button
        type="button"
        aria-label="Delete option"
        onClick={onRemove}
        className="mt-5 flex size-8 shrink-0 cursor-pointer items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
      >
        <Trash2 className="size-5" />
      </button>
    </div>
  );
}
