import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { PackagePlus, Plus, Search, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import AppBar, { AppBarIconButton } from "@/components/layout/app-bar.tsx";
import ItemRow from "@/components/items/item-row.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { useStockByItem } from "@/hooks/use-stock-by-item.ts";
import StockBadge from "@/components/inventory/stock-badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import ItemFormDialog from "./_components/item-form-dialog.tsx";
import ItemCsvActions from "./_components/item-csv-actions.tsx";

export default function ItemListPage() {
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [debouncedSearch] = useDebounce(search, 250);
  const [editing, setEditing] = useState<Doc<"items"> | null>(null);
  const [formOpen, setFormOpen] = useState(false);

  const items = useQuery(api.catalog.items.list, { search: debouncedSearch });
  const categories = useQuery(api.catalog.categories.list, {});
  const stock = useStockByItem();
  const categoryName = new Map(categories?.map((c) => [c._id, c.name]) ?? []);

  const openForm = (item: Doc<"items"> | null) => {
    setEditing(item);
    setFormOpen(true);
  };

  return (
    <>
      <AppBar
        onBack={() => navigate("/items")}
        title={
          searchOpen ? (
            <Input
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search items"
              className="h-9 border-0 bg-white/15 text-secondary-foreground placeholder:text-secondary-foreground/70"
            />
          ) : (
            "Items"
          )
        }
        actions={
          <AppBarIconButton
            label={searchOpen ? "Close search" : "Search items"}
            onClick={() => {
              setSearchOpen(!searchOpen);
              setSearch("");
            }}
          >
            {searchOpen ? <X className="size-5" /> : <Search className="size-5" />}
          </AppBarIconButton>
        }
      />

      <main className="relative min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl pb-24">
          <div className="flex items-center justify-end border-b bg-card px-2 py-1.5">
            <ItemCsvActions />
          </div>
          {items === undefined ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4 border-b px-4 py-2.5">
                <Skeleton className="size-10" />
                <Skeleton className="h-4 flex-1" />
              </div>
            ))
          ) : items.length === 0 ? (
            <Empty className="pt-20">
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <PackagePlus />
                </EmptyMedia>
                <EmptyTitle>{search ? "No matching items" : "No items yet"}</EmptyTitle>
                <EmptyDescription>
                  {search ? "Try a different search" : "Create your first item to sell it at the counter"}
                </EmptyDescription>
              </EmptyHeader>
              {!search && (
                <EmptyContent>
                  <Button size="sm" onClick={() => openForm(null)}>Create item</Button>
                </EmptyContent>
              )}
            </Empty>
          ) : (
            items.map((item) => (
              <ItemRow
                key={item._id}
                item={item}
                onClick={() => openForm(item)}
                trailing={
                  <span className="flex flex-col items-end">
                    <span>{item.variants.length ? `${item.variants.length} variants` : item.priceCents === null ? "Variable" : undefined}</span>
                    <span className="text-xs">
                      {item.categoryId ? categoryName.get(item.categoryId) : "No category"}
                    </span>
                    {stock?.get(item._id) && (
                      <span className="text-xs">
                        <StockBadge inStock={stock.get(item._id)?.inStock ?? 0} isLow={stock.get(item._id)?.isLow} /> in stock
                      </span>
                    )}
                  </span>
                }
              />
            ))
          )}
        </div>

        <Button
          size="icon"
          aria-label="Create item"
          onClick={() => openForm(null)}
          className="fixed bottom-6 right-6 size-14 rounded-full shadow-lg"
        >
          <Plus className="size-6" />
        </Button>
      </main>

      <ItemFormDialog open={formOpen} item={editing} onClose={() => setFormOpen(false)} />
    </>
  );
}
