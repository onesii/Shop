import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import type { StockDraft } from "@/lib/stock.ts";


type Row = { key: string | number; label: string | null; draft: StockDraft };

type Props = {
  track: boolean;
  onTrackChange: (on: boolean) => void;
  rows: Row[];
  onChange: (key: string | number, patch: Partial<StockDraft>) => void;
};

/** "Track stock" switch with in-stock and low-stock fields for the item or each variant. */
export default function StockFields({ track, onTrackChange, rows, onChange }: Props) {
  return (
    <div className="space-y-3 rounded-md border p-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <Label htmlFor="track-stock">Track stock</Label>
          <p className="text-xs text-muted-foreground">Goes down on sales and back up on refunds</p>
        </div>
        <Switch id="track-stock" checked={track} onCheckedChange={onTrackChange} />
      </div>
      {track && (
        <div className="space-y-2">
          <div className="grid grid-cols-[1fr_6rem_6rem] gap-2 text-xs font-medium text-muted-foreground">
            <span>{rows.some((r) => r.label) ? "Variant" : ""}</span>
            <span>In stock</span>
            <span>Low stock</span>
          </div>
          {rows.map((r) => (
            <div key={r.key} className="grid grid-cols-[1fr_6rem_6rem] items-center gap-2">
              <span className="truncate text-sm">{r.label ?? "This item"}</span>
              <Input
                inputMode="numeric"
                aria-label={`In stock${r.label ? ` for ${r.label}` : ""}`}
                value={r.draft.inStock}
                onChange={(e) => onChange(r.key, { inStock: e.target.value })}
                placeholder="0"
              />
              <Input
                inputMode="numeric"
                aria-label={`Low stock level${r.label ? ` for ${r.label}` : ""}`}
                value={r.draft.lowStock}
                onChange={(e) => onChange(r.key, { lowStock: e.target.value })}
                placeholder="None"
              />
            </div>
          ))}
          <p className="text-xs text-muted-foreground">
            You'll get a low stock alert when stock reaches the low stock level.
          </p>
        </div>
      )}
    </div>
  );
}
