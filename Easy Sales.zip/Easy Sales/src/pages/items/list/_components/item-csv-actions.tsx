import { useState } from "react";
import { useConvex, useQuery } from "convex/react";
import { Download, Upload } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { downloadCsv } from "@/lib/csv.ts";
import { ITEM_COLUMNS, itemsToRows } from "@/lib/items-csv.ts";
import { Button } from "@/components/ui/button.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import ImportItemsDialog from "./import-items-dialog.tsx";

const EXPORT_PAGE = 200;

const TEMPLATE_ROWS: Record<string, string>[] = [
  { Handle: "soda-500ml", Name: "Soda 500ml", Category: "Drinks", "Sold by weight": "N", Price: "60.00", "Track stock": "Y", "In stock": "48", "Low stock": "12" },
  { Handle: "sugar", Name: "Sugar", Category: "Groceries", "Sold by weight": "Y", Unit: "kg", Price: "180.00", "Track stock": "N" },
  { Handle: "t-shirt", Name: "T-shirt", Category: "Clothes", "Sold by weight": "N", "Option 1 name": "Size", "Option 1 value": "Small", Price: "800.00", "Track stock": "N" },
  { Handle: "t-shirt", "Option 1 value": "Large", Price: "900.00" },
];

/** Import and Export buttons for the item list. */
export default function ItemCsvActions() {
  const convex = useConvex();
  const categories = useQuery(api.catalog.categories.list, {});
  const [importOpen, setImportOpen] = useState(false);
  const [exporting, setExporting] = useState(false);

  const exportItems = async () => {
    setExporting(true);
    try {
      const names = new Map((categories ?? []).map((c) => [c._id, c.name]));
      const entries = [];
      let cursor: string | null = null;
      for (;;) {
        const result: Awaited<ReturnType<typeof fetchPage>> = await fetchPage(cursor);
        entries.push(...result.page);
        if (result.isDone) break;
        cursor = result.continueCursor;
      }
      if (entries.length === 0) {
        toast.info("There are no items to export yet");
        return;
      }
      const rows = itemsToRows(entries, (id) => (id ? (names.get(id) ?? "") : ""));
      downloadCsv(`items-${new Date().toISOString().slice(0, 10)}.csv`, rows, ITEM_COLUMNS);
      toast.success(`Exported ${entries.length} items`);
    } catch {
      toast.error("Export failed. Check your connection and try again.");
    } finally {
      setExporting(false);
    }
  };

  const fetchPage = (cursor: string | null) =>
    convex.query(api.catalog.itemCsv.exportPage, { paginationOpts: { numItems: EXPORT_PAGE, cursor } });

  return (
    <>
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="sm" className="font-semibold uppercase" onClick={() => setImportOpen(true)}>
          <Upload className="size-4" /> Import
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="font-semibold uppercase"
          disabled={exporting || categories === undefined}
          onClick={() => void exportItems()}
        >
          {exporting ? <Spinner /> : <Download className="size-4" />} Export
        </Button>
      </div>
      <ImportItemsDialog
        open={importOpen}
        onClose={() => setImportOpen(false)}
        onDownloadTemplate={() => downloadCsv("items-template.csv", TEMPLATE_ROWS, ITEM_COLUMNS)}
      />
    </>
  );
}
