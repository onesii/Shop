import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { centsToInput, parseToCents } from "@/lib/money.ts";
import { ITEM_COLORS, ITEM_COLOR_KEYS, type ItemColor } from "@/lib/item-colors.ts";
import { cn } from "@/lib/utils.ts";
import { EMPTY_STOCK, parseStockInput, type StockDraft } from "@/lib/stock.ts";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group.tsx";
import StockFields from "./stock-fields.tsx";
import UnitSwitch from "@/components/items/unit-switch.tsx";
import type { WeightUnit } from "@/convex/lib/quantity.ts";

const NONE = "none";

type VariantDraft = { id: number; name: string; price: string; stock: StockDraft };
type StockLevel = Doc<"stockLevels">;
// Key of the stock draft for an item without variants
const ITEM_KEY = "item";

const toDraft = (level: StockLevel | undefined): StockDraft =>
  level
    ? { inStock: String(level.inStock), lowStock: level.lowStock === null ? "" : String(level.lowStock) }
    : EMPTY_STOCK;

type Props = {
  open: boolean;
  item: Doc<"items"> | null;
  onClose: () => void;
};

function errorMessage(err: unknown): string {
  if (err instanceof ConvexError) {
    return (err.data as { message?: string }).message ?? "Something went wrong";
  }
  return "Something went wrong";
}

export default function ItemFormDialog({ open, item, onClose }: Props) {
  if (!open) return null;
  // Keyed remount resets the form whenever a different item is opened
  return item ? (
    <EditItemForm key={item._id} item={item} onClose={onClose} />
  ) : (
    <ItemForm key="new" item={null} levels={[]} onClose={onClose} />
  );
}

/** Waits for the item's stock levels so the form starts with the right counts. */
function EditItemForm({ item, onClose }: { item: Doc<"items">; onClose: () => void }) {
  const levels = useQuery(api.inventory.stock.forItem, { itemId: item._id });
  if (levels === undefined) {
    return (
      <Dialog open onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit item</DialogTitle>
            <DialogDescription>Loading item...</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        </DialogContent>
      </Dialog>
    );
  }
  return <ItemForm item={item} levels={levels} onClose={onClose} />;
}

type FormProps = { item: Doc<"items"> | null; levels: StockLevel[]; onClose: () => void };

function ItemForm({ item, levels, onClose }: FormProps) {
  const categories = useQuery(api.catalog.categories.list, {});
  const createItem = useMutation(api.catalog.items.create);
  const updateItem = useMutation(api.catalog.items.update);
  const removeItem = useMutation(api.catalog.items.remove);
  const createCategory = useMutation(api.catalog.categories.create);

  const [name, setName] = useState(item?.name ?? "");
  const [price, setPrice] = useState(centsToInput(item?.priceCents ?? null));
  const [category, setCategory] = useState<string>(item?.categoryId ?? NONE);
  const [color, setColor] = useState<ItemColor>(item?.color ?? "gray");
  const [soldBy, setSoldBy] = useState<"each" | "weight">(item?.soldBy ?? "each");
  const [weightUnit, setWeightUnit] = useState<WeightUnit>(item?.weightUnit ?? "kg");
  const levelFor = (variantName: string | null) => levels.find((l) => l.variantName === variantName);
  const [variants, setVariants] = useState<VariantDraft[]>(
    item?.variants.map((v, i) => ({
      id: i,
      name: v.name,
      price: centsToInput(v.priceCents),
      stock: toDraft(levelFor(v.name)),
    })) ?? [],
  );
  const [trackStock, setTrackStock] = useState(levels.length > 0);
  const [itemStock, setItemStock] = useState<StockDraft>(toDraft(levelFor(null)));
  // Stock is only sent when touched, so an open form never overwrites sales made meanwhile
  const [stockDirty, setStockDirty] = useState(false);
  const [newCategory, setNewCategory] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const updateVariant = (id: number, patch: Partial<VariantDraft>) => {
    if (patch.name !== undefined) setStockDirty(true);
    setVariants((prev) => prev.map((v) => (v.id === id ? { ...v, ...patch } : v)));
  };
  const setVariantList = (update: (prev: VariantDraft[]) => VariantDraft[]) => {
    setStockDirty(true);
    setVariants(update);
  };
  const updateStock = (key: string | number, patch: Partial<StockDraft>) => {
    setStockDirty(true);
    if (key === ITEM_KEY) setItemStock((s) => ({ ...s, ...patch }));
    else setVariants((prev) => prev.map((v) => (v.id === key ? { ...v, stock: { ...v.stock, ...patch } } : v)));
  };

  const namedVariants = variants.filter((v) => v.name.trim());
  const stockRows =
    namedVariants.length > 0
      ? namedVariants.map((v) => ({ key: v.id, label: v.name.trim(), draft: v.stock }))
      : [{ key: ITEM_KEY, label: null, draft: itemStock }];

  /** Stock to send with the save: undefined = unchanged, null = not tracked, or the counts. */
  const buildStock = () => {
    if (!stockDirty) return { ok: true as const, stock: undefined };
    if (!trackStock) return { ok: true as const, stock: null };
    const drafts =
      namedVariants.length > 0
        ? namedVariants.map((v) => ({ variantName: v.name.trim(), draft: v.stock }))
        : [{ variantName: null, draft: itemStock }];
    const seen = new Set<string | null>();
    const stock = [];
    for (const { variantName, draft } of drafts) {
      // Variants with the same name share one stock count
      if (seen.has(variantName)) continue;
      seen.add(variantName);
      const inStock = parseStockInput(draft.inStock, 0);
      const lowStock = parseStockInput(draft.lowStock, null);
      if (inStock === null || Number.isNaN(inStock) || Number.isNaN(lowStock) || (lowStock ?? 0) < 0) {
        return { ok: false as const };
      }
      stock.push({ variantName, inStock, lowStock });
    }
    return { ok: true as const, stock };
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Item name is required");
    const priceCents = parseToCents(price);
    if (Number.isNaN(priceCents)) return toast.error("Enter a valid price, e.g. 150.00");
    const parsedVariants = variants
      .filter((v) => v.name.trim())
      .map((v) => ({ name: v.name, priceCents: parseToCents(v.price) }));
    if (parsedVariants.some((v) => Number.isNaN(v.priceCents))) {
      return toast.error("One of the variant prices is invalid");
    }
    const stockResult = buildStock();
    if (!stockResult.ok) return toast.error("Stock must be a whole number, e.g. 12");

    setSaving(true);
    try {
      let categoryId: Id<"categories"> | null = category === NONE ? null : (category as Id<"categories">);
      if (newCategory !== null && newCategory.trim()) {
        categoryId = await createCategory({ name: newCategory, color });
      }
      const data = {
        name,
        priceCents,
        categoryId,
        color,
        variants: parsedVariants,
        soldBy,
        ...(soldBy === "weight" ? { weightUnit } : {}),
        stock: stockResult.stock,
      };
      if (item) await updateItem({ id: item._id, ...data });
      else await createItem(data);
      toast.success(item ? "Item updated" : "Item added");
      onClose();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!item) return;
    try {
      await removeItem({ id: item._id });
      toast.success("Item deleted");
      onClose();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-lg">
        <form onSubmit={handleSave} className="space-y-5">
          <DialogHeader>
            <DialogTitle>{item ? "Edit item" : "Create item"}</DialogTitle>
            <DialogDescription>Leave price empty to enter it at the time of sale.</DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <Label htmlFor="item-name">Name</Label>
            <Input id="item-name" autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="Chicken burger" />
          </div>

          <div className="space-y-2">
            <Label>Category</Label>
            {newCategory === null ? (
              <Select
                value={category}
                onValueChange={(v) => (v === "__new" ? setNewCategory("") : setCategory(v))}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={NONE}>No category</SelectItem>
                  {categories?.map((c) => (
                    <SelectItem key={c._id} value={c._id}>{c.name}</SelectItem>
                  ))}
                  <SelectItem value="__new">+ Create category</SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <div className="flex gap-2">
                <Input autoFocus value={newCategory} onChange={(e) => setNewCategory(e.target.value)} placeholder="Drinks" />
                <Button type="button" variant="ghost" onClick={() => setNewCategory(null)}>Cancel</Button>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="item-price">
              Price (KSh){soldBy === "weight" && ` per ${weightUnit === "kg" ? "kg" : "gram"}`}
            </Label>
            <Input
              id="item-price"
              inputMode="decimal"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder={variants.length ? "Set per variant below" : "Variable"}
              disabled={variants.length > 0}
            />
          </div>

          <div className="space-y-2">
            <Label>Sold by</Label>
            <RadioGroup
              value={soldBy}
              onValueChange={(v) => setSoldBy(v === "weight" ? "weight" : "each")}
              className="flex gap-6"
            >
              <Label className="cursor-pointer font-normal">
                <RadioGroupItem value="each" /> Each
              </Label>
              <Label className="cursor-pointer font-normal">
                <RadioGroupItem value="weight" /> Weight/Volume
              </Label>
            </RadioGroup>
            {soldBy === "weight" && (
              <div className="flex items-center justify-between gap-3 rounded-md bg-muted px-3 py-2.5">
                <span className="text-sm text-muted-foreground">Price is per</span>
                <UnitSwitch value={weightUnit} onChange={setWeightUnit} />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Variants</Label>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="text-primary"
                onClick={() => setVariantList((p) => [...p, { id: Date.now(), name: "", price: "", stock: EMPTY_STOCK }])}
              >
                <Plus className="size-4" /> Add variant
              </Button>
            </div>
            {variants.map((v) => (
              <div key={v.id} className="flex gap-2">
                <Input value={v.name} onChange={(e) => updateVariant(v.id, { name: e.target.value })} placeholder="Large" />
                <Input
                  inputMode="decimal"
                  className="w-32"
                  value={v.price}
                  onChange={(e) => updateVariant(v.id, { price: e.target.value })}
                  placeholder="Price"
                />
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  aria-label="Remove variant"
                  onClick={() => setVariantList((p) => p.filter((x) => x.id !== v.id))}
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            ))}
          </div>

          <StockFields
            track={trackStock}
            onTrackChange={(on) => {
              setStockDirty(true);
              setTrackStock(on);
            }}
            rows={stockRows}
            onChange={updateStock}
          />

          <div className="space-y-2">
            <Label>Color</Label>
            <div className="flex flex-wrap gap-2">
              {ITEM_COLOR_KEYS.map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-label={c}
                  onClick={() => setColor(c)}
                  className={cn(
                    "size-10 cursor-pointer rounded-sm ring-offset-2 ring-offset-background transition",
                    ITEM_COLORS[c],
                    color === c && "ring-2 ring-foreground",
                  )}
                />
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            {item ? (
              <Button type="button" variant="ghost" className="text-destructive" onClick={handleDelete}>
                <Trash2 className="size-4" /> Delete
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Saving..." : "Save"}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
