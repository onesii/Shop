import { useState } from "react";
import { useMutation } from "convex/react";
import { AlertCircle, CheckCircle2, FileSpreadsheet, Upload } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { convexMessage } from "@/lib/errors.ts";
import {
  MAX_IMPORT_FILE_BYTES,
  parseItemsCsv,
  type ImportItem,
  type RowProblem,
} from "@/lib/items-csv.ts";
import { Button } from "@/components/ui/button.tsx";
import { Progress } from "@/components/ui/progress.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";

// Matches MAX_IMPORT_BATCH on the server
const BATCH = 50;

type Stage =
  | { kind: "pick"; error: string | null }
  | { kind: "review"; fileName: string; items: ImportItem[]; problems: RowProblem[] }
  | { kind: "importing"; done: number; total: number }
  | { kind: "done"; created: number; updated: number; problems: RowProblem[]; stopped: string | null };

type Props = { open: boolean; onClose: () => void; onDownloadTemplate: () => void };

export default function ImportItemsDialog({ open, onClose, onDownloadTemplate }: Props) {
  const [stage, setStage] = useState<Stage>({ kind: "pick", error: null });
  const importBatch = useMutation(api.catalog.itemCsv.importBatch);

  const close = () => {
    if (stage.kind === "importing") return;
    setStage({ kind: "pick", error: null });
    onClose();
  };

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    if (!/\.(csv|txt)$/i.test(file.name)) return setStage({ kind: "pick", error: "Choose a CSV file (.csv)" });
    if (file.size > MAX_IMPORT_FILE_BYTES) return setStage({ kind: "pick", error: "The file must be smaller than 5 MB" });
    const parsed = parseItemsCsv(await file.text());
    if ("fileError" in parsed) return setStage({ kind: "pick", error: parsed.fileError });
    setStage({ kind: "review", fileName: file.name, ...parsed });
  };

  const runImport = async (items: ImportItem[], parseProblems: RowProblem[]) => {
    let created = 0;
    let updated = 0;
    const problems = [...parseProblems];
    let stopped: string | null = null;
    setStage({ kind: "importing", done: 0, total: items.length });
    for (let i = 0; i < items.length; i += BATCH) {
      try {
        const result = await importBatch({ items: items.slice(i, i + BATCH) });
        created += result.created;
        updated += result.updated;
        problems.push(...result.failures);
      } catch (err) {
        // Saved batches stay saved; importing the same file again just updates them
        stopped = convexMessage(err, "The connection dropped. Import the file again to finish.");
        break;
      }
      setStage({ kind: "importing", done: Math.min(i + BATCH, items.length), total: items.length });
    }
    problems.sort((a, b) => a.sourceRow - b.sourceRow);
    setStage({ kind: "done", created, updated, problems, stopped });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && close()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-lg" showCloseButton={stage.kind !== "importing"}>
        <DialogHeader>
          <DialogTitle>Import items</DialogTitle>
          <DialogDescription>
            Items with a name that already exists are updated. New names are added.
          </DialogDescription>
        </DialogHeader>

        {stage.kind === "pick" && (
          <div className="space-y-4">
            <label className="flex cursor-pointer flex-col items-center gap-3 rounded-md border-2 border-dashed px-4 py-10 text-center transition hover:border-primary hover:bg-accent/40">
              <Upload className="size-8 text-primary" />
              <span className="font-medium">Choose a CSV file</span>
              <span className="text-sm text-muted-foreground">A Loyverse item export works as it is</span>
              <input
                type="file"
                accept=".csv,text/csv"
                className="sr-only"
                onChange={(e) => {
                  void handleFile(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
            </label>
            {stage.error && <ProblemNote text={stage.error} />}
            <button
              type="button"
              onClick={onDownloadTemplate}
              className="flex cursor-pointer items-center gap-2 text-sm font-medium text-primary hover:underline"
            >
              <FileSpreadsheet className="size-4" /> Download a template
            </button>
          </div>
        )}

        {stage.kind === "review" && (
          <div className="space-y-4">
            <div className="rounded-md bg-muted px-4 py-3 text-sm">
              <p className="truncate font-medium">{stage.fileName}</p>
              <p className="text-muted-foreground">
                {stage.items.length} {stage.items.length === 1 ? "item" : "items"} ready to import
              </p>
            </div>
            <ProblemList problems={stage.problems} title="These rows will be skipped" />
            <DialogFooter>
              <Button variant="ghost" onClick={() => setStage({ kind: "pick", error: null })}>
                Choose another file
              </Button>
              <Button disabled={stage.items.length === 0} onClick={() => void runImport(stage.items, stage.problems)}>
                Import {stage.items.length} {stage.items.length === 1 ? "item" : "items"}
              </Button>
            </DialogFooter>
          </div>
        )}

        {stage.kind === "importing" && (
          <div className="space-y-3 py-4">
            <Progress value={(stage.done / Math.max(stage.total, 1)) * 100} />
            <p className="text-center text-sm text-muted-foreground">
              Importing {stage.done} of {stage.total}... keep this screen open
            </p>
          </div>
        )}

        {stage.kind === "done" && (
          <div className="space-y-4">
            <div className="flex items-start gap-3 rounded-md bg-accent px-4 py-3 text-accent-foreground">
              <CheckCircle2 className="mt-0.5 size-5 shrink-0" />
              <p className="text-sm">
                <span className="font-semibold">{stage.created}</span> added,{" "}
                <span className="font-semibold">{stage.updated}</span> updated
                {stage.problems.length > 0 && (
                  <>
                    , <span className="font-semibold">{stage.problems.length}</span> skipped
                  </>
                )}
              </p>
            </div>
            {stage.stopped && <ProblemNote text={`Import stopped: ${stage.stopped}`} />}
            <ProblemList problems={stage.problems} title="Skipped rows" />
            <DialogFooter>
              <Button onClick={close}>Done</Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ProblemNote({ text }: { text: string }) {
  return (
    <p className="flex items-start gap-2 rounded-md bg-destructive/10 px-3 py-2.5 text-sm text-destructive">
      <AlertCircle className="mt-0.5 size-4 shrink-0" /> {text}
    </p>
  );
}

function ProblemList({ problems, title }: { problems: RowProblem[]; title: string }) {
  if (problems.length === 0) return null;
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-destructive">
        {title} ({problems.length})
      </p>
      <ul className="max-h-48 divide-y overflow-y-auto rounded-md border text-sm">
        {problems.map((p, i) => (
          <li key={i} className="px-3 py-2">
            <span className="font-medium">
              Row {p.sourceRow} · {p.name}
            </span>
            <span className="block text-muted-foreground">{p.reason}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
