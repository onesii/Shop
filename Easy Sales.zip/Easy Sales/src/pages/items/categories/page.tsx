import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { Layers, Plus } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import AppBar from "@/components/layout/app-bar.tsx";
import { ITEM_COLORS } from "@/lib/item-colors.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import CategoryFormDialog from "./_components/category-form-dialog.tsx";

export default function CategoriesPage() {
  const navigate = useNavigate();
  const categories = useQuery(api.catalog.categories.list, {});
  const [editing, setEditing] = useState<Doc<"categories"> | null>(null);
  const [formOpen, setFormOpen] = useState(false);

  const openForm = (category: Doc<"categories"> | null) => {
    setEditing(category);
    setFormOpen(true);
  };

  return (
    <>
      <AppBar title="Categories" onBack={() => navigate("/items")} />
      <main className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl pb-24">
          {categories === undefined ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4 border-b px-4 py-2.5">
                <Skeleton className="size-10 rounded-full" />
                <Skeleton className="h-4 flex-1" />
              </div>
            ))
          ) : categories.length === 0 ? (
            <Empty className="pt-20">
              <EmptyHeader>
                <EmptyMedia variant="icon"><Layers /></EmptyMedia>
                <EmptyTitle>No categories yet</EmptyTitle>
                <EmptyDescription>Group items like Drinks or Food to find them faster at the counter</EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button size="sm" onClick={() => openForm(null)}>Create category</Button>
              </EmptyContent>
            </Empty>
          ) : (
            categories.map((c) => (
              <button
                key={c._id}
                type="button"
                onClick={() => openForm(c)}
                className="flex w-full cursor-pointer items-center gap-4 border-b bg-card px-4 py-2.5 text-left transition-colors hover:bg-muted active:bg-accent"
              >
                <span className={cn("size-10 shrink-0 rounded-full", ITEM_COLORS[c.color])} />
                <span className="min-w-0 flex-1 truncate font-medium">{c.name}</span>
              </button>
            ))
          )}
        </div>

        <Button
          size="icon"
          aria-label="Create category"
          onClick={() => openForm(null)}
          className="fixed bottom-6 right-6 size-14 rounded-full shadow-lg"
        >
          <Plus className="size-6" />
        </Button>
      </main>

      <CategoryFormDialog open={formOpen} category={editing} onClose={() => setFormOpen(false)} />
    </>
  );
}
