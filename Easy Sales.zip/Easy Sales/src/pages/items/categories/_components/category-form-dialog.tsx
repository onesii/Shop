import { useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { ITEM_COLORS, ITEM_COLOR_KEYS, type ItemColor } from "@/lib/item-colors.ts";
import { cn } from "@/lib/utils.ts";

type Props = { open: boolean; category: Doc<"categories"> | null; onClose: () => void };

function errorMessage(err: unknown): string {
  if (err instanceof ConvexError) {
    return (err.data as { message?: string }).message ?? "Something went wrong";
  }
  return "Something went wrong";
}

export default function CategoryFormDialog({ open, category, onClose }: Props) {
  // Keyed remount resets the form whenever a different category is opened
  return open ? <CategoryForm key={category?._id ?? "new"} category={category} onClose={onClose} /> : null;
}

function CategoryForm({ category, onClose }: { category: Doc<"categories"> | null; onClose: () => void }) {
  const create = useMutation(api.catalog.categories.create);
  const update = useMutation(api.catalog.categories.update);
  const remove = useMutation(api.catalog.categories.remove);
  const [name, setName] = useState(category?.name ?? "");
  const [color, setColor] = useState<ItemColor>(category?.color ?? "gray");
  const [busy, setBusy] = useState(false);

  const run = async (action: () => Promise<unknown>, success: string) => {
    setBusy(true);
    try {
      await action();
      toast.success(success);
      onClose();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Category name is required");
    void run(
      () => (category ? update({ id: category._id, name, color }) : create({ name, color })),
      category ? "Category updated" : "Category created",
    );
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <form onSubmit={handleSave} className="space-y-5">
          <DialogHeader>
            <DialogTitle>{category ? "Edit category" : "Create category"}</DialogTitle>
            <DialogDescription>
              {category ? "Deleting a category keeps its items, they just move to No category." : "Group related items together."}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <Label htmlFor="category-name">Name</Label>
            <Input
              id="category-name"
              autoFocus
              maxLength={60}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Drinks"
            />
          </div>

          <div className="space-y-2">
            <Label>Color</Label>
            <div className="flex flex-wrap gap-2">
              {ITEM_COLOR_KEYS.map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-label={c}
                  onClick={() => setColor(c)}
                  className={cn(
                    "size-10 cursor-pointer rounded-full ring-offset-2 ring-offset-background transition",
                    ITEM_COLORS[c],
                    color === c && "ring-2 ring-foreground",
                  )}
                />
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            {category ? (
              <Button
                type="button"
                variant="ghost"
                className="text-destructive"
                disabled={busy}
                onClick={() => void run(() => remove({ id: category._id }), "Category deleted")}
              >
                <Trash2 className="size-4" /> Delete
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={busy}>{busy ? "Saving..." : "Save"}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
