import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { toast } from "sonner";
import { FileCog, Layers, List, Tag, Truck, type LucideIcon } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import AppBar from "@/components/layout/app-bar.tsx";

type Entry = { label: string; icon: LucideIcon; to?: string; alert?: boolean };

// Matches the Items menu in the original app; entries without `to` aren't built yet
const ENTRIES: Entry[] = [
  { label: "Items", icon: List, to: "/items/list" },
  { label: "Categories", icon: Layers, to: "/items/categories" },
  { label: "Modifiers", icon: FileCog, to: "/items/modifiers" },
  { label: "Discounts", icon: Tag, to: "/items/discounts" },
  { label: "Inventory", icon: Truck, to: "/back-office/inventory", alert: true },
];

export default function ItemsMenuPage() {
  const navigate = useNavigate();
  const lowCount = useQuery(api.inventory.stock.lowCount, {});
  return (
    <>
      <AppBar title="Items" />
      <main className="min-h-0 flex-1 overflow-y-auto bg-card">
        <nav className="mx-auto max-w-3xl">
          {ENTRIES.map(({ label, icon: Icon, to, alert }) => (
            <button
              key={label}
              type="button"
              onClick={() => (to ? navigate(to) : toast("Coming soon in a future milestone!"))}
              className="flex w-full cursor-pointer items-center gap-8 pl-6 text-left transition-colors hover:bg-muted active:bg-accent"
            >
              <Icon className="size-5 shrink-0 text-muted-foreground" />
              <span className="flex flex-1 items-center justify-between gap-3 border-b py-4 pr-6 text-base">
                {label}
                {alert && lowCount !== undefined && lowCount > 0 && (
                  <span className="rounded-full bg-amber-500 px-2 py-0.5 text-xs font-semibold text-white">
                    {lowCount >= 100 ? "100+" : lowCount} low stock
                  </span>
                )}
              </span>
            </button>
          ))}
        </nav>
      </main>
    </>
  );
}
