import { useState } from "react";
import { useQuery } from "convex/react";
import { format } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import AppBar from "@/components/layout/app-bar.tsx";
import OpenShiftForm from "@/components/shifts/open-shift-form.tsx";
import { formatKsh } from "@/lib/money.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import CloseShiftDialog from "./_components/close-shift-dialog.tsx";
import CashMovementDialog from "./_components/cash-movement-dialog.tsx";

type Row = { label: string; cents: number; strong?: boolean; negative?: boolean };

function Section({ title, rows }: { title: string; rows: Row[] }) {
  return (
    <section className="rounded-md border bg-card">
      <h3 className="border-b px-4 py-3 text-sm font-semibold text-primary">{title}</h3>
      <dl className="divide-y">
        {rows.map((r) => (
          <div
            key={r.label}
            className={cn("flex justify-between px-4 py-2.5 text-sm", r.strong && "font-semibold")}
          >
            <dt className={r.strong ? "" : "text-muted-foreground"}>{r.label}</dt>
            <dd className="tabular-nums">
              {r.negative && r.cents > 0 ? "-" : ""}
              {formatKsh(r.cents)}
            </dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

export default function ShiftPage() {
  const data = useQuery(api.sales.shifts.current, {});
  const [dialog, setDialog] = useState<"cash" | "close" | null>(null);

  if (data === undefined) {
    return (
      <>
        <AppBar title="Shift" />
        <div className="mx-auto w-full max-w-xl space-y-4 p-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      </>
    );
  }

  if (data === null) {
    return (
      <>
        <AppBar title="Shift" />
        <main className="min-h-0 flex-1 overflow-y-auto">
          <OpenShiftForm />
        </main>
      </>
    );
  }

  const { shift, movements, expectedCashCents } = data;
  const netSales = shift.grossSalesCents - shift.refundsCents;

  return (
    <>
      <AppBar title="Shift" />
      <main className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-xl space-y-4 p-4 pb-10">
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="secondary"
              size="lg"
              className="h-12 rounded-sm font-semibold uppercase"
              onClick={() => setDialog("cash")}
            >
              Cash management
            </Button>
            <Button
              size="lg"
              className="h-12 rounded-sm font-semibold uppercase"
              onClick={() => setDialog("close")}
            >
              Close shift
            </Button>
          </div>

          <div className="rounded-md border bg-card px-4 py-3 text-sm">
            <p className="font-semibold">Shift number: {shift.number}</p>
            <p className="text-muted-foreground">
              Shift opened: {format(new Date(shift.openedAt), "d MMM yyyy, h:mm a")}
            </p>
          </div>

          <Section
            title="Cash drawer"
            rows={[
              { label: "Starting cash", cents: shift.startingCashCents },
              { label: "Cash payments", cents: shift.cashPaymentsCents },
              { label: "Cash refunds", cents: shift.cashRefundsCents, negative: true },
              { label: "Paid in", cents: shift.paidInCents },
              { label: "Paid out", cents: shift.paidOutCents, negative: true },
              { label: "Expected cash amount", cents: expectedCashCents, strong: true },
            ]}
          />

          <Section
            title="Sales summary"
            rows={[
              { label: "Gross sales", cents: shift.grossSalesCents, strong: true },
              { label: "Refunds", cents: shift.refundsCents, negative: true },
              { label: "Net sales", cents: netSales, strong: true },
              { label: "Cash", cents: shift.cashPaymentsCents - shift.cashRefundsCents },
              { label: "Card", cents: shift.cardCents },
              { label: "M-Pesa", cents: shift.mpesaCents },
            ]}
          />

          {movements.length > 0 && (
            <section className="rounded-md border bg-card">
              <h3 className="border-b px-4 py-3 text-sm font-semibold text-primary">
                Pay in / Pay out
              </h3>
              <ul className="divide-y">
                {movements.map((m) => (
                  <li key={m._id} className="flex items-center justify-between gap-4 px-4 py-2.5 text-sm">
                    <div className="min-w-0">
                      <p className="truncate">{m.comment ?? (m.kind === "in" ? "Pay in" : "Pay out")}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(m.createdAt), "h:mm a")}
                      </p>
                    </div>
                    <span
                      className={cn(
                        "shrink-0 font-semibold tabular-nums",
                        m.kind === "out" ? "text-destructive" : "text-primary",
                      )}
                    >
                      {m.kind === "out" ? "-" : "+"}
                      {formatKsh(m.amountCents)}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      </main>

      <CashMovementDialog
        shiftId={shift._id}
        open={dialog === "cash"}
        onClose={() => setDialog(null)}
      />
      <CloseShiftDialog
        key={shift._id}
        shiftId={shift._id}
        expectedCashCents={expectedCashCents}
        open={dialog === "close"}
        onClose={() => setDialog(null)}
      />
    </>
  );
}
