import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { formatKsh, parseToCents } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";

type Props = {
  shiftId: Id<"shifts">;
  expectedCashCents: number;
  open: boolean;
  onClose: () => void;
};

export default function CloseShiftDialog({ shiftId, expectedCashCents, open, onClose }: Props) {
  const close = useMutation(api.sales.shifts.close);
  const [cash, setCash] = useState("");
  const [saving, setSaving] = useState(false);
  const parsed = parseToCents(cash);
  const invalid = parsed === null || Number.isNaN(parsed);
  const difference = invalid ? 0 : parsed - expectedCashCents;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (invalid) return;
    setSaving(true);
    try {
      await close({ shiftId, actualCashCents: parsed });
      toast.success("Shift closed");
      onClose();
    } catch (err) {
      toast.error(convexMessage(err, "Could not close shift"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <form onSubmit={submit} className="grid gap-4">
          <DialogHeader>
            <DialogTitle>Close shift</DialogTitle>
            <DialogDescription>Count the cash in the drawer and enter the total.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Expected cash amount</span>
            <span className="font-semibold tabular-nums">{formatKsh(expectedCashCents)}</span>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="actual-cash">Actual cash amount</Label>
            <Input
              id="actual-cash"
              autoFocus
              inputMode="decimal"
              value={cash}
              onChange={(e) => setCash(e.target.value)}
              placeholder={(expectedCashCents / 100).toFixed(2)}
            />
          </div>
          {!invalid && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Difference</span>
              <span
                className={
                  difference < 0
                    ? "font-semibold text-destructive tabular-nums"
                    : "font-semibold text-primary tabular-nums"
                }
              >
                {difference > 0 ? "+" : ""}
                {difference < 0 ? "-" : ""}
                {formatKsh(Math.abs(difference))}
              </span>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={invalid || saving}>
              {saving ? "Closing..." : "Close shift"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
