import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { formatKsh, parseToCents } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";

type Props = { shiftId: Id<"shifts">; open: boolean; onClose: () => void };

/** Pay in / pay out: cash put into or taken out of the drawer. */
export default function CashMovementDialog({ shiftId, open, onClose }: Props) {
  const add = useMutation(api.sales.shifts.addCashMovement);
  const [amount, setAmount] = useState("");
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState<"in" | "out" | null>(null);
  const cents = parseToCents(amount);
  const invalid = cents === null || Number.isNaN(cents) || cents === 0;

  const submit = async (kind: "in" | "out") => {
    if (invalid) return;
    setSaving(kind);
    try {
      await add({ shiftId, kind, amountCents: cents, comment });
      toast.success(`${kind === "in" ? "Paid in" : "Paid out"} ${formatKsh(cents)}`);
      setAmount("");
      setComment("");
      onClose();
    } catch (err) {
      toast.error(convexMessage(err, "Could not save"));
    } finally {
      setSaving(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Cash management</DialogTitle>
          <DialogDescription>Record cash added to or taken from the drawer.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-2">
          <Label htmlFor="move-amount">Amount</Label>
          <Input
            id="move-amount"
            autoFocus
            inputMode="decimal"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="500.00"
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="move-comment">Comment</Label>
          <Input
            id="move-comment"
            maxLength={120}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Bought milk for the shop"
          />
        </div>
        <DialogFooter className="grid grid-cols-2 gap-3 sm:space-x-0">
          <Button
            variant="secondary"
            disabled={invalid || saving !== null}
            onClick={() => submit("in")}
            className="uppercase"
          >
            {saving === "in" ? "Saving..." : "Pay in"}
          </Button>
          <Button
            disabled={invalid || saving !== null}
            onClick={() => submit("out")}
            className="uppercase"
          >
            {saving === "out" ? "Saving..." : "Pay out"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
