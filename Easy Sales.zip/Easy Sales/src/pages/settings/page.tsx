import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Download, Monitor, Percent, Printer, ReceiptText, Settings, type LucideIcon } from "lucide-react";
import AppBar from "@/components/layout/app-bar.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";
import InstallAppDialog from "@/components/install/install-app-dialog.tsx";
import { useUser } from "@/hooks/use-auth.ts";

type Entry = { label: string; icon: LucideIcon; to?: string; action?: "install" };

// Matches the Settings menu in the original app; entries without `to` or `action` aren't built yet
const ENTRIES: Entry[] = [
  { label: "Printers", icon: Printer, to: "/settings/printers" },
  { label: "Customer displays", icon: Monitor },
  { label: "Taxes", icon: Percent, to: "/settings/taxes" },
  { label: "Receipt", icon: ReceiptText, to: "/settings/receipt" },
  { label: "General", icon: Settings, to: "/settings/general" },
  { label: "Install app", icon: Download, action: "install" },
];

export default function SettingsMenuPage() {
  const navigate = useNavigate();
  const user = useUser();
  const profile = user?.profile;
  const [installOpen, setInstallOpen] = useState(false);

  const handleEntry = ({ to, action }: Entry) => {
    if (action === "install") return setInstallOpen(true);
    if (to) return navigate(to);
    toast("Coming soon in a future milestone!");
  };

  return (
    <>
      <AppBar title="Settings" />
      <main className="flex min-h-0 flex-1 flex-col overflow-y-auto bg-card">
        <nav className="mx-auto w-full max-w-3xl flex-1">
          {ENTRIES.map((entry) => (
            <button
              key={entry.label}
              type="button"
              onClick={() => handleEntry(entry)}
              className="flex w-full cursor-pointer items-center gap-8 pl-6 text-left transition-colors hover:bg-muted active:bg-accent"
            >
              <entry.icon className="size-5 shrink-0 text-muted-foreground" />
              <span className="flex-1 border-b py-4 text-base">{entry.label}</span>
            </button>
          ))}
        </nav>

        <div className="mx-auto w-full max-w-3xl space-y-4 px-6 pb-6 pt-10 text-center">
          <p className="truncate text-sm text-muted-foreground">
            {profile?.email ?? profile?.name ?? ""}
          </p>
          <SignInButton
            variant="ghost"
            showIcon={false}
            signOutText="Sign out"
            className="h-12 w-full rounded-sm border bg-muted font-medium uppercase hover:bg-accent"
          />
        </div>
      </main>
      <InstallAppDialog open={installOpen} onOpenChange={setInstallOpen} />
    </>
  );
}
