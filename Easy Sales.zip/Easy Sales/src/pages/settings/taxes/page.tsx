import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { StoreSettings } from "@/convex/settings.ts";
import { Form } from "@/components/ui/form.tsx";
import TaxesEditor from "../_components/taxes-editor.tsx";
import {
  SaveBar,
  Section,
  SettingsSubPage,
  useSaveSettings,
} from "../_components/settings-sub-page.tsx";
import {
  fromTaxesForm,
  taxesSchema,
  toTaxesForm,
  type TaxesForm,
} from "../_lib/settings-form.ts";

export default function TaxesSettingsPage() {
  return <SettingsSubPage title="Taxes">{(s) => <TaxesFormView initial={s} />}</SettingsSubPage>;
}

function TaxesFormView({ initial }: { initial: StoreSettings }) {
  const save = useSaveSettings(initial);
  const form = useForm<TaxesForm>({
    resolver: zodResolver(taxesSchema),
    defaultValues: toTaxesForm(initial),
  });

  const onSubmit = async (values: TaxesForm) => {
    if (await save({ taxes: fromTaxesForm(values) })) form.reset(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <Section title="Taxes">
          <p className="text-sm text-muted-foreground">
            Included taxes are already part of your item prices (like VAT in Kenya). Added taxes are
            charged on top of the ticket total.
          </p>
          <TaxesEditor />
        </Section>
        <SaveBar disabled={!form.formState.isDirty} saving={form.formState.isSubmitting} />
      </form>
    </Form>
  );
}
