import { z } from "zod";
import { parseRateBps } from "@/convex/lib/taxes.ts";
import { SETTINGS_LIMITS } from "@/convex/lib/settingsLimits.ts";
import type { StoreSettings } from "@/convex/settings.ts";

const text = (max: number) => z.string().trim().max(max, `Up to ${max} characters`);

export const generalSchema = z.object({
  storeName: text(SETTINGS_LIMITS.storeName),
  posName: z.string().trim().min(1, "POS name is required").max(SETTINGS_LIMITS.posName, `Up to ${SETTINGS_LIMITS.posName} characters`),
});

export const receiptSchema = z.object({
  receiptHeader: text(SETTINGS_LIMITS.receiptHeader),
  receiptFooter: text(SETTINGS_LIMITS.receiptFooter),
  showCustomerInfo: z.boolean(),
  showComments: z.boolean(),
});

export const taxesSchema = z.object({
  taxes: z
    .array(
      z.object({
        name: z.string().trim().min(1, "Name is required").max(30, "Up to 30 characters"),
        rate: z
          .string()
          .refine((r) => !Number.isNaN(parseRateBps(r)), "Enter a rate from 0 to 100"),
        type: z.enum(["included", "added"]),
        enabled: z.boolean(),
      }),
    )
    .max(10, "Up to 10 taxes"),
});

export type GeneralForm = z.infer<typeof generalSchema>;
export type ReceiptForm = z.infer<typeof receiptSchema>;
export type TaxesForm = z.infer<typeof taxesSchema>;
export type TaxFormRow = TaxesForm["taxes"][number];

export const NEW_TAX: TaxFormRow = { name: "VAT", rate: "16", type: "included", enabled: true };

export function toTaxesForm(s: StoreSettings): TaxesForm {
  return { taxes: s.taxes.map((t) => ({ ...t, rate: String(t.rateBps / 100) })) };
}

export function fromTaxesForm(values: TaxesForm): StoreSettings["taxes"] {
  return values.taxes.map(({ name, rate, type, enabled }) => ({
    name,
    rateBps: parseRateBps(rate),
    type,
    enabled,
  }));
}
