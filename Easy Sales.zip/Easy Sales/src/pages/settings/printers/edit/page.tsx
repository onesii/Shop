import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Bluetooth, ExternalLink, Printer, Trash2, Usb } from "lucide-react";
import { toast } from "sonner";
import AppBar from "@/components/layout/app-bar.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import {
  deletePrinter,
  isValidIp,
  newPrinter,
  savePrinter,
  usePrinters,
  type HardwareInterface,
  type PrinterConfig,
} from "@/lib/printing/printers-store.ts";
import { findModel, PRINTER_MODELS, printsOnPaper } from "@/lib/printing/models.ts";
import { bluetoothSupported, pickBluetoothPrinter } from "@/lib/printing/bluetooth.ts";
import { pickUsbPrinter, usbSupported } from "@/lib/printing/usb.ts";
import { canPrint, connectionLabel, INTERFACE_LABELS, printLines, usesDialog } from "@/lib/printing/print.ts";
import { buildTestLines } from "@/lib/printing/receipt-layout.ts";
import { detectPlatform, isNativeApp } from "@/lib/printing/platform.ts";
import { printerPageUrl } from "@/lib/printing/network.ts";
import ConnectionHelp from "../_components/connection-help.tsx";
import PrinterGroupsCard from "../_components/printer-groups-card.tsx";

export default function PrinterEditPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const printers = usePrinters();
  const isNew = id === "new";
  const existing = isNew ? null : printers.find((p) => p.id === id);
  const back = () => navigate("/settings/printers");

  if (!isNew && !existing) {
    return (
      <>
        <AppBar title="Printer" onBack={back} />
        <Empty className="pt-20">
          <EmptyHeader>
            <EmptyMedia variant="icon"><Printer /></EmptyMedia>
            <EmptyTitle>Printer not found</EmptyTitle>
          </EmptyHeader>
        </Empty>
      </>
    );
  }
  return <PrinterForm key={id} initial={existing ?? newPrinter()} isNew={isNew} onDone={back} />;
}

type FormProps = { initial: PrinterConfig; isNew: boolean; onDone: () => void };

/** Connections the chosen model supports, in dropdown order. */
function interfacesFor(modelId: string): HardwareInterface[] {
  return [...findModel(modelId).interfaces];
}

/** Name of the paired device for Bluetooth / USB, or null when none picked yet. */
function pairedName(p: PrinterConfig): string | null {
  if (p.interface === "bluetooth") return p.bluetoothDeviceName;
  if (p.interface === "usb") return p.usbDevice?.name ?? null;
  return null;
}

/** Why the printer can't be saved or tested yet, or null when it's ready. */
function missingSetup(p: PrinterConfig, nativeApp: boolean): string | null {
  if (usesDialog(p) || !canPrint(p)) return null;
  if (p.interface === "ethernet" && !isValidIp(p.ipAddress)) return "Enter the printer's IP address, e.g. 192.168.1.50";
  if (p.interface === "builtin") return "The Sunmi built-in printer isn't supported. Choose a Wi-Fi or Bluetooth printer";
  // The store app can't reach Bluetooth/USB at all; printing explains how to fix it
  if (nativeApp) return null;
  if (p.interface === "bluetooth" && !p.bluetoothDeviceId) return "Search for your Bluetooth printer first";
  if (p.interface === "usb" && !p.usbDevice) return "Search for your USB printer first";
  return null;
}

function PrinterForm({ initial, isNew, onDone }: FormProps) {
  // Printers saved before Interface had USB/Ethernet only offered the dialog as an interface
  const [printer, setPrinter] = useState<PrinterConfig>(() =>
    initial.interface === "system" ? { ...initial, interface: "ethernet", model: "system" } : initial,
  );
  const [searching, setSearching] = useState(false);
  const [testing, setTesting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const platform = detectPlatform();
  const nativeApp = isNativeApp();
  const bluetoothOk = bluetoothSupported();
  const usbOk = usbSupported();
  const update = (patch: Partial<PrinterConfig>) => setPrinter((p) => ({ ...p, ...patch }));
  const model = findModel(printer.model);
  const dialog = usesDialog(printer);
  const paper = canPrint(printer) && !dialog;
  const options = interfacesFor(printer.model);
  const iface: HardwareInterface =
    printer.interface !== "system" && options.includes(printer.interface) ? printer.interface : (options[0] ?? "ethernet");
  const problem = missingSetup({ ...printer, interface: iface }, nativeApp);

  const chooseModel = (id: string) => {
    const next = findModel(id);
    const allowed = interfacesFor(next.id);
    const keep = printer.interface !== "system" && allowed.includes(printer.interface);
    update({
      model: next.id,
      paperWidth: next.paperWidth,
      interface: keep ? printer.interface : (allowed[0] ?? printer.interface),
      // Nothing to print on: turn printing off so it isn't picked for receipts or orders
      ...(printsOnPaper(next) ? {} : { printReceipts: false, printOrders: false, autoPrint: false }),
    });
  };

  const search = async () => {
    setSearching(true);
    try {
      if (iface === "usb") {
        const device = await pickUsbPrinter();
        update({ usbDevice: device, name: printer.name || device.name });
      } else {
        const device = await pickBluetoothPrinter();
        update({
          bluetoothDeviceId: device.id,
          bluetoothDeviceName: device.name,
          name: printer.name || device.name,
        });
      }
    } catch (err) {
      // Closing the picker isn't an error worth showing
      if (!(err instanceof DOMException && err.name === "NotFoundError")) {
        toast.error("Could not search for printers", {
          description: err instanceof Error ? err.message : undefined,
        });
      }
    } finally {
      setSearching(false);
    }
  };

  const test = async () => {
    if (problem) return toast.error(problem);
    setTesting(true);
    try {
      const ready = { ...printer, interface: iface };
      await printLines(ready, buildTestLines(printer.name, connectionLabel(ready), printer.paperWidth));
    } catch (err) {
      toast.error("Test print failed", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setTesting(false);
    }
  };

  const save = () => {
    if (!printer.name.trim()) return toast.error("Enter a printer name");
    if (problem) return toast.error(problem);
    savePrinter({
      ...printer,
      interface: dialog ? printer.interface : iface,
      name: printer.name.trim(),
      ipAddress: printer.ipAddress.trim(),
    });
    toast.success("Printer saved");
    onDone();
  };

  const remove = () => {
    deletePrinter(printer.id);
    toast.success("Printer deleted");
    onDone();
  };

  // The store app's browser has no Bluetooth/USB, so there's nothing to search for
  const searchable = paper && !nativeApp && (iface === "bluetooth" || iface === "usb");
  const searchOk = iface === "usb" ? usbOk : bluetoothOk;
  const SearchIcon = iface === "usb" ? Usb : Bluetooth;
  const helpConnection =
    model.kind === "none" ? "none" : model.kind === "display" ? "display" : dialog ? "system" : iface;

  return (
    <>
      <AppBar
        title={isNew ? "Create printer" : "Edit printer"}
        onBack={onDone}
        actions={
          <Button
            variant="ghost"
            className="font-semibold uppercase text-secondary-foreground hover:bg-white/10 hover:text-secondary-foreground"
            onClick={save}
          >
            Save
          </Button>
        }
      />
      <main className="min-h-0 flex-1 overflow-y-auto bg-muted/60">
        <div className="mx-auto w-full max-w-3xl space-y-4 p-4 pb-10">
          <section className="rounded-sm bg-card shadow-sm">
            <div className="space-y-6 p-6">
              <Field label="Name" htmlFor="printer-name">
                <Input
                  id="printer-name"
                  maxLength={40}
                  value={printer.name}
                  onChange={(e) => update({ name: e.target.value })}
                  placeholder="Epson"
                  className="h-auto rounded-none border-0 border-b border-foreground/30 bg-transparent px-0 pb-2 text-xl shadow-none focus-visible:border-primary focus-visible:ring-0 md:text-2xl dark:bg-transparent"
                />
              </Field>

              <Field label="Printer model">
                <Select value={printer.model} onValueChange={chooseModel}>
                  <UnderlineTrigger />
                  <SelectContent>
                    {PRINTER_MODELS.map((m) => (
                      <SelectItem key={m.id} value={m.id}>{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              {paper && options.length > 1 && (
                <Field label="Interface">
                  <Select
                    value={iface}
                    onValueChange={(v) => {
                      const next = options.find((h) => h === v);
                      if (next) update({ interface: next });
                    }}
                  >
                    <UnderlineTrigger />
                    <SelectContent>
                      {options.map((k) => (
                        <SelectItem key={k} value={k}>{INTERFACE_LABELS[k]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              )}

              {paper && iface === "ethernet" && (
                <Field label="Printer IP address" htmlFor="printer-ip">
                  <Input
                    id="printer-ip"
                    inputMode="decimal"
                    maxLength={15}
                    value={printer.ipAddress}
                    onChange={(e) => update({ ipAddress: e.target.value.replace(/[^\d.]/g, "") })}
                    placeholder="192.168.1.50"
                    className="h-auto rounded-none border-0 border-b border-foreground/30 bg-transparent px-0 pb-2 text-base shadow-none focus-visible:border-primary focus-visible:ring-0 dark:bg-transparent"
                  />
                  {isValidIp(printer.ipAddress) && (
                    <Button asChild variant="secondary" size="sm" className="mt-3">
                      <a href={printerPageUrl(printer.ipAddress)} target="_blank" rel="noreferrer">
                        <ExternalLink className="size-4" /> Open printer page
                      </a>
                    </Button>
                  )}
                </Field>
              )}

              {searchable && (
                <div className="flex items-center justify-between gap-3 border-b border-foreground/30 pb-2">
                  <div className="min-w-0">
                    <p className="text-xs text-muted-foreground">
                      {iface === "usb" ? "USB printer" : "Bluetooth printer"}
                    </p>
                    <p className="truncate">{pairedName(printer) ?? "Not selected"}</p>
                  </div>
                  <Button type="button" variant="secondary" disabled={!searchOk || searching} onClick={search}>
                    {searching ? <Spinner /> : <SearchIcon className="size-4" />}
                    Search
                  </Button>
                </div>
              )}

              <ConnectionHelp
                connection={helpConnection}
                platform={platform}
                nativeApp={nativeApp}
                bluetoothOk={bluetoothOk}
                usbOk={usbOk}
              />
            </div>

            {canPrint(printer) && (
              <>
                <div className="border-t">
                  <SwitchRow
                    label="Print receipts and bills"
                    checked={printer.printReceipts}
                    onChange={(v) => update({ printReceipts: v, autoPrint: v && printer.autoPrint })}
                  />
                  <SwitchRow
                    label="Print orders"
                    checked={printer.printOrders}
                    onChange={(v) => update({ printOrders: v })}
                  />
                </div>
                <div className="border-t">
                  {printer.printReceipts && (
                    <SwitchRow
                      label="Automatically print receipt"
                      checked={printer.autoPrint}
                      onChange={(v) => update({ autoPrint: v })}
                    />
                  )}
                  {printer.printOrders && (
                    <>
                      <SwitchRow
                        label="Print single item per order ticket"
                        checked={printer.printSingleItem}
                        onChange={(v) => update({ printSingleItem: v })}
                      />
                      <SwitchRow
                        label="Group identical items in order tickets"
                        checked={printer.groupIdentical}
                        onChange={(v) => update({ groupIdentical: v })}
                      />
                    </>
                  )}
                </div>
                <button
                  type="button"
                  disabled={testing}
                  onClick={test}
                  className="flex w-full cursor-pointer items-center justify-center gap-3 border-t py-4 text-sm font-medium uppercase transition-colors hover:bg-muted disabled:opacity-60"
                >
                  {testing ? <Spinner /> : <Printer className="size-5 text-muted-foreground" />} Print test
                </button>
              </>
            )}
          </section>

          {canPrint(printer) && printer.printOrders && (
            <PrinterGroupsCard selected={printer.groupIds} onChange={(groupIds) => update({ groupIds })} />
          )}

          {!isNew && (
            <button
              type="button"
              onClick={() => setConfirmDelete(true)}
              className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-sm bg-card py-4 text-sm font-medium uppercase shadow-sm transition-colors hover:bg-muted"
            >
              <Trash2 className="size-5 text-muted-foreground" /> Delete printer
            </button>
          )}
        </div>
      </main>

      <Dialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete printer?</DialogTitle>
            <DialogDescription>{printer.name || "This printer"} will be removed from this device.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmDelete(false)}>Cancel</Button>
            <Button variant="destructive" onClick={remove}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function Field({ label, htmlFor, children }: { label: string; htmlFor?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <Label htmlFor={htmlFor} className="text-xs font-normal text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

/** Android-style underlined dropdown, as in the original app. */
function UnderlineTrigger() {
  return (
    <SelectTrigger className="h-auto w-full cursor-pointer rounded-none border-0 border-b border-foreground/30 bg-transparent px-0 pb-2 text-base shadow-none focus-visible:ring-0 data-[size=default]:h-auto dark:bg-transparent dark:hover:bg-transparent">
      <SelectValue />
    </SelectTrigger>
  );
}

type SwitchRowProps = {
  label: string;
  description?: string;
  checked: boolean;
  disabled?: boolean;
  onChange: (v: boolean) => void;
};

function SwitchRow({ label, description, checked, disabled, onChange }: SwitchRowProps) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-4 px-6 py-4">
      <span>
        <span className="block">{label}</span>
        {description && <span className="block text-sm text-muted-foreground">{description}</span>}
      </span>
      <Switch checked={checked} disabled={disabled} onCheckedChange={onChange} />
    </label>
  );
}
