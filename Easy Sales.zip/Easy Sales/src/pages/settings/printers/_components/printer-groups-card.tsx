import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { convexMessage } from "@/lib/errors.ts";

type Props = {
  selected: string[];
  onChange: (ids: string[]) => void;
};

/** "Printer groups" card: which kitchen/bar groups this printer prints orders for. */
export default function PrinterGroupsCard({ selected, onChange }: Props) {
  const groups = useQuery(api.printing.printerGroups.list, {});
  const [editing, setEditing] = useState<Doc<"printerGroups"> | "new" | null>(null);

  const toggle = (id: string, on: boolean) =>
    onChange(on ? [...selected, id] : selected.filter((g) => g !== id));

  return (
    <section className="rounded-sm bg-card shadow-sm">
      <div className="flex items-center justify-between px-6 pb-1 pt-4">
        <h2 className="text-sm font-medium text-primary">Printer groups</h2>
        <Button variant="ghost" size="sm" className="text-primary" onClick={() => setEditing("new")}>
          <Plus className="size-4" /> Add group
        </Button>
      </div>
      {groups === undefined ? (
        <div className="space-y-3 px-6 py-4">
          <Skeleton className="h-6 w-full" />
          <Skeleton className="h-6 w-full" />
        </div>
      ) : groups.length === 0 ? (
        <p className="px-6 pb-5 pt-1 text-sm text-muted-foreground">
          Group printers by category, e.g. "Kitchen" for food and "Bar" for drinks. A printer in no group prints
          every order.
        </p>
      ) : (
        <div className="pb-2">
          {groups.map((g) => (
            <div key={g._id} className="flex items-center gap-4 px-6 py-3">
              <button
                type="button"
                onClick={() => setEditing(g)}
                className="min-w-0 flex-1 cursor-pointer text-left"
              >
                <span className="block truncate">{g.name}</span>
                <span className="block truncate text-xs text-muted-foreground">
                  {g.categoryIds.length === 0
                    ? "No categories yet, tap to edit"
                    : `${g.categoryIds.length} ${g.categoryIds.length === 1 ? "category" : "categories"}`}
                </span>
              </button>
              <Switch
                aria-label={`Print orders for ${g.name}`}
                checked={selected.includes(g._id)}
                onCheckedChange={(on) => toggle(g._id, on)}
              />
            </div>
          ))}
        </div>
      )}

      <Dialog open={editing !== null} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          {editing !== null && (
            <GroupForm
              group={editing === "new" ? null : editing}
              onDone={(createdId) => {
                if (createdId) onChange([...selected, createdId]);
                setEditing(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function GroupForm({ group, onDone }: { group: Doc<"printerGroups"> | null; onDone: (createdId?: string) => void }) {
  const categories = useQuery(api.catalog.categories.list, {});
  const create = useMutation(api.printing.printerGroups.create);
  const update = useMutation(api.printing.printerGroups.update);
  const remove = useMutation(api.printing.printerGroups.remove);
  const [name, setName] = useState(group?.name ?? "");
  const [categoryIds, setCategoryIds] = useState<Id<"categories">[]>(group?.categoryIds ?? []);
  const [saving, setSaving] = useState(false);

  const run = async (action: () => Promise<string | undefined>, done: string) => {
    setSaving(true);
    try {
      const createdId = await action();
      toast.success(done);
      onDone(createdId);
    } catch (err) {
      toast.error(convexMessage(err, "Could not save the printer group"));
      setSaving(false);
    }
  };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return toast.error("Group name cannot be blank");
    void run(async () => {
      if (group) {
        await update({ id: group._id, name, categoryIds });
        return undefined;
      }
      return await create({ name, categoryIds });
    }, "Printer group saved");
  };

  return (
    <form onSubmit={save} className="grid gap-4">
      <DialogHeader>
        <DialogTitle>{group ? "Edit printer group" : "Create printer group"}</DialogTitle>
        <DialogDescription>Orders for these categories print on the printers in this group.</DialogDescription>
      </DialogHeader>
      <div className="grid gap-2">
        <Label htmlFor="group-name">Name</Label>
        <Input
          id="group-name"
          autoFocus
          maxLength={40}
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Kitchen"
        />
      </div>
      <div className="grid gap-2">
        <Label>Categories</Label>
        <div className="max-h-56 space-y-1 overflow-y-auto rounded-md border p-2">
          {categories === undefined ? (
            <Skeleton className="h-6 w-full" />
          ) : categories.length === 0 ? (
            <p className="p-2 text-sm text-muted-foreground">Create categories in Items first.</p>
          ) : (
            categories.map((c) => (
              <label key={c._id} className="flex cursor-pointer items-center gap-3 rounded px-2 py-1.5 hover:bg-muted">
                <Checkbox
                  checked={categoryIds.includes(c._id)}
                  onCheckedChange={(on) =>
                    setCategoryIds((ids) => (on === true ? [...ids, c._id] : ids.filter((i) => i !== c._id)))
                  }
                />
                <span className="truncate">{c.name}</span>
              </label>
            ))
          )}
        </div>
      </div>
      <DialogFooter className="gap-2 sm:justify-between">
        {group ? (
          <Button
            type="button"
            variant="ghost"
            className="text-destructive hover:text-destructive"
            disabled={saving}
            onClick={() =>
              run(async () => {
                await remove({ id: group._id });
                return undefined;
              }, "Printer group deleted")
            }
          >
            Delete
          </Button>
        ) : (
          <span />
        )}
        <div className="flex gap-2">
          <Button type="button" variant="ghost" onClick={() => onDone()}>Cancel</Button>
          <Button type="submit" disabled={saving}>Save</Button>
        </div>
      </DialogFooter>
    </form>
  );
}
