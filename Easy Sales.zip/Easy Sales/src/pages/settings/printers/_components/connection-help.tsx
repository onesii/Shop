import { Info } from "lucide-react";
import type { HardwareInterface } from "@/lib/printing/printers-store.ts";
import { BLUEFY_URL, type Platform } from "@/lib/printing/platform.ts";

type Props = {
  connection: HardwareInterface | "system" | "none" | "display";
  platform: Platform;
  /** Running inside the installed store app, whose browser has no Bluetooth or USB. */
  nativeApp: boolean;
  bluetoothOk: boolean;
  usbOk: boolean;
};

const linkClass = "font-medium text-primary underline underline-offset-2";

const INSTALL_FROM_CHROME =
  "The store app can't use Bluetooth or USB. Open this app's link in Google Chrome and choose \"Add to Home screen\" (Install app). That installed app prints over Bluetooth and USB.";

function helpText({ connection, platform, nativeApp, bluetoothOk, usbOk }: Props): React.ReactNode {
  if (connection === "none") return "This printer is turned off. Nothing will print on it.";
  if (connection === "display") {
    return "Kitchen display screens aren't available yet. Choose a printer model to print orders in the kitchen.";
  }
  if (connection === "system") {
    return nativeApp
      ? "The store app has no print window. Choose your printer model and connect over Wi-Fi instead."
      : "Uses the device's own print window. Works with AirPrint printers on iPhone and printers added to the Android print service.";
  }
  if (connection === "builtin") {
    return "The Sunmi built-in printer can't be reached from the app. Connect a Wi-Fi or Bluetooth receipt printer instead.";
  }
  if (connection === "ethernet") {
    return (
      <>
        Prints straight to the printer over Wi-Fi, with no other app needed. Works with Epson TM printers (TM-m30,
        TM-T20II, TM-T88V). Keep this phone on the same Wi-Fi as the printer and enter the IP address from the
        printer's self-test page. The first time, tap <b>Open printer page</b>, accept the security warning, then
        come back and tap <b>Print test</b>. If the phone asks to find devices on your local network, tap Allow.
      </>
    );
  }
  if (connection === "bluetooth") {
    if (nativeApp) return INSTALL_FROM_CHROME;
    if (bluetoothOk) {
      return "Turn the printer on, then tap Search and pick it from the list. Works with Bluetooth Low Energy (BLE) thermal printers. Older printers that only pair in Android settings can't be reached; use Wi-Fi for those.";
    }
    if (platform === "ios") {
      return (
        <>
          Safari on iPhone and iPad can't reach Bluetooth printers. Open this app in the free{" "}
          <a href={BLUEFY_URL} target="_blank" rel="noreferrer" className={linkClass}>Bluefy browser</a>{" "}
          to print over Bluetooth, or use a Wi-Fi printer.
        </>
      );
    }
    return "This browser can't use Bluetooth. Open the app in Google Chrome, or use Wi-Fi.";
  }
  if (nativeApp) return INSTALL_FROM_CHROME;
  if (usbOk) {
    return "Plug the printer into this device (on a phone or tablet use an OTG cable), then tap Search and pick it from the list.";
  }
  return platform === "ios"
    ? "iPhone and iPad can't print over USB. Use a Wi-Fi printer."
    : "This browser can't use USB printers. Open the app in Google Chrome.";
}

export default function ConnectionHelp(props: Props) {
  return (
    <div className="flex gap-3 rounded-md bg-muted p-3 text-sm text-muted-foreground">
      <Info className="mt-0.5 size-4 shrink-0" />
      <p>{helpText(props)}</p>
    </div>
  );
}
