import { useNavigate } from "react-router-dom";
import { Plus, Printer } from "lucide-react";
import AppBar from "@/components/layout/app-bar.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { usePrinters } from "@/lib/printing/printers-store.ts";
import { connectionLabel } from "@/lib/printing/print.ts";
import { findModel } from "@/lib/printing/models.ts";

export default function PrintersPage() {
  const navigate = useNavigate();
  const printers = usePrinters();

  return (
    <>
      <AppBar title="Printers" onBack={() => navigate("/settings")} />
      <main className="min-h-0 flex-1 overflow-y-auto bg-card">
        <div className="mx-auto max-w-3xl pb-24">
          {printers.length === 0 ? (
            <Empty className="pt-20">
              <EmptyHeader>
                <EmptyMedia variant="icon"><Printer /></EmptyMedia>
                <EmptyTitle>You have no printers yet</EmptyTitle>
                <EmptyDescription>
                  Add an Ethernet, Bluetooth or USB receipt printer for this device
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button size="sm" onClick={() => navigate("/settings/printers/new")}>Add printer</Button>
              </EmptyContent>
            </Empty>
          ) : (
            printers.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => navigate(`/settings/printers/${p.id}`)}
                className="flex w-full cursor-pointer items-center gap-8 pl-6 text-left transition-colors hover:bg-muted active:bg-accent"
              >
                <Printer className="size-5 shrink-0 text-muted-foreground" />
                <span className="min-w-0 flex-1 border-b py-3 pr-4">
                  <span className="block truncate text-base">{p.name || "Printer"}</span>
                  <span className="block truncate text-sm text-muted-foreground">
                    {[
                      findModel(p.model).label,
                      connectionLabel(p),
                      p.printOrders ? "Orders" : null,
                      p.autoPrint ? "Auto print" : null,
                    ]
                      .filter(Boolean)
                      .join(" · ")}
                  </span>
                </span>
              </button>
            ))
          )}
        </div>

        <Button
          size="icon"
          aria-label="Add printer"
          onClick={() => navigate("/settings/printers/new")}
          className="fixed bottom-6 right-6 size-14 rounded-full shadow-lg"
        >
          <Plus className="size-6" />
        </Button>
      </main>
    </>
  );
}
