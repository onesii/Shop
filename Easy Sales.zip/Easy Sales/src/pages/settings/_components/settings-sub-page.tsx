import { useNavigate } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { StoreSettings } from "@/convex/settings.ts";
import AppBar from "@/components/layout/app-bar.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { convexMessage } from "@/lib/errors.ts";

type ShellProps = {
  title: string;
  children: (settings: StoreSettings) => React.ReactNode;
};

/** Sub-screen frame: back arrow to the Settings menu, loads settings first. */
export function SettingsSubPage({ title, children }: ShellProps) {
  const navigate = useNavigate();
  const settings = useQuery(api.settings.get, {});
  return (
    <>
      <AppBar title={title} onBack={() => navigate("/settings")} />
      <main className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-2xl p-4 pb-10">
          {settings === undefined ? (
            <div className="space-y-4">
              {Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-40 w-full" />
              ))}
            </div>
          ) : (
            children(settings)
          )}
        </div>
      </main>
    </>
  );
}

/** Saves part of the settings; the update mutation needs every field, so merge the rest in. */
export function useSaveSettings(current: StoreSettings) {
  const update = useMutation(api.settings.update);
  return async (patch: Partial<StoreSettings>): Promise<boolean> => {
    const next = { ...current, ...patch };
    try {
      await update({
        storeName: next.storeName,
        posName: next.posName,
        receiptHeader: next.receiptHeader,
        receiptFooter: next.receiptFooter,
        showCustomerInfo: next.showCustomerInfo,
        showComments: next.showComments,
        taxes: next.taxes,
      });
      toast.success("Settings saved");
      return true;
    } catch (err) {
      toast.error(convexMessage(err, "Could not save settings"));
      return false;
    }
  };
}

export function SaveBar({ disabled, saving }: { disabled: boolean; saving: boolean }) {
  return (
    <div className="sticky bottom-0 -mx-4 border-t bg-background/95 px-4 py-3 backdrop-blur">
      <Button
        type="submit"
        size="lg"
        disabled={disabled || saving}
        className="h-12 w-full rounded-sm font-semibold uppercase"
      >
        {saving ? "Saving..." : "Save"}
      </Button>
    </div>
  );
}

export function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-md border bg-card">
      <h2 className="border-b px-4 py-3 text-sm font-semibold text-primary">{title}</h2>
      <div className="space-y-4 p-4">{children}</div>
    </section>
  );
}
