import { useFieldArray, useFormContext } from "react-hook-form";
import { Percent, Plus, Trash2 } from "lucide-react";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import { NEW_TAX, type TaxesForm } from "../_lib/settings-form.ts";

const TYPE_LABELS = {
  included: "Included in price",
  added: "Added to price",
} as const;

export default function TaxesEditor() {
  const { control } = useFormContext<TaxesForm>();
  const { fields, append, remove } = useFieldArray({ control, name: "taxes" });

  return (
    <div className="space-y-3">
      {fields.length === 0 ? (
        <Empty className="border border-dashed py-8">
          <EmptyHeader>
            <EmptyMedia variant="icon"><Percent /></EmptyMedia>
            <EmptyTitle>No taxes</EmptyTitle>
            <EmptyDescription>Add VAT or other taxes to apply them to every sale.</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        fields.map((field, i) => (
          <div key={field.id} className="space-y-3 rounded-md border bg-background p-3">
            <div className="flex items-center justify-between gap-3">
              <FormField
                control={control}
                name={`taxes.${i}.enabled`}
                render={({ field: f }) => (
                  <FormItem className="flex items-center gap-2">
                    <FormControl>
                      <Switch checked={f.value} onCheckedChange={f.onChange} />
                    </FormControl>
                    <FormLabel className="text-sm font-normal">
                      {f.value ? "Applied to sales" : "Off"}
                    </FormLabel>
                  </FormItem>
                )}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label="Remove tax"
                className="text-muted-foreground hover:text-destructive"
                onClick={() => remove(i)}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
            <div className="grid gap-3 sm:grid-cols-[1fr_7rem_12rem]">
              <FormField
                control={control}
                name={`taxes.${i}.name`}
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl><Input placeholder="VAT" maxLength={30} {...f} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={control}
                name={`taxes.${i}.rate`}
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Rate %</FormLabel>
                    <FormControl><Input inputMode="decimal" placeholder="16" {...f} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={control}
                name={`taxes.${i}.type`}
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Type</FormLabel>
                    <Select value={f.value} onValueChange={f.onChange}>
                      <FormControl>
                        <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {(Object.keys(TYPE_LABELS) as (keyof typeof TYPE_LABELS)[]).map((k) => (
                          <SelectItem key={k} value={k}>{TYPE_LABELS[k]}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </div>
          </div>
        ))
      )}
      {fields.length < 10 && (
        <Button
          type="button"
          variant="ghost"
          className="text-primary"
          onClick={() => append(fields.length === 0 ? NEW_TAX : { ...NEW_TAX, name: "", rate: "" })}
        >
          <Plus className="size-4" /> Add tax
        </Button>
      )}
    </div>
  );
}
