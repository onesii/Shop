import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { StoreSettings } from "@/convex/settings.ts";
import { SETTINGS_LIMITS } from "@/convex/lib/settingsLimits.ts";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import {
  SaveBar,
  Section,
  SettingsSubPage,
  useSaveSettings,
} from "../_components/settings-sub-page.tsx";
import { receiptSchema, type ReceiptForm } from "../_lib/settings-form.ts";

type TextField = { name: "receiptHeader" | "receiptFooter"; label: string; placeholder: string; hint: string };
type ToggleField = { name: "showCustomerInfo" | "showComments"; label: string; hint: string };

const TEXT_FIELDS: TextField[] = [
  {
    name: "receiptHeader",
    label: "Header",
    placeholder: "Contact us: 0712 345 678",
    hint: "Printed under the store name.",
  },
  {
    name: "receiptFooter",
    label: "Footer",
    placeholder: "Goods once sold cannot be refunded",
    hint: "Printed at the bottom of each receipt.",
  },
];

const TOGGLES: ToggleField[] = [
  { name: "showCustomerInfo", label: "Show customer info", hint: "The customer's name on the receipt." },
  { name: "showComments", label: "Show comments", hint: "Item comments under each line." },
];

export default function ReceiptSettingsPage() {
  return <SettingsSubPage title="Receipt">{(s) => <ReceiptFormView initial={s} />}</SettingsSubPage>;
}

function ReceiptFormView({ initial }: { initial: StoreSettings }) {
  const save = useSaveSettings(initial);
  const form = useForm<ReceiptForm>({
    resolver: zodResolver(receiptSchema),
    defaultValues: {
      receiptHeader: initial.receiptHeader,
      receiptFooter: initial.receiptFooter,
      showCustomerInfo: initial.showCustomerInfo,
      showComments: initial.showComments,
    },
  });

  const onSubmit = async (values: ReceiptForm) => {
    if (await save(values)) form.reset(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <Section title="Receipt text">
          {TEXT_FIELDS.map((f) => (
            <FormField
              key={f.name}
              control={form.control}
              name={f.name}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{f.label}</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      maxLength={SETTINGS_LIMITS[f.name]}
                      placeholder={f.placeholder}
                      {...field}
                    />
                  </FormControl>
                  <div className="flex justify-between gap-4">
                    <FormDescription>{f.hint}</FormDescription>
                    <span className="shrink-0 text-xs text-muted-foreground tabular-nums">
                      {field.value.length} / {SETTINGS_LIMITS[f.name]}
                    </span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
        </Section>

        <Section title="Show on receipt">
          {TOGGLES.map((t) => (
            <FormField
              key={t.name}
              control={form.control}
              name={t.name}
              render={({ field }) => (
                <FormItem className="flex items-center justify-between gap-4">
                  <div className="space-y-0.5">
                    <FormLabel>{t.label}</FormLabel>
                    <FormDescription>{t.hint}</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} className="cursor-pointer" />
                  </FormControl>
                </FormItem>
              )}
            />
          ))}
        </Section>

        <SaveBar disabled={!form.formState.isDirty} saving={form.formState.isSubmitting} />
      </form>
    </Form>
  );
}
