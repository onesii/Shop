import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { StoreSettings } from "@/convex/settings.ts";
import { Input } from "@/components/ui/input.tsx";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import {
  SaveBar,
  Section,
  SettingsSubPage,
  useSaveSettings,
} from "../_components/settings-sub-page.tsx";
import { generalSchema, type GeneralForm } from "../_lib/settings-form.ts";

export default function GeneralSettingsPage() {
  return <SettingsSubPage title="General">{(s) => <GeneralFormView initial={s} />}</SettingsSubPage>;
}

function GeneralFormView({ initial }: { initial: StoreSettings }) {
  const save = useSaveSettings(initial);
  const form = useForm<GeneralForm>({
    resolver: zodResolver(generalSchema),
    defaultValues: {
      storeName: initial.storeName,
      posName: initial.posName,
    },
  });

  const onSubmit = async (values: GeneralForm) => {
    if (await save(values)) form.reset(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <Section title="Store">
          <FormField
            control={form.control}
            name="storeName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Store name</FormLabel>
                <FormControl><Input placeholder="Mama Njeri's Kitchen" maxLength={60} {...field} /></FormControl>
                <FormDescription>Printed at the top of every receipt.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="posName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>POS name</FormLabel>
                <FormControl><Input placeholder="POS 1" maxLength={30} {...field} /></FormControl>
                <FormDescription>Identifies this till on receipts and in the menu.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </Section>

        <SaveBar disabled={!form.formState.isDirty} saving={form.formState.isSubmitting} />
      </form>
    </Form>
  );
}
