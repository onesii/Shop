import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Users } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import ReportShell from "../_components/report-shell.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { useEmployeeOptions, useOwnerName } from "../_components/employee-filter.tsx";
import { reportFilename, useReportFilters } from "../_lib/filters.ts";
import { rangeToIso, totals } from "../_lib/summary.ts";
import { money } from "../_lib/columns.ts";

type Row = {
  key: string;
  name: string;
  grossSalesCents: number;
  refundsCents: number;
  discountsCents: number;
  netSalesCents: number;
  receipts: number;
  averageSaleCents: number;
};

const COLUMNS: Column<Row>[] = [
  {
    key: "name",
    label: "Name",
    fixed: true,
    render: (r) => <span className="font-medium">{r.name}</span>,
    csv: (r) => r.name,
  },
  money<Row>("gross", "Gross sales", (r) => r.grossSalesCents),
  money<Row>("refunds", "Refunds", (r) => r.refundsCents),
  money<Row>("discounts", "Discounts", (r) => r.discountsCents),
  money<Row>("net", "Net sales", (r) => r.netSalesCents),
  { key: "receipts", label: "Receipts", numeric: true, render: (r) => r.receipts, csv: (r) => r.receipts },
  money<Row>("average", "Average sale", (r) => r.averageSaleCents),
];

/** One row per employee who made sales in the period. */
export default function SalesByEmployeePage() {
  const { range, hourWindow, employeeIds } = useReportFilters();
  const ownerName = useOwnerName();
  const employees = useEmployeeOptions();
  const args = useMemo(() => ({ ...rangeToIso(range), ...(employeeIds ? { employeeIds } : {}) }), [range, employeeIds]);
  const hours = useQuery(api.reports.salesSummary.hourly, args);

  const rows = useMemo<Row[] | undefined>(() => {
    if (!hours || !employees) return undefined;
    const ownerRow = employees.find((e) => e.role === "owner");
    // Buckets without an employee belong to the owner
    const nameOf = (id: string | null) =>
      id === null ? (ownerRow?.name ?? ownerName) : (employees.find((e) => e._id === id)?.name ?? "Removed employee");
    const groups = new Map<string, typeof hours>();
    for (const h of hours) {
      const key = h.employeeId ?? "owner";
      groups.set(key, [...(groups.get(key) ?? []), h]);
    }
    return [...groups.entries()]
      .map(([key, list]) => {
        const m = totals(list, hourWindow);
        const receipts = list
          .filter((h) => {
            const hour = new Date(h.hour).getHours();
            return hour >= hourWindow.start && hour < hourWindow.end;
          })
          .reduce((s, h) => s + h.salesCount, 0);
        return {
          key,
          name: nameOf(key === "owner" ? null : key),
          ...m,
          receipts,
          averageSaleCents: receipts === 0 ? 0 : Math.round(m.netSalesCents / receipts),
        };
      })
      .filter((r) => r.receipts > 0 || r.refundsCents > 0)
      .sort((a, b) => b.netSalesCents - a.netSalesCents);
  }, [hours, employees, hourWindow, ownerName]);

  return (
    <ReportShell>
      <ReportTable
        columns={COLUMNS}
        rows={rows}
        rowKey={(r) => r.key}
        filename={reportFilename("sales-by-employee", range)}
        empty={{ icon: Users, title: "No sales", description: "No sales were made in this period." }}
      />
    </ReportShell>
  );
}
