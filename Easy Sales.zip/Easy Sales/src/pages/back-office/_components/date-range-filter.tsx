import { useState } from "react";
import { format, startOfDay, startOfMonth, startOfWeek, endOfMonth, endOfWeek, subDays, subMonths, subWeeks } from "date-fns";
import { CalendarDays, ChevronLeft, ChevronRight } from "lucide-react";
import type { DateRange as DayPickerRange } from "react-day-picker";
import { Calendar } from "@/components/ui/calendar.tsx";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover.tsx";
import { Button } from "@/components/ui/button.tsx";
import { cn } from "@/lib/utils.ts";
import { shiftRange, type DateRange } from "../_lib/summary.ts";

const WEEK = { weekStartsOn: 1 } as const;

function presets(today: Date): { label: string; range: DateRange }[] {
  const t = startOfDay(today);
  return [
    { label: "Today", range: { from: t, to: t } },
    { label: "Yesterday", range: { from: subDays(t, 1), to: subDays(t, 1) } },
    { label: "This week", range: { from: startOfWeek(t, WEEK), to: t } },
    {
      label: "Last week",
      range: { from: startOfWeek(subWeeks(t, 1), WEEK), to: startOfDay(endOfWeek(subWeeks(t, 1), WEEK)) },
    },
    { label: "This month", range: { from: startOfMonth(t), to: t } },
    {
      label: "Last month",
      range: { from: startOfMonth(subMonths(t, 1)), to: startOfDay(endOfMonth(subMonths(t, 1))) },
    },
    { label: "Last 7 days", range: { from: subDays(t, 6), to: t } },
    { label: "Last 30 days", range: { from: subDays(t, 29), to: t } },
  ];
}

const MAX_DAYS = 366;

type Props = { value: DateRange; onChange: (r: DateRange) => void };

export default function DateRangeFilter({ value, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<DayPickerRange | undefined>(value);
  const today = startOfDay(new Date());
  const next = shiftRange(value, 1);
  const canGoNext = next.from <= today;

  const apply = (r: DateRange) => {
    onChange(r);
    setOpen(false);
  };

  const label =
    value.from.getTime() === value.to.getTime()
      ? format(value.from, "MMM d, yyyy")
      : `${format(value.from, "MMM d, yyyy")} - ${format(value.to, "MMM d, yyyy")}`;

  return (
    <div className="flex h-11 items-stretch overflow-hidden rounded-sm border bg-card shadow-xs">
      <button
        type="button"
        aria-label="Previous period"
        onClick={() => onChange(shiftRange(value, -1))}
        className="flex w-10 cursor-pointer items-center justify-center text-muted-foreground transition-colors hover:bg-muted"
      >
        <ChevronLeft className="size-4" />
      </button>
      <Popover
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (o) setDraft(value);
        }}
      >
        <PopoverTrigger className="flex cursor-pointer items-center gap-3 border-x px-4 text-sm font-medium transition-colors hover:bg-muted">
          <CalendarDays className="size-4 text-muted-foreground" />
          <span className="whitespace-nowrap">{label}</span>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-auto p-0">
          <div className="flex flex-col sm:flex-row">
            <div className="grid grid-cols-2 gap-1 border-b p-2 sm:flex sm:w-36 sm:flex-col sm:border-b-0 sm:border-r">
              {presets(today).map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => apply(p.range)}
                  className="cursor-pointer rounded-sm px-3 py-1.5 text-left text-sm transition-colors hover:bg-muted"
                >
                  {p.label}
                </button>
              ))}
            </div>
            <div>
              <Calendar
                mode="range"
                numberOfMonths={1}
                selected={draft}
                onSelect={setDraft}
                defaultMonth={value.to}
                disabled={{ after: today }}
                weekStartsOn={1}
              />
              <div className="flex justify-end gap-2 border-t p-2">
                <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button
                  size="sm"
                  disabled={!draft?.from}
                  onClick={() => {
                    if (!draft?.from) return;
                    const to = draft.to ?? draft.from;
                    const days = (to.getTime() - draft.from.getTime()) / 86_400_000 + 1;
                    if (days > MAX_DAYS) return;
                    apply({ from: startOfDay(draft.from), to: startOfDay(to) });
                  }}
                >
                  Done
                </Button>
              </div>
            </div>
          </div>
        </PopoverContent>
      </Popover>
      <button
        type="button"
        aria-label="Next period"
        disabled={!canGoNext}
        onClick={() => onChange(next)}
        className={cn(
          "flex w-10 items-center justify-center text-muted-foreground transition-colors",
          canGoNext ? "cursor-pointer hover:bg-muted" : "opacity-40",
        )}
      >
        <ChevronRight className="size-4" />
      </button>
    </div>
  );
}
