import { useState, type ReactNode } from "react";
import { Columns3, type LucideIcon } from "lucide-react";
import { downloadCsv } from "@/lib/csv.ts";
import { cn } from "@/lib/utils.ts";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";

export type Column<T> = {
  key: string;
  label: string;
  numeric?: boolean;
  /** Can't be hidden with the column picker */
  fixed?: boolean;
  render: (row: T) => ReactNode;
  /** Value written to the CSV */
  csv: (row: T) => string | number;
};

type Props<T> = {
  columns: Column<T>[];
  rows: T[] | undefined;
  rowKey: (row: T) => string;
  filename: string;
  empty: { icon: LucideIcon; title: string; description: string };
  /** Optional totals row; receives the visible columns */
  footer?: Record<string, ReactNode>;
  notice?: ReactNode;
  after?: ReactNode;
  onRowClick?: (row: T) => void;
  /** Custom export, e.g. when the table only holds the loaded pages */
  onExport?: () => void;
};

/** Report table with EXPORT (CSV of the visible columns) and a column picker. */
export default function ReportTable<T>({
  columns,
  rows,
  rowKey,
  filename,
  empty,
  footer,
  notice,
  after,
  onRowClick,
  onExport,
}: Props<T>) {
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const visible = columns.filter((c) => !hidden.has(c.key));
  const optional = columns.filter((c) => !c.fixed);

  const toggle = (key: string, on: boolean) => {
    const next = new Set(hidden);
    if (on) next.delete(key);
    else next.add(key);
    setHidden(next);
  };

  const exportCsv = () => {
    if (onExport) return onExport();
    if (!rows) return;
    downloadCsv(
      filename,
      rows.map((r) => Object.fromEntries(visible.map((c) => [c.label, c.csv(r)]))),
    );
  };

  const EmptyIcon = empty.icon;

  return (
    <section className="overflow-hidden rounded-sm border bg-card shadow-xs">
      <div className="flex items-center justify-between border-b px-4 py-2">
        <button
          type="button"
          onClick={exportCsv}
          disabled={!rows || rows.length === 0}
          className="cursor-pointer rounded-sm px-2 py-2 text-sm font-semibold uppercase tracking-wide transition-colors hover:bg-muted disabled:cursor-default disabled:opacity-40 disabled:hover:bg-transparent"
        >
          Export
        </button>
        {optional.length > 0 && (
          <DropdownMenu>
            <DropdownMenuTrigger
              aria-label="Choose columns"
              className="flex size-10 cursor-pointer items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted"
            >
              <Columns3 className="size-5" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Columns</DropdownMenuLabel>
              {optional.map((c) => (
                <DropdownMenuCheckboxItem
                  key={c.key}
                  checked={!hidden.has(c.key)}
                  onCheckedChange={(on) => toggle(c.key, on === true)}
                  onSelect={(e) => e.preventDefault()}
                >
                  {c.label}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
      {notice}
      {rows === undefined ? (
        <div className="space-y-2 p-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <Empty className="py-16">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <EmptyIcon />
            </EmptyMedia>
            <EmptyTitle>{empty.title}</EmptyTitle>
            <EmptyDescription>{empty.description}</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              {visible.map((c) => (
                <TableHead key={c.key} className={cn("px-4", c.numeric && "text-right")}>
                  {c.label}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow
                key={rowKey(r)}
                onClick={onRowClick ? () => onRowClick(r) : undefined}
                className={cn(onRowClick && "cursor-pointer")}
              >
                {visible.map((c) => (
                  <TableCell
                    key={c.key}
                    className={cn("whitespace-nowrap px-4 py-4", c.numeric && "text-right tabular-nums")}
                  >
                    {c.render(r)}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
          {footer && (
            <TableFooter>
              <TableRow>
                {visible.map((c) => (
                  <TableCell
                    key={c.key}
                    className={cn("whitespace-nowrap px-4 py-4 font-semibold", c.numeric && "text-right tabular-nums")}
                  >
                    {footer[c.key] ?? ""}
                  </TableCell>
                ))}
              </TableRow>
            </TableFooter>
          )}
        </Table>
      )}
      {after}
    </section>
  );
}
