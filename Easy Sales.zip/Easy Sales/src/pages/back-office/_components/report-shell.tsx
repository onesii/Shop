import { useReportFilters } from "../_lib/filters.ts";
import DateRangeFilter from "./date-range-filter.tsx";
import HourFilter from "./hour-filter.tsx";
import EmployeeFilter from "./employee-filter.tsx";

type Props = {
  /** List reports (receipts, shifts) only filter by date. */
  showHours?: boolean;
  children: React.ReactNode;
};

/** Page container with the shared report filters on top. */
export default function ReportShell({ showHours = true, children }: Props) {
  const { range, setRange, hourWindow, setHourWindow } = useReportFilters();
  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <div className="flex flex-wrap gap-3">
        <DateRangeFilter value={range} onChange={setRange} />
        {showHours && <HourFilter value={hourWindow} onChange={setHourWindow} />}
        <EmployeeFilter />
      </div>
      {children}
    </div>
  );
}
