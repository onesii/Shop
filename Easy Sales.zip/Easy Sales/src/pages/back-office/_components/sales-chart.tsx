import { Area, AreaChart, Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { format } from "date-fns";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart.tsx";
import { formatKsh } from "@/lib/money.ts";
import type { Bucket, Granularity, MetricKey } from "../_lib/summary.ts";

export type ChartType = "area" | "bar";

type Props = {
  buckets: Bucket[];
  metric: MetricKey;
  label: string;
  type: ChartType;
  granularity: Granularity;
};

function tickLabel(start: Date, g: Granularity): string {
  if (g === "months") return format(start, "MMM yy");
  return format(start, "MMM dd");
}

export default function SalesChart({ buckets, metric, label, type, granularity }: Props) {
  const config = { value: { label, color: "var(--chart-1)" } } satisfies ChartConfig;
  const data = buckets.map((b) => ({ tick: tickLabel(b.start, granularity), label: b.label, value: b[metric] }));
  const axes = (
    <>
      <CartesianGrid vertical={false} />
      <XAxis
        dataKey="tick"
        tickLine={false}
        axisLine={false}
        angle={-45}
        textAnchor="end"
        height={56}
        interval="preserveStartEnd"
        minTickGap={8}
      />
      <YAxis
        tickLine={false}
        axisLine={false}
        width={96}
        allowDecimals={false}
        domain={[0, (max: number) => Math.max(max, 100000)]}
        tickFormatter={(v: number) => formatKsh(v)}
      />
      <ChartTooltip
        content={
          <ChartTooltipContent
            labelFormatter={(_, payload) => {
              const first = payload?.[0]?.payload as { label?: string } | undefined;
              return first?.label ?? "";
            }}
            formatter={(value) => (
              <div className="flex w-full justify-between gap-4">
                <span className="text-muted-foreground">{label}</span>
                <span className="font-medium tabular-nums">{formatKsh(Number(value))}</span>
              </div>
            )}
          />
        }
      />
    </>
  );

  return (
    <ChartContainer config={config} className="aspect-auto h-72 w-full">
      {type === "area" ? (
        <AreaChart data={data} margin={{ left: 0, right: 12, top: 12 }}>
          {axes}
          <Area
            dataKey="value"
            type="linear"
            stroke="var(--color-value)"
            strokeWidth={2}
            fill="var(--color-value)"
            fillOpacity={0.15}
            dot={{ r: 3, fill: "var(--background)", strokeWidth: 1.5 }}
            activeDot={{ r: 5 }}
          />
        </AreaChart>
      ) : (
        <BarChart data={data} margin={{ left: 0, right: 12, top: 12 }}>
          {axes}
          <Bar dataKey="value" fill="var(--color-value)" radius={[3, 3, 0, 0]} />
        </BarChart>
      )}
    </ChartContainer>
  );
}
