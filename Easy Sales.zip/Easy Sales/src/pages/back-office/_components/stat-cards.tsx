import { cn } from "@/lib/utils.ts";

export type StatCard = { label: string; value: string; tone?: "default" | "bad" };

/** Row of headline numbers above a report table. */
export default function StatCards({ cards }: { cards: StatCard[] }) {
  return (
    <div className="grid grid-cols-2 overflow-hidden rounded-sm border bg-card shadow-xs lg:grid-cols-4">
      {cards.map((c) => (
        <div key={c.label} className="min-w-0 border-b px-4 py-4 md:px-6 lg:border-b-0 lg:border-r lg:last:border-r-0">
          <p className="truncate text-sm text-muted-foreground">{c.label}</p>
          <p
            className={cn(
              "truncate pt-1 text-lg font-medium tabular-nums md:text-2xl",
              c.tone === "bad" && "text-destructive",
            )}
          >
            {c.value}
          </p>
        </div>
      ))}
    </div>
  );
}
