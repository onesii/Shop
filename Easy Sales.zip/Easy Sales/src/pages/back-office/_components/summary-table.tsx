import { useState } from "react";
import { Columns3 } from "lucide-react";
import { formatKsh } from "@/lib/money.ts";
import { downloadCsv } from "@/lib/csv.ts";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table.tsx";
import { METRIC_KEYS, METRIC_LABELS, type Bucket, type MetricKey } from "../_lib/summary.ts";

type Props = { buckets: Bucket[]; filename: string };

export default function SummaryTable({ buckets, filename }: Props) {
  const [visible, setVisible] = useState<Set<MetricKey>>(new Set(METRIC_KEYS));
  const columns = METRIC_KEYS.filter((k) => visible.has(k));
  const rows = [...buckets].reverse(); // newest first

  const toggle = (key: MetricKey, on: boolean) => {
    const next = new Set(visible);
    if (on) next.add(key);
    else if (next.size > 1) next.delete(key);
    setVisible(next);
  };

  const exportCsv = () =>
    downloadCsv(
      filename,
      rows.map((b) => {
        const record: Record<string, string | number> = { Date: b.label };
        for (const k of columns) record[METRIC_LABELS[k]] = (b[k] / 100).toFixed(2);
        return record;
      }),
    );

  return (
    <section className="overflow-hidden rounded-sm border bg-card shadow-xs">
      <div className="flex items-center justify-between border-b px-4 py-2">
        <button
          type="button"
          onClick={exportCsv}
          className="cursor-pointer rounded-sm px-2 py-2 text-sm font-semibold uppercase tracking-wide transition-colors hover:bg-muted"
        >
          Export
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger
            aria-label="Choose columns"
            className="flex size-10 cursor-pointer items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted"
          >
            <Columns3 className="size-5" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel>Columns</DropdownMenuLabel>
            {METRIC_KEYS.map((k) => (
              <DropdownMenuCheckboxItem
                key={k}
                checked={visible.has(k)}
                onCheckedChange={(c) => toggle(k, c === true)}
                onSelect={(e) => e.preventDefault()}
              >
                {METRIC_LABELS[k]}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="px-4">Date</TableHead>
            {columns.map((k) => (
              <TableHead key={k} className="px-4 text-right">
                {METRIC_LABELS[k]}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((b) => (
            <TableRow key={b.key}>
              <TableCell className="whitespace-nowrap px-4 py-4">{b.label}</TableCell>
              {columns.map((k) => (
                <TableCell key={k} className="whitespace-nowrap px-4 py-4 text-right tabular-nums">
                  {formatKsh(b[k])}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </section>
  );
}
