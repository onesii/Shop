import { useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { toast } from "sonner";
import {
  BarChart3,
  ChevronDown,
  CircleHelp,
  Contact,
  Menu,
  Puzzle,
  Settings,
  ShoppingBasket,
  Store,
  Truck,
  Users,
  type LucideIcon,
} from "lucide-react";
import { useAuth, useUser } from "@/hooks/use-auth.ts";
import { cn } from "@/lib/utils.ts";
import { Sheet, SheetContent, SheetDescription, SheetTitle } from "@/components/ui/sheet.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar.tsx";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible.tsx";
import { ALL_DAY, defaultRange, type DateRange, type HourWindow } from "../_lib/summary.ts";
import type { EmployeeSelection, ReportFilters } from "../_lib/filters.ts";
import type { Permission } from "@/convex/lib/access.ts";
import { useStaff } from "@/hooks/use-staff.tsx";
import RequirePermission from "@/components/staff/require-permission.tsx";

type Can = (p: Permission) => boolean;
type SubEntry = { label: string; to?: string };
type Section = {
  label: string;
  icon: LucideIcon;
  to?: string;
  children?: SubEntry[];
  /** Hidden from employees without access */
  allowed?: (can: Can) => boolean;
};

// Mirrors the Loyverse back office menu; entries without `to` are not built yet
const SECTIONS: Section[] = [
  {
    label: "Reports",
    icon: BarChart3,
    allowed: (can) => can("reports"),
    children: [
      { label: "Sales summary", to: "/back-office" },
      { label: "Sales by item", to: "/back-office/sales-by-item" },
      { label: "Sales by category", to: "/back-office/sales-by-category" },
      { label: "Sales by employee", to: "/back-office/sales-by-employee" },
      { label: "Sales by payment type", to: "/back-office/sales-by-payment-type" },
      { label: "Receipts", to: "/back-office/receipts" },
      { label: "Discounts", to: "/back-office/discounts" },
      { label: "Shifts", to: "/back-office/shifts" },
    ],
  },
  {
    label: "Items",
    icon: ShoppingBasket,
    allowed: (can) => can("items"),
    children: [
      { label: "Item list", to: "/items/list" },
      { label: "Categories", to: "/items/categories" },
      { label: "Discounts", to: "/items/discounts" },
    ],
  },
  {
    label: "Inventory management",
    icon: Truck,
    allowed: (can) => can("items"),
    children: [
      { label: "Stock levels", to: "/back-office/inventory" },
      { label: "Purchase orders", to: "/back-office/purchase-orders" },
      { label: "Transfer orders" },
      { label: "Stock adjustments", to: "/back-office/inventory" },
      { label: "Inventory counts", to: "/back-office/inventory-counts" },
      { label: "Suppliers", to: "/back-office/suppliers" },
      { label: "Inventory history", to: "/back-office/inventory-history" },
      { label: "Inventory valuation", to: "/back-office/inventory-valuation" },
    ],
  },
  {
    label: "Employees",
    icon: Contact,
    allowed: (can) => can("employees"),
    children: [
      { label: "Employee list", to: "/back-office/employees" },
      { label: "Access rights", to: "/back-office/access-rights" },
      { label: "Timecards", to: "/back-office/timecards" },
      { label: "Total hours worked", to: "/back-office/hours-worked" },
    ],
  },
  { label: "Customers", icon: Users, to: "/back-office/customers", allowed: (can) => can("customers") },
  { label: "Integrations", icon: Puzzle },
  { label: "Settings", icon: Settings, to: "/settings", allowed: (can) => can("settings") },
  { label: "Help", icon: CircleHelp },
];

const comingSoon = () => toast("Coming soon in a future milestone!");

function initials(name: string): string {
  return name
    .split(/[\s@.]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

function AccountMenu({ compact }: { compact?: boolean }) {
  const user = useUser();
  const { signout } = useAuth();
  const profile = user?.profile;
  const label = profile?.email ?? profile?.name ?? "Account";
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className={cn(
          "flex w-full cursor-pointer items-center gap-3 px-4 py-4 text-left transition-colors hover:bg-muted",
          compact && "justify-center px-0",
        )}
        aria-label="Account menu"
      >
        <Avatar className="size-9">
          {typeof profile?.avatar === "string" && <AvatarImage src={profile.avatar} alt="" />}
          <AvatarFallback className="bg-muted-foreground/70 text-xs text-background">
            {initials(label)}
          </AvatarFallback>
        </Avatar>
        {!compact && (
          <>
            <span className="min-w-0 flex-1 truncate text-sm font-medium">{label}</span>
            <ChevronDown className="size-4 text-muted-foreground" />
          </>
        )}
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-56">
        <DropdownMenuItem onClick={comingSoon}>Account</DropdownMenuItem>
        <DropdownMenuItem onClick={() => void signout()}>Sign out</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

const rowClass =
  "flex w-full cursor-pointer items-center gap-6 px-5 py-3 text-sm font-medium transition-colors hover:bg-muted";

function SubLink({ entry, onNavigate }: { entry: SubEntry; onNavigate: () => void }) {
  const cls = "block w-full cursor-pointer py-2.5 pl-16 pr-4 text-left text-sm transition-colors hover:bg-muted";
  if (!entry.to) {
    return (
      <button type="button" className={cn(cls, "text-foreground/80")} onClick={comingSoon}>
        {entry.label}
      </button>
    );
  }
  return (
    <NavLink
      to={entry.to}
      end
      onClick={onNavigate}
      className={({ isActive }) =>
        cn(cls, isActive ? "font-semibold text-primary" : "text-foreground/80")
      }
    >
      {entry.label}
    </NavLink>
  );
}

function SectionRow({ section, onNavigate }: { section: Section; onNavigate: () => void }) {
  const { pathname } = useLocation();
  const containsActive = section.children?.some((c) => c.to === pathname) ?? false;
  const [open, setOpen] = useState(containsActive);
  const Icon = section.icon;

  if (!section.children) {
    if (section.to) {
      return (
        <NavLink to={section.to} onClick={onNavigate} className={rowClass}>
          <Icon className="size-5 text-muted-foreground" />
          {section.label}
        </NavLink>
      );
    }
    return (
      <button type="button" className={rowClass} onClick={comingSoon}>
        <Icon className="size-5 text-muted-foreground" />
        {section.label}
      </button>
    );
  }
  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <CollapsibleTrigger className={cn(rowClass, containsActive && "text-primary")}>
        <Icon className={cn("size-5", containsActive ? "text-primary" : "text-muted-foreground")} />
        <span className="flex-1 text-left">{section.label}</span>
        <ChevronDown
          className={cn("size-4 text-muted-foreground transition-transform", open && "rotate-180")}
        />
      </CollapsibleTrigger>
      <CollapsibleContent>
        {section.children.map((c) => (
          <SubLink key={c.label} entry={c} onNavigate={onNavigate} />
        ))}
      </CollapsibleContent>
    </Collapsible>
  );
}

function useSections(): Section[] {
  const { can } = useStaff();
  return SECTIONS.filter((s) => !s.allowed || s.allowed(can));
}

function FullMenu({ onNavigate }: { onNavigate: () => void }) {
  const sections = useSections();
  return (
    <div className="flex h-full flex-col bg-card">
      <AccountMenu />
      <nav className="flex-1 overflow-y-auto border-t py-2">
        {sections.map((s) => (
          <SectionRow key={s.label} section={s} onNavigate={onNavigate} />
        ))}
      </nav>
      <NavLink
        to="/"
        onClick={onNavigate}
        className="flex items-center gap-6 border-t px-5 py-4 text-sm font-medium text-primary transition-colors hover:bg-muted"
      >
        <Store className="size-5" />
        Back to POS
      </NavLink>
    </div>
  );
}

/** Icon-only rail for tablet/desktop, like the Loyverse dashboard. */
function Rail({ onExpand }: { onExpand: () => void }) {
  const { pathname } = useLocation();
  const sections = useSections();
  return (
    <aside className="hidden w-[72px] shrink-0 flex-col border-r bg-card md:flex">
      <AccountMenu compact />
      <nav className="flex flex-1 flex-col border-t">
        {sections.map((s) => {
          const Icon = s.icon;
          const active = s.to === pathname || (s.children?.some((c) => c.to === pathname) ?? false);
          return (
            <button
              key={s.label}
              type="button"
              title={s.label}
              aria-label={s.label}
              onClick={onExpand}
              className={cn(
                "relative flex h-14 cursor-pointer items-center justify-center transition-colors hover:bg-muted",
                active && "bg-muted",
              )}
            >
              {active && <span className="absolute inset-y-0 left-0 w-1 bg-primary" />}
              <Icon className={cn("size-6", active ? "text-primary" : "text-muted-foreground")} />
            </button>
          );
        })}
      </nav>
    </aside>
  );
}

const TITLES: Record<string, string> = {
  "/back-office/purchase-orders": "Purchase orders",
  "/back-office/purchase-orders/new": "Create purchase order",
  "/back-office/suppliers": "Suppliers",
  "/back-office/inventory-counts": "Inventory counts",
  "/back-office/inventory-counts/new": "Create inventory count",
  "/back-office/inventory-history": "Inventory history",
  "/back-office/inventory-valuation": "Inventory valuation",
  "/back-office": "Sales summary",
  "/back-office/sales-by-item": "Sales by item",
  "/back-office/sales-by-category": "Sales by category",
  "/back-office/sales-by-employee": "Sales by employee",
  "/back-office/sales-by-payment-type": "Sales by payment type",
  "/back-office/receipts": "Receipts",
  "/back-office/discounts": "Discounts",
  "/back-office/shifts": "Shifts",
  "/back-office/customers": "Customers",
  "/back-office/inventory": "Inventory management",
  "/back-office/employees": "Employee list",
  "/back-office/access-rights": "Access rights",
  "/back-office/timecards": "Timecards",
  "/back-office/hours-worked": "Total hours worked",
};

// What each back office page needs; pages not listed need "reports"
const PAGE_ACCESS: Record<string, (can: Can) => boolean> = {
  "/back-office/inventory": (can) => can("items"),
  "/back-office/purchase-orders": (can) => can("items"),
  "/back-office/suppliers": (can) => can("items"),
  "/back-office/inventory-counts": (can) => can("items"),
  "/back-office/inventory-history": (can) => can("items"),
  "/back-office/inventory-valuation": (can) => can("items"),
  "/back-office/customers": (can) => can("customers"),
  "/back-office/employees": (can) => can("employees"),
  "/back-office/access-rights": (can) => can("employees"),
  "/back-office/timecards": (can) => can("employees"),
  "/back-office/hours-worked": (can) => can("employees"),
};

// Detail pages (/:id) of inventory screens; all need "items"
const DETAIL_PAGES = [
  { prefix: "/back-office/purchase-orders/", title: "Purchase order" },
  { prefix: "/back-office/inventory-counts/", title: "Inventory count" },
];

export default function BackOfficeLayout() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  // Filters live here so they stay put when switching between reports
  const [range, setRange] = useState<DateRange>(() => defaultRange());
  const [hourWindow, setHourWindow] = useState<HourWindow>(ALL_DAY);
  const [employeeIds, setEmployeeIds] = useState<EmployeeSelection>(undefined);
  const filters: ReportFilters = { range, setRange, hourWindow, setHourWindow, employeeIds, setEmployeeIds };
  const detail = DETAIL_PAGES.find((d) => pathname.startsWith(d.prefix));
  const access = PAGE_ACCESS[pathname] ?? (detail ? (can: Can) => can("items") : (can: Can) => can("reports"));
  const title = TITLES[pathname] ?? detail?.title ?? "Back office";
  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="sticky top-0 z-30 flex h-14 shrink-0 items-center gap-2 bg-secondary px-2 text-secondary-foreground shadow-md">
        <button
          type="button"
          aria-label="Open menu"
          onClick={() => setOpen(true)}
          className="flex size-10 cursor-pointer items-center justify-center rounded-full transition hover:bg-white/10"
        >
          <Menu className="size-6" />
        </button>
        <h1 className="truncate pl-2 text-lg font-semibold">{title}</h1>
      </header>
      <div className="flex min-h-0 flex-1">
        <Rail onExpand={() => setOpen(true)} />
        <main className="min-h-0 flex-1 overflow-y-auto bg-muted/60">
          <RequirePermission permission={access}>
            <Outlet context={filters} />
          </RequirePermission>
        </main>
      </div>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="w-[85vw] max-w-80 gap-0 p-0 [&>button]:hidden">
          <SheetTitle className="sr-only">Back office menu</SheetTitle>
          <SheetDescription className="sr-only">Back office navigation</SheetDescription>
          <FullMenu onNavigate={() => setOpen(false)} />
        </SheetContent>
      </Sheet>
    </div>
  );
}
