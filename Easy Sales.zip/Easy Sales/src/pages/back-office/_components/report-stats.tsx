/** Small summary cards shown above some report tables. */
export function StatCards({ stats }: { stats: { label: string; value: string }[] }) {
  return (
    <div className="grid grid-cols-2 overflow-hidden rounded-sm border bg-card shadow-xs lg:grid-cols-4">
      {stats.map((s) => (
        <div key={s.label} className="min-w-0 border-b px-4 py-4 last:border-b-0 md:px-6 md:py-5 lg:border-b-0">
          <p className="text-sm text-muted-foreground">{s.label}</p>
          <p className="truncate pt-1 text-lg font-medium tabular-nums md:text-2xl">{s.value}</p>
        </div>
      ))}
    </div>
  );
}

export function TruncatedNotice({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <p className="border-b bg-muted/60 px-4 py-2 text-sm text-muted-foreground">
      This range has a lot of sales, so only part of it is shown. Pick a shorter range for full totals.
    </p>
  );
}
