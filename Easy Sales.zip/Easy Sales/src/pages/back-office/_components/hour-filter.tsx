import { useState } from "react";
import { ChevronDown, Clock } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { ALL_DAY, type HourWindow } from "../_lib/summary.ts";

function hourLabel(h: number): string {
  if (h === 0 || h === 24) return "12:00 AM";
  if (h === 12) return "12:00 PM";
  return h < 12 ? `${h}:00 AM` : `${h - 12}:00 PM`;
}

const HOURS = Array.from({ length: 25 }, (_, h) => h);

type Props = { value: HourWindow; onChange: (w: HourWindow) => void };

/** "All day" or a custom hour window, applied to every day in the range. */
export default function HourFilter({ value, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(value);
  const isAllDay = value.start === 0 && value.end === 24;
  const draftAllDay = draft.start === 0 && draft.end === 24;

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (o) setDraft(value);
      }}
    >
      <PopoverTrigger className="flex h-11 cursor-pointer items-center gap-3 rounded-sm border bg-card px-4 text-sm font-medium shadow-xs transition-colors hover:bg-muted">
        <Clock className="size-4 text-muted-foreground" />
        {isAllDay ? "All day" : `${hourLabel(value.start)} - ${hourLabel(value.end)}`}
        <ChevronDown className="size-4 text-muted-foreground" />
      </PopoverTrigger>
      <PopoverContent align="start" className="w-72 space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="all-day">All day</Label>
          <Switch
            id="all-day"
            checked={draftAllDay}
            onCheckedChange={(c) => setDraft(c ? ALL_DAY : { start: 8, end: 17 })}
          />
        </div>
        {!draftAllDay && (
          <div className="grid grid-cols-2 gap-3">
            {(["start", "end"] as const).map((key) => (
              <div key={key} className="grid gap-1.5">
                <Label className="text-xs text-muted-foreground">{key === "start" ? "Start" : "End"}</Label>
                <Select
                  value={String(draft[key])}
                  onValueChange={(v) => setDraft({ ...draft, [key]: Number(v) })}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {HOURS.filter((h) => (key === "start" ? h < 24 : h > 0)).map((h) => (
                      <SelectItem key={h} value={String(h)}>
                        {hourLabel(h)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>
        )}
        {draft.start >= draft.end && (
          <p className="text-sm text-destructive">End time must be after start time</p>
        )}
        <div className="flex justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button
            size="sm"
            disabled={draft.start >= draft.end}
            onClick={() => {
              onChange(draft);
              setOpen(false);
            }}
          >
            Done
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
