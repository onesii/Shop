import { cn } from "@/lib/utils.ts";
import { formatKsh } from "@/lib/money.ts";
import {
  change,
  METRIC_KEYS,
  METRIC_LABELS,
  type MetricKey,
  type Metrics,
} from "../_lib/summary.ts";

// For these, a rise is bad news, so it shows in red
const HIGHER_IS_WORSE: ReadonlySet<MetricKey> = new Set(["refundsCents", "discountsCents"]);

function ChangeLine({ metric, current, previous }: { metric: MetricKey; current: number; previous: number }) {
  const { cents, percent } = change(current, previous);
  const sign = cents > 0 ? "+" : cents < 0 ? "-" : "";
  const bad = HIGHER_IS_WORSE.has(metric) ? cents > 0 : cents < 0;
  const pct = percent === null ? "" : ` (${sign}${Math.abs(percent).toFixed(2)}%)`;
  return (
    <p
      className={cn(
        "truncate pt-1 text-xs tabular-nums",
        cents === 0 ? "text-muted-foreground" : bad ? "text-destructive" : "text-primary",
      )}
    >
      {sign}
      {formatKsh(Math.abs(cents))}
      {percent === null && cents === 0 ? " (0%)" : pct}
    </p>
  );
}

type Props = {
  current: Metrics;
  previous: Metrics;
  selected: MetricKey;
  onSelect: (m: MetricKey) => void;
};

export default function KpiTabs({ current, previous, selected, onSelect }: Props) {
  return (
    <div className="grid grid-cols-2 border-b lg:grid-cols-4" role="tablist">
      {METRIC_KEYS.map((key) => {
        const active = key === selected;
        return (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onSelect(key)}
            className="relative min-w-0 cursor-pointer px-4 py-4 text-left transition-colors hover:bg-muted/60 md:px-6 md:py-5"
          >
            <p className="text-sm text-muted-foreground">{METRIC_LABELS[key]}</p>
            <p className="truncate pt-1 text-lg font-medium tabular-nums md:text-2xl">{formatKsh(current[key])}</p>
            <ChangeLine metric={key} current={current[key]} previous={previous[key]} />
            <span
              className={cn(
                "absolute inset-x-0 bottom-0 h-1 transition-colors",
                active ? "bg-primary" : "bg-transparent",
              )}
            />
          </button>
        );
      })}
    </div>
  );
}
