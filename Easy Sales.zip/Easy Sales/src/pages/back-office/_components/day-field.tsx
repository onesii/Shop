import { useState } from "react";
import { format, parseISO } from "date-fns";
import { CalendarDays, X } from "lucide-react";
import { Calendar } from "@/components/ui/calendar.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover.tsx";

type Props = {
  id: string;
  label: string;
  /** YYYY-MM-DD local calendar day, or null when empty */
  value: string | null;
  onChange: (day: string | null) => void;
  clearable?: boolean;
  minDay?: string;
};

export const toDay = (d: Date) => format(d, "yyyy-MM-dd");
export const formatDay = (day: string) => format(parseISO(day), "MMM d, yyyy");

/** A calendar-day input with a pop-up month picker, like the Loyverse date fields. */
export default function DayField({ id, label, value, onChange, clearable, minDay }: Props) {
  const [open, setOpen] = useState(false);
  const selected = value ? parseISO(value) : undefined;
  return (
    <div className="space-y-1">
      <Label htmlFor={id} className="text-xs font-normal text-muted-foreground">{label}</Label>
      <Popover open={open} onOpenChange={setOpen}>
        <div className="flex h-10 items-center rounded-sm border bg-background">
          <PopoverTrigger
            id={id}
            className="flex h-full flex-1 cursor-pointer items-center justify-between gap-2 px-3 text-left text-sm"
          >
            <span className={value ? undefined : "text-muted-foreground"}>{value ? formatDay(value) : "Select date"}</span>
            <CalendarDays className="size-4 text-muted-foreground" />
          </PopoverTrigger>
          {clearable && value && (
            <button
              type="button"
              aria-label={`Clear ${label}`}
              onClick={() => onChange(null)}
              className="flex h-full cursor-pointer items-center border-l px-2 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" />
            </button>
          )}
        </div>
        <PopoverContent align="start" className="w-auto p-0">
          <Calendar
            mode="single"
            selected={selected}
            defaultMonth={selected}
            disabled={minDay ? { before: parseISO(minDay) } : undefined}
            onSelect={(d) => {
              if (d) onChange(toDay(d));
              setOpen(false);
            }}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
