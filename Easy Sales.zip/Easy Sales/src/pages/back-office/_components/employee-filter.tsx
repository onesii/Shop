import { useQuery } from "convex/react";
import { ChevronDown, User } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { EmployeeFilterId } from "@/convex/reports/range.ts";
import { useUser } from "@/hooks/use-auth.ts";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { useReportFilters } from "../_lib/filters.ts";

/** Fallback name for records made before employees existed (they belong to the owner). */
export function useOwnerName(): string {
  const user = useUser();
  return user?.profile?.name ?? user?.profile?.email ?? "Owner";
}

/** Employees for the report filter and the per-employee report. */
export function useEmployeeOptions() {
  return useQuery(api.staff.employees.list, {});
}

/** Multi-select employee filter shared by every report. */
export default function EmployeeFilter() {
  const { employeeIds, setEmployeeIds } = useReportFilters();
  const employees = useEmployeeOptions();
  const all = employees?.map((e) => e._id) ?? [];
  const selected = new Set<EmployeeFilterId>(employeeIds ?? all);

  const toggle = (id: EmployeeFilterId, on: boolean) => {
    const next = new Set(selected);
    if (on) next.add(id);
    else next.delete(id);
    // Everyone selected is the same as no filter
    setEmployeeIds(next.size === all.length ? undefined : all.filter((x) => next.has(x)));
  };

  const label =
    !employeeIds
      ? "All employees"
      : employeeIds.length === 1
        ? (employees?.find((e) => e._id === employeeIds[0])?.name ?? "1 employee")
        : `${employeeIds.length} employees`;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="flex h-11 cursor-pointer items-center gap-3 rounded-sm border bg-card px-4 text-sm font-medium shadow-xs transition-colors hover:bg-muted">
        <User className="size-4 text-muted-foreground" />
        <span className="max-w-40 truncate">{label}</span>
        <ChevronDown className="size-4 text-muted-foreground" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="max-h-80 w-60 overflow-y-auto">
        <DropdownMenuCheckboxItem
          checked={!employeeIds}
          onCheckedChange={() => setEmployeeIds(undefined)}
          onSelect={(e) => e.preventDefault()}
        >
          All employees
        </DropdownMenuCheckboxItem>
        <DropdownMenuSeparator />
        {(employees ?? []).map((e) => (
          <DropdownMenuCheckboxItem
            key={e._id}
            checked={selected.has(e._id)}
            onCheckedChange={(on) => toggle(e._id, on === true)}
            onSelect={(ev) => ev.preventDefault()}
          >
            <span className="truncate">{e.name}</span>
          </DropdownMenuCheckboxItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
