import { useMemo } from "react";
import { usePaginatedQuery } from "convex/react";
import { format } from "date-fns";
import { Clock } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { formatKsh } from "@/lib/money.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import ReportShell from "../_components/report-shell.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { useOwnerName } from "../_components/employee-filter.tsx";
import { rangeToIso } from "../_lib/summary.ts";
import { reportFilename, useReportFilters } from "../_lib/filters.ts";
import { money } from "../_lib/columns.ts";

type Row = Doc<"shifts"> & { expectedCashCents: number };

const PAGE = 50;
const difference = (r: Row) => (r.actualCashCents === null ? null : r.actualCashCents - r.expectedCashCents);

const dateTime = (iso: string) => format(new Date(iso), "MMM d, yyyy h:mm a");

function columns(employee: string): Column<Row>[] {
  return [
    {
      key: "number",
      label: "Shift",
      fixed: true,
      render: (r) => <span className="font-medium">#{r.number}</span>,
      csv: (r) => r.number,
    },
    {
      key: "employee",
      label: "Employee",
      render: (r) => r.employeeName ?? employee,
      csv: (r) => r.employeeName ?? employee,
    },
    { key: "opened", label: "Opened", render: (r) => dateTime(r.openedAt), csv: (r) => dateTime(r.openedAt) },
    {
      key: "closed",
      label: "Closed",
      render: (r) =>
        r.closedAt ? dateTime(r.closedAt) : <span className="font-medium text-primary">Open</span>,
      csv: (r) => (r.closedAt ? dateTime(r.closedAt) : "Open"),
    },
    money<Row>("gross", "Gross sales", (r) => r.grossSalesCents),
    money<Row>("refunds", "Refunds", (r) => r.refundsCents),
    money<Row>("net", "Net sales", (r) => r.grossSalesCents - r.refundsCents),
    money<Row>("starting", "Starting cash", (r) => r.startingCashCents),
    money<Row>("paidIn", "Paid in", (r) => r.paidInCents),
    money<Row>("paidOut", "Paid out", (r) => r.paidOutCents),
    money<Row>("expected", "Expected cash", (r) => r.expectedCashCents),
    {
      key: "actual",
      label: "Actual cash",
      numeric: true,
      render: (r) => (r.actualCashCents === null ? "-" : formatKsh(r.actualCashCents)),
      csv: (r) => (r.actualCashCents === null ? "" : (r.actualCashCents / 100).toFixed(2)),
    },
    {
      key: "difference",
      label: "Difference",
      numeric: true,
      render: (r) => {
        const d = difference(r);
        if (d === null) return "-";
        return (
          <span className={cn(d < 0 && "text-destructive")}>
            {d < 0 ? "-" : ""}
            {formatKsh(Math.abs(d))}
          </span>
        );
      },
      csv: (r) => {
        const d = difference(r);
        return d === null ? "" : (d / 100).toFixed(2);
      },
    },
  ];
}

export default function ShiftsReportPage() {
  const { range, employeeIds } = useReportFilters();
  const employee = useOwnerName();
  const args = useMemo(() => ({ ...rangeToIso(range), ...(employeeIds ? { employeeIds } : {}) }), [range, employeeIds]);
  const { results, status, loadMore } = usePaginatedQuery(api.reports.shiftsReport.list, args, {
    initialNumItems: PAGE,
  });
  const cols = useMemo(() => columns(employee), [employee]);

  return (
    <ReportShell showHours={false}>
      <ReportTable
        columns={cols}
        rows={status === "LoadingFirstPage" ? undefined : results}
        rowKey={(r) => r._id}
        filename={reportFilename("shifts", range)}
        empty={{ icon: Clock, title: "No shifts", description: "No shifts were opened in this period." }}
        after={
          status === "CanLoadMore" || status === "LoadingMore" ? (
            <div className="border-t p-4">
              <Button
                variant="secondary"
                className="w-full"
                disabled={status === "LoadingMore"}
                onClick={() => loadMore(PAGE)}
              >
                {status === "LoadingMore" ? "Loading..." : "Load more"}
              </Button>
            </div>
          ) : null
        }
      />
    </ReportShell>
  );
}
