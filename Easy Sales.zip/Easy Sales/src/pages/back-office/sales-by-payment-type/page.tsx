import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Wallet } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { formatKsh } from "@/lib/money.ts";
import { PAYMENT_METHODS, type PaymentMethod } from "@/lib/payments.ts";
import ReportShell from "../_components/report-shell.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { reportArgs, reportFilename, useReportFilters } from "../_lib/filters.ts";
import { money, sumBy } from "../_lib/columns.ts";

type Row = {
  method: PaymentMethod;
  salesCount: number;
  salesCents: number;
  refundsCount: number;
  refundsCents: number;
  netCents: number;
};

const COLUMNS: Column<Row>[] = [
  {
    key: "type",
    label: "Payment type",
    fixed: true,
    render: (r) => {
      const { icon: Icon, label } = PAYMENT_METHODS[r.method];
      return (
        <span className="flex items-center gap-3 font-medium">
          <Icon className="size-4 text-muted-foreground" />
          {label}
        </span>
      );
    },
    csv: (r) => PAYMENT_METHODS[r.method].label,
  },
  {
    key: "transactions",
    label: "Payment transactions",
    numeric: true,
    render: (r) => r.salesCount,
    csv: (r) => r.salesCount,
  },
  money<Row>("amount", "Payment amount", (r) => r.salesCents),
  {
    key: "refundTransactions",
    label: "Refund transactions",
    numeric: true,
    render: (r) => r.refundsCount,
    csv: (r) => r.refundsCount,
  },
  money<Row>("refunds", "Refund amount", (r) => r.refundsCents),
  money<Row>("net", "Net amount", (r) => r.netCents),
];

export default function SalesByPaymentTypePage() {
  const { range, hourWindow, employeeIds } = useReportFilters();
  const args = useMemo(() => reportArgs(range, hourWindow, employeeIds), [range, hourWindow, employeeIds]);
  const data = useQuery(api.reports.salesReports.byPaymentType, args);
  // Show every payment type that had activity
  const rows = data?.filter((r) => r.salesCount > 0 || r.refundsCount > 0);

  const footer = rows && {
    type: "Total",
    transactions: sumBy(rows, (r) => r.salesCount),
    amount: formatKsh(sumBy(rows, (r) => r.salesCents)),
    refundTransactions: sumBy(rows, (r) => r.refundsCount),
    refunds: formatKsh(sumBy(rows, (r) => r.refundsCents)),
    net: formatKsh(sumBy(rows, (r) => r.netCents)),
  };

  return (
    <ReportShell>
      <ReportTable
        columns={COLUMNS}
        rows={rows}
        rowKey={(r) => r.method}
        filename={reportFilename("sales-by-payment-type", range)}
        footer={footer}
        empty={{ icon: Wallet, title: "No payments", description: "No payments were taken in this period." }}
      />
    </ReportShell>
  );
}
