import { useMemo, useState } from "react";
import { useConvex, usePaginatedQuery, useQuery } from "convex/react";
import { format } from "date-fns";
import { History } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { STOCK_REASONS, type StockReason } from "@/convex/lib/stock.ts";
import { downloadCsv } from "@/lib/csv.ts";
import { REASON_LABELS, stockLabel } from "@/lib/stock.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import DateRangeFilter from "../_components/date-range-filter.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { reportFilename, useReportFilters } from "../_lib/filters.ts";
import { rangeToIso } from "../_lib/summary.ts";

type Adjustment = Doc<"stockAdjustments">;
type Row = Adjustment["lines"][number] & {
  key: string;
  createdAt: string;
  reason: StockReason;
  note: string | null;
  employeeName: string | null;
};

const PAGE = 30;
const EXPORT_LIMIT = 5000;

/** One table row per item changed; an adjustment can touch many items. */
function flatten(adjustments: Adjustment[]): Row[] {
  return adjustments.flatMap((a) =>
    a.lines.map((l, i) => ({
      ...l,
      key: `${a._id}-${i}`,
      createdAt: a.createdAt,
      reason: a.reason,
      note: a.note,
      employeeName: a.employeeName ?? null,
    })),
  );
}

const signed = (n: number) => (n > 0 ? `+${n}` : String(n));

function columns(storeName: string): Column<Row>[] {
  return [
    {
      key: "date",
      label: "Date",
      fixed: true,
      render: (r) => format(new Date(r.createdAt), "MMM d, yyyy h:mm a"),
      csv: (r) => format(new Date(r.createdAt), "yyyy-MM-dd HH:mm"),
    },
    {
      key: "item",
      label: "Item",
      fixed: true,
      render: (r) => <span className="font-medium">{stockLabel(r.variantName, r.itemName)}</span>,
      csv: (r) => stockLabel(r.variantName, r.itemName),
    },
    { key: "store", label: "Store", render: () => storeName, csv: () => storeName },
    { key: "employee", label: "Employee", render: (r) => r.employeeName ?? "-", csv: (r) => r.employeeName ?? "" },
    {
      key: "reason",
      label: "Reason",
      render: (r) => (
        <span>
          {REASON_LABELS[r.reason]}
          {r.note && <span className="block text-xs text-muted-foreground">{r.note}</span>}
        </span>
      ),
      csv: (r) => (r.note ? `${REASON_LABELS[r.reason]} (${r.note})` : REASON_LABELS[r.reason]),
    },
    {
      key: "change",
      label: "Adjustment",
      numeric: true,
      fixed: true,
      render: (r) => (
        <span className={cn("font-medium", r.change > 0 ? "text-primary" : r.change < 0 && "text-destructive")}>
          {signed(r.change)}
        </span>
      ),
      csv: (r) => r.change,
    },
    { key: "after", label: "Stock after", numeric: true, render: (r) => r.inStockAfter, csv: (r) => r.inStockAfter },
  ];
}

export default function InventoryHistoryPage() {
  const convex = useConvex();
  const { range, setRange } = useReportFilters();
  const [reason, setReason] = useState<StockReason | "all">("all");
  const settings = useQuery(api.settings.get, {});
  const args = useMemo(
    () => ({ ...rangeToIso(range), ...(reason === "all" ? {} : { reason }) }),
    [range, reason],
  );
  const { results, status, loadMore } = usePaginatedQuery(api.inventory.stock.history, args, {
    initialNumItems: PAGE,
  });
  const rows = useMemo(() => flatten(results), [results]);
  const cols = columns(settings?.storeName || "My store");
  const filename = reportFilename("inventory-history", range);

  const exportAll = async () => {
    const all: Adjustment[] = [];
    let cursor: string | null = null;
    for (;;) {
      const page: { page: Adjustment[]; isDone: boolean; continueCursor: string } = await convex.query(
        api.inventory.stock.history,
        { ...args, paginationOpts: { numItems: 200, cursor } },
      );
      all.push(...page.page);
      if (page.isDone || all.length >= EXPORT_LIMIT) break;
      cursor = page.continueCursor;
    }
    downloadCsv(filename, flatten(all).map((r) => Object.fromEntries(cols.map((c) => [c.label, c.csv(r)]))));
  };

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <div className="flex flex-wrap items-end gap-4">
        <DateRangeFilter value={range} onChange={setRange} />
        <div className="w-48 space-y-1">
          <Label className="text-xs font-normal text-muted-foreground">Reason</Label>
          <Select value={reason} onValueChange={(v) => setReason(STOCK_REASONS.find((r) => r === v) ?? "all")}>
            <SelectTrigger className="w-full cursor-pointer bg-card">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All reasons</SelectItem>
              {STOCK_REASONS.map((r) => (
                <SelectItem key={r} value={r}>{REASON_LABELS[r]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <ReportTable
        columns={cols}
        rows={status === "LoadingFirstPage" ? undefined : rows}
        rowKey={(r) => r.key}
        filename={filename}
        onExport={() => void exportAll()}
        empty={{
          icon: History,
          title: "No stock changes in this period",
          description: "Sales, refunds, received orders, counts and adjustments show up here.",
        }}
        after={
          status === "CanLoadMore" || status === "LoadingMore" ? (
            <div className="border-t p-4">
              <Button variant="secondary" className="w-full" disabled={status === "LoadingMore"} onClick={() => loadMore(PAGE)}>
                {status === "LoadingMore" ? "Loading..." : "Load more"}
              </Button>
            </div>
          ) : null
        }
      />
    </div>
  );
}
