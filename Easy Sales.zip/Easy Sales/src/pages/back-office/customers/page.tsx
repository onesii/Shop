import { useState } from "react";
import { useConvex, useMutation, usePaginatedQuery } from "convex/react";
import { format } from "date-fns";
import { Search, Trash2, UserPlus, Users } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { downloadCsv } from "@/lib/csv.ts";
import { convexMessage } from "@/lib/errors.ts";
import { formatKsh } from "@/lib/money.ts";
import CustomerForm from "@/components/customers/customer-form.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";

type Row = Doc<"customers">;

const PAGE = 50;
// Export walks every page, so cap it to keep a single download reasonable
const EXPORT_LIMIT = 5000;
const lastVisit = (r: Row) => (r.lastVisitAt ? format(new Date(r.lastVisitAt), "MMM d, yyyy") : "-");

const COLUMNS: Column<Row>[] = [
  {
    key: "name",
    label: "Customer",
    fixed: true,
    render: (r) => <span className="font-medium">{r.name}</span>,
    csv: (r) => r.name,
  },
  { key: "phone", label: "Phone", render: (r) => r.phone ?? "-", csv: (r) => r.phone ?? "" },
  { key: "email", label: "Email", render: (r) => r.email ?? "-", csv: (r) => r.email ?? "" },
  { key: "lastVisit", label: "Last visit", render: lastVisit, csv: (r) => r.lastVisitAt ?? "" },
  { key: "visits", label: "Visits", numeric: true, render: (r) => r.visits, csv: (r) => r.visits },
  {
    key: "spent",
    label: "Total spent",
    numeric: true,
    render: (r) => formatKsh(r.totalSpentCents),
    csv: (r) => (r.totalSpentCents / 100).toFixed(2),
  },
];

export default function CustomersPage() {
  const convex = useConvex();
  const [search, setSearch] = useState("");
  const [debounced] = useDebounce(search, 250);
  const [editing, setEditing] = useState<Row | "new" | null>(null);
  const { results, status, loadMore } = usePaginatedQuery(
    api.customers.list,
    { search: debounced || undefined },
    { initialNumItems: PAGE },
  );

  // The table only holds loaded pages, so fetch the full list for the file
  const exportAll = async () => {
    const all: Row[] = [];
    let cursor: string | null = null;
    for (;;) {
      const page: { page: Row[]; isDone: boolean; continueCursor: string } = await convex.query(api.customers.list, {
        search: debounced || undefined,
        paginationOpts: { numItems: 500, cursor },
      });
      all.push(...page.page);
      if (page.isDone || all.length >= EXPORT_LIMIT) break;
      cursor = page.continueCursor;
    }
    downloadCsv(
      "customers.csv",
      all.map((r) => Object.fromEntries(COLUMNS.map((c) => [c.label, c.csv(r)]))),
    );
  };

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <div className="flex flex-wrap items-center gap-3">
        <Button className="h-11" onClick={() => setEditing("new")}>
          <UserPlus className="size-4" /> Add customer
        </Button>
        <div className="relative min-w-0 flex-1 sm:max-w-xs">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search customers"
            className="h-11 bg-card pl-9"
          />
        </div>
      </div>
      <ReportTable
        columns={COLUMNS}
        rows={status === "LoadingFirstPage" ? undefined : results}
        rowKey={(r) => r._id}
        filename="customers.csv"
        onExport={() => void exportAll()}
        onRowClick={(r) => setEditing(r)}
        empty={{
          icon: Users,
          title: debounced ? "No matching customers" : "No customers yet",
          description: debounced
            ? "Try a different name, phone or email."
            : "Add customers here or from the ticket at the POS.",
        }}
        after={
          status === "CanLoadMore" || status === "LoadingMore" ? (
            <div className="border-t p-4">
              <Button
                variant="secondary"
                className="w-full"
                disabled={status === "LoadingMore"}
                onClick={() => loadMore(PAGE)}
              >
                {status === "LoadingMore" ? "Loading..." : "Load more"}
              </Button>
            </div>
          ) : null
        }
      />
      <Dialog open={editing !== null} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing === "new" ? "Add customer" : "Edit customer"}</DialogTitle>
            <DialogDescription>
              {editing && editing !== "new"
                ? `${editing.visits} visits · ${formatKsh(editing.totalSpentCents)} spent`
                : "Customers can be added to a ticket at the POS"}
            </DialogDescription>
          </DialogHeader>
          {editing !== null && (
            <CustomerForm
              key={editing === "new" ? "new" : editing._id}
              customer={editing === "new" ? null : editing}
              onSaved={() => setEditing(null)}
              onCancel={() => setEditing(null)}
              extra={editing !== "new" ? <DeleteButton customer={editing} onDone={() => setEditing(null)} /> : undefined}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DeleteButton({ customer, onDone }: { customer: Row; onDone: () => void }) {
  const remove = useMutation(api.customers.remove);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const run = async () => {
    if (!confirming) return setConfirming(true);
    setBusy(true);
    try {
      await remove({ id: customer._id });
      toast.success("Customer deleted");
      onDone();
    } catch (err) {
      toast.error(convexMessage(err, "Could not delete customer"));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Button type="button" variant="ghost" className="text-destructive" disabled={busy} onClick={() => void run()}>
      <Trash2 className="size-4" /> {confirming ? "Tap again to delete" : "Delete"}
    </Button>
  );
}
