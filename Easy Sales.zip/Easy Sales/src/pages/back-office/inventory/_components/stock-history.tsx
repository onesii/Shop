import { usePaginatedQuery } from "convex/react";
import { format } from "date-fns";
import { History } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { REASON_LABELS, stockLabel } from "@/lib/stock.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";

const PAGE = 30;

/** Past stock adjustments, newest first. */
export default function StockHistory() {
  const { results, status, loadMore } = usePaginatedQuery(
    api.inventory.stock.history,
    {},
    { initialNumItems: PAGE },
  );

  if (status === "LoadingFirstPage") {
    return (
      <div className="space-y-2 rounded-sm border bg-card p-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }
  if (results.length === 0 && status === "Exhausted") {
    return (
      <Empty className="rounded-sm border bg-card py-16">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <History />
          </EmptyMedia>
          <EmptyTitle>No stock changes yet</EmptyTitle>
          <EmptyDescription>Adjustments and stock edits will show up here.</EmptyDescription>
        </EmptyHeader>
      </Empty>
    );
  }
  return (
    <section className="overflow-hidden rounded-sm border bg-card shadow-xs">
      {results.map((a) => (
        <AdjustmentRow key={a._id} adjustment={a} />
      ))}
      {(status === "CanLoadMore" || status === "LoadingMore") && (
        <div className="p-4">
          <Button
            variant="secondary"
            className="w-full"
            disabled={status === "LoadingMore"}
            onClick={() => loadMore(PAGE)}
          >
            {status === "LoadingMore" ? "Loading..." : "Load more"}
          </Button>
        </div>
      )}
    </section>
  );
}

function AdjustmentRow({ adjustment: a }: { adjustment: Doc<"stockAdjustments"> }) {
  return (
    <div className="space-y-2 border-b px-4 py-3 last:border-b-0">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <span className="font-semibold">{REASON_LABELS[a.reason]}</span>
        <span className="text-xs text-muted-foreground">{format(new Date(a.createdAt), "MMM d, yyyy · h:mm a")}</span>
      </div>
      {a.note && <p className="text-sm text-muted-foreground">{a.note}</p>}
      <ul className="space-y-1 text-sm">
        {a.lines.map((l, i) => (
          <li key={i} className="flex items-center justify-between gap-3">
            <span className="min-w-0 truncate">{stockLabel(l.variantName, l.itemName)}</span>
            <span className="shrink-0 tabular-nums">
              <span className={cn("font-medium", l.change > 0 ? "text-primary" : l.change < 0 && "text-destructive")}>
                {l.change > 0 ? `+${l.change}` : l.change}
              </span>
              <span className="text-muted-foreground"> → {l.inStockAfter}</span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
