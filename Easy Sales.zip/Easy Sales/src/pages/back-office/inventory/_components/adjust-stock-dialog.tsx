import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { MAX_ADJUSTMENT_LINES, stockAfter, type ManualStockReason } from "@/convex/lib/stock.ts";
import { convexMessage } from "@/lib/errors.ts";
import { MANUAL_REASONS, parseStockInput, stockLabel } from "@/lib/stock.ts";
import StockBadge from "@/components/inventory/stock-badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";

type Props = { open: boolean; onClose: () => void; initialLevelId?: Id<"stockLevels"> };

type Line = { levelId: Id<"stockLevels">; qty: string };

export default function AdjustStockDialog({ open, onClose, initialLevelId }: Props) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Adjust stock</DialogTitle>
          <DialogDescription>Record received items, losses, damage or a stock count.</DialogDescription>
        </DialogHeader>
        {open && <AdjustForm key={initialLevelId ?? "new"} initialLevelId={initialLevelId} onClose={onClose} />}
      </DialogContent>
    </Dialog>
  );
}

function AdjustForm({ initialLevelId, onClose }: { initialLevelId?: Id<"stockLevels">; onClose: () => void }) {
  const levels = useQuery(api.inventory.stock.listAll, {});
  const adjust = useMutation(api.inventory.stock.adjust);
  const [reason, setReason] = useState<ManualStockReason>("receive");
  const [lines, setLines] = useState<Line[]>(initialLevelId ? [{ levelId: initialLevelId, qty: "" }] : []);
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  if (levels === undefined) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-10 w-full" />
        ))}
      </div>
    );
  }
  if (levels.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-muted-foreground">
        No items track stock yet. Turn on "Track stock" when editing an item.
      </p>
    );
  }

  const byId = new Map(levels.map((l) => [l._id, l]));
  const available = levels.filter((l) => !lines.some((x) => x.levelId === l._id));
  const isCount = reason === "recount";

  const save = async () => {
    if (lines.length === 0) return toast.error("Add at least one item");
    const parsed = lines.map((l) => ({ stockLevelId: l.levelId, quantity: parseStockInput(l.qty, null) }));
    const invalid = parsed.some(
      (p) => p.quantity === null || Number.isNaN(p.quantity) || p.quantity < 0 || (!isCount && p.quantity === 0),
    );
    if (invalid) return toast.error(isCount ? "Enter the counted stock for every item" : "Enter a quantity for every item");
    setSaving(true);
    try {
      await adjust({
        reason,
        note: note || undefined,
        lines: parsed.map((p) => ({ stockLevelId: p.stockLevelId, quantity: p.quantity ?? 0 })),
      });
      toast.success("Stock updated");
      onClose();
    } catch (err) {
      toast.error(convexMessage(err, "Could not update stock"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <Label>Reason</Label>
        <Select value={reason} onValueChange={(v) => setReason(v as ManualStockReason)}>
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {MANUAL_REASONS.map((r) => (
              <SelectItem key={r.value} value={r.value}>
                {r.label} <span className="text-muted-foreground">· {r.hint}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <div className="grid grid-cols-[1fr_5rem_6rem_5rem_2.25rem] items-end gap-2 text-xs font-medium text-muted-foreground">
          <span>Item</span>
          <span className="text-right">In stock</span>
          <span>{isCount ? "Counted" : reason === "receive" ? "Add" : "Remove"}</span>
          <span className="text-right">After</span>
          <span />
        </div>
        {lines.map((line) => {
          const level = byId.get(line.levelId);
          if (!level) return null;
          const qty = parseStockInput(line.qty, null);
          const after = qty === null || Number.isNaN(qty) ? null : stockAfter(reason, level.inStock, qty);
          return (
            <div key={line.levelId} className="grid grid-cols-[1fr_5rem_6rem_5rem_2.25rem] items-center gap-2 border-b pb-2">
              <span className="truncate text-sm font-medium">{stockLabel(level.variantName, level.itemName)}</span>
              <StockBadge inStock={level.inStock} lowStock={level.lowStock} className="text-right text-sm" />
              <Input
                inputMode="numeric"
                autoFocus={line.levelId === initialLevelId}
                aria-label={`Quantity for ${level.itemName}`}
                value={line.qty}
                onChange={(e) =>
                  setLines((p) => p.map((x) => (x.levelId === line.levelId ? { ...x, qty: e.target.value } : x)))
                }
                placeholder="0"
              />
              <span className="text-right text-sm">
                {after === null ? "-" : <StockBadge inStock={after} lowStock={level.lowStock} />}
              </span>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                aria-label="Remove item"
                onClick={() => setLines((p) => p.filter((x) => x.levelId !== line.levelId))}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          );
        })}
        {available.length > 0 && lines.length < MAX_ADJUSTMENT_LINES && (
          <Select value="" onValueChange={(id) => setLines((p) => [...p, { levelId: id as Id<"stockLevels">, qty: "" }])}>
            <SelectTrigger className="w-full text-primary">
              <span className="flex items-center gap-2">
                <Plus className="size-4" /> Add item
              </span>
            </SelectTrigger>
            <SelectContent>
              {available.map((l) => (
                <SelectItem key={l._id} value={l._id}>
                  {stockLabel(l.variantName, l.itemName)} · {l.inStock} in stock
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="adjust-note">Note (optional)</Label>
        <Textarea
          id="adjust-note"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Delivery from Bidco, invoice 2231"
          rows={2}
        />
      </div>

      <DialogFooter className="gap-2">
        <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
        <Button type="button" disabled={saving} onClick={() => void save()}>
          {saving ? "Saving..." : "Adjust"}
        </Button>
      </DialogFooter>
    </div>
  );
}
