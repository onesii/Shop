import { useState } from "react";
import { useConvex, usePaginatedQuery, useQuery } from "convex/react";
import { AlertTriangle, PackageSearch, SlidersHorizontal } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { stockStatus } from "@/convex/lib/stock.ts";
import { downloadCsv } from "@/lib/csv.ts";
import { STATUS_LABELS } from "@/lib/stock.ts";
import StockBadge from "@/components/inventory/stock-badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import AdjustStockDialog from "./_components/adjust-stock-dialog.tsx";
import StockHistory from "./_components/stock-history.tsx";

type Row = Doc<"stockLevels">;
type Filter = "all" | "low";

const PAGE = 50;
const EXPORT_LIMIT = 5000;

const COLUMNS: Column<Row>[] = [
  {
    key: "item",
    label: "Item",
    fixed: true,
    render: (r) => (
      <span className="font-medium">
        {r.itemName}
        {r.variantName && <span className="text-muted-foreground"> · {r.variantName}</span>}
      </span>
    ),
    csv: (r) => r.itemName,
  },
  { key: "variant", label: "Variant", render: (r) => r.variantName ?? "-", csv: (r) => r.variantName ?? "" },
  {
    key: "status",
    label: "Status",
    render: (r) => STATUS_LABELS[stockStatus(r.inStock, r.lowStock)],
    csv: (r) => STATUS_LABELS[stockStatus(r.inStock, r.lowStock)],
  },
  {
    key: "low",
    label: "Low stock",
    numeric: true,
    render: (r) => r.lowStock ?? "-",
    csv: (r) => r.lowStock ?? "",
  },
  {
    key: "inStock",
    label: "In stock",
    numeric: true,
    fixed: true,
    render: (r) => <StockBadge inStock={r.inStock} lowStock={r.lowStock} />,
    csv: (r) => r.inStock,
  },
];

export default function InventoryPage() {
  const convex = useConvex();
  const [filter, setFilter] = useState<Filter>("all");
  const [adjusting, setAdjusting] = useState<{ levelId?: Id<"stockLevels"> } | null>(null);
  const lowCount = useQuery(api.inventory.stock.lowCount, {});
  const { results, status, loadMore } = usePaginatedQuery(
    api.inventory.stock.list,
    { lowOnly: filter === "low" },
    { initialNumItems: PAGE },
  );

  const exportAll = async () => {
    const all: Row[] = [];
    let cursor: string | null = null;
    for (;;) {
      const page: { page: Row[]; isDone: boolean; continueCursor: string } = await convex.query(api.inventory.stock.list, {
        lowOnly: filter === "low",
        paginationOpts: { numItems: 500, cursor },
      });
      all.push(...page.page);
      if (page.isDone || all.length >= EXPORT_LIMIT) break;
      cursor = page.continueCursor;
    }
    downloadCsv("inventory.csv", all.map((r) => Object.fromEntries(COLUMNS.map((c) => [c.label, c.csv(r)]))));
  };

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <Tabs defaultValue="stock" className="gap-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <TabsList>
            <TabsTrigger value="stock" className="cursor-pointer">Stock</TabsTrigger>
            <TabsTrigger value="history" className="cursor-pointer">History</TabsTrigger>
          </TabsList>
          <Button className="h-11" onClick={() => setAdjusting({})}>
            <SlidersHorizontal className="size-4" /> Adjust stock
          </Button>
        </div>

        <TabsContent value="stock" className="space-y-4">
          {lowCount !== undefined && lowCount > 0 && (
            <button
              type="button"
              onClick={() => setFilter("low")}
              className="flex w-full cursor-pointer items-center gap-3 rounded-sm border border-amber-500/40 bg-amber-50 px-4 py-3 text-left text-sm text-amber-900 transition-colors hover:bg-amber-100 dark:bg-amber-950/40 dark:text-amber-200 dark:hover:bg-amber-950/60"
            >
              <AlertTriangle className="size-5 shrink-0" />
              <span className="flex-1">
                <span className="font-semibold">{lowCount >= 100 ? "100+" : lowCount}</span>{" "}
                {lowCount === 1 ? "item is" : "items are"} low or out of stock
              </span>
              {filter !== "low" && <span className="font-semibold uppercase">View</span>}
            </button>
          )}
          <div className="flex gap-2">
            {(["all", "low"] as const).map((f) => (
              <Button
                key={f}
                size="sm"
                variant={filter === f ? "default" : "ghost"}
                className={filter === f ? undefined : "border bg-card"}
                onClick={() => setFilter(f)}
              >
                {f === "all" ? "All items" : "Low stock"}
              </Button>
            ))}
          </div>
          <ReportTable
            columns={COLUMNS}
            rows={status === "LoadingFirstPage" ? undefined : results}
            rowKey={(r) => r._id}
            filename="inventory.csv"
            onExport={() => void exportAll()}
            onRowClick={(r) => setAdjusting({ levelId: r._id })}
            empty={
              filter === "low"
                ? { icon: PackageSearch, title: "Nothing is running low", description: "All tracked items are above their low stock level." }
                : {
                    icon: PackageSearch,
                    title: "No items track stock yet",
                    description: 'Open an item in Items and turn on "Track stock".',
                  }
            }
            after={
              status === "CanLoadMore" || status === "LoadingMore" ? (
                <div className="border-t p-4">
                  <Button
                    variant="secondary"
                    className="w-full"
                    disabled={status === "LoadingMore"}
                    onClick={() => loadMore(PAGE)}
                  >
                    {status === "LoadingMore" ? "Loading..." : "Load more"}
                  </Button>
                </div>
              ) : null
            }
          />
        </TabsContent>

        <TabsContent value="history">
          <StockHistory />
        </TabsContent>
      </Tabs>

      <AdjustStockDialog
        open={adjusting !== null}
        initialLevelId={adjusting?.levelId}
        onClose={() => setAdjusting(null)}
      />
    </div>
  );
}
