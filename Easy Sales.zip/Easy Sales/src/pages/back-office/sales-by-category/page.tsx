import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Layers } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { formatKsh } from "@/lib/money.ts";
import ReportShell from "../_components/report-shell.tsx";
import { TruncatedNotice } from "../_components/report-stats.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { reportArgs, reportFilename, useReportFilters } from "../_lib/filters.ts";
import { money, sumBy } from "../_lib/columns.ts";

type Row = {
  name: string;
  categoryId: string | null;
  itemsSold: number;
  grossSalesCents: number;
  refundsCents: number;
  discountsCents: number;
  netSalesCents: number;
};

const COLUMNS: Column<Row>[] = [
  {
    key: "category",
    label: "Category",
    fixed: true,
    render: (r) => <span className="font-medium">{r.name}</span>,
    csv: (r) => r.name,
  },
  { key: "sold", label: "Items sold", numeric: true, render: (r) => r.itemsSold, csv: (r) => r.itemsSold },
  money<Row>("gross", "Gross sales", (r) => r.grossSalesCents),
  money<Row>("refunds", "Refunds", (r) => r.refundsCents),
  money<Row>("discounts", "Discounts", (r) => r.discountsCents),
  money<Row>("net", "Net sales", (r) => r.netSalesCents),
];

export default function SalesByCategoryPage() {
  const { range, hourWindow, employeeIds } = useReportFilters();
  const args = useMemo(() => reportArgs(range, hourWindow, employeeIds), [range, hourWindow, employeeIds]);
  const data = useQuery(api.reports.salesReports.byCategory, args);
  const rows = data?.categories;

  const footer = rows && {
    category: "Total",
    sold: sumBy(rows, (r) => r.itemsSold),
    gross: formatKsh(sumBy(rows, (r) => r.grossSalesCents)),
    refunds: formatKsh(sumBy(rows, (r) => r.refundsCents)),
    discounts: formatKsh(sumBy(rows, (r) => r.discountsCents)),
    net: formatKsh(sumBy(rows, (r) => r.netSalesCents)),
  };

  return (
    <ReportShell>
      <ReportTable
        columns={COLUMNS}
        rows={rows}
        rowKey={(r) => r.categoryId ?? "none"}
        filename={reportFilename("sales-by-category", range)}
        footer={footer}
        notice={<TruncatedNotice show={data?.truncated ?? false} />}
        empty={{ icon: Layers, title: "No category sales", description: "No items were sold in this period." }}
      />
    </ReportShell>
  );
}
