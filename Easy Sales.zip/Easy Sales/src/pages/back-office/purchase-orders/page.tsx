import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { usePaginatedQuery, useQuery } from "convex/react";
import { ClipboardList, Plus } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { formatPoNumber, PO_STATUS_LABELS, type PoStatus } from "@/convex/lib/purchaseOrders.ts";
import { formatKsh } from "@/lib/money.ts";
import { Button } from "@/components/ui/button.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { formatDay } from "../_components/day-field.tsx";
import { ReceivedBar, StatusText } from "./_components/po-status.tsx";

type Row = Doc<"purchaseOrders">;
const PAGE = 25;
const STATUSES = Object.keys(PO_STATUS_LABELS) as PoStatus[];

function columns(storeName: string): Column<Row>[] {
  return [
    { key: "number", label: "Purchase order #", fixed: true, render: (r) => formatPoNumber(r.number), csv: (r) => formatPoNumber(r.number) },
    { key: "date", label: "Date", render: (r) => formatDay(r.orderedOn), csv: (r) => r.orderedOn },
    { key: "supplier", label: "Supplier", render: (r) => r.supplierName, csv: (r) => r.supplierName },
    { key: "store", label: "Store", render: () => storeName, csv: () => storeName },
    { key: "status", label: "Status", render: (r) => <StatusText status={r.status} />, csv: (r) => PO_STATUS_LABELS[r.status] },
    {
      key: "received",
      label: "Received",
      render: (r) => <ReceivedBar received={r.receivedQty} ordered={r.orderedQty} />,
      csv: (r) => `${r.receivedQty} of ${r.orderedQty}`,
    },
    {
      key: "expected",
      label: "Expected on",
      render: (r) => (r.expectedOn ? formatDay(r.expectedOn) : "-"),
      csv: (r) => r.expectedOn ?? "",
    },
    { key: "total", label: "Total", numeric: true, fixed: true, render: (r) => formatKsh(r.totalCents), csv: (r) => r.totalCents / 100 },
  ];
}

export default function PurchaseOrdersPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<PoStatus | "all">("all");
  const [supplierId, setSupplierId] = useState<Id<"suppliers"> | "all">("all");
  const suppliers = useQuery(api.inventory.suppliers.list, {});
  const settings = useQuery(api.settings.get, {});
  const { results, status: loadStatus, loadMore } = usePaginatedQuery(
    api.inventory.purchaseOrders.list,
    {
      status: status === "all" ? undefined : status,
      supplierId: supplierId === "all" ? undefined : supplierId,
    },
    { initialNumItems: PAGE },
  );
  const filtered = status !== "all" || supplierId !== "all";

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-4 rounded-sm bg-card p-4 shadow-xs">
        <Button className="h-10 uppercase" onClick={() => navigate("/back-office/purchase-orders/new")}>
          <Plus className="size-4" /> Add purchase order
        </Button>
        <div className="flex flex-wrap gap-4">
          <FilterSelect label="Status" value={status} onChange={(v) => setStatus(STATUSES.find((s) => s === v) ?? "all")}>
            <SelectItem value="all">All</SelectItem>
            {STATUSES.map((s) => (
              <SelectItem key={s} value={s}>{PO_STATUS_LABELS[s]}</SelectItem>
            ))}
          </FilterSelect>
          <FilterSelect
            label="Supplier"
            value={supplierId}
            onChange={(v) => setSupplierId(suppliers?.find((s) => s._id === v)?._id ?? "all")}
          >
            <SelectItem value="all">All suppliers</SelectItem>
            {(suppliers ?? []).map((s) => (
              <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
            ))}
          </FilterSelect>
        </div>
      </div>

      <ReportTable
        columns={columns(settings?.storeName || "My store")}
        rows={loadStatus === "LoadingFirstPage" ? undefined : results}
        rowKey={(r) => r._id}
        filename="purchase-orders.csv"
        onRowClick={(r) => navigate(`/back-office/purchase-orders/${r._id}`)}
        empty={
          filtered
            ? { icon: ClipboardList, title: "No matching purchase orders", description: "Try another status or supplier." }
            : {
                icon: ClipboardList,
                title: "No purchase orders yet",
                description: "Order stock from your suppliers, then receive it straight into your inventory.",
              }
        }
        after={
          loadStatus === "CanLoadMore" || loadStatus === "LoadingMore" ? (
            <div className="border-t p-4">
              <Button variant="secondary" className="w-full" disabled={loadStatus === "LoadingMore"} onClick={() => loadMore(PAGE)}>
                {loadStatus === "LoadingMore" ? "Loading..." : "Load more"}
              </Button>
            </div>
          ) : null
        }
      />
    </div>
  );
}

type FilterProps = { label: string; value: string; onChange: (v: string) => void; children: React.ReactNode };

function FilterSelect({ label, value, onChange, children }: FilterProps) {
  return (
    <div className="w-44 space-y-1">
      <Label className="text-xs font-normal text-muted-foreground">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-full cursor-pointer">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>{children}</SelectContent>
      </Select>
    </div>
  );
}
