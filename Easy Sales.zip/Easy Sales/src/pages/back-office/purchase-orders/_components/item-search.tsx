import { useState } from "react";
import { Search } from "lucide-react";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Popover, PopoverAnchor, PopoverContent } from "@/components/ui/popover.tsx";

type Level = Doc<"stockLevels">;

type Props = {
  levels: Level[];
  exclude: Set<Id<"stockLevels">>;
  onPick: (level: Level) => void;
};

const MAX_RESULTS = 20;

export const levelLabel = (l: { itemName: string; variantName: string | null }) =>
  l.variantName ? `${l.itemName} (${l.variantName})` : l.itemName;

/** "Search item" row at the bottom of the items table. Only items that track stock can be ordered. */
export default function ItemSearch({ levels, exclude, onPick }: Props) {
  const [text, setText] = useState("");
  const [open, setOpen] = useState(false);
  const q = text.trim().toLowerCase();
  const matches = levels
    .filter((l) => !exclude.has(l._id) && (!q || levelLabel(l).toLowerCase().includes(q)))
    .slice(0, MAX_RESULTS);

  return (
    <Popover open={open && text.length > 0} onOpenChange={setOpen}>
      <PopoverAnchor asChild>
        <div className="flex items-center gap-2 border-b py-2">
          <Search className="size-4 text-muted-foreground" />
          <input
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
            placeholder="Search item"
            aria-label="Search item"
            className="h-9 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
      </PopoverAnchor>
      <PopoverContent align="start" className="w-[var(--radix-popover-trigger-width)] min-w-64 p-1" onOpenAutoFocus={(e) => e.preventDefault()}>
        {matches.length === 0 ? (
          <p className="px-3 py-2 text-sm text-muted-foreground">
            No items found. Only items with "Track stock" turned on can be ordered.
          </p>
        ) : (
          matches.map((l) => (
            <button
              key={l._id}
              type="button"
              onClick={() => {
                onPick(l);
                setText("");
                setOpen(false);
              }}
              className="flex w-full cursor-pointer items-center justify-between gap-3 rounded-sm px-3 py-2 text-left text-sm hover:bg-muted"
            >
              <span className="truncate">{levelLabel(l)}</span>
              <span className="shrink-0 text-xs text-muted-foreground">In stock: {l.inStock}</span>
            </button>
          ))
        )}
      </PopoverContent>
    </Popover>
  );
}
