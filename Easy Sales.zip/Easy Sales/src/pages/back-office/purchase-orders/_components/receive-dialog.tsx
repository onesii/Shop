import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { levelLabel } from "./item-search.tsx";

type Line = { itemName: string; variantName: string | null; quantity: number; receivedQty: number };

type Props = { open: boolean; onClose: () => void; poId: Id<"purchaseOrders">; lines: Line[] };

export default function ReceiveDialog({ open, onClose, poId, lines }: Props) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Receive items</DialogTitle>
          <DialogDescription>Enter how many of each item arrived. They're added to your stock.</DialogDescription>
        </DialogHeader>
        {open && <ReceiveForm poId={poId} lines={lines} onClose={onClose} />}
      </DialogContent>
    </Dialog>
  );
}

function ReceiveForm({ poId, lines, onClose }: Omit<Props, "open">) {
  const receive = useMutation(api.inventory.purchaseOrders.receive);
  const [qty, setQty] = useState<string[]>(lines.map(() => ""));
  const [saving, setSaving] = useState(false);
  const left = lines.map((l) => Math.max(0, l.quantity - l.receivedQty));

  const submit = async (quantities: number[]) => {
    setSaving(true);
    try {
      await receive({ id: poId, quantities });
      toast.success("Items received into stock");
      onClose();
    } catch (err) {
      toast.error(convexMessage(err, "Could not receive the items"));
    } finally {
      setSaving(false);
    }
  };

  const enter = () => {
    const quantities = qty.map((q) => (q.trim() === "" ? 0 : Number(q)));
    const over = quantities.findIndex((q, i) => q > left[i]);
    if (over >= 0) return toast.error(`Only ${left[over]} more ${lines[over].itemName} to receive`);
    if (quantities.every((q) => q === 0)) return toast.error("Enter how many items arrived");
    void submit(quantities);
  };

  return (
    <>
      <div className="divide-y rounded-sm border">
        {lines.map((l, i) => (
          <div key={i} className="flex items-center gap-3 px-3 py-2">
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{levelLabel(l)}</p>
              <p className="text-xs text-muted-foreground">
                {l.receivedQty} of {l.quantity} received
              </p>
            </div>
            {left[i] > 0 ? (
              <Input
                aria-label={`Receive ${l.itemName}`}
                inputMode="numeric"
                placeholder={String(left[i])}
                value={qty[i]}
                onChange={(e) => setQty((q) => q.map((v, j) => (j === i ? e.target.value.replace(/\D/g, "") : v)))}
                className="h-9 w-20 text-right"
              />
            ) : (
              <span className="text-xs text-muted-foreground">Done</span>
            )}
          </div>
        ))}
      </div>
      <DialogFooter className="gap-2 sm:justify-between">
        <Button variant="ghost" disabled={saving} onClick={() => void submit(left)}>Mark all received</Button>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={saving} onClick={enter}>{saving && <Spinner />} Receive</Button>
        </div>
      </DialogFooter>
    </>
  );
}
