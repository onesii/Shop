import { useMemo, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { ChevronDown, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import {
  lineAmount,
  MAX_ADDITIONAL_COSTS,
  MAX_PO_LINES,
  MAX_PO_NOTES,
  poTotal,
  purchaseOrderError,
  suggestedQty,
} from "@/convex/lib/purchaseOrders.ts";
import { centsToInput, formatKsh, parseToCents } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu.tsx";
import DayField, { toDay } from "../../_components/day-field.tsx";
import SupplierDialog from "../../suppliers/_components/supplier-dialog.tsx";
import ItemSearch, { levelLabel } from "./item-search.tsx";

export type PoFormInitial = {
  id?: Id<"purchaseOrders">;
  supplierId: Id<"suppliers"> | null;
  orderedOn: string;
  expectedOn: string | null;
  notes: string;
  lines: { stockLevelId: Id<"stockLevels">; quantity: number; costCents: number }[];
  additionalCosts: { name: string; amountCents: number }[];
  /** Already ordered: saving keeps it ordered, so there's no draft button */
  sent: boolean;
};

export const emptyPo = (): PoFormInitial => ({
  supplierId: null,
  orderedOn: toDay(new Date()),
  expectedOn: null,
  notes: "",
  lines: [],
  additionalCosts: [],
  sent: false,
});

type LineDraft = { stockLevelId: Id<"stockLevels">; qty: string; cost: string };
type CostDraft = { key: string; name: string; amount: string };

const NEW_SUPPLIER = "__new";

const parseQty = (s: string) => (/^\d+$/.test(s.trim()) ? Number(s.trim()) : Number.NaN);
const cellInput =
  "h-9 w-20 rounded-none border-0 border-b border-foreground/20 bg-transparent px-1 text-right shadow-none focus-visible:border-primary focus-visible:ring-0 dark:bg-transparent";

type Props = { initial: PoFormInitial; onDone: (id?: Id<"purchaseOrders">) => void };

export default function PoForm({ initial, onDone }: Props) {
  const levels = useQuery(api.inventory.stock.listAll, {});
  const suppliers = useQuery(api.inventory.suppliers.list, {});
  const incoming = useQuery(api.inventory.purchaseOrders.incoming, {});
  const settings = useQuery(api.settings.get, {});
  const save = useMutation(api.inventory.purchaseOrders.save);

  const [supplierId, setSupplierId] = useState(initial.supplierId);
  const [orderedOn, setOrderedOn] = useState(initial.orderedOn);
  const [expectedOn, setExpectedOn] = useState(initial.expectedOn);
  const [notes, setNotes] = useState(initial.notes);
  const [lines, setLines] = useState<LineDraft[]>(
    initial.lines.map((l) => ({ stockLevelId: l.stockLevelId, qty: String(l.quantity), cost: centsToInput(l.costCents) })),
  );
  const [costs, setCosts] = useState<CostDraft[]>(
    initial.additionalCosts.map((c, i) => ({ key: String(i), name: c.name, amount: centsToInput(c.amountCents) })),
  );
  const [supplierError, setSupplierError] = useState(false);
  const [creatingSupplier, setCreatingSupplier] = useState(false);
  const [saving, setSaving] = useState(false);

  const levelById = useMemo(() => new Map((levels ?? []).map((l) => [l._id, l])), [levels]);
  const inOrder = new Set(lines.map((l) => l.stockLevelId));

  const parsedLines = lines.map((l) => ({ stockLevelId: l.stockLevelId, quantity: parseQty(l.qty), costCents: parseToCents(l.cost) ?? 0 }));
  const parsedCosts = costs.map((c) => ({ name: c.name, amountCents: parseToCents(c.amount) ?? 0 }));
  const safe = (n: number) => (Number.isFinite(n) ? n : 0);
  const total = poTotal(
    parsedLines.map((l) => ({ quantity: safe(l.quantity), costCents: safe(l.costCents) })),
    parsedCosts.map((c) => ({ amountCents: safe(c.amountCents) })),
  );

  if (levels === undefined || suppliers === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-56 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  const addLevel = (id: Id<"stockLevels">, qty = 1) => {
    const level = levelById.get(id);
    if (!level || inOrder.has(id)) return;
    setLines((ls) => [...ls, { stockLevelId: id, qty: String(qty), cost: centsToInput(level.lastCostCents ?? 0) }]);
  };

  const autofillLow = () => {
    const low = levels.filter((l) => l.isLow && !inOrder.has(l._id)).slice(0, MAX_PO_LINES - lines.length);
    if (low.length === 0) return toast("No low stock items to add");
    setLines((ls) => [
      ...ls,
      ...low.map((l) => ({
        stockLevelId: l._id,
        qty: String(suggestedQty(l.inStock + (incoming?.[l._id] ?? 0), l.lowStock)),
        cost: centsToInput(l.lastCostCents ?? 0),
      })),
    ]);
    toast.success(`Added ${low.length} low stock ${low.length === 1 ? "item" : "items"}`);
  };

  const updateLine = (i: number, patch: Partial<LineDraft>) =>
    setLines((ls) => ls.map((l, j) => (j === i ? { ...l, ...patch } : l)));
  const updateCost = (i: number, patch: Partial<CostDraft>) =>
    setCosts((cs) => cs.map((c, j) => (j === i ? { ...c, ...patch } : c)));

  const submit = async (send: boolean) => {
    if (!supplierId) {
      setSupplierError(true);
      return toast.error("Select a supplier");
    }
    const payload = {
      orderedOn,
      expectedOn,
      notes,
      lines: parsedLines,
      additionalCosts: parsedCosts.map((c) => ({ ...c, name: c.name.trim() })),
    };
    if (lines.some((l) => parseToCents(l.cost) !== null && Number.isNaN(parseToCents(l.cost)))) {
      return toast.error("Enter a valid purchase cost");
    }
    const error = purchaseOrderError(payload);
    if (error) return toast.error(error);
    setSaving(true);
    try {
      const id = await save({ id: initial.id, supplierId, ...payload, send });
      toast.success(send ? "Purchase order created" : "Draft saved");
      onDone(id);
    } catch (err) {
      toast.error(convexMessage(err, "Could not save the purchase order"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <section className="grid gap-x-8 gap-y-5 rounded-sm bg-card p-6 shadow-xs sm:grid-cols-2">
        <div className="space-y-1">
          <Label htmlFor="po-supplier" className="text-xs font-normal text-muted-foreground">Supplier</Label>
          <Select
            value={supplierId ?? ""}
            onValueChange={(v) => {
              if (v === NEW_SUPPLIER) return setCreatingSupplier(true);
              setSupplierId(suppliers.find((s) => s._id === v)?._id ?? null);
              setSupplierError(false);
            }}
          >
            <SelectTrigger id="po-supplier" aria-invalid={supplierError} className="w-full cursor-pointer">
              <SelectValue placeholder="Select a supplier" />
            </SelectTrigger>
            <SelectContent>
              {suppliers.map((s) => (
                <SelectItem key={s._id} value={s._id}>{s.name}</SelectItem>
              ))}
              <SelectItem value={NEW_SUPPLIER} className="font-medium text-primary">+ Add new supplier</SelectItem>
            </SelectContent>
          </Select>
          {supplierError && <p className="text-xs text-destructive">Select a supplier</p>}
        </div>
        <div className="space-y-1">
          <Label className="text-xs font-normal text-muted-foreground">Store</Label>
          <div className="flex h-9 items-center border-b text-sm">{settings?.storeName || "My store"}</div>
        </div>
        <DayField id="po-date" label="Purchase order date" value={orderedOn} onChange={(d) => d && setOrderedOn(d)} />
        <DayField id="po-expected" label="Expected on" value={expectedOn} onChange={setExpectedOn} clearable minDay={orderedOn} />
        <div className="space-y-1 sm:col-span-2">
          <Label htmlFor="po-notes" className="text-xs font-normal text-muted-foreground">Notes</Label>
          <Textarea id="po-notes" value={notes} maxLength={MAX_PO_NOTES} onChange={(e) => setNotes(e.target.value)} className="min-h-16" />
          <p className="text-right text-xs text-muted-foreground">{notes.length} / {MAX_PO_NOTES}</p>
        </div>
      </section>

      <section className="rounded-sm bg-card shadow-xs">
        <div className="flex items-center justify-between px-6 pt-5">
          <h2 className="text-lg font-medium">Items</h2>
          <DropdownMenu>
            <DropdownMenuTrigger className="flex cursor-pointer items-center gap-1 text-sm font-semibold uppercase text-primary">
              Autofill <ChevronDown className="size-4" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={autofillLow}>Add all low stock items</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="overflow-x-auto px-6 pb-2">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b text-xs text-muted-foreground">
                <th className="py-3 text-left font-normal">Item</th>
                <th className="w-20 py-3 text-right font-normal">In stock</th>
                <th className="w-20 py-3 text-right font-normal">Incoming</th>
                <th className="w-24 py-3 text-right font-normal">Quantity</th>
                <th className="w-28 py-3 text-right font-normal">Purchase cost</th>
                <th className="w-32 py-3 text-right font-normal">Amount</th>
                <th className="w-10" />
              </tr>
            </thead>
            <tbody>
              {lines.map((l, i) => {
                const level = levelById.get(l.stockLevelId);
                const q = parseQty(l.qty);
                const c = parseToCents(l.cost) ?? 0;
                return (
                  <tr key={l.stockLevelId} className="border-b">
                    <td className="py-2 pr-2">{level ? levelLabel(level) : "Item no longer tracks stock"}</td>
                    <td className="py-2 text-right tabular-nums">{level?.inStock ?? "-"}</td>
                    <td className="py-2 text-right tabular-nums">{incoming?.[l.stockLevelId] ?? 0}</td>
                    <td className="py-2 text-right">
                      <Input aria-label="Quantity" inputMode="numeric" value={l.qty} onChange={(e) => updateLine(i, { qty: e.target.value.replace(/\D/g, "") })} className={cellInput} />
                    </td>
                    <td className="py-2 text-right">
                      <Input aria-label="Purchase cost" inputMode="decimal" value={l.cost} onChange={(e) => updateLine(i, { cost: e.target.value })} className={`${cellInput} w-24`} />
                    </td>
                    <td className="py-2 text-right tabular-nums">
                      {formatKsh(Number.isFinite(q) && Number.isFinite(c) ? lineAmount({ quantity: q, costCents: c }) : 0)}
                    </td>
                    <td className="py-2 text-right">
                      <button type="button" aria-label="Remove item" onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))} className="cursor-pointer p-1 text-muted-foreground hover:text-foreground">
                        <Trash2 className="size-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {lines.length < MAX_PO_LINES && <ItemSearch levels={levels} exclude={inOrder} onPick={(l) => addLevel(l._id)} />}

          {costs.map((c, i) => (
            <div key={c.key} className="flex items-center gap-3 border-b py-2">
              <Input aria-label="Cost name" placeholder="Delivery" value={c.name} maxLength={40} onChange={(e) => updateCost(i, { name: e.target.value })} className="h-9 flex-1 rounded-none border-0 border-b border-foreground/20 bg-transparent px-1 shadow-none focus-visible:ring-0 dark:bg-transparent" />
              <Input aria-label="Cost amount" inputMode="decimal" placeholder="0.00" value={c.amount} onChange={(e) => updateCost(i, { amount: e.target.value })} className={`${cellInput} w-28`} />
              <button type="button" aria-label="Remove cost" onClick={() => setCosts((cs) => cs.filter((_, j) => j !== i))} className="cursor-pointer p-1 text-muted-foreground hover:text-foreground">
                <Trash2 className="size-4" />
              </button>
            </div>
          ))}
          {costs.length < MAX_ADDITIONAL_COSTS && (
            <button
              type="button"
              onClick={() => setCosts((cs) => [...cs, { key: crypto.randomUUID(), name: "", amount: "" }])}
              className="flex cursor-pointer items-center gap-1 py-3 text-sm text-primary"
            >
              <Plus className="size-4" /> Add additional costs
            </button>
          )}
          <div className="flex justify-end gap-12 border-t py-4 text-sm font-semibold">
            <span>Total</span>
            <span className="tabular-nums">{formatKsh(total)}</span>
          </div>
        </div>
      </section>

      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="ghost" className="border bg-card uppercase" onClick={() => onDone(initial.id)}>Cancel</Button>
        {!initial.sent && (
          <Button variant="ghost" className="border bg-card uppercase" disabled={saving} onClick={() => void submit(false)}>
            Save as draft
          </Button>
        )}
        <Button className="uppercase" disabled={saving} onClick={() => void submit(true)}>
          {saving && <Spinner />} {initial.sent ? "Save" : "Create"}
        </Button>
      </div>

      <SupplierDialog
        open={creatingSupplier}
        supplier={null}
        onClose={() => setCreatingSupplier(false)}
        onSaved={(id) => {
          setSupplierId(id);
          setSupplierError(false);
        }}
      />
    </div>
  );
}
