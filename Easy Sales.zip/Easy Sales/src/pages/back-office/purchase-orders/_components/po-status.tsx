import { PO_STATUS_LABELS, type PoStatus } from "@/convex/lib/purchaseOrders.ts";
import { cn } from "@/lib/utils.ts";

/** "4 of 10" with a thin progress bar, as in the Loyverse list. */
export function ReceivedBar({ received, ordered }: { received: number; ordered: number }) {
  const pct = ordered > 0 ? Math.min(100, (received / ordered) * 100) : 0;
  return (
    <div className="w-28 space-y-1">
      <div className="h-1.5 overflow-hidden rounded-full bg-muted">
        <div className="h-full bg-muted-foreground/50" style={{ width: `${pct}%` }} />
      </div>
      <p className="text-xs text-muted-foreground">{received} of {ordered}</p>
    </div>
  );
}

const STATUS_CLASS: Record<PoStatus, string> = {
  draft: "text-muted-foreground",
  pending: "text-amber-600 dark:text-amber-400",
  partial: "text-primary",
  closed: "text-muted-foreground",
};

export function StatusText({ status }: { status: PoStatus }) {
  return <span className={cn("text-sm", STATUS_CLASS[status])}>{PO_STATUS_LABELS[status]}</span>;
}
