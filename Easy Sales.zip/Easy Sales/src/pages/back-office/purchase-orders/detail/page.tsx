import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ClipboardList, PackageCheck, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { formatPoNumber, lineAmount } from "@/convex/lib/purchaseOrders.ts";
import { formatKsh } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyContent, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { formatDay } from "../../_components/day-field.tsx";
import PoForm, { emptyPo } from "../_components/po-form.tsx";
import ReceiveDialog from "../_components/receive-dialog.tsx";
import { ReceivedBar, StatusText } from "../_components/po-status.tsx";
import { levelLabel } from "../_components/item-search.tsx";

const LIST = "/back-office/purchase-orders";

export default function PurchaseOrderPage() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  if (id === "new") {
    return (
      <Shell>
        <PoForm initial={emptyPo()} onDone={(poId) => navigate(poId ? `${LIST}/${poId}` : LIST)} />
      </Shell>
    );
  }
  return <PurchaseOrderView id={id} />;
}

function Shell({ children }: { children: React.ReactNode }) {
  return <div className="mx-auto w-full max-w-4xl p-4 pb-12 md:p-6">{children}</div>;
}

function PurchaseOrderView({ id }: { id: string }) {
  const navigate = useNavigate();
  const po = useQuery(api.inventory.purchaseOrders.get, { id });
  const settings = useQuery(api.settings.get, {});
  const remove = useMutation(api.inventory.purchaseOrders.remove);
  const [editing, setEditing] = useState(false);
  const [receiving, setReceiving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (po === undefined) {
    return (
      <Shell>
        <div className="space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </Shell>
    );
  }
  if (po === null) {
    return (
      <Shell>
        <Empty className="pt-16">
          <EmptyHeader>
            <EmptyMedia variant="icon"><ClipboardList /></EmptyMedia>
            <EmptyTitle>Purchase order not found</EmptyTitle>
          </EmptyHeader>
          <EmptyContent>
            <Button onClick={() => navigate(LIST)}>Back to purchase orders</Button>
          </EmptyContent>
        </Empty>
      </Shell>
    );
  }

  const editable = po.receivedQty === 0 && po.status !== "closed";
  if (editing) {
    return (
      <Shell>
        <PoForm
          initial={{
            id: po._id,
            supplierId: po.supplierId,
            orderedOn: po.orderedOn,
            expectedOn: po.expectedOn,
            notes: po.notes,
            lines: po.lines,
            additionalCosts: po.additionalCosts,
            sent: po.status !== "draft",
          }}
          onDone={() => setEditing(false)}
        />
      </Shell>
    );
  }

  const del = async () => {
    try {
      await remove({ id: po._id });
      toast.success("Purchase order deleted");
      navigate(LIST);
    } catch (err) {
      toast.error(convexMessage(err, "Could not delete the purchase order"));
    }
  };

  const details: [string, string][] = [
    ["Supplier", po.supplierName],
    ["Store", settings?.storeName || "My store"],
    ["Purchase order date", formatDay(po.orderedOn)],
    ["Expected on", po.expectedOn ? formatDay(po.expectedOn) : "-"],
  ];

  return (
    <Shell>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          {(po.status === "pending" || po.status === "partial") && (
            <Button className="uppercase" onClick={() => setReceiving(true)}>
              <PackageCheck className="size-4" /> Receive
            </Button>
          )}
          {editable && (
            <Button variant="ghost" className="border bg-card uppercase" onClick={() => setEditing(true)}>
              <Pencil className="size-4" /> Edit
            </Button>
          )}
          {editable && (
            <Button variant="ghost" className="border bg-card uppercase" onClick={() => setConfirmDelete(true)}>
              <Trash2 className="size-4" /> Delete
            </Button>
          )}
        </div>

        <section className="space-y-5 rounded-sm bg-card p-6 shadow-xs">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h2 className="text-2xl font-semibold">{formatPoNumber(po.number)}</h2>
              <StatusText status={po.status} />
            </div>
            <ReceivedBar received={po.receivedQty} ordered={po.orderedQty} />
          </div>
          <dl className="grid gap-4 sm:grid-cols-2">
            {details.map(([k, v]) => (
              <div key={k}>
                <dt className="text-xs text-muted-foreground">{k}</dt>
                <dd className="text-sm">{v}</dd>
              </div>
            ))}
            {po.notes && (
              <div className="sm:col-span-2">
                <dt className="text-xs text-muted-foreground">Notes</dt>
                <dd className="whitespace-pre-wrap text-sm">{po.notes}</dd>
              </div>
            )}
          </dl>
        </section>

        <section className="overflow-x-auto rounded-sm bg-card px-6 pb-2 shadow-xs">
          <h2 className="pt-5 text-lg font-medium">Items</h2>
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b text-xs text-muted-foreground">
                <th className="py-3 text-left font-normal">Item</th>
                <th className="py-3 text-right font-normal">Received</th>
                <th className="py-3 text-right font-normal">Quantity</th>
                <th className="py-3 text-right font-normal">Purchase cost</th>
                <th className="py-3 text-right font-normal">Amount</th>
              </tr>
            </thead>
            <tbody>
              {po.lines.map((l) => (
                <tr key={l.stockLevelId} className="border-b">
                  <td className="py-3">{levelLabel(l)}</td>
                  <td className="py-3 text-right tabular-nums">{l.receivedQty}</td>
                  <td className="py-3 text-right tabular-nums">{l.quantity}</td>
                  <td className="py-3 text-right tabular-nums">{formatKsh(l.costCents)}</td>
                  <td className="py-3 text-right tabular-nums">{formatKsh(lineAmount(l))}</td>
                </tr>
              ))}
              {po.additionalCosts.map((c, i) => (
                <tr key={`cost-${i}`} className="border-b text-muted-foreground">
                  <td className="py-3" colSpan={4}>{c.name}</td>
                  <td className="py-3 text-right tabular-nums">{formatKsh(c.amountCents)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex justify-end gap-12 py-4 text-sm font-semibold">
            <span>Total</span>
            <span className="tabular-nums">{formatKsh(po.totalCents)}</span>
          </div>
        </section>
      </div>

      <ReceiveDialog open={receiving} onClose={() => setReceiving(false)} poId={po._id} lines={po.lines} />

      <Dialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete purchase order?</DialogTitle>
            <DialogDescription>{formatPoNumber(po.number)} will be removed.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmDelete(false)}>Cancel</Button>
            <Button variant="destructive" onClick={() => void del()}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Shell>
  );
}
