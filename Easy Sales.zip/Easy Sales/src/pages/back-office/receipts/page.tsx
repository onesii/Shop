import { useMemo, useState } from "react";
import { usePaginatedQuery } from "convex/react";
import { format } from "date-fns";
import { ReceiptText } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { formatKsh } from "@/lib/money.ts";
import { PAYMENT_METHODS } from "@/lib/payments.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog.tsx";
import ReceiptDetail from "@/pages/receipts/_components/receipt-detail.tsx";
import ReportShell from "../_components/report-shell.tsx";
import { StatCards } from "../_components/report-stats.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { useOwnerName } from "../_components/employee-filter.tsx";
import { rangeToIso } from "../_lib/summary.ts";
import { reportFilename, useReportFilters, utcMinuteWindow } from "../_lib/filters.ts";
import { sumBy } from "../_lib/columns.ts";

type Row = Doc<"receipts">;

const PAGE = 50;
const dateTime = (iso: string) => format(new Date(iso), "MMM d, yyyy h:mm a");
const itemCount = (r: Row) => r.lines.reduce((s, l) => s + l.quantity, 0);
const signed = (r: Row) => (r.kind === "refund" ? -r.totalCents : r.totalCents);

function columns(employee: string): Column<Row>[] {
  return [
    {
      key: "number",
      label: "Receipt no.",
      fixed: true,
      render: (r) => <span className="font-medium">#{r.number}</span>,
      csv: (r) => r.number,
    },
    { key: "date", label: "Date", render: (r) => dateTime(r.createdAt), csv: (r) => dateTime(r.createdAt) },
    {
      key: "employee",
      label: "Employee",
      render: (r) => r.employeeName ?? employee,
      csv: (r) => r.employeeName ?? employee,
    },
    {
      key: "type",
      label: "Type",
      render: (r) =>
        r.kind === "refund" ? (
          <span className="font-medium text-destructive">Refund</span>
        ) : r.refundedCents > 0 ? (
          "Sale (refunded)"
        ) : (
          "Sale"
        ),
      csv: (r) => (r.kind === "refund" ? "Refund" : "Sale"),
    },
    {
      key: "payment",
      label: "Payment",
      render: (r) => PAYMENT_METHODS[r.paymentMethod].label,
      csv: (r) => PAYMENT_METHODS[r.paymentMethod].label,
    },
    { key: "items", label: "Items", numeric: true, render: itemCount, csv: itemCount },
    {
      key: "total",
      label: "Total",
      numeric: true,
      render: (r) => (
        <span className={cn(r.kind === "refund" && "text-destructive")}>
          {r.kind === "refund" ? "-" : ""}
          {formatKsh(r.totalCents)}
        </span>
      ),
      csv: (r) => (signed(r) / 100).toFixed(2),
    },
  ];
}

export default function ReceiptsReportPage() {
  const { range, hourWindow, employeeIds } = useReportFilters();
  const employee = useOwnerName();
  const [openId, setOpenId] = useState<Id<"receipts"> | null>(null);
  const args = useMemo(
    () => ({
      ...rangeToIso(range),
      ...(utcMinuteWindow(hourWindow) ?? {}),
      ...(employeeIds ? { employeeIds } : {}),
    }),
    [range, hourWindow, employeeIds],
  );
  const { results, status, loadMore } = usePaginatedQuery(api.reports.receiptsReport.list, args, {
    initialNumItems: PAGE,
  });
  const cols = useMemo(() => columns(employee), [employee]);
  const loading = status === "LoadingFirstPage";
  const done = status === "Exhausted";

  const sales = results.filter((r) => r.kind === "sale");
  const refunds = results.filter((r) => r.kind === "refund");
  // Totals cover the receipts loaded so far; label them so they never look final
  const suffix = done ? "" : " (loaded)";
  const stats = [
    { label: "All receipts", value: String(results.length) + (done ? "" : "+") },
    { label: "Sales", value: String(sales.length) },
    { label: "Refunds", value: String(refunds.length) },
    { label: `Net total${suffix}`, value: formatKsh(sumBy(results, signed)) },
  ];

  return (
    <ReportShell>
      {!loading && results.length > 0 && <StatCards stats={stats} />}
      <ReportTable
        columns={cols}
        rows={loading ? undefined : results}
        rowKey={(r) => r._id}
        filename={reportFilename("receipts", range)}
        onRowClick={(r) => setOpenId(r._id)}
        empty={{ icon: ReceiptText, title: "No receipts", description: "No receipts in this period." }}
        after={
          status === "CanLoadMore" || status === "LoadingMore" ? (
            <div className="border-t p-4">
              <Button
                variant="secondary"
                className="w-full"
                disabled={status === "LoadingMore"}
                onClick={() => loadMore(PAGE)}
              >
                {status === "LoadingMore" ? "Loading..." : "Load more"}
              </Button>
            </div>
          ) : null
        }
      />
      <Dialog open={openId !== null} onOpenChange={(o) => !o && setOpenId(null)}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto p-0 sm:max-w-md">
          <DialogTitle className="sr-only">Receipt</DialogTitle>
          <DialogDescription className="sr-only">Receipt details</DialogDescription>
          {openId && (
            <ReceiptDetail key={openId} id={openId} onBack={() => setOpenId(null)} onOpen={setOpenId} />
          )}
        </DialogContent>
      </Dialog>
    </ReportShell>
  );
}
