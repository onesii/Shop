import { useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import ReportShell from "./_components/report-shell.tsx";
import KpiTabs from "./_components/kpi-tabs.tsx";
import SalesChart, { type ChartType } from "./_components/sales-chart.tsx";
import SummaryTable from "./_components/summary-table.tsx";
import { reportFilename, useReportFilters } from "./_lib/filters.ts";
import {
  groupRows,
  METRIC_LABELS,
  previousRange,
  rangeToIso,
  totals,
  type Granularity,
  type MetricKey,
} from "./_lib/summary.ts";

function SummarySkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-[420px] w-full" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}

export default function SalesSummaryPage() {
  const { range, hourWindow, employeeIds } = useReportFilters();
  const [metric, setMetric] = useState<MetricKey>("grossSalesCents");
  const [chartType, setChartType] = useState<ChartType>("area");
  const [granularity, setGranularity] = useState<Granularity>("days");

  const currentArgs = useMemo(() => ({ ...rangeToIso(range), ...(employeeIds ? { employeeIds } : {}) }), [range, employeeIds]);
  const previousArgs = useMemo(
    () => ({ ...rangeToIso(previousRange(range)), ...(employeeIds ? { employeeIds } : {}) }),
    [range, employeeIds],
  );
  const current = useQuery(api.reports.salesSummary.hourly, currentArgs);
  const previous = useQuery(api.reports.salesSummary.hourly, previousArgs);

  const data = useMemo(() => {
    if (!current || !previous) return null;
    return {
      totals: totals(current, hourWindow),
      previousTotals: totals(previous, hourWindow),
      buckets: groupRows(current, range, granularity, hourWindow),
    };
  }, [current, previous, range, granularity, hourWindow]);

  const filename = reportFilename("sales-summary", range);

  return (
    <ReportShell>
      {!data ? (
        <SummarySkeleton />
      ) : (
        <>
          <section className="overflow-hidden rounded-sm border bg-card shadow-xs">
            <KpiTabs
              current={data.totals}
              previous={data.previousTotals}
              selected={metric}
              onSelect={setMetric}
            />
            <div className="flex flex-wrap items-center justify-between gap-3 px-4 pt-5 md:px-6">
              <h2 className="text-lg font-medium">{METRIC_LABELS[metric]}</h2>
              <div className="flex gap-3">
                <Select value={chartType} onValueChange={(v) => setChartType(v as ChartType)}>
                  <SelectTrigger className="w-32" aria-label="Chart type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="area">Area</SelectItem>
                    <SelectItem value="bar">Bar</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={granularity} onValueChange={(v) => setGranularity(v as Granularity)}>
                  <SelectTrigger className="w-32" aria-label="Group by">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="days">Days</SelectItem>
                    <SelectItem value="weeks">Weeks</SelectItem>
                    <SelectItem value="months">Months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="px-2 pb-4 pt-2 md:px-4">
              <SalesChart
                buckets={data.buckets}
                metric={metric}
                label={METRIC_LABELS[metric]}
                type={chartType}
                granularity={granularity}
              />
            </div>
          </section>
          <SummaryTable buckets={data.buckets} filename={filename} />
        </>
      )}
    </ReportShell>
  );
}
