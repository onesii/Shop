import { useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { timecardError } from "@/convex/lib/timecards.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";

type EmployeeOption = { _id: Id<"employees"> | "owner"; name: string };

type Props = {
  card: Doc<"timecards"> | null;
  employees: EmployeeOption[];
  onDone: () => void;
};

// datetime-local works in the device's local time
const toLocalInput = (iso: string) => format(new Date(iso), "yyyy-MM-dd'T'HH:mm");
const fromLocalInput = (value: string) => new Date(value).toISOString();

const schema = z
  .object({
    employeeId: z.string().min(1, "Choose an employee"),
    clockIn: z.string().min(1, "Enter the clock in time"),
    clockOut: z.string(),
  })
  .superRefine((v, ctx) => {
    if (!v.clockIn) return;
    const error = timecardError(fromLocalInput(v.clockIn), v.clockOut ? fromLocalInput(v.clockOut) : null, Date.now());
    if (error) ctx.addIssue({ code: "custom", path: [v.clockOut ? "clockOut" : "clockIn"], message: error });
  });

type Values = z.infer<typeof schema>;

export default function TimecardForm({ card, employees, onDone }: Props) {
  const create = useMutation(api.staff.timecards.create);
  const update = useMutation(api.staff.timecards.update);
  const remove = useMutation(api.staff.timecards.remove);
  const form = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: {
      employeeId: card?.employeeId ?? employees[0]?._id ?? "",
      clockIn: card ? toLocalInput(card.clockIn) : "",
      clockOut: card?.clockOut ? toLocalInput(card.clockOut) : "",
    },
  });

  const submit = async (v: Values) => {
    try {
      if (card) {
        await update({
          id: card._id,
          clockIn: fromLocalInput(v.clockIn),
          clockOut: v.clockOut ? fromLocalInput(v.clockOut) : null,
        });
      } else {
        if (!v.clockOut) {
          form.setError("clockOut", { message: "Enter the clock out time" });
          return;
        }
        const employee = employees.find((e) => e._id === v.employeeId);
        if (!employee) return;
        await create({
          employeeId: employee._id,
          clockIn: fromLocalInput(v.clockIn),
          clockOut: fromLocalInput(v.clockOut),
        });
      }
      toast.success("Timecard saved");
      onDone();
    } catch (err) {
      toast.error(convexMessage(err, "Could not save timecard"));
    }
  };

  const del = async () => {
    if (!card) return;
    try {
      await remove({ id: card._id });
      toast.success("Timecard deleted");
      onDone();
    } catch (err) {
      toast.error(convexMessage(err, "Could not delete timecard"));
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(submit)} className="space-y-4">
        {card ? (
          <p className="text-sm font-medium">{card.employeeName}</p>
        ) : (
          <FormField
            control={form.control}
            name="employeeId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Employee</FormLabel>
                <Select value={field.value} onValueChange={field.onChange}>
                  <FormControl>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Choose an employee" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {employees.map((e) => (
                      <SelectItem key={e._id} value={e._id}>
                        {e.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="clockIn"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Clock in</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="clockOut"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Clock out</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                {card && <FormDescription>Leave empty while still working.</FormDescription>}
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="flex items-center justify-between gap-2 pt-2">
          {card ? (
            <Button type="button" variant="ghost" className="text-destructive" onClick={() => void del()}>
              <Trash2 className="size-4" /> Delete
            </Button>
          ) : (
            <span />
          )}
          <div className="flex gap-2">
            <Button type="button" variant="ghost" onClick={onDone}>
              Cancel
            </Button>
            <Button type="submit" disabled={form.formState.isSubmitting}>
              Save
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
