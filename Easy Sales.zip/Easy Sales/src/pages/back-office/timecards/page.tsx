import { useMemo, useState } from "react";
import { usePaginatedQuery } from "convex/react";
import { format } from "date-fns";
import { Plus, Timer } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { formatHours, workedMinutes } from "@/convex/lib/timecards.ts";
import { Button } from "@/components/ui/button.tsx";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import ReportShell from "../_components/report-shell.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { useEmployeeOptions } from "../_components/employee-filter.tsx";
import { reportFilename, useReportFilters } from "../_lib/filters.ts";
import { rangeToIso } from "../_lib/summary.ts";
import TimecardForm from "./_components/timecard-form.tsx";

type Row = Doc<"timecards">;

const PAGE = 50;
const dateTime = (iso: string) => format(new Date(iso), "MMM d, yyyy h:mm a");

const COLUMNS: Column<Row>[] = [
  {
    key: "employee",
    label: "Employee",
    fixed: true,
    render: (r) => <span className="font-medium">{r.employeeName}</span>,
    csv: (r) => r.employeeName,
  },
  { key: "in", label: "Clock in", render: (r) => dateTime(r.clockIn), csv: (r) => dateTime(r.clockIn) },
  {
    key: "out",
    label: "Clock out",
    render: (r) => (r.clockOut ? dateTime(r.clockOut) : <span className="font-medium text-primary">Working</span>),
    csv: (r) => (r.clockOut ? dateTime(r.clockOut) : ""),
  },
  {
    key: "hours",
    label: "Total hours",
    numeric: true,
    render: (r) => (r.clockOut ? formatHours(workedMinutes(r.clockIn, r.clockOut)) : "-"),
    csv: (r) => (r.clockOut ? (workedMinutes(r.clockIn, r.clockOut) / 60).toFixed(2) : ""),
  },
];

export default function TimecardsPage() {
  const { range, employeeIds } = useReportFilters();
  const employees = useEmployeeOptions();
  const [editing, setEditing] = useState<Row | "new" | null>(null);
  const args = useMemo(() => ({ ...rangeToIso(range), ...(employeeIds ? { employeeIds } : {}) }), [range, employeeIds]);
  const { results, status, loadMore } = usePaginatedQuery(api.staff.timecards.list, args, { initialNumItems: PAGE });

  return (
    <ReportShell showHours={false}>
      <div>
        <Button className="h-11" disabled={!employees?.length} onClick={() => setEditing("new")}>
          <Plus className="size-4" /> Add timecard
        </Button>
      </div>
      <ReportTable
        columns={COLUMNS}
        rows={status === "LoadingFirstPage" ? undefined : results}
        rowKey={(r) => r._id}
        filename={reportFilename("timecards", range)}
        onRowClick={(r) => setEditing(r)}
        empty={{
          icon: Timer,
          title: "No timecards",
          description: "Employees clock in and out from the POS menu.",
        }}
        after={
          status === "CanLoadMore" || status === "LoadingMore" ? (
            <div className="border-t p-4">
              <Button
                variant="secondary"
                className="w-full"
                disabled={status === "LoadingMore"}
                onClick={() => loadMore(PAGE)}
              >
                {status === "LoadingMore" ? "Loading..." : "Load more"}
              </Button>
            </div>
          ) : null
        }
      />
      <Dialog open={editing !== null} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing === "new" ? "Add timecard" : "Edit timecard"}</DialogTitle>
            <DialogDescription>Times are in your local time zone</DialogDescription>
          </DialogHeader>
          {editing !== null && (
            <TimecardForm
              key={editing === "new" ? "new" : editing._id}
              card={editing === "new" ? null : editing}
              employees={employees ?? []}
              onDone={() => setEditing(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </ReportShell>
  );
}
