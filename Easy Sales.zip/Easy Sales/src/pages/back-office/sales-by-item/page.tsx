import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Package } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { formatKsh } from "@/lib/money.ts";
import ReportShell from "../_components/report-shell.tsx";
import { TruncatedNotice } from "../_components/report-stats.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { reportArgs, reportFilename, useReportFilters } from "../_lib/filters.ts";
import { money, sumBy } from "../_lib/columns.ts";

type Row = {
  itemKey: string;
  name: string;
  variantName: string | null;
  categoryName: string;
  itemsSold: number;
  itemsRefunded: number;
  grossSalesCents: number;
  refundsCents: number;
  discountsCents: number;
  netSalesCents: number;
};

const COLUMNS: Column<Row>[] = [
  {
    key: "item",
    label: "Item",
    fixed: true,
    render: (r) => (
      <span className="font-medium">
        {r.name}
        {r.variantName && <span className="text-muted-foreground"> ({r.variantName})</span>}
      </span>
    ),
    csv: (r) => (r.variantName ? `${r.name} (${r.variantName})` : r.name),
  },
  { key: "category", label: "Category", render: (r) => r.categoryName, csv: (r) => r.categoryName },
  { key: "sold", label: "Items sold", numeric: true, render: (r) => r.itemsSold, csv: (r) => r.itemsSold },
  {
    key: "refunded",
    label: "Items refunded",
    numeric: true,
    render: (r) => r.itemsRefunded,
    csv: (r) => r.itemsRefunded,
  },
  money<Row>("gross", "Gross sales", (r) => r.grossSalesCents),
  money<Row>("refunds", "Refunds", (r) => r.refundsCents),
  money<Row>("discounts", "Discounts", (r) => r.discountsCents),
  money<Row>("net", "Net sales", (r) => r.netSalesCents),
];

export default function SalesByItemPage() {
  const { range, hourWindow, employeeIds } = useReportFilters();
  const args = useMemo(() => reportArgs(range, hourWindow, employeeIds), [range, hourWindow, employeeIds]);
  const data = useQuery(api.reports.salesReports.byItem, args);
  const categories = useQuery(api.catalog.categories.list, {});

  const rows = useMemo<Row[] | undefined>(() => {
    if (!data || !categories) return undefined;
    const names = new Map(categories.map((c) => [c._id, c.name]));
    return data.items.map((i) => ({
      ...i,
      categoryName: (i.categoryId && names.get(i.categoryId)) || "No category",
    }));
  }, [data, categories]);

  const footer = rows && {
    item: "Total",
    sold: sumBy(rows, (r) => r.itemsSold),
    refunded: sumBy(rows, (r) => r.itemsRefunded),
    gross: formatKsh(sumBy(rows, (r) => r.grossSalesCents)),
    refunds: formatKsh(sumBy(rows, (r) => r.refundsCents)),
    discounts: formatKsh(sumBy(rows, (r) => r.discountsCents)),
    net: formatKsh(sumBy(rows, (r) => r.netSalesCents)),
  };

  return (
    <ReportShell>
      <ReportTable
        columns={COLUMNS}
        rows={rows}
        rowKey={(r) => r.itemKey}
        filename={reportFilename("sales-by-item", range)}
        footer={footer}
        notice={<TruncatedNotice show={data?.truncated ?? false} />}
        empty={{ icon: Package, title: "No item sales", description: "No items were sold in this period." }}
      />
    </ReportShell>
  );
}
