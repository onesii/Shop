import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { PERMISSIONS, type AccessRights, type Permission, type StaffRole } from "@/convex/lib/access.ts";
import { useStaff } from "@/hooks/use-staff.tsx";
import { convexMessage } from "@/lib/errors.ts";
import { PERMISSION_INFO, ROLE_LABELS } from "@/lib/staff.ts";
import { Button } from "@/components/ui/button.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

const ROLES: StaffRole[] = ["manager", "cashier"];

function RightsEditor({ initial }: { initial: AccessRights }) {
  const { role } = useStaff();
  const update = useMutation(api.staff.accessRights.update);
  const [rights, setRights] = useState<AccessRights>(initial);
  const [busy, setBusy] = useState(false);
  const readOnly = role !== "owner";
  const dirty = ROLES.some((r) => rights[r].join() !== initial[r].join());

  const toggle = (r: StaffRole, p: Permission, on: boolean) =>
    setRights((cur) => ({
      ...cur,
      [r]: PERMISSIONS.filter((x) => (x === p ? on : cur[r].includes(x))),
    }));

  const save = async () => {
    setBusy(true);
    try {
      await update(rights);
      toast.success("Access rights saved");
    } catch (err) {
      toast.error(convexMessage(err, "Could not save access rights"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <section className="overflow-hidden rounded-sm border bg-card shadow-xs">
        <div className="grid grid-cols-[1fr_auto_auto] items-center gap-x-4 border-b px-4 py-3 text-sm font-semibold sm:gap-x-10">
          <span>Permission</span>
          {ROLES.map((r) => (
            <span key={r} className="w-16 text-center">
              {ROLE_LABELS[r]}
            </span>
          ))}
        </div>
        {PERMISSIONS.map((p) => (
          <div
            key={p}
            className="grid grid-cols-[1fr_auto_auto] items-center gap-x-4 border-b px-4 py-4 last:border-b-0 sm:gap-x-10"
          >
            <div className="min-w-0">
              <p className="text-sm font-medium">{PERMISSION_INFO[p].label}</p>
              <p className="text-xs text-muted-foreground">{PERMISSION_INFO[p].description}</p>
            </div>
            {ROLES.map((r) => (
              <div key={r} className="flex w-16 justify-center">
                <Switch
                  checked={rights[r].includes(p)}
                  disabled={readOnly}
                  onCheckedChange={(on) => toggle(r, p, on)}
                  aria-label={`${ROLE_LABELS[r]}: ${PERMISSION_INFO[p].label}`}
                />
              </div>
            ))}
          </div>
        ))}
      </section>
      <p className="text-sm text-muted-foreground">
        The owner can always do everything. Everyone can make sales, open shifts, use open tickets and clock in.
      </p>
      {readOnly ? (
        <p className="text-sm text-muted-foreground">Only the owner can change access rights.</p>
      ) : (
        <div className="flex justify-end gap-2">
          <Button variant="ghost" disabled={!dirty || busy} onClick={() => setRights(initial)}>
            Reset
          </Button>
          <Button disabled={!dirty || busy} onClick={() => void save()}>
            Save
          </Button>
        </div>
      )}
    </div>
  );
}

export default function AccessRightsPage() {
  const rights = useQuery(api.staff.accessRights.get, {});
  return (
    <div className="mx-auto w-full max-w-3xl space-y-4 p-4 pb-12 md:p-6">
      {rights === undefined ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-14 w-full" />
          ))}
        </div>
      ) : (
        <RightsEditor key={JSON.stringify(rights)} initial={rights} />
      )}
    </div>
  );
}
