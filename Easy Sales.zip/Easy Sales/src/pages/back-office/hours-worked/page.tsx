import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Timer } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { formatHours } from "@/convex/lib/timecards.ts";
import ReportShell from "../_components/report-shell.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { reportFilename, useReportFilters } from "../_lib/filters.ts";
import { rangeToIso } from "../_lib/summary.ts";

type Row = { employeeId: string; name: string; minutes: number; cards: number };

const COLUMNS: Column<Row>[] = [
  {
    key: "name",
    label: "Employee",
    fixed: true,
    render: (r) => <span className="font-medium">{r.name}</span>,
    csv: (r) => r.name,
  },
  { key: "cards", label: "Timecards", numeric: true, render: (r) => r.cards, csv: (r) => r.cards },
  {
    key: "hours",
    label: "Total hours",
    numeric: true,
    render: (r) => formatHours(r.minutes),
    csv: (r) => (r.minutes / 60).toFixed(2),
  },
];

export default function HoursWorkedPage() {
  const { range, employeeIds } = useReportFilters();
  const args = useMemo(() => ({ ...rangeToIso(range), ...(employeeIds ? { employeeIds } : {}) }), [range, employeeIds]);
  const data = useQuery(api.staff.timecards.totals, args);
  const total = data?.rows.reduce((s, r) => s + r.minutes, 0) ?? 0;

  return (
    <ReportShell showHours={false}>
      <ReportTable
        columns={COLUMNS}
        rows={data?.rows}
        rowKey={(r) => r.employeeId}
        filename={reportFilename("hours-worked", range)}
        empty={{ icon: Timer, title: "No hours worked", description: "No timecards were closed in this period." }}
        footer={data && data.rows.length > 0 ? { name: "Total", hours: formatHours(total) } : undefined}
        notice={
          data?.truncated ? (
            <p className="border-b px-4 py-2 text-xs text-muted-foreground">
              Showing the first 5,000 timecards. Choose a shorter period for exact totals.
            </p>
          ) : null
        }
      />
      <p className="text-xs text-muted-foreground">Hours count once an employee clocks out.</p>
    </ReportShell>
  );
}
