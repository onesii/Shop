import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Coins } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { rowValue, valuationTotals, type RowValue } from "@/convex/lib/valuation.ts";
import { formatKsh } from "@/lib/money.ts";
import { stockLabel } from "@/lib/stock.ts";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import StatCards from "../_components/stat-cards.tsx";
import { money } from "../_lib/columns.ts";

type Row = {
  stockLevelId: string;
  itemName: string;
  variantName: string | null;
  inStock: number;
  costCents: number | null;
  priceCents: number | null;
} & RowValue;

const pct = (n: number | null) => (n === null ? "-" : `${n.toFixed(2)}%`);
const centsOrDash = (n: number | null) => (n === null ? "-" : formatKsh(n));

const COLUMNS: Column<Row>[] = [
  {
    key: "item",
    label: "Item",
    fixed: true,
    render: (r) => <span className="font-medium">{stockLabel(r.variantName, r.itemName)}</span>,
    csv: (r) => stockLabel(r.variantName, r.itemName),
  },
  { key: "inStock", label: "In stock", numeric: true, render: (r) => r.inStock, csv: (r) => r.inStock },
  {
    key: "cost",
    label: "Cost",
    numeric: true,
    render: (r) => centsOrDash(r.costCents),
    csv: (r) => (r.costCents === null ? "" : (r.costCents / 100).toFixed(2)),
  },
  money<Row>("inventory", "Inventory value", (r) => r.inventoryCents),
  money<Row>("retail", "Retail value", (r) => r.retailCents),
  money<Row>("profit", "Potential profit", (r) => r.profitCents),
  { key: "margin", label: "Margin", numeric: true, render: (r) => pct(r.marginPct), csv: (r) => pct(r.marginPct) },
];

export default function InventoryValuationPage() {
  const data = useQuery(api.inventory.stock.valuation, {});
  const rows = useMemo<Row[] | undefined>(
    () => (data === undefined ? undefined : (data?.rows ?? []).map((r) => ({ ...r, ...rowValue(r) }))),
    [data],
  );
  const totals = valuationTotals(data?.rows ?? []);
  const missingCost = rows?.filter((r) => r.costCents === null && r.inStock > 0).length ?? 0;

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <StatCards
        cards={[
          { label: "Total inventory value", value: rows ? formatKsh(totals.inventoryCents) : "-" },
          { label: "Total retail value", value: rows ? formatKsh(totals.retailCents) : "-" },
          { label: "Potential profit", value: rows ? formatKsh(totals.profitCents) : "-" },
          { label: "Margin", value: rows ? pct(totals.marginPct) : "-" },
        ]}
      />
      <ReportTable
        columns={COLUMNS}
        rows={rows}
        rowKey={(r) => r.stockLevelId}
        filename="inventory-valuation.csv"
        footer={
          rows && {
            item: "Total",
            inventory: formatKsh(totals.inventoryCents),
            retail: formatKsh(totals.retailCents),
            profit: formatKsh(totals.profitCents),
            margin: pct(totals.marginPct),
          }
        }
        notice={
          (missingCost > 0 || data?.truncated) && (
            <div className="space-y-1 border-b bg-muted/50 px-4 py-3 text-sm text-muted-foreground">
              {missingCost > 0 && (
                <p>
                  {missingCost} {missingCost === 1 ? "item has" : "items have"} no cost yet. Cost comes from the last
                  received purchase order.
                </p>
              )}
              {data?.truncated && <p>Showing the first 1,000 items.</p>}
            </div>
          )
        }
        empty={{
          icon: Coins,
          title: "No items track stock yet",
          description: 'Open an item in Items and turn on "Track stock" to see its value here.',
        }}
      />
    </div>
  );
}
