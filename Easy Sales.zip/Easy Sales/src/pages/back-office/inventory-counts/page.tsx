import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { usePaginatedQuery, useQuery } from "convex/react";
import { format } from "date-fns";
import { ClipboardCheck, Plus } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import {
  COUNT_STATUS_LABELS,
  COUNT_TYPE_LABELS,
  formatCountNumber,
  type CountStatus,
} from "@/convex/lib/inventoryCounts.ts";
import { Button } from "@/components/ui/button.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { CountStatusText } from "./_components/count-status.tsx";

type Row = {
  _id: string;
  number: number;
  type: "partial" | "full";
  status: CountStatus;
  notes: string;
  createdAt: string;
  completedAt: string | null;
  itemCount: number;
  countedCount: number;
};

const PAGE = 25;
const STATUSES = Object.keys(COUNT_STATUS_LABELS) as CountStatus[];
const when = (iso: string) => format(new Date(iso), "MMM d, yyyy");

function columns(storeName: string): Column<Row>[] {
  return [
    { key: "number", label: "Inventory count #", fixed: true, render: (r) => formatCountNumber(r.number), csv: (r) => formatCountNumber(r.number) },
    { key: "created", label: "Created", render: (r) => when(r.createdAt), csv: (r) => r.createdAt },
    { key: "completed", label: "Completed", render: (r) => (r.completedAt ? when(r.completedAt) : "-"), csv: (r) => r.completedAt ?? "" },
    { key: "store", label: "Store", render: () => storeName, csv: () => storeName },
    { key: "type", label: "Type", render: (r) => COUNT_TYPE_LABELS[r.type], csv: (r) => COUNT_TYPE_LABELS[r.type] },
    {
      key: "notes",
      label: "Notes",
      render: (r) => <span className="line-clamp-1 max-w-56">{r.notes || "-"}</span>,
      csv: (r) => r.notes,
    },
    { key: "status", label: "Status", fixed: true, render: (r) => <CountStatusText status={r.status} />, csv: (r) => COUNT_STATUS_LABELS[r.status] },
  ];
}

export default function InventoryCountsPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<CountStatus | "all">("all");
  const settings = useQuery(api.settings.get, {});
  const { results, status: loadStatus, loadMore } = usePaginatedQuery(
    api.inventory.inventoryCounts.list,
    { status: status === "all" ? undefined : status },
    { initialNumItems: PAGE },
  );

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-4 rounded-sm bg-card p-4 shadow-xs">
        <Button className="h-10 uppercase" onClick={() => navigate("/back-office/inventory-counts/new")}>
          <Plus className="size-4" /> Add inventory count
        </Button>
        <div className="w-44 space-y-1">
          <Label className="text-xs font-normal text-muted-foreground">Status</Label>
          <Select value={status} onValueChange={(v) => setStatus(STATUSES.find((s) => s === v) ?? "all")}>
            <SelectTrigger className="w-full cursor-pointer">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              {STATUSES.map((s) => (
                <SelectItem key={s} value={s}>{COUNT_STATUS_LABELS[s]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <ReportTable
        columns={columns(settings?.storeName || "My store")}
        rows={loadStatus === "LoadingFirstPage" ? undefined : results}
        rowKey={(r) => r._id}
        filename="inventory-counts.csv"
        onRowClick={(r) => navigate(`/back-office/inventory-counts/${r._id}`)}
        empty={
          status !== "all"
            ? { icon: ClipboardCheck, title: "No matching inventory counts", description: "Try another status." }
            : {
                icon: ClipboardCheck,
                title: "No inventory counts yet",
                description: "Count what's on your shelves and fix your stock numbers in one go.",
              }
        }
        after={
          loadStatus === "CanLoadMore" || loadStatus === "LoadingMore" ? (
            <div className="border-t p-4">
              <Button variant="secondary" className="w-full" disabled={loadStatus === "LoadingMore"} onClick={() => loadMore(PAGE)}>
                {loadStatus === "LoadingMore" ? "Loading..." : "Load more"}
              </Button>
            </div>
          ) : null
        }
      />
    </div>
  );
}
