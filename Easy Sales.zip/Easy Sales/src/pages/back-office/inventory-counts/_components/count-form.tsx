import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { COUNT_TYPE_LABELS, MAX_COUNT_LINES, MAX_COUNT_NOTES, type CountType } from "@/convex/lib/inventoryCounts.ts";
import { convexMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import ItemSearch, { levelLabel } from "../../purchase-orders/_components/item-search.tsx";

type Props = { onDone: (id?: Id<"inventoryCounts">) => void };

const TYPE_HINTS: Record<CountType, string> = {
  partial: "Count only the items you pick",
  full: "Count every item that tracks stock",
};

/** "Create inventory count": store, type, notes and (for partial counts) the items to count. */
export default function CountForm({ onDone }: Props) {
  const levels = useQuery(api.inventory.stock.listAll, {});
  const settings = useQuery(api.settings.get, {});
  const create = useMutation(api.inventory.inventoryCounts.create);
  const [type, setType] = useState<CountType>("partial");
  const [notes, setNotes] = useState("");
  const [picked, setPicked] = useState<Id<"stockLevels">[]>([]);
  const [saving, setSaving] = useState(false);

  if (levels === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  const byId = new Map(levels.map((l) => [l._id, l]));
  const pickedSet = new Set(picked);

  const submit = async () => {
    if (type === "partial" && picked.length === 0) return toast.error("Add at least one item to count");
    if (type === "full" && levels.length === 0) return toast.error('No items track stock yet. Turn on "Track stock" first.');
    setSaving(true);
    try {
      const id = await create({ type, notes, stockLevelIds: type === "partial" ? picked : [] });
      toast.success("Inventory count created");
      onDone(id);
    } catch (err) {
      toast.error(convexMessage(err, "Could not create the inventory count"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <section className="space-y-5 rounded-sm bg-card p-6 shadow-xs">
        <div className="space-y-1">
          <Label className="text-xs font-normal text-muted-foreground">Store</Label>
          <div className="flex h-9 items-center border-b text-sm">{settings?.storeName || "My store"}</div>
        </div>
        <div className="space-y-2">
          <Label className="text-xs font-normal text-muted-foreground">Type</Label>
          <div className="grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Type">
            {(["partial", "full"] as const).map((t) => (
              <button
                key={t}
                type="button"
                role="radio"
                aria-checked={type === t}
                onClick={() => setType(t)}
                className={cn(
                  "flex cursor-pointer items-start gap-3 rounded-sm border p-3 text-left transition",
                  type === t ? "border-primary bg-accent" : "hover:bg-muted",
                )}
              >
                <span
                  className={cn(
                    "mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-full border-2",
                    type === t ? "border-primary" : "border-muted-foreground/50",
                  )}
                >
                  {type === t && <span className="size-2 rounded-full bg-primary" />}
                </span>
                <span>
                  <span className="block text-sm font-medium">{COUNT_TYPE_LABELS[t]}</span>
                  <span className="block text-xs text-muted-foreground">{TYPE_HINTS[t]}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-1">
          <Label htmlFor="count-notes" className="text-xs font-normal text-muted-foreground">Notes</Label>
          <Textarea id="count-notes" value={notes} maxLength={MAX_COUNT_NOTES} onChange={(e) => setNotes(e.target.value)} className="min-h-16" />
          <p className="text-right text-xs text-muted-foreground">{notes.length} / {MAX_COUNT_NOTES}</p>
        </div>
      </section>

      {type === "partial" ? (
        <section className="rounded-sm bg-card px-6 pb-4 shadow-xs">
          <div className="flex items-center justify-between pt-5">
            <h2 className="text-lg font-medium">Items</h2>
            {levels.length > picked.length && (
              <button
                type="button"
                onClick={() => setPicked(levels.slice(0, MAX_COUNT_LINES).map((l) => l._id))}
                className="cursor-pointer text-sm font-semibold uppercase text-primary"
              >
                Add all items
              </button>
            )}
          </div>
          <ul className="divide-y border-b">
            {picked.map((id) => {
              const level = byId.get(id);
              return (
                <li key={id} className="flex items-center gap-3 py-2 text-sm">
                  <span className="min-w-0 flex-1 truncate">{level ? levelLabel(level) : "Item no longer tracks stock"}</span>
                  <span className="text-xs text-muted-foreground">In stock: {level?.inStock ?? "-"}</span>
                  <button
                    type="button"
                    aria-label="Remove item"
                    onClick={() => setPicked((p) => p.filter((x) => x !== id))}
                    className="cursor-pointer p-1 text-muted-foreground hover:text-foreground"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              );
            })}
          </ul>
          {picked.length < MAX_COUNT_LINES && (
            <ItemSearch levels={levels} exclude={pickedSet} onPick={(l) => setPicked((p) => [...p, l._id])} />
          )}
        </section>
      ) : (
        <section className="rounded-sm bg-card p-6 text-sm text-muted-foreground shadow-xs">
          All {levels.length} {levels.length === 1 ? "item" : "items"} that track stock will be added to this count.
        </section>
      )}

      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="ghost" className="border bg-card uppercase" onClick={() => onDone()}>Cancel</Button>
        <Button className="uppercase" disabled={saving} onClick={() => void submit()}>
          {saving && <Spinner />} Create
        </Button>
      </div>
    </div>
  );
}
