import { useMemo, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { countTotals, lineDifference, MAX_COUNT_LINES, MAX_COUNT_NOTES } from "@/convex/lib/inventoryCounts.ts";
import { formatKsh } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import ItemSearch, { levelLabel } from "../../purchase-orders/_components/item-search.tsx";
import { DiffText } from "./count-status.tsx";

type Count = Doc<"inventoryCounts">;
type Draft = {
  stockLevelId: Id<"stockLevels">;
  itemName: string;
  variantName: string | null;
  expected: number | null;
  costCents: number;
  counted: string;
};

const cellInput =
  "ml-auto h-9 w-20 rounded-none border-0 border-b border-foreground/20 bg-transparent px-1 text-right shadow-none focus-visible:border-primary focus-visible:ring-0 dark:bg-transparent";

const toDraft = (l: Count["lines"][number]): Draft => ({
  stockLevelId: l.stockLevelId,
  itemName: l.itemName,
  variantName: l.variantName,
  expected: l.expected,
  costCents: l.costCents ?? 0,
  counted: l.counted === null ? "" : String(l.counted),
});

const parseCounted = (s: string) => (s.trim() === "" ? null : Number(s));

type Props = { count: Count; onDeleted: () => void };

/** The counting sheet of an open count: enter what's on the shelf, save, then complete. */
export default function CountSheet({ count, onDeleted }: Props) {
  const levels = useQuery(api.inventory.stock.listAll, count.type === "partial" ? {} : "skip");
  const save = useMutation(api.inventory.inventoryCounts.save);
  const complete = useMutation(api.inventory.inventoryCounts.complete);
  const remove = useMutation(api.inventory.inventoryCounts.remove);
  const [lines, setLines] = useState<Draft[]>(() => count.lines.map(toDraft));
  const [notes, setNotes] = useState(count.notes);
  const [filter, setFilter] = useState("");
  const [busy, setBusy] = useState<"save" | "complete" | "delete" | null>(null);
  const [confirm, setConfirm] = useState<"complete" | "delete" | null>(null);

  // Expected stock is live until completion, so read it from the latest query result
  const live = useMemo(() => new Map(count.lines.map((l) => [l.stockLevelId, l])), [count.lines]);
  const levelById = useMemo(() => new Map((levels ?? []).map((l) => [l._id, l])), [levels]);
  const expectedOf = (d: Draft) => live.get(d.stockLevelId)?.expected ?? levelById.get(d.stockLevelId)?.inStock ?? d.expected;
  const costOf = (d: Draft) => live.get(d.stockLevelId)?.costCents ?? levelById.get(d.stockLevelId)?.lastCostCents ?? d.costCents;

  const parsed = lines.map((d) => ({ counted: parseCounted(d.counted), expected: expectedOf(d), costCents: costOf(d) }));
  const totals = countTotals(parsed);
  const q = filter.trim().toLowerCase();
  const visible = lines.map((d, i) => ({ d, i })).filter(({ d }) => !q || levelLabel(d).toLowerCase().includes(q));

  const payload = () => ({
    id: count._id,
    notes,
    lines: lines.map((d) => ({ stockLevelId: d.stockLevelId, counted: parseCounted(d.counted) })),
  });

  const run = async (kind: "save" | "complete" | "delete") => {
    setBusy(kind);
    try {
      if (kind === "delete") {
        await remove({ id: count._id });
        toast.success("Inventory count deleted");
        onDeleted();
      } else if (kind === "save") {
        await save(payload());
        toast.success("Count saved");
      } else {
        await complete(payload());
        toast.success("Inventory count completed. Stock updated.");
      }
      setConfirm(null);
    } catch (err) {
      toast.error(convexMessage(err, "Something went wrong. Try again."));
    } finally {
      setBusy(null);
    }
  };

  const tryComplete = () => {
    if (totals.counted === 0) return toast.error("Enter the counted stock for at least one item");
    setConfirm("complete");
  };

  const setCounted = (i: number, value: string) =>
    setLines((ls) => ls.map((l, j) => (j === i ? { ...l, counted: value.replace(/\D/g, "") } : l)));

  const uncounted = lines.length - totals.counted;

  return (
    <>
      <section className="space-y-1 rounded-sm bg-card p-6 shadow-xs">
        <Label htmlFor="count-notes" className="text-xs font-normal text-muted-foreground">Notes</Label>
        <Textarea id="count-notes" value={notes} maxLength={MAX_COUNT_NOTES} onChange={(e) => setNotes(e.target.value)} className="min-h-14" />
      </section>

      <section className="rounded-sm bg-card shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 pt-5">
          <h2 className="text-lg font-medium">Items</h2>
          <div className="flex items-center gap-2 border-b">
            <Search className="size-4 text-muted-foreground" />
            <input
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder="Find item"
              aria-label="Find item"
              className="h-9 w-40 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>
        </div>
        <div className="overflow-x-auto px-6 pb-2">
          <table className="w-full min-w-[600px] text-sm">
            <thead>
              <tr className="border-b text-xs text-muted-foreground">
                <th className="py-3 text-left font-normal">Item</th>
                <th className="w-24 py-3 text-right font-normal">Expected stock</th>
                <th className="w-24 py-3 text-right font-normal">Counted</th>
                <th className="w-24 py-3 text-right font-normal">Difference</th>
                <th className="w-32 py-3 text-right font-normal">Cost difference</th>
                {count.type === "partial" && <th className="w-10" />}
              </tr>
            </thead>
            <tbody>
              {visible.map(({ d, i }) => {
                const expected = expectedOf(d);
                const diff = expected === null ? null : lineDifference(parseCounted(d.counted), expected);
                return (
                  <tr key={d.stockLevelId} className="border-b">
                    <td className="py-2 pr-2">
                      {levelLabel(d)}
                      {expected === null && <span className="block text-xs text-destructive">No longer tracks stock</span>}
                    </td>
                    <td className="py-2 text-right tabular-nums">{expected ?? "-"}</td>
                    <td className="py-2 text-right">
                      <Input
                        aria-label={`Counted ${d.itemName}`}
                        inputMode="numeric"
                        value={d.counted}
                        onChange={(e) => setCounted(i, e.target.value)}
                        className={cellInput}
                      />
                    </td>
                    <td className="py-2 text-right"><DiffText value={diff} /></td>
                    <td className="py-2 text-right">
                      <DiffText value={diff}>{diff === null ? null : formatKsh(diff * costOf(d))}</DiffText>
                    </td>
                    {count.type === "partial" && (
                      <td className="py-2 text-right">
                        <button
                          type="button"
                          aria-label="Remove item"
                          onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))}
                          className="cursor-pointer p-1 text-muted-foreground hover:text-foreground"
                        >
                          <Trash2 className="size-4" />
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
          {visible.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">No items match "{filter}"</p>}
          {count.type === "partial" && levels && lines.length < MAX_COUNT_LINES && (
            <ItemSearch
              levels={levels}
              exclude={new Set(lines.map((l) => l.stockLevelId))}
              onPick={(l) =>
                setLines((ls) => [
                  ...ls,
                  { stockLevelId: l._id, itemName: l.itemName, variantName: l.variantName, expected: l.inStock, costCents: l.lastCostCents ?? 0, counted: "" },
                ])
              }
            />
          )}
          <div className="flex flex-wrap justify-end gap-x-10 gap-y-1 py-4 text-sm">
            <span className="text-muted-foreground">Counted {totals.counted} of {lines.length}</span>
            <span>Difference <DiffText value={totals.counted ? totals.differenceQty : null} /></span>
            <span className="font-semibold">
              Cost difference{" "}
              <DiffText value={totals.counted ? totals.costDifferenceCents : null}>{formatKsh(totals.costDifferenceCents)}</DiffText>
            </span>
          </div>
        </div>
      </section>

      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="ghost" className="mr-auto border bg-card uppercase" disabled={busy !== null} onClick={() => setConfirm("delete")}>
          <Trash2 className="size-4" /> Delete
        </Button>
        <Button variant="ghost" className="border bg-card uppercase" disabled={busy !== null} onClick={() => void run("save")}>
          {busy === "save" && <Spinner />} Save
        </Button>
        <Button className="uppercase" disabled={busy !== null} onClick={tryComplete}>Complete</Button>
      </div>

      <Dialog open={confirm !== null} onOpenChange={(o) => !o && setConfirm(null)}>
        <DialogContent className="sm:max-w-sm">
          {confirm === "complete" ? (
            <DialogHeader>
              <DialogTitle>Complete inventory count?</DialogTitle>
              <DialogDescription>
                Stock will be set to the counted numbers.
                {uncounted > 0 && ` ${uncounted} uncounted ${uncounted === 1 ? "item keeps its" : "items keep their"} current stock.`}{" "}
                This can't be undone.
              </DialogDescription>
            </DialogHeader>
          ) : (
            <DialogHeader>
              <DialogTitle>Delete inventory count?</DialogTitle>
              <DialogDescription>The count will be removed. Your stock won't change.</DialogDescription>
            </DialogHeader>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirm(null)}>Cancel</Button>
            {confirm === "complete" ? (
              <Button disabled={busy !== null} onClick={() => void run("complete")}>{busy === "complete" && <Spinner />} Complete</Button>
            ) : (
              <Button variant="destructive" disabled={busy !== null} onClick={() => void run("delete")}>
                {busy === "delete" && <Spinner />} Delete
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
