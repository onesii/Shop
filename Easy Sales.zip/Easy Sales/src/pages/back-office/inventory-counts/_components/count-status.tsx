import { COUNT_STATUS_LABELS, type CountStatus } from "@/convex/lib/inventoryCounts.ts";
import { cn } from "@/lib/utils.ts";

const STATUS_CLASS: Record<CountStatus, string> = {
  pending: "text-amber-600 dark:text-amber-400",
  in_progress: "text-primary",
  completed: "text-muted-foreground",
};

export function CountStatusText({ status }: { status: CountStatus }) {
  return <span className={cn("text-sm", STATUS_CLASS[status])}>{COUNT_STATUS_LABELS[status]}</span>;
}

/** "+3" / "-2" / "0", colored like the stock history. */
export function DiffText({ value, children }: { value: number | null; children?: React.ReactNode }) {
  if (value === null) return <span className="text-muted-foreground">-</span>;
  return (
    <span className={cn("tabular-nums", value > 0 ? "text-primary" : value < 0 && "text-destructive")}>
      {children ?? (value > 0 ? `+${value}` : value)}
    </span>
  );
}
