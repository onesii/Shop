import { useNavigate, useParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { format } from "date-fns";
import { ClipboardCheck } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { COUNT_TYPE_LABELS, countTotals, formatCountNumber, lineDifference } from "@/convex/lib/inventoryCounts.ts";
import { formatKsh } from "@/lib/money.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyContent, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import { levelLabel } from "../../purchase-orders/_components/item-search.tsx";
import CountForm from "../_components/count-form.tsx";
import CountSheet from "../_components/count-sheet.tsx";
import { CountStatusText, DiffText } from "../_components/count-status.tsx";

const LIST = "/back-office/inventory-counts";
const when = (iso: string) => format(new Date(iso), "MMM d, yyyy · h:mm a");

function Shell({ children }: { children: React.ReactNode }) {
  return <div className="mx-auto w-full max-w-4xl space-y-4 p-4 pb-12 md:p-6">{children}</div>;
}

export default function InventoryCountPage() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  if (id === "new") {
    return (
      <Shell>
        <CountForm onDone={(countId) => navigate(countId ? `${LIST}/${countId}` : LIST)} />
      </Shell>
    );
  }
  return <CountView id={id} />;
}

function CountView({ id }: { id: string }) {
  const navigate = useNavigate();
  const count = useQuery(api.inventory.inventoryCounts.get, { id });
  const settings = useQuery(api.settings.get, {});

  if (count === undefined) {
    return (
      <Shell>
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </Shell>
    );
  }
  if (count === null) {
    return (
      <Shell>
        <Empty className="pt-16">
          <EmptyHeader>
            <EmptyMedia variant="icon"><ClipboardCheck /></EmptyMedia>
            <EmptyTitle>Inventory count not found</EmptyTitle>
          </EmptyHeader>
          <EmptyContent>
            <Button onClick={() => navigate(LIST)}>Back to inventory counts</Button>
          </EmptyContent>
        </Empty>
      </Shell>
    );
  }

  const details: [string, string][] = [
    ["Store", settings?.storeName || "My store"],
    ["Type", COUNT_TYPE_LABELS[count.type]],
    ["Created", when(count.createdAt)],
    ["Completed", count.completedAt ? when(count.completedAt) : "-"],
  ];

  return (
    <Shell>
      <section className="space-y-5 rounded-sm bg-card p-6 shadow-xs">
        <div>
          <h2 className="text-2xl font-semibold">{formatCountNumber(count.number)}</h2>
          <CountStatusText status={count.status} />
        </div>
        <dl className="grid gap-4 sm:grid-cols-2">
          {details.map(([k, v]) => (
            <div key={k}>
              <dt className="text-xs text-muted-foreground">{k}</dt>
              <dd className="text-sm">{v}</dd>
            </div>
          ))}
          {count.status === "completed" && count.notes && (
            <div className="sm:col-span-2">
              <dt className="text-xs text-muted-foreground">Notes</dt>
              <dd className="whitespace-pre-wrap text-sm">{count.notes}</dd>
            </div>
          )}
        </dl>
      </section>

      {count.status === "completed" ? (
        <CompletedItems count={count} />
      ) : (
        // Keyed so a fresh sheet loads if the count changes elsewhere after completing
        <CountSheet key={`${count._id}-${count.status}`} count={count} onDeleted={() => navigate(LIST)} />
      )}
    </Shell>
  );
}

function CompletedItems({ count }: { count: Doc<"inventoryCounts"> }) {
  const totals = countTotals(count.lines);
  return (
    <section className="overflow-x-auto rounded-sm bg-card px-6 pb-2 shadow-xs">
      <h2 className="pt-5 text-lg font-medium">Items</h2>
      <table className="w-full min-w-[560px] text-sm">
        <thead>
          <tr className="border-b text-xs text-muted-foreground">
            <th className="py-3 text-left font-normal">Item</th>
            <th className="py-3 text-right font-normal">Expected stock</th>
            <th className="py-3 text-right font-normal">Counted</th>
            <th className="py-3 text-right font-normal">Difference</th>
            <th className="py-3 text-right font-normal">Cost difference</th>
          </tr>
        </thead>
        <tbody>
          {count.lines.map((l) => {
            const diff = l.expected === null ? null : lineDifference(l.counted, l.expected);
            return (
              <tr key={l.stockLevelId} className="border-b">
                <td className="py-3">{levelLabel(l)}</td>
                <td className="py-3 text-right tabular-nums">{l.expected ?? "-"}</td>
                <td className="py-3 text-right tabular-nums">{l.counted ?? "Not counted"}</td>
                <td className="py-3 text-right"><DiffText value={diff} /></td>
                <td className="py-3 text-right">
                  <DiffText value={diff}>{diff === null ? null : formatKsh(diff * (l.costCents ?? 0))}</DiffText>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="flex flex-wrap justify-end gap-x-10 gap-y-1 py-4 text-sm">
        <span className="text-muted-foreground">Counted {totals.counted} of {count.lines.length}</span>
        <span>Difference <DiffText value={totals.differenceQty} /></span>
        <span className="font-semibold">
          Cost difference <DiffText value={totals.costDifferenceCents}>{formatKsh(totals.costDifferenceCents)}</DiffText>
        </span>
      </div>
    </section>
  );
}
