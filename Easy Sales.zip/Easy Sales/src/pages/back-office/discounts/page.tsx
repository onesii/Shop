import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Tag } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { formatKsh } from "@/lib/money.ts";
import ReportShell from "../_components/report-shell.tsx";
import { TruncatedNotice } from "../_components/report-stats.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import { reportArgs, reportFilename, useReportFilters } from "../_lib/filters.ts";
import { money, sumBy } from "../_lib/columns.ts";

type Row = { name: string; timesApplied: number; amountCents: number };

const COLUMNS: Column<Row>[] = [
  {
    key: "name",
    label: "Name",
    fixed: true,
    render: (r) => <span className="font-medium">{r.name}</span>,
    csv: (r) => r.name,
  },
  {
    key: "applied",
    label: "Discounts applied",
    numeric: true,
    render: (r) => r.timesApplied,
    csv: (r) => r.timesApplied,
  },
  money<Row>("amount", "Amount discounted", (r) => r.amountCents),
];

export default function DiscountsReportPage() {
  const { range, hourWindow, employeeIds } = useReportFilters();
  const args = useMemo(() => reportArgs(range, hourWindow, employeeIds), [range, hourWindow, employeeIds]);
  const data = useQuery(api.reports.salesReports.byDiscount, args);
  const rows = data?.discounts;

  const footer = rows && {
    name: "Total",
    applied: sumBy(rows, (r) => r.timesApplied),
    amount: formatKsh(sumBy(rows, (r) => r.amountCents)),
  };

  return (
    <ReportShell>
      <ReportTable
        columns={COLUMNS}
        rows={rows}
        rowKey={(r) => r.name}
        filename={reportFilename("discounts", range)}
        footer={footer}
        notice={<TruncatedNotice show={data?.truncated ?? false} />}
        empty={{ icon: Tag, title: "No discounts given", description: "No discounts were applied in this period." }}
      />
    </ReportShell>
  );
}
