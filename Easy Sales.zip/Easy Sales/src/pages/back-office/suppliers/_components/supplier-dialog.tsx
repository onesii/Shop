import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";

type Props = {
  open: boolean;
  /** Supplier to edit, or null to create one */
  supplier: Doc<"suppliers"> | null;
  onClose: () => void;
  onSaved?: (id: Id<"suppliers">) => void;
};

type Fields = { name: string; contact: string; email: string; phone: string; address: string; note: string };

const EMPTY: Fields = { name: "", contact: "", email: "", phone: "", address: "", note: "" };

const INPUTS: { key: Exclude<keyof Fields, "address" | "note">; label: string; placeholder: string; type?: string }[] = [
  { key: "name", label: "Supplier name", placeholder: "Jelly Traders" },
  { key: "contact", label: "Contact", placeholder: "John Kamau" },
  { key: "email", label: "Email", placeholder: "orders@example.com", type: "email" },
  { key: "phone", label: "Phone number", placeholder: "0712 345 678", type: "tel" },
];

export default function SupplierDialog({ open, supplier, onClose, onSaved }: Props) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{supplier ? "Edit supplier" : "Create supplier"}</DialogTitle>
          <DialogDescription>Who you buy stock from.</DialogDescription>
        </DialogHeader>
        {open && <SupplierForm key={supplier?._id ?? "new"} supplier={supplier} onClose={onClose} onSaved={onSaved} />}
      </DialogContent>
    </Dialog>
  );
}

function SupplierForm({ supplier, onClose, onSaved }: Omit<Props, "open">) {
  const create = useMutation(api.inventory.suppliers.create);
  const update = useMutation(api.inventory.suppliers.update);
  const remove = useMutation(api.inventory.suppliers.remove);
  const [fields, setFields] = useState<Fields>(supplier ?? EMPTY);
  const [nameError, setNameError] = useState(false);
  const [saving, setSaving] = useState(false);
  const set = (key: keyof Fields, value: string) => setFields((f) => ({ ...f, [key]: value }));

  const values = {
    name: fields.name,
    contact: fields.contact,
    email: fields.email,
    phone: fields.phone,
    address: fields.address,
    note: fields.note,
  };

  const save = async () => {
    if (!fields.name.trim()) return setNameError(true);
    setSaving(true);
    try {
      if (supplier) {
        await update({ id: supplier._id, ...values });
        onSaved?.(supplier._id);
      } else {
        onSaved?.(await create(values));
      }
      toast.success("Supplier saved");
      onClose();
    } catch (err) {
      toast.error(convexMessage(err, "Could not save the supplier"));
    } finally {
      setSaving(false);
    }
  };

  const del = async () => {
    if (!supplier) return;
    setSaving(true);
    try {
      await remove({ id: supplier._id });
      toast.success("Supplier deleted");
      onClose();
    } catch (err) {
      toast.error(convexMessage(err, "Could not delete the supplier"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="space-y-4">
        {INPUTS.map((f) => (
          <div key={f.key} className="space-y-1.5">
            <Label htmlFor={`supplier-${f.key}`}>{f.label}</Label>
            <Input
              id={`supplier-${f.key}`}
              type={f.type}
              value={fields[f.key]}
              placeholder={f.placeholder}
              maxLength={f.key === "email" ? 100 : 64}
              aria-invalid={f.key === "name" && nameError}
              onChange={(e) => {
                set(f.key, e.target.value);
                if (f.key === "name") setNameError(false);
              }}
            />
            {f.key === "name" && nameError && <p className="text-xs text-destructive">This field cannot be blank</p>}
          </div>
        ))}
        <div className="space-y-1.5">
          <Label htmlFor="supplier-address">Address</Label>
          <Textarea id="supplier-address" maxLength={300} value={fields.address} onChange={(e) => set("address", e.target.value)} placeholder="Moi Avenue, Nairobi" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="supplier-note">Note</Label>
          <Textarea id="supplier-note" maxLength={500} value={fields.note} onChange={(e) => set("note", e.target.value)} />
        </div>
      </div>
      <DialogFooter className="gap-2 sm:justify-between">
        {supplier ? (
          <Button variant="ghost" className="text-destructive" disabled={saving} onClick={() => void del()}>Delete</Button>
        ) : <span />}
        <div className="flex gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={saving} onClick={() => void save()}>{saving && <Spinner />} Save</Button>
        </div>
      </DialogFooter>
    </>
  );
}
