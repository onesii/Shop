import { useState } from "react";
import { useQuery } from "convex/react";
import { Plus, Truck } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import SupplierDialog from "./_components/supplier-dialog.tsx";

type Row = Doc<"suppliers">;

const COLUMNS: Column<Row>[] = [
  { key: "name", label: "Name", fixed: true, render: (r) => <span className="font-medium">{r.name}</span>, csv: (r) => r.name },
  { key: "contact", label: "Contact", render: (r) => r.contact || "-", csv: (r) => r.contact },
  { key: "phone", label: "Phone number", render: (r) => r.phone || "-", csv: (r) => r.phone },
  { key: "email", label: "Email", render: (r) => r.email || "-", csv: (r) => r.email },
];

export default function SuppliersPage() {
  const suppliers = useQuery(api.inventory.suppliers.list, {});
  const [editing, setEditing] = useState<Row | null | undefined>(undefined);
  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <Button className="h-11 uppercase" onClick={() => setEditing(null)}>
        <Plus className="size-4" /> Add supplier
      </Button>
      <ReportTable
        columns={COLUMNS}
        rows={suppliers}
        rowKey={(r) => r._id}
        filename="suppliers.csv"
        onRowClick={(r) => setEditing(r)}
        empty={{ icon: Truck, title: "No suppliers yet", description: "Add the people and companies you buy stock from." }}
      />
      <SupplierDialog open={editing !== undefined} supplier={editing ?? null} onClose={() => setEditing(undefined)} />
    </div>
  );
}
