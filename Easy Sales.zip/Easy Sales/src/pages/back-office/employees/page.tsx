import { useState } from "react";
import { useQuery } from "convex/react";
import { Contact, KeyRound, UserPlus } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { ROLE_LABELS } from "@/lib/staff.ts";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import ReportTable, { type Column } from "../_components/report-table.tsx";
import EmployeeForm, { type EmployeeRow } from "./_components/employee-form.tsx";

const COLUMNS: Column<EmployeeRow>[] = [
  {
    key: "name",
    label: "Name",
    fixed: true,
    render: (r) => <span className="font-medium">{r.name}</span>,
    csv: (r) => r.name,
  },
  { key: "email", label: "Email", render: (r) => r.email ?? "-", csv: (r) => r.email ?? "" },
  { key: "phone", label: "Phone", render: (r) => r.phone ?? "-", csv: (r) => r.phone ?? "" },
  {
    key: "role",
    label: "Role",
    render: (r) => (
      <Badge variant={r.role === "owner" ? "default" : "secondary"}>{ROLE_LABELS[r.role]}</Badge>
    ),
    csv: (r) => ROLE_LABELS[r.role],
  },
  {
    key: "pin",
    label: "PIN",
    render: (r) => (r.hasPin ? "Set" : <span className="text-amber-600 dark:text-amber-400">Not set</span>),
    csv: (r) => (r.hasPin ? "Set" : "Not set"),
  },
  {
    key: "device",
    label: "Own device",
    render: (r) => (r.role === "owner" ? "-" : r.joined ? "Joined" : "-"),
    csv: (r) => (r.joined ? "Joined" : ""),
  },
];

export default function EmployeesPage() {
  const employees = useQuery(api.staff.employees.list, {});
  const ownerNeedsPin = useQuery(api.staff.employees.ownerNeedsPin, {});
  const [editing, setEditing] = useState<EmployeeRow | "new" | null>(null);
  const owner = employees?.find((e) => e.role === "owner");

  return (
    <div className="mx-auto w-full max-w-6xl space-y-4 p-4 pb-12 md:p-6">
      <div className="flex flex-wrap items-center gap-3">
        <Button className="h-11" disabled={ownerNeedsPin !== false} onClick={() => setEditing("new")}>
          <UserPlus className="size-4" /> Add employee
        </Button>
      </div>

      {ownerNeedsPin && owner && (
        <div className="flex flex-wrap items-center gap-3 rounded-sm border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-200">
          <KeyRound className="size-5 shrink-0" />
          <p className="min-w-0 flex-1">
            Set your own PIN first. Once employees are added, the POS asks for a PIN so everyone signs in as themselves.
          </p>
          <Button size="sm" onClick={() => setEditing(owner)}>
            Set my PIN
          </Button>
        </div>
      )}

      <ReportTable
        columns={COLUMNS}
        rows={employees}
        rowKey={(r) => r._id}
        filename="employees.csv"
        onRowClick={(r) => setEditing(r)}
        empty={{ icon: Contact, title: "No employees", description: "Add your first employee." }}
      />

      <Dialog open={editing !== null} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing === "new" ? "Add employee" : "Edit employee"}</DialogTitle>
            <DialogDescription>
              {editing && editing !== "new" ? ROLE_LABELS[editing.role] : "Choose what they can do under Access rights"}
            </DialogDescription>
          </DialogHeader>
          {editing !== null && (
            <EmployeeForm
              key={editing === "new" ? "new" : editing._id}
              employee={editing === "new" ? null : editing}
              onDone={() => setEditing(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
