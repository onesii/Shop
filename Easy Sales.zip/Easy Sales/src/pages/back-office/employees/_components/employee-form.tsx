import { useState } from "react";
import { useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import type { Role } from "@/convex/lib/access.ts";
import { useStaff } from "@/hooks/use-staff.tsx";
import { convexMessage } from "@/lib/errors.ts";
import { ROLE_LABELS } from "@/lib/staff.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import InviteSection from "./invite-section.tsx";

export type EmployeeRow = {
  _id: Id<"employees"> | "owner";
  name: string;
  email: string | null;
  phone: string | null;
  role: Role;
  hasPin: boolean;
  joined: boolean;
};

type Props = {
  employee: EmployeeRow | null;
  onDone: () => void;
};

function schemaFor(pinRequired: boolean) {
  return z.object({
    name: z.string().trim().min(1, "Name is required").max(60, "Name is too long"),
    email: z.union([z.literal(""), z.string().trim().email("Enter a valid email")]),
    phone: z.string().trim().max(20, "Phone is too long"),
    role: z.enum(["manager", "cashier"]),
    pin: pinRequired
      ? z.string().regex(/^\d{4}$/, "Enter a 4-digit PIN")
      : z.union([z.literal(""), z.string().regex(/^\d{4}$/, "Enter a 4-digit PIN")]),
  });
}

type Values = z.infer<ReturnType<typeof schemaFor>>;

export default function EmployeeForm({ employee, onDone }: Props) {
  const staff = useStaff();
  const create = useMutation(api.staff.employees.create);
  const update = useMutation(api.staff.employees.update);
  const isOwner = employee?.role === "owner";
  const pinRequired = !employee;
  const form = useForm<Values>({
    resolver: zodResolver(schemaFor(pinRequired)),
    defaultValues: {
      name: employee?.name ?? "",
      email: employee?.email ?? "",
      phone: employee?.phone ?? "",
      role: employee && employee.role !== "owner" ? employee.role : "cashier",
      pin: "",
    },
  });
  // Only the owner can add or change managers
  const canPickManager = staff.role === "owner";

  const submit = async (values: Values) => {
    const contact = {
      name: values.name,
      email: values.email || undefined,
      phone: values.phone || undefined,
    };
    try {
      if (!employee) {
        await create({ ...contact, role: values.role, pin: values.pin });
        toast.success("Employee added");
      } else {
        await update({
          id: employee._id,
          ...contact,
          ...(isOwner ? {} : { role: values.role }),
          ...(values.pin ? { pin: values.pin } : {}),
        });
        toast.success("Employee saved");
      }
      onDone();
    } catch (err) {
      toast.error(convexMessage(err, "Could not save employee"));
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(submit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="Grace Wanjiru" autoComplete="off" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="grace@gmail.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone</FormLabel>
                <FormControl>
                  <Input type="tel" placeholder="0712 345 678" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        {!isOwner && (
          <FormField
            control={form.control}
            name="role"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Role</FormLabel>
                <Select
                  value={field.value}
                  onValueChange={field.onChange}
                  disabled={!canPickManager && employee?.role === "manager"}
                >
                  <FormControl>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="cashier">{ROLE_LABELS.cashier}</SelectItem>
                    {(canPickManager || employee?.role === "manager") && (
                      <SelectItem value="manager">{ROLE_LABELS.manager}</SelectItem>
                    )}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        <FormField
          control={form.control}
          name="pin"
          render={({ field }) => (
            <FormItem>
              <FormLabel>POS PIN</FormLabel>
              <FormControl>
                <Input
                  inputMode="numeric"
                  maxLength={4}
                  placeholder={employee?.hasPin ? "••••" : "4 digits"}
                  autoComplete="off"
                  {...field}
                  onChange={(e) => field.onChange(e.target.value.replace(/\D/g, ""))}
                />
              </FormControl>
              <FormDescription>
                {employee?.hasPin ? "Leave empty to keep the current PIN." : "Used to unlock the POS. Each employee needs their own."}
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        {employee && employee._id !== "owner" && employee.role !== "owner" && (
          <InviteSection employeeId={employee._id} />
        )}
        <div className="flex items-center justify-between gap-2 pt-2">
          {employee && !isOwner ? <RemoveButton id={employee._id} onDone={onDone} /> : <span />}
          <div className="flex gap-2">
            <Button type="button" variant="ghost" onClick={onDone}>
              Cancel
            </Button>
            <Button type="submit" disabled={form.formState.isSubmitting}>
              Save
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}

function RemoveButton({ id, onDone }: { id: Id<"employees"> | "owner"; onDone: () => void }) {
  const remove = useMutation(api.staff.employees.remove);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  if (id === "owner") return null;
  const run = async () => {
    if (!confirming) return setConfirming(true);
    setBusy(true);
    try {
      await remove({ id });
      toast.success("Employee removed");
      onDone();
    } catch (err) {
      toast.error(convexMessage(err, "Could not remove employee"));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Button type="button" variant="ghost" className="text-destructive" disabled={busy} onClick={() => void run()}>
      <Trash2 className="size-4" /> {confirming ? "Tap again" : "Remove"}
    </Button>
  );
}
