import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Copy, Link2, Unlink } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

/** Lets the owner share a join link so the employee can sign in on their own device. */
export default function InviteSection({ employeeId }: { employeeId: Id<"employees"> }) {
  const status = useQuery(api.staff.invites.forEmployee, { employeeId });
  const create = useMutation(api.staff.invites.create);
  const disconnect = useMutation(api.staff.invites.disconnect);
  const [busy, setBusy] = useState(false);

  const run = async (action: () => Promise<unknown>, done: string, failed: string) => {
    setBusy(true);
    try {
      await action();
      toast.success(done);
    } catch (err) {
      toast.error(convexMessage(err, failed));
    } finally {
      setBusy(false);
    }
  };

  if (status === undefined) return <Skeleton className="h-20 w-full" />;
  if (status === null) return null;

  const link = status.invite ? `${window.location.origin}/join/${status.invite.token}` : null;
  const copy = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      toast.success("Link copied");
    } catch {
      toast.error("Could not copy. Select the link and copy it.");
    }
  };

  return (
    <div className="space-y-2 rounded-sm border bg-muted/40 p-3">
      <p className="text-sm font-medium">Own device sign-in</p>
      {status.joined ? (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-muted-foreground">Signed in with their own account.</p>
          <Button
            type="button"
            size="sm"
            variant="ghost"
            className="text-destructive"
            disabled={busy}
            onClick={() => void run(() => disconnect({ employeeId }), "Account disconnected", "Could not disconnect")}
          >
            <Unlink className="size-4" /> Disconnect
          </Button>
        </div>
      ) : link && status.invite ? (
        <>
          <div className="flex gap-2">
            <Input readOnly value={link} className="min-w-0 flex-1 text-xs" onFocus={(e) => e.target.select()} />
            <Button type="button" size="icon" variant="secondary" aria-label="Copy link" onClick={() => void copy()}>
              <Copy className="size-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            {`Send this link to the employee. It works once and expires ${format(new Date(status.invite.expiresAt), "MMM d")}.`}
          </p>
        </>
      ) : (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-muted-foreground">Let them use the POS on their own phone or tablet.</p>
          <Button
            type="button"
            size="sm"
            variant="secondary"
            disabled={busy}
            onClick={() => void run(() => create({ employeeId }), "Invite link created", "Could not create invite")}
          >
            <Link2 className="size-4" /> Create invite link
          </Button>
        </div>
      )}
    </div>
  );
}
