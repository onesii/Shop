import { useOutletContext } from "react-router-dom";
import { format } from "date-fns";
import type { EmployeeFilterId } from "@/convex/reports/range.ts";
import { rangeToIso, type DateRange, type HourWindow } from "./summary.ts";

/** Selected employees; undefined = all employees. */
export type EmployeeSelection = EmployeeFilterId[] | undefined;

/** Filters shared by every report; kept in the back office layout so they survive switching reports. */
export type ReportFilters = {
  range: DateRange;
  setRange: (r: DateRange) => void;
  hourWindow: HourWindow;
  setHourWindow: (w: HourWindow) => void;
  employeeIds: EmployeeSelection;
  setEmployeeIds: (ids: EmployeeSelection) => void;
};

export function useReportFilters(): ReportFilters {
  return useOutletContext<ReportFilters>();
}

export function isAllDay(w: HourWindow): boolean {
  return w.start <= 0 && w.end >= 24;
}

/** Args for the aggregated report queries (local hour window + device UTC offset). */
export function reportArgs(range: DateRange, w: HourWindow, employeeIds: EmployeeSelection) {
  const iso = { ...rangeToIso(range), ...(employeeIds ? { employeeIds } : {}) };
  if (isAllDay(w)) return iso;
  return {
    ...iso,
    hourStart: w.start,
    hourEnd: w.end,
    timezoneOffsetMinutes: new Date().getTimezoneOffset(),
  };
}

const DAY_MINUTES = 1440;

/** Converts a local hour window to UTC minutes of the day (may wrap past midnight). */
export function utcMinuteWindow(
  w: HourWindow,
  offsetMinutes: number = new Date().getTimezoneOffset(),
): { minuteStart: number; minuteEnd: number } | null {
  if (isAllDay(w)) return null;
  const toUtc = (h: number) => (((h * 60 + offsetMinutes) % DAY_MINUTES) + DAY_MINUTES) % DAY_MINUTES;
  return { minuteStart: toUtc(w.start), minuteEnd: toUtc(w.end) };
}

/** e.g. "sales-by-item-2026-09-24-to-2026-10-23.csv" */
export function reportFilename(slug: string, range: DateRange): string {
  return `${slug}-${format(range.from, "yyyy-MM-dd")}-to-${format(range.to, "yyyy-MM-dd")}.csv`;
}
