import type { Column } from "../_components/report-table.tsx";
import { formatKsh } from "@/lib/money.ts";

/** A right-aligned KSh column; the CSV gets a plain number like 1900.00. */
export function money<T>(key: string, label: string, get: (row: T) => number): Column<T> {
  return {
    key,
    label,
    numeric: true,
    render: (r) => formatKsh(get(r)),
    csv: (r) => (get(r) / 100).toFixed(2),
  };
}

export function sumBy<T>(rows: T[], get: (row: T) => number): number {
  return rows.reduce((s, r) => s + get(r), 0);
}
