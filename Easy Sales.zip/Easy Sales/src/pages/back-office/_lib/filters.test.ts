import { describe, expect, it } from "vitest";
import { utcMinuteWindow } from "./filters.ts";

describe("utcMinuteWindow", () => {
  it("returns null for all day", () => {
    expect(utcMinuteWindow({ start: 0, end: 24 }, -180)).toBeNull();
  });

  it("converts Nairobi (UTC+3) hours to UTC minutes", () => {
    // 8 AM - 5 PM in Nairobi is 05:00 - 14:00 UTC
    expect(utcMinuteWindow({ start: 8, end: 17 }, -180)).toEqual({ minuteStart: 300, minuteEnd: 840 });
  });

  it("wraps past midnight when the local window crosses UTC midnight", () => {
    // 1 AM - 6 AM in Nairobi is 22:00 - 03:00 UTC
    expect(utcMinuteWindow({ start: 1, end: 6 }, -180)).toEqual({ minuteStart: 1320, minuteEnd: 180 });
  });
});
