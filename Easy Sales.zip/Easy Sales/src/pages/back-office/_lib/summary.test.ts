import { describe, expect, it } from "vitest";
import {
  change,
  groupRows,
  previousRange,
  shiftRange,
  totals,
  type DateRange,
  type HourRow,
} from "./summary.ts";

function local(y: number, m: number, d: number, h = 0): Date {
  return new Date(y, m - 1, d, h);
}

function row(date: Date, gross: number, refunds = 0): HourRow {
  return { hour: date.toISOString(), grossSalesCents: gross, refundsCents: refunds };
}

const RANGE: DateRange = { from: local(2026, 10, 1), to: local(2026, 10, 3) };

describe("groupRows", () => {
  it("fills empty days and sums hours into local days", () => {
    const rows = [row(local(2026, 10, 1, 9), 1000), row(local(2026, 10, 1, 15), 500, 200)];
    const buckets = groupRows(rows, RANGE, "days");
    expect(buckets).toHaveLength(3);
    expect(buckets[0]).toMatchObject({ grossSalesCents: 1500, refundsCents: 200, netSalesCents: 1300 });
    expect(buckets[1].grossSalesCents).toBe(0);
  });

  it("applies the hour window", () => {
    const rows = [row(local(2026, 10, 2, 7), 1000), row(local(2026, 10, 2, 12), 300)];
    const [, day2] = groupRows(rows, RANGE, "days", { start: 8, end: 17 });
    expect(day2.grossSalesCents).toBe(300);
  });

  it("groups by month", () => {
    const range = { from: local(2026, 9, 20), to: local(2026, 10, 5) };
    const rows = [row(local(2026, 9, 25, 10), 100), row(local(2026, 10, 2, 10), 200)];
    const buckets = groupRows(rows, range, "months");
    expect(buckets.map((b) => b.grossSalesCents)).toEqual([100, 200]);
  });
});

describe("ranges", () => {
  it("previous range has the same length right before", () => {
    expect(previousRange(RANGE)).toEqual({ from: local(2026, 9, 28), to: local(2026, 9, 30) });
  });

  it("shifts forward by the range length", () => {
    expect(shiftRange(RANGE, 1)).toEqual({ from: local(2026, 10, 4), to: local(2026, 10, 6) });
  });
});

describe("totals and change", () => {
  it("computes net sales and percent change", () => {
    const t = totals([row(local(2026, 10, 1, 9), 1000, 250)]);
    expect(t.netSalesCents).toBe(750);
    expect(change(900, 1000)).toEqual({ cents: -100, percent: -10 });
    expect(change(500, 0).percent).toBeNull();
  });
});
