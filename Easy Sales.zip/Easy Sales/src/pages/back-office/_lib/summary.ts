import {
  addDays,
  differenceInCalendarDays,
  eachDayOfInterval,
  eachMonthOfInterval,
  eachWeekOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  startOfDay,
  startOfMonth,
  startOfWeek,
  subDays,
} from "date-fns";

export type HourRow = {
  hour: string; // ISO UTC start of hour
  grossSalesCents: number;
  refundsCents: number;
  discountsCents?: number;
};

export type Granularity = "days" | "weeks" | "months";

export type Metrics = {
  grossSalesCents: number;
  refundsCents: number;
  discountsCents: number;
  netSalesCents: number;
};

export type Bucket = Metrics & { key: string; label: string; start: Date };

export type DateRange = { from: Date; to: Date }; // local calendar days, inclusive

/** Local hours of the day to include, start inclusive, end exclusive (0-24). */
export type HourWindow = { start: number; end: number };

export const ALL_DAY: HourWindow = { start: 0, end: 24 };

export const METRIC_KEYS = [
  "grossSalesCents",
  "refundsCents",
  "discountsCents",
  "netSalesCents",
] as const satisfies readonly (keyof Metrics)[];

export type MetricKey = (typeof METRIC_KEYS)[number];

export const METRIC_LABELS: Record<MetricKey, string> = {
  grossSalesCents: "Gross sales",
  refundsCents: "Refunds",
  discountsCents: "Discounts",
  netSalesCents: "Net sales",
};

const WEEK_OPTS = { weekStartsOn: 1 } as const;

export function emptyMetrics(): Metrics {
  return { grossSalesCents: 0, refundsCents: 0, discountsCents: 0, netSalesCents: 0 };
}

/** UTC instants covering the whole local range, end exclusive. */
export function rangeToIso(range: DateRange): { startIso: string; endIso: string } {
  return {
    startIso: startOfDay(range.from).toISOString(),
    endIso: addDays(startOfDay(range.to), 1).toISOString(),
  };
}

/** The equally long period right before `range`. */
export function previousRange(range: DateRange): DateRange {
  const days = differenceInCalendarDays(range.to, range.from) + 1;
  return { from: subDays(range.from, days), to: subDays(range.to, days) };
}

/** Shifts the range by its own length, e.g. back or forward 30 days. */
export function shiftRange(range: DateRange, direction: -1 | 1): DateRange {
  const days = (differenceInCalendarDays(range.to, range.from) + 1) * direction;
  return { from: addDays(range.from, days), to: addDays(range.to, days) };
}

export function defaultRange(today: Date = new Date()): DateRange {
  const to = startOfDay(today);
  return { from: subDays(to, 29), to };
}

function inWindow(date: Date, window: HourWindow): boolean {
  const h = date.getHours();
  return h >= window.start && h < window.end;
}

function addRow(m: Metrics, row: HourRow): void {
  const discounts = row.discountsCents ?? 0;
  m.grossSalesCents += row.grossSalesCents;
  m.refundsCents += row.refundsCents;
  m.discountsCents += discounts;
  m.netSalesCents += row.grossSalesCents - row.refundsCents - discounts;
}

export function totals(rows: HourRow[], window: HourWindow = ALL_DAY): Metrics {
  const m = emptyMetrics();
  for (const row of rows) {
    if (inWindow(new Date(row.hour), window)) addRow(m, row);
  }
  return m;
}

function bucketStart(date: Date, g: Granularity): Date {
  if (g === "days") return startOfDay(date);
  if (g === "weeks") return startOfWeek(date, WEEK_OPTS);
  return startOfMonth(date);
}

function bucketLabel(start: Date, g: Granularity, range: DateRange): string {
  if (g === "days") return format(start, "MMM d, yyyy");
  if (g === "months") return format(start, "MMM yyyy");
  // Clamp week labels to the selected range
  const from = start < range.from ? range.from : start;
  const endOfW = endOfWeek(start, WEEK_OPTS);
  const to = endOfW > range.to ? range.to : endOfW;
  return `${format(from, "MMM d")} - ${format(to, "MMM d, yyyy")}`;
}

/** Groups hourly rows into local day/week/month buckets, including empty ones, oldest first. */
export function groupRows(
  rows: HourRow[],
  range: DateRange,
  g: Granularity,
  window: HourWindow = ALL_DAY,
): Bucket[] {
  const interval = { start: startOfDay(range.from), end: startOfDay(range.to) };
  const starts =
    g === "days"
      ? eachDayOfInterval(interval)
      : g === "weeks"
        ? eachWeekOfInterval(interval, WEEK_OPTS)
        : eachMonthOfInterval({ start: interval.start, end: endOfMonth(interval.end) });

  const buckets = new Map<string, Bucket>();
  for (const start of starts) {
    const key = start.toISOString();
    buckets.set(key, { key, start, label: bucketLabel(start, g, range), ...emptyMetrics() });
  }
  for (const row of rows) {
    const date = new Date(row.hour);
    if (!inWindow(date, window)) continue;
    const bucket = buckets.get(bucketStart(date, g).toISOString());
    if (bucket) addRow(bucket, row);
  }
  return [...buckets.values()];
}

export type Change = { cents: number; percent: number | null };

/** Difference vs previous period; percent is null when the previous value was 0. */
export function change(current: number, previous: number): Change {
  const cents = current - previous;
  return { cents, percent: previous === 0 ? null : (cents / Math.abs(previous)) * 100 };
}
