import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Authenticated, AuthLoading, Unauthenticated, useMutation, useQuery } from "convex/react";
import { ShoppingBasket } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { convexMessage } from "@/lib/errors.ts";
import { ROLE_LABELS } from "@/lib/staff.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";

function AcceptButton({ token }: { token: string }) {
  const accept = useMutation(api.staff.invites.accept);
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const run = async () => {
    setBusy(true);
    try {
      const res = await accept({ token });
      toast.success(`Welcome, ${res.name}`);
      navigate("/", { replace: true });
    } catch (err) {
      toast.error(convexMessage(err, "Could not join the store"));
      setBusy(false);
    }
  };
  return (
    <Button
      size="lg"
      disabled={busy}
      onClick={() => void run()}
      className="h-12 w-full bg-white text-base font-semibold text-secondary hover:bg-white/90"
    >
      Join store
    </Button>
  );
}

/** Invite landing page: an employee signs in with their own account and joins the owner's store. */
export default function JoinPage() {
  const { token = "" } = useParams();
  const invite = useQuery(api.staff.invites.preview, { token });

  return (
    <div className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-secondary px-6 text-secondary-foreground">
      <div className="pointer-events-none absolute -right-32 top-0 h-full w-[55%] skew-x-[-18deg] bg-primary/35" />
      <div className="relative w-full max-w-sm space-y-6">
        <div className="flex size-14 items-center justify-center rounded-2xl bg-white text-secondary shadow-lg">
          <ShoppingBasket className="size-7" />
        </div>
        {invite === undefined ? (
          <div className="space-y-3">
            <Skeleton className="h-8 w-3/4 bg-white/20" />
            <Skeleton className="h-5 w-full bg-white/20" />
          </div>
        ) : invite === null ? (
          <div className="space-y-3">
            <h1 className="text-2xl font-semibold">This invite has expired</h1>
            <p className="opacity-85">Ask the store owner to send you a new link.</p>
          </div>
        ) : (
          <>
            <div className="space-y-3">
              <h1 className="text-balance text-3xl font-bold">Join {invite.storeName}</h1>
              <p className="opacity-85">
                {`You've been invited as ${invite.employeeName} (${ROLE_LABELS[invite.role]}). Sign in with your own account to use the register on this device.`}
              </p>
            </div>
            <AuthLoading>
              <Skeleton className="h-12 w-full bg-white/20" />
            </AuthLoading>
            <Unauthenticated>
              <SignInButton
                size="lg"
                signInText="Sign in to join"
                className="h-12 w-full bg-white text-base font-semibold text-secondary hover:bg-white/90"
              />
            </Unauthenticated>
            <Authenticated>
              <AcceptButton token={token} />
            </Authenticated>
          </>
        )}
      </div>
    </div>
  );
}
