import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import AppBar from "@/components/layout/app-bar.tsx";
import OpenShiftForm from "@/components/shifts/open-shift-form.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import SalesPage from "./sales/page.tsx";

export default function Index() {
  const shift = useQuery(api.sales.shifts.current, {});

  if (shift === undefined) {
    return (
      <>
        <AppBar title="Ticket" />
        <div className="space-y-2 p-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      </>
    );
  }

  if (shift === null) {
    return (
      <>
        <AppBar title="Ticket" />
        <main className="min-h-0 flex-1 overflow-y-auto">
          <OpenShiftForm />
        </main>
      </>
    );
  }

  return <SalesPage />;
}
