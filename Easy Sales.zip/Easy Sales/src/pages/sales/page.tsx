import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { ChevronDown, PackagePlus, Search, UserPlus, UserRound, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import AppBar, { AppBarIconButton } from "@/components/layout/app-bar.tsx";
import ItemRow, { itemPriceLabel } from "@/components/items/item-row.tsx";
import StockBadge from "@/components/inventory/stock-badge.tsx";
import { useTicket, type TicketLine } from "@/hooks/use-ticket.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { useStockByItem, type ItemStock } from "@/hooks/use-stock-by-item.ts";
import { isValidQuantity, itemUnit, roundQty } from "@/convex/lib/quantity.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import TicketBar from "./_components/ticket-bar.tsx";
import TicketLines, { LineEditor } from "./_components/ticket-lines.tsx";
import TicketMenu from "./_components/ticket-menu.tsx";
import ItemSheet from "./_components/item-sheet.tsx";
import QuantityKeypad from "./_components/quantity-keypad.tsx";
import CustomerDialog from "./_components/customer-dialog.tsx";

const ALL = "all";
const NONE = "none";

/** What tapping an item opens: nothing (added at once), the keypad, or the item popup. */
type Pending = { kind: "keypad" | "sheet"; item: Doc<"items"> };

export default function SalesPage() {
  const navigate = useNavigate();
  const { addLine, updateLine, removeLine, customer } = useTicket();
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [debouncedSearch] = useDebounce(search, 250);
  const [category, setCategory] = useState<string>(ALL);
  const [pending, setPending] = useState<Pending | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState<TicketLine | null>(null);
  const [customerOpen, setCustomerOpen] = useState(false);

  const categories = useQuery(api.catalog.categories.list, {});
  const categoryId: Id<"categories"> | null | undefined =
    category === ALL ? undefined : category === NONE ? null : (category as Id<"categories">);
  const items = useQuery(api.catalog.items.list, { search: debouncedSearch, categoryId });
  const stock = useStockByItem();

  const lineFor = (item: Doc<"items">, priceCents: number) => ({
    itemId: item._id,
    name: item.name,
    variantName: null,
    priceCents,
    color: item.color,
    unit: itemUnit(item),
  });

  const handleItem = (item: Doc<"items">) => {
    const simple = item.variants.length === 0 && item.priceCents !== null;
    if (!simple) return setPending({ kind: "sheet", item });
    if (item.soldBy === "weight") return setPending({ kind: "keypad", item });
    addLine(lineFor(item, item.priceCents ?? 0));
  };

  const handleKeypad = (item: Doc<"items">, quantity: number) => {
    setPending(null);
    if (!isValidQuantity(quantity) || item.priceCents === null) return;
    addLine(lineFor(item, item.priceCents), roundQty(quantity));
  };

  const title = searchOpen ? (
    <Input
      autoFocus
      value={search}
      onChange={(e) => setSearch(e.target.value)}
      placeholder="Search items"
      className="h-9 border-0 bg-white/15 text-secondary-foreground placeholder:text-secondary-foreground/70"
    />
  ) : (
    <Select value={category} onValueChange={setCategory}>
      <SelectTrigger
        aria-label="Category"
        className="h-10 w-auto max-w-full gap-2 border-0 bg-transparent px-1 text-lg font-semibold text-secondary-foreground shadow-none focus-visible:ring-white/40 dark:bg-transparent [&>svg]:hidden"
      >
        <SelectValue />
        <ChevronDown className="size-4 opacity-90" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL}>All items</SelectItem>
        <SelectItem value={NONE}>No category</SelectItem>
        {categories?.map((c) => (
          <SelectItem key={c._id} value={c._id}>
            {c.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );

  const itemList =
    items === undefined ? (
      Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 border-b px-4 py-2.5">
          <Skeleton className="size-10" />
          <Skeleton className="h-4 flex-1" />
          <Skeleton className="h-4 w-20" />
        </div>
      ))
    ) : items.length === 0 ? (
      <Empty className="h-full">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <PackagePlus />
          </EmptyMedia>
          <EmptyTitle>{search ? "No matching items" : "No items yet"}</EmptyTitle>
          <EmptyDescription>
            {search ? "Try a different search" : "Add the products you sell to start ringing up sales"}
          </EmptyDescription>
        </EmptyHeader>
        {!search && (
          <EmptyContent>
            <Button size="sm" onClick={() => navigate("/items/list")}>
              Add items
            </Button>
          </EmptyContent>
        )}
      </Empty>
    ) : (
      items.map((item) => (
        <ItemRow
          key={item._id}
          item={item}
          onClick={() => handleItem(item)}
          trailing={<PriceWithStock label={itemPriceLabel(item)} stock={stock?.get(item._id)} />}
        />
      ))
    );

  return (
    <>
      <AppBar
        title={title}
        actions={
          <>
            <AppBarIconButton
              label={searchOpen ? "Close search" : "Search items"}
              onClick={() => {
                setSearchOpen(!searchOpen);
                setSearch("");
              }}
            >
              {searchOpen ? <X className="size-5" /> : <Search className="size-5" />}
            </AppBarIconButton>
            <AppBarIconButton
              label={customer ? `Customer: ${customer.name}` : "Add customer"}
              onClick={() => setCustomerOpen(true)}
            >
              {customer ? <UserRound className="size-5" /> : <UserPlus className="size-5" />}
            </AppBarIconButton>
            <TicketMenu />
          </>
        }
      />

      <div className="flex min-h-0 flex-1">
        {/* Phones and tablets: ticket bar on top, lines drop down over the item list */}
        <section className="relative flex min-h-0 flex-1 flex-col lg:border-r">
          {expanded && (
            <button
              type="button"
              aria-label="Close ticket"
              onClick={() => setExpanded(false)}
              className="absolute inset-0 z-10 cursor-default bg-black/40 lg:hidden"
            />
          )}
          <div className="relative z-20 shadow-sm lg:hidden">
            <TicketBar expanded={expanded} onToggle={() => setExpanded(!expanded)} />
            {expanded && (
              <div className="absolute inset-x-0 top-full max-h-[60dvh] overflow-y-auto border-b bg-card shadow-lg">
                <TicketLines onEdit={setEditing} />
              </div>
            )}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">{itemList}</div>
        </section>

        {/* Large screens: ticket always shown on the right */}
        <aside className="hidden w-[420px] min-h-0 flex-col bg-card lg:flex">
          <TicketBar expanded onToggle={() => undefined} collapsible={false} />
          <div className="min-h-0 flex-1 overflow-y-auto">
            <TicketLines onEdit={setEditing} />
          </div>
        </aside>
      </div>

      {pending?.kind === "keypad" && (
        <Dialog open onOpenChange={(o) => !o && setPending(null)}>
          <DialogContent className="gap-0 overflow-hidden p-0 sm:max-w-xl" showCloseButton={false}>
            <div className="flex items-center gap-3 border-b px-3 py-2">
              <button
                type="button"
                aria-label="Close"
                onClick={() => setPending(null)}
                className="flex size-10 cursor-pointer items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted"
              >
                <X className="size-5" />
              </button>
              <DialogTitle className="truncate text-lg font-semibold">{pending.item.name}</DialogTitle>
              <DialogDescription className="sr-only">Type the quantity sold</DialogDescription>
            </div>
            <QuantityKeypad unit={itemUnit(pending.item)} onDone={(qty) => handleKeypad(pending.item, qty)} />
          </DialogContent>
        </Dialog>
      )}
      {pending?.kind === "sheet" && (
        <ItemSheet
          item={pending.item}
          onAdd={addLine}
          onUpdate={updateLine}
          onRemove={removeLine}
          onClose={() => setPending(null)}
        />
      )}
      {editing && <LineEditor line={editing} onClose={() => setEditing(null)} />}
      <CustomerDialog open={customerOpen} onClose={() => setCustomerOpen(false)} />
    </>
  );
}

function PriceWithStock({ label, stock }: { label: string; stock: ItemStock | undefined }) {
  return (
    <span className="flex flex-col items-end">
      <span>{label}</span>
      {stock && (
        <span className="text-xs">
          <StockBadge inStock={stock.inStock} isLow={stock.isLow} /> in stock
        </span>
      )}
    </span>
  );
}
