import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { Check, Tag } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { useTicket } from "@/hooks/use-ticket.tsx";
import { formatDiscountValue } from "@/lib/discounts.ts";
import { cn } from "@/lib/utils.ts";
import { MAX_TICKET_DISCOUNTS } from "@/convex/lib/discounts.ts";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";

type Props = { open: boolean; onClose: () => void };

export default function ApplyDiscountDialog({ open, onClose }: Props) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Discounts</DialogTitle>
          <DialogDescription>Tap to apply or remove a discount on this ticket</DialogDescription>
        </DialogHeader>
        {/* Only subscribe while open */}
        {open && <DiscountChoices onClose={onClose} />}
      </DialogContent>
    </Dialog>
  );
}

function DiscountChoices({ onClose }: { onClose: () => void }) {
  const navigate = useNavigate();
  const discounts = useQuery(api.catalog.discounts.list, {});
  const { discountIds, toggleDiscount } = useTicket();

  if (discounts === undefined) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
      </div>
    );
  }
  if (discounts.length === 0) {
    return (
      <Empty className="py-6">
        <EmptyHeader>
          <EmptyMedia variant="icon"><Tag /></EmptyMedia>
          <EmptyTitle>No discounts yet</EmptyTitle>
          <EmptyDescription>Create discounts in Items, then apply them here</EmptyDescription>
        </EmptyHeader>
        <EmptyContent>
          <Button size="sm" onClick={() => navigate("/items/discounts")}>Create discount</Button>
        </EmptyContent>
      </Empty>
    );
  }

  const toggle = (id: (typeof discountIds)[number]) => {
    if (!discountIds.includes(id) && discountIds.length >= MAX_TICKET_DISCOUNTS) {
      return toast.error(`Up to ${MAX_TICKET_DISCOUNTS} discounts per ticket`);
    }
    toggleDiscount(id);
  };

  return (
    <>
      <div className="-mx-6 max-h-[50vh] overflow-y-auto border-y">
        {discounts.map((d) => {
          const active = discountIds.includes(d._id);
          return (
            <button
              key={d._id}
              type="button"
              aria-pressed={active}
              onClick={() => toggle(d._id)}
              className={cn(
                "flex w-full cursor-pointer items-center gap-4 border-b px-6 py-3 text-left transition-colors last:border-b-0 hover:bg-muted",
                active && "bg-accent",
              )}
            >
              <span
                className={cn(
                  "flex size-6 shrink-0 items-center justify-center rounded-sm border",
                  active && "border-primary bg-primary text-primary-foreground",
                )}
              >
                {active && <Check className="size-4" />}
              </span>
              <span className="min-w-0 flex-1 truncate font-medium">{d.name}</span>
              <span className="shrink-0 text-sm tabular-nums text-muted-foreground">
                {formatDiscountValue(d.type, d.value)}
              </span>
            </button>
          );
        })}
      </div>
      <DialogFooter>
        <Button onClick={onClose}>Done</Button>
      </DialogFooter>
    </>
  );
}
