import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation } from "convex/react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { toTicketLines, useTicket } from "@/hooks/use-ticket.tsx";
import { useTicketTotals } from "@/hooks/use-ticket-totals.ts";
import { formatKsh } from "@/lib/money.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import SaveTicketDialog, { saveErrorMessage } from "./save-ticket-dialog.tsx";
import OpenTicketsDialog from "./open-tickets-dialog.tsx";

type Props = {
  expanded: boolean;
  onToggle: () => void;
  /** Hides the expand arrow when the lines are always shown (side panel). */
  collapsible?: boolean;
};

/** Ticket summary bar with OPEN TICKETS / SAVE and CHARGE, like the original app. */
export default function TicketBar({ expanded, onToggle, collapsible = true }: Props) {
  const navigate = useNavigate();
  const { lines, saved, discountIds, customer, itemCount, clear } = useTicket();
  const { totalCents } = useTicketTotals();
  const save = useMutation(api.sales.openTickets.save);
  const [dialog, setDialog] = useState<"save" | "open" | null>(null);
  const [saving, setSaving] = useState(false);
  const empty = lines.length === 0;

  // Empty sale shows OPEN TICKETS, a sale with items shows SAVE
  const handleLeft = async () => {
    if (empty) return setDialog("open");
    if (!saved) return setDialog("save");
    // Reopened ticket: save changes straight back to it
    setSaving(true);
    try {
      await save({
        id: saved.id,
        name: saved.name,
        comment: saved.comment ?? undefined,
        lines: toTicketLines(lines),
        discountIds,
        customerId: customer?.id,
      });
      clear();
      toast.success(`Saved "${saved.name}"`);
    } catch (err) {
      toast.error(saveErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const Chevron = expanded ? ChevronUp : ChevronDown;

  return (
    <div className="flex border-b bg-card">
      <button
        type="button"
        onClick={onToggle}
        disabled={!collapsible}
        aria-expanded={expanded}
        className={cn(
          "flex min-w-0 flex-1 items-center gap-2 border-r px-4 py-3 text-left",
          collapsible && "cursor-pointer transition-colors hover:bg-muted",
        )}
      >
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-2 text-lg font-medium">
            <span className="truncate">{saved?.name ?? "Ticket"}</span>
            <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-[3px] border border-dashed border-foreground/60 px-1 text-xs tabular-nums">
              {itemCount}
            </span>
          </p>
          <p className="truncate text-sm font-semibold">
            Total: <span className="tabular-nums">{formatKsh(totalCents)}</span>
          </p>
          {customer && <p className="truncate text-xs text-primary">{customer.name}</p>}
        </div>
        {collapsible && <Chevron className="size-5 shrink-0 text-muted-foreground" />}
      </button>

      <div className="grid w-[52%] max-w-80 shrink-0 grid-cols-2 items-center gap-3 p-3 sm:gap-4 sm:px-4">
        <Button
          type="button"
          disabled={saving}
          onClick={handleLeft}
          className="h-12 rounded-sm px-2 text-sm leading-tight font-semibold whitespace-normal uppercase"
        >
          {empty ? "Open tickets" : saving ? "Saving..." : "Save"}
        </Button>
        <Button
          type="button"
          disabled={empty}
          onClick={() => navigate("/charge")}
          className="h-12 rounded-sm px-2 text-sm font-semibold uppercase disabled:opacity-60"
        >
          Charge
        </Button>
      </div>

      <SaveTicketDialog open={dialog === "save"} onClose={() => setDialog(null)} />
      <OpenTicketsDialog open={dialog === "open"} onClose={() => setDialog(null)} />
    </div>
  );
}
