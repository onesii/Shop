import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { formatDistanceToNow } from "date-fns";
import { ClipboardList, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { useTicket } from "@/hooks/use-ticket.tsx";
import { formatKsh } from "@/lib/money.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";

type Props = { open: boolean; onClose: () => void };

export default function OpenTicketsDialog({ open, onClose }: Props) {
  // Only subscribe while the dialog is visible
  const tickets = useQuery(api.sales.openTickets.list, open ? {} : "skip");
  const remove = useMutation(api.sales.openTickets.remove);
  const { load } = useTicket();
  const [confirmDelete, setConfirmDelete] = useState<Doc<"openTickets"> | null>(null);

  const openTicket = (ticket: Doc<"openTickets">) => {
    load(ticket);
    onClose();
  };

  const deleteTicket = async (ticket: Doc<"openTickets">) => {
    setConfirmDelete(null);
    try {
      await remove({ id: ticket._id });
      toast.success(`Deleted "${ticket.name}"`);
    } catch {
      toast.error("Could not delete ticket");
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="flex max-h-[85dvh] flex-col gap-0 p-0 sm:max-w-md">
          <DialogHeader className="border-b p-4">
            <DialogTitle>Open tickets</DialogTitle>
            <DialogDescription>Tap a ticket to continue the sale</DialogDescription>
          </DialogHeader>
          <div className="min-h-0 flex-1 overflow-y-auto">
            {tickets === undefined ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="space-y-2 border-b p-4">
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              ))
            ) : tickets.length === 0 ? (
              <Empty className="py-12">
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <ClipboardList />
                  </EmptyMedia>
                  <EmptyTitle>No open tickets</EmptyTitle>
                  <EmptyDescription>
                    Add items to a sale and tap Save to keep it for later
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            ) : (
              tickets.map((t) => (
                <div key={t._id} className="flex items-center border-b hover:bg-muted">
                  <button
                    type="button"
                    onClick={() => openTicket(t)}
                    className="min-w-0 flex-1 cursor-pointer px-4 py-3 text-left"
                  >
                    <p className="truncate font-semibold">{t.name}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(t.updatedAt), { addSuffix: true })}
                      {t.comment && ` · ${t.comment}`}
                    </p>
                  </button>
                  <span className="shrink-0 text-sm font-semibold tabular-nums">
                    {formatKsh(t.totalCents)}
                  </span>
                  <button
                    type="button"
                    aria-label={`Delete ${t.name}`}
                    onClick={() => setConfirmDelete(t)}
                    className="cursor-pointer p-4 text-muted-foreground transition hover:text-destructive"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={confirmDelete !== null} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete ticket?</DialogTitle>
            <DialogDescription>
              {confirmDelete?.name} will be removed. This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmDelete(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => confirmDelete && deleteTicket(confirmDelete)}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
