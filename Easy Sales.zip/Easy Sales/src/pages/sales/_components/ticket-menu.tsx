import { useState } from "react";
import { useQuery } from "convex/react";
import { EllipsisVertical, Printer, RefreshCw, Tag, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { useTicket } from "@/hooks/use-ticket.tsx";
import { useTicketTotals } from "@/hooks/use-ticket-totals.ts";
import { usePrintBill } from "@/hooks/use-print-receipt.ts";
import { useStaff } from "@/hooks/use-staff.tsx";
import { useOfflineSync } from "@/hooks/use-offline-sync.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import ApplyDiscountDialog from "./apply-discount-dialog.tsx";

/** The three-dot menu on the sales screen. */
export default function TicketMenu() {
  const { lines, saved, clear } = useTicket();
  const { subtotalCents, discounts, taxes, totalCents } = useTicketTotals();
  const settings = useQuery(api.settings.get, {});
  const printBill = usePrintBill();
  const { can } = useStaff();
  const [discountOpen, setDiscountOpen] = useState(false);
  const { online, pending, syncNow } = useOfflineSync();
  const empty = lines.length === 0;

  const handleSync = () => {
    if (!online) return toast.error("You're offline", { description: "Sales will sync when you're back online" });
    if (pending.length === 0) return toast.success("Everything is up to date");
    syncNow();
  };

  const handlePrint = () =>
    void printBill({
      name: saved?.name ?? "Ticket",
      storeName: settings?.storeName || null,
      lines,
      subtotalCents,
      discounts,
      taxes,
      totalCents,
    });

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger
          aria-label="More options"
          className="flex size-10 cursor-pointer items-center justify-center rounded-full outline-none transition hover:bg-white/10"
        >
          <EllipsisVertical className="size-5" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuItem disabled={empty} onSelect={clear} className="cursor-pointer py-2.5">
            <Trash2 /> Clear ticket
          </DropdownMenuItem>
          <DropdownMenuItem disabled={empty} onSelect={handlePrint} className="cursor-pointer py-2.5">
            <Printer /> Print bill
          </DropdownMenuItem>
          {can("discounts") && (
            <DropdownMenuItem disabled={empty} onSelect={() => setDiscountOpen(true)} className="cursor-pointer py-2.5">
              <Tag /> {discounts.length > 0 ? "Edit discounts" : "Add discount"}
            </DropdownMenuItem>
          )}
          <DropdownMenuItem onSelect={handleSync} className="cursor-pointer py-2.5">
            <RefreshCw /> Sync
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <ApplyDiscountDialog open={discountOpen} onClose={() => setDiscountOpen(false)} />
    </>
  );
}
