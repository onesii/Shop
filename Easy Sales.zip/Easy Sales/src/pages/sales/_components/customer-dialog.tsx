import { useState } from "react";
import { useQuery } from "convex/react";
import { Search, UserPlus, Users, UserX } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { useTicket, type TicketCustomer } from "@/hooks/use-ticket.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { formatKsh } from "@/lib/money.ts";
import CustomerForm from "@/components/customers/customer-form.tsx";
import CustomerRow from "@/components/customers/customer-row.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";

type Props = { open: boolean; onClose: () => void };

export default function CustomerDialog({ open, onClose }: Props) {
  const [adding, setAdding] = useState(false);
  const close = () => {
    setAdding(false);
    onClose();
  };
  return (
    <Dialog open={open} onOpenChange={(o) => !o && close()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{adding ? "New customer" : "Add customer to ticket"}</DialogTitle>
          <DialogDescription>
            {adding ? "The customer is added to this ticket once saved" : "Search by name, phone or email"}
          </DialogDescription>
        </DialogHeader>
        {/* Only subscribe while open */}
        {open && (adding ? <NewCustomer onDone={close} onCancel={() => setAdding(false)} /> : <Picker onAdd={() => setAdding(true)} onDone={close} />)}
      </DialogContent>
    </Dialog>
  );
}

function NewCustomer({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const { setCustomer } = useTicket();
  return (
    <CustomerForm
      customer={null}
      onCancel={onCancel}
      onSaved={(c) => {
        setCustomer(c);
        onDone();
      }}
    />
  );
}

function Picker({ onAdd, onDone }: { onAdd: () => void; onDone: () => void }) {
  const { customer, setCustomer } = useTicket();
  const [search, setSearch] = useState("");
  const [debounced] = useDebounce(search, 250);
  const results = useQuery(api.customers.search, { search: debounced });

  const pick = (c: TicketCustomer | null) => {
    setCustomer(c);
    onDone();
  };

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          autoFocus
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search customers"
          className="pl-9"
        />
      </div>
      <Button variant="secondary" className="w-full" onClick={onAdd}>
        <UserPlus className="size-4" /> Add new customer
      </Button>
      <div className="-mx-6 max-h-[45vh] overflow-y-auto border-t">
        {results === undefined ? (
          Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="mx-6 my-2 h-12" />)
        ) : results.length === 0 ? (
          <Empty className="py-8">
            <EmptyHeader>
              <EmptyMedia variant="icon"><Users /></EmptyMedia>
              <EmptyTitle>{debounced ? "No matching customers" : "No customers yet"}</EmptyTitle>
              <EmptyDescription>Add a new customer to keep track of their visits</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          results.map((c) => (
            <CustomerRow
              key={c._id}
              name={c.name}
              detail={c.phone ?? c.email}
              right={`${c.visits} visits · ${formatKsh(c.totalSpentCents)}`}
              active={customer?.id === c._id}
              onClick={() => pick({ id: c._id, name: c.name })}
            />
          ))
        )}
      </div>
      {customer && (
        <Button variant="ghost" className="w-full text-destructive" onClick={() => pick(null)}>
          <UserX className="size-4" /> Remove {customer.name} from ticket
        </Button>
      )}
    </div>
  );
}
