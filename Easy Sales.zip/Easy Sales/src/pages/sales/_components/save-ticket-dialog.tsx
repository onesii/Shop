import { useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { format } from "date-fns";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { toTicketLines, useTicket } from "@/hooks/use-ticket.tsx";
import { usePrintOrder } from "@/hooks/use-print-receipt.ts";
import { formatKsh } from "@/lib/money.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";

export function saveErrorMessage(err: unknown): string {
  if (err instanceof ConvexError) {
    return (err.data as { message?: string }).message ?? "Could not save ticket";
  }
  return "Could not save ticket. Check your connection and try again.";
}

type Props = { open: boolean; onClose: () => void };

export default function SaveTicketDialog({ open, onClose }: Props) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        {/* Mounted only while open so the default name is fresh each time */}
        {open && <SaveTicketForm onClose={onClose} />}
      </DialogContent>
    </Dialog>
  );
}

function SaveTicketForm({ onClose }: { onClose: () => void }) {
  const { lines, discountIds, customer, totalCents, clear } = useTicket();
  const save = useMutation(api.sales.openTickets.save);
  const { printOrder } = usePrintOrder();
  // Default to the customer name, like the original app
  const [name, setName] = useState(() => customer?.name ?? `Ticket - ${format(new Date(), "h:mm a")}`);
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await save({ name, comment, lines: toTicketLines(lines), discountIds, customerId: customer?.id });
      // Kitchen/bar printers get the order as soon as the ticket is saved
      void printOrder({ name: name.trim(), comment: comment.trim() || null, lines });
      clear();
      toast.success(`Saved "${name.trim()}"`);
      onClose();
    } catch (err) {
      toast.error(saveErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="grid gap-4">
      <DialogHeader>
        <DialogTitle>Save ticket</DialogTitle>
        <DialogDescription>
          {formatKsh(totalCents)} · reopen it any time from Open tickets
        </DialogDescription>
      </DialogHeader>
      <div className="grid gap-2">
        <Label htmlFor="ticket-name">Name</Label>
        <Input
          id="ticket-name"
          autoFocus
          maxLength={60}
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Table 4"
        />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="ticket-comment">Comment</Label>
        <Textarea
          id="ticket-comment"
          rows={2}
          maxLength={200}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="No onions on the burger"
        />
      </div>
      <DialogFooter>
        <Button type="button" variant="ghost" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" disabled={saving || !name.trim()}>
          {saving ? "Saving..." : "Save"}
        </Button>
      </DialogFooter>
    </form>
  );
}
