import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { formatQtyWithUnit, lineTotalCents } from "@/convex/lib/quantity.ts";
import { useTicket, type TicketLine } from "@/hooks/use-ticket.tsx";
import { useTicketTotals } from "@/hooks/use-ticket-totals.ts";
import TaxBreakdown from "@/components/taxes/tax-breakdown.tsx";
import { formatKsh } from "@/lib/money.ts";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import ItemSheet from "./item-sheet.tsx";

type Props = { onEdit: (line: TicketLine) => void };

/** Lines on the current ticket; tap a line to change it. */
export default function TicketLines({ onEdit }: Props) {
  const { lines } = useTicket();
  const { subtotalCents, discounts, taxes } = useTicketTotals();

  if (lines.length === 0) {
    return <p className="py-5 text-center text-sm text-muted-foreground">Blank ticket</p>;
  }

  return (
    <>
      <ul className="divide-y">
        {lines.map((line) => (
          <li key={line.key}>
            <button
              type="button"
              onClick={() => onEdit(line)}
              className="flex w-full cursor-pointer items-start gap-3 px-4 py-3 text-left transition-colors hover:bg-muted"
            >
              <div className="min-w-0 flex-1">
                <p className="truncate">
                  {line.name}
                  <span className="text-muted-foreground"> x {formatQtyWithUnit(line.quantity, line.unit)}</span>
                </p>
                {line.variantName && <p className="truncate text-sm text-muted-foreground">{line.variantName}</p>}
                {line.comment && <p className="truncate text-sm text-muted-foreground italic">{line.comment}</p>}
              </div>
              <span className="shrink-0 tabular-nums">{formatKsh(lineTotalCents(line.priceCents, line.quantity))}</span>
            </button>
          </li>
        ))}
      </ul>
      <TaxBreakdown
        subtotalCents={subtotalCents}
        taxes={taxes}
        discounts={discounts}
        className="border-t px-4 py-3"
      />
    </>
  );
}

/** Loads the line's item so its variants and stock can be shown. */
export function LineEditor({ line, onClose }: { line: TicketLine; onClose: () => void }) {
  const { addLine, updateLine, removeLine } = useTicket();
  const item = useQuery(api.catalog.items.get, { id: line.itemId });

  if (item === undefined) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
        <Skeleton className="h-64 w-full max-w-xl" />
      </div>
    );
  }
  if (item === null) {
    // Item was deleted from the catalog: the line can only be removed
    return (
      <Dialog open onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{line.name}</DialogTitle>
            <DialogDescription>This item was deleted, so it can no longer be edited.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={onClose}>
              Keep
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                removeLine(line.key);
                onClose();
              }}
            >
              Remove from ticket
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }
  return (
    <ItemSheet
      item={item}
      line={line}
      onAdd={addLine}
      onUpdate={updateLine}
      onRemove={removeLine}
      onClose={onClose}
    />
  );
}
