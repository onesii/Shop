import { describe, expect, it } from "vitest";
import { nextQtyText } from "./quantity-keypad.tsx";

const type = (keys: string[]) => keys.reduce(nextQtyText, "");

describe("nextQtyText", () => {
  it("builds a decimal quantity and replaces a leading zero", () => {
    expect(type(["2", ".", "2", "5"])).toBe("2.25");
    expect(type(["0", "5"])).toBe("5");
    expect(type([".", "5"])).toBe("0.5");
  });

  it("allows one decimal point and at most 3 decimals", () => {
    expect(type(["1", ".", ".", "2"])).toBe("1.2");
    expect(type(["1", ".", "1", "2", "3", "4"])).toBe("1.123");
  });

  it("deletes the last character", () => {
    expect(type(["1", "2", "back"])).toBe("1");
    expect(type(["back"])).toBe("");
  });
});
