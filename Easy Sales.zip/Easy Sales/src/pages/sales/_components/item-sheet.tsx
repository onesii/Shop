import { useState } from "react";
import { useQuery } from "convex/react";
import { Minus, Plus, Trash2, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import {
  formatQty,
  isValidQuantity,
  itemUnit,
  lineTotalCents,
  MAX_LINE_COMMENT,
  roundQty,
  type WeightUnit,
} from "@/convex/lib/quantity.ts";
import type { LinePatch, TicketLine } from "@/hooks/use-ticket.tsx";
import { centsToInput, formatKsh, parseToCents } from "@/lib/money.ts";
import { cn } from "@/lib/utils.ts";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

export type NewLine = Omit<TicketLine, "key" | "quantity">;

type Props = {
  item: Doc<"items">;
  /** Set when editing a line already on the ticket. */
  line?: TicketLine;
  onAdd: (line: NewLine, quantity: number) => void;
  onUpdate: (key: string, patch: LinePatch) => void;
  onRemove: (key: string) => void;
  onClose: () => void;
};

/** Shows quantities like the original app: "2.000" for kg items, "2" otherwise. */
function qtyToText(qty: number, unit: WeightUnit | undefined): string {
  return unit === "kg" ? roundQty(qty).toFixed(3) : formatQty(qty);
}

/** +/- step: 100 g for gram items, otherwise 1. */
const stepSize = (unit: WeightUnit | undefined) => (unit === "g" ? 100 : 1);

/** Item popup: variant, quantity and comment (plus price for variable-price items). */
export default function ItemSheet(props: Props) {
  return (
    <Dialog open onOpenChange={(o) => !o && props.onClose()}>
      <DialogContent showCloseButton={false} className="gap-0 overflow-hidden p-0 sm:max-w-xl">
        <ItemSheetForm {...props} />
      </DialogContent>
    </Dialog>
  );
}

function ItemSheetForm({ item, line, onAdd, onUpdate, onRemove, onClose }: Props) {
  const unit = itemUnit(item);
  const variants = item.variants;
  const [variantName, setVariantName] = useState<string | null>(
    line ? line.variantName : (variants[0]?.name ?? null),
  );
  const variant = variants.find((v) => v.name === variantName);
  const fixedPrice = variants.length > 0 ? (variant?.priceCents ?? null) : item.priceCents;
  // Lines keep the price they were added with, unless a different variant is picked
  const keepsLinePrice = line && line.variantName === variantName;
  const [priceText, setPriceText] = useState(line ? centsToInput(line.priceCents) : "");
  const [qtyText, setQtyText] = useState(line ? qtyToText(line.quantity, unit) : unit ? "" : "1");
  const [comment, setComment] = useState(line?.comment ?? "");
  const levels = useQuery(api.inventory.stock.forItem, { itemId: item._id });

  const askPrice = fixedPrice === null;
  const typedPrice = parseToCents(priceText);
  const priceCents = askPrice
    ? typedPrice !== null && !Number.isNaN(typedPrice) ? typedPrice : null
    : keepsLinePrice ? line.priceCents : fixedPrice;
  const qty = Number(qtyText || "0");
  // Editing to 0 removes the line, like the original app
  const qtyOk = isValidQuantity(qty) || (line !== undefined && qty === 0);
  const canSave = priceCents !== null && priceCents > 0 && qtyOk && Number.isFinite(qty);

  const level = levels?.find((l) => l.variantName === (variants.length > 0 ? variantName : null));
  const outOfStock = level !== undefined && level.inStock <= 0;

  const step = (dir: 1 | -1) =>
    setQtyText(qtyToText(Math.max(0, roundQty(qty + dir * stepSize(unit))), unit));

  const save = () => {
    if (!canSave || priceCents === null) return;
    if (line && qty === 0) onRemove(line.key);
    else if (line) onUpdate(line.key, { variantName, priceCents, quantity: roundQty(qty), comment, unit });
    else {
      const base = { itemId: item._id, name: item.name, variantName, priceCents, color: item.color, unit };
      onAdd({ ...base, comment: comment.trim() || undefined }, roundQty(qty));
    }
    onClose();
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        save();
      }}
      className="flex max-h-[90dvh] flex-col"
    >
      <div className="flex items-center gap-3 border-b px-3 py-2">
        <button
          type="button"
          aria-label="Close"
          onClick={onClose}
          className="flex size-10 cursor-pointer items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted"
        >
          <X className="size-5" />
        </button>
        <DialogTitle className="min-w-0 flex-1 truncate text-lg font-semibold">
          {item.name}{" "}
          <span className="tabular-nums">
            {formatKsh(priceCents !== null && Number.isFinite(qty) ? lineTotalCents(priceCents, qty) : 0)}
          </span>
        </DialogTitle>
        <DialogDescription className="sr-only">Choose the variant, quantity and comment</DialogDescription>
        {line && (
          <button
            type="button"
            aria-label="Remove from ticket"
            onClick={() => {
              onRemove(line.key);
              onClose();
            }}
            className="flex size-10 cursor-pointer items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-destructive"
          >
            <Trash2 className="size-5" />
          </button>
        )}
        <button
          type="submit"
          disabled={!canSave}
          className="cursor-pointer rounded-sm px-3 py-2 text-sm font-semibold text-primary uppercase transition hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
        >
          Save
        </button>
      </div>

      {levels === undefined ? (
        <Skeleton className="h-10 w-full rounded-none" />
      ) : (
        outOfStock && <div className="bg-destructive/15 px-4 py-2.5 text-sm">Out of stock</div>
      )}

      <div className="min-h-0 flex-1 space-y-7 overflow-y-auto px-4 py-4">
        {variants.length > 0 && (
          <Section title="Variants">
            <div className="grid grid-cols-2 gap-3">
              {variants.map((v) => (
                <button
                  key={v.name}
                  type="button"
                  onClick={() => setVariantName(v.name)}
                  className={cn(
                    "flex min-h-12 cursor-pointer items-center justify-between gap-2 rounded-sm border px-3.5 py-3 text-left transition",
                    v.name === variantName ? "border-primary/30 bg-accent" : "bg-card hover:bg-muted",
                  )}
                >
                  <span className="truncate">{v.name}</span>
                  <span className="shrink-0 text-sm tabular-nums">
                    {v.priceCents === null ? "Variable" : `${formatKsh(v.priceCents)}${unit ? `/${unit}` : ""}`}
                  </span>
                </button>
              ))}
            </div>
          </Section>
        )}

        {askPrice && (
          <Section title={unit ? `Price per ${unit}` : "Price"}>
            <Input
              autoFocus
              inputMode="decimal"
              placeholder="0.00"
              value={priceText}
              onChange={(e) => setPriceText(e.target.value)}
              className="h-11 text-center text-base"
            />
          </Section>
        )}

        <Section title={unit ? `Weight (${unit})` : "Quantity"}>
          <div className="flex items-center gap-3">
            <StepButton label="Decrease quantity" onClick={() => step(-1)} disabled={qty <= 0}>
              <Minus className="size-4" />
            </StepButton>
            <Input
              inputMode="decimal"
              value={qtyText}
              placeholder="0"
              onChange={(e) => {
                if (/^\d*\.?\d{0,3}$/.test(e.target.value)) setQtyText(e.target.value);
              }}
              onBlur={() => qtyText && Number.isFinite(qty) && setQtyText(qtyToText(qty, unit))}
              aria-invalid={!qtyOk}
              className="h-11 flex-1 rounded-none border-0 border-b-2 text-center text-base shadow-none focus-visible:ring-0"
            />
            <StepButton label="Increase quantity" onClick={() => step(1)}>
              <Plus className="size-4" />
            </StepButton>
          </div>
        </Section>

        <Section title="Comment">
          <Input
            value={comment}
            maxLength={MAX_LINE_COMMENT}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Enter comment"
            className="h-11 rounded-none border-0 border-b-2 px-0 text-base shadow-none focus-visible:ring-0"
          />
        </Section>
      </div>
    </form>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-primary">{title}</p>
      {children}
    </div>
  );
}

function StepButton({
  label,
  onClick,
  disabled,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      disabled={disabled}
      className="flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-sm border bg-muted text-muted-foreground transition hover:bg-accent disabled:cursor-not-allowed disabled:opacity-50"
    >
      {children}
    </button>
  );
}
