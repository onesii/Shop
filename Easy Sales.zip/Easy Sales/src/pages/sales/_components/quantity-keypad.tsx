import { useState } from "react";
import { Delete } from "lucide-react";
import { convertWeight, type WeightUnit } from "@/convex/lib/quantity.ts";
import UnitSwitch from "@/components/items/unit-switch.tsx";
import { cn } from "@/lib/utils.ts";

const MAX_DIGITS = 9;
const MAX_DECIMALS = 3;

/** Applies one keypad press to the typed quantity text. */
export function nextQtyText(text: string, key: string): string {
  if (key === "back") return text.slice(0, -1);
  if (key === ".") return text.includes(".") ? text : `${text || "0"}.`;
  const decimals = text.split(".")[1];
  if (decimals !== undefined && decimals.length >= MAX_DECIMALS) return text;
  if (text.replace(".", "").length >= MAX_DIGITS) return text;
  return text === "0" ? key : text + key;
}

const keyClass =
  "flex cursor-pointer items-center justify-center border-r border-b text-xl transition-colors hover:bg-muted active:bg-accent";

type Props = {
  /** Unit the item is priced in; shows a kg / g switch. Omit for items sold by count. */
  unit?: WeightUnit;
  /** Quantity in the item's own unit. */
  onDone: (quantity: number) => void;
};

/** Full-width number pad for typing a quantity, like the original app. */
export default function QuantityKeypad({ unit, onDone }: Props) {
  const [text, setText] = useState("");
  const [entryUnit, setEntryUnit] = useState<WeightUnit | undefined>(unit);
  const press = (key: string) => setText((t) => nextQtyText(t, key));
  const done = () => {
    const typed = Number(text || "0");
    onDone(unit && entryUnit ? convertWeight(typed, entryUnit, unit) : typed);
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (/^[0-9.]$/.test(e.key)) press(e.key);
    else if (e.key === "Backspace") press("back");
    else if (e.key === "Enter") {
      e.preventDefault();
      done();
    }
  };

  return (
    <div tabIndex={-1} onKeyDown={handleKey} autoFocus className="outline-none">
      <div className="flex items-center justify-between gap-4 border-b px-5 py-5">
        {entryUnit ? (
          <UnitSwitch value={entryUnit} onChange={setEntryUnit} />
        ) : (
          <span className="text-sm">Quantity</span>
        )}
        <span className="truncate text-3xl tabular-nums">
          {text || "0"}
          {entryUnit && <span className="pl-1.5 text-lg text-muted-foreground">{entryUnit}</span>}
        </span>
      </div>
      <div className="grid h-[min(60dvh,460px)] grid-cols-4 grid-rows-4 border-l">
        {["1", "2", "3"].map((k) => (
          <KeyButton key={k} k={k} onPress={press} />
        ))}
        <button type="button" aria-label="Delete" onClick={() => press("back")} className={cn(keyClass, "row-span-2")}>
          <Delete className="size-6 text-muted-foreground" />
        </button>
        {["4", "5", "6", "7", "8", "9"].map((k) => (
          <KeyButton key={k} k={k} onPress={press} />
        ))}
        <button
          type="button"
          onClick={done}
          className={cn(keyClass, "col-start-4 row-span-2 row-start-3 text-lg font-semibold text-primary")}
        >
          OK
        </button>
        <KeyButton k="." onPress={press} />
        <KeyButton k="0" onPress={press} className="col-span-2" />
      </div>
    </div>
  );
}

function KeyButton({ k, onPress, className }: { k: string; onPress: (k: string) => void; className?: string }) {
  return (
    <button type="button" onClick={() => onPress(k)} className={cn(keyClass, className)}>
      {k}
    </button>
  );
}
