import { useState } from "react";
import { useQuery } from "convex/react";
import { format } from "date-fns";
import { ArrowLeft, Printer, ReceiptText, Undo2 } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { usePrintReceipt } from "@/hooks/use-print-receipt.ts";
import { useStaff } from "@/hooks/use-staff.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { formatKsh } from "@/lib/money.ts";
import { formatQtyWithUnit, lineTotalCents } from "@/convex/lib/quantity.ts";
import { PAYMENT_METHODS } from "@/lib/payments.ts";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import RefundDialog from "./refund-dialog.tsx";
import TaxBreakdown from "@/components/taxes/tax-breakdown.tsx";

type Props = {
  id: Id<"receipts">;
  onBack: () => void;
  onOpen: (id: Id<"receipts">) => void;
};

export default function ReceiptDetail({ id, onBack, onOpen }: Props) {
  const data = useQuery(api.sales.receipts.get, { id });
  const [refunding, setRefunding] = useState(false);
  const { print, printing } = usePrintReceipt();
  const { can } = useStaff();

  if (data === undefined) {
    return (
      <div className="mx-auto w-full max-w-md space-y-4 p-6">
        <Skeleton className="mx-auto h-10 w-40" />
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-6 w-full" />
        ))}
      </div>
    );
  }
  if (data === null) {
    return (
      <Empty className="h-full">
        <EmptyHeader>
          <EmptyMedia variant="icon"><ReceiptText /></EmptyMedia>
          <EmptyTitle>Receipt not found</EmptyTitle>
          <EmptyDescription>It may have been removed or belongs to another account.</EmptyDescription>
        </EmptyHeader>
      </Empty>
    );
  }

  const { receipt, refunds, original, refundedByLine } = data;
  const isRefund = receipt.kind === "refund";
  const fullyRefunded = !isRefund && receipt.refundedCents >= receipt.totalCents;
  const Pay = PAYMENT_METHODS[receipt.paymentMethod];

  return (
    <div className="mx-auto w-full max-w-md p-4 md:p-6">
      <div className="flex items-center justify-between pb-4">
        <Button variant="ghost" size="sm" className="md:hidden" onClick={onBack}>
          <ArrowLeft className="size-4" /> Receipts
        </Button>
        <span className="hidden md:block" />
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" disabled={printing} onClick={() => void print(receipt)}>
            {printing ? <Spinner /> : <Printer className="size-4" />} Print
          </Button>
          {!isRefund && can("refunds") && (
            <Button
              variant="ghost"
              size="sm"
              className="text-destructive"
              disabled={fullyRefunded}
              onClick={() => setRefunding(true)}
            >
              <Undo2 className="size-4" /> {fullyRefunded ? "Refunded" : "Refund"}
            </Button>
          )}
        </div>
      </div>

      <article className="space-y-4 rounded-md border bg-card p-6 shadow-sm">
        <div className="text-center">
          <p className={`text-4xl font-bold tabular-nums ${isRefund ? "text-destructive" : ""}`}>
            {isRefund ? "-" : ""}
            {formatKsh(receipt.totalCents)}
          </p>
          <p className="pt-1 text-sm text-muted-foreground">{isRefund ? "Refund" : "Total"}</p>
        </div>
        <Separator />
        {receipt.storeName && (
          <p className="text-center font-semibold">{receipt.storeName}</p>
        )}
        {receipt.receiptHeader && (
          <p className="whitespace-pre-line text-center text-sm text-muted-foreground">{receipt.receiptHeader}</p>
        )}
        <div className="space-y-1 text-sm text-muted-foreground">
          <p>Receipt #{receipt.number}</p>
          <p>{format(new Date(receipt.createdAt), "d MMM yyyy, h:mm a")}</p>
          <p>POS: {receipt.posName ?? "POS 1"}</p>
          {receipt.employeeName && <p>Employee: {receipt.employeeName}</p>}
          {receipt.customerName && <p>Customer: {receipt.customerName}</p>}
        </div>
        <Separator />
        <div className="space-y-3">
          {receipt.lines.map((l, i) => (
            <div key={i} className="flex justify-between gap-4 text-sm">
              <div className="min-w-0">
                <p className="font-medium">
                  {l.name}
                  {l.variantName && <span className="text-muted-foreground"> ({l.variantName})</span>}
                </p>
                <p className="text-muted-foreground">
                  {formatQtyWithUnit(l.quantity, l.unit)} x {formatKsh(l.priceCents)}
                  {l.unit && `/${l.unit}`}
                </p>
                {l.comment && <p className="text-muted-foreground italic">{l.comment}</p>}
              </div>
              <span className="shrink-0 tabular-nums">{formatKsh(lineTotalCents(l.priceCents, l.quantity))}</span>
            </div>
          ))}
        </div>
        <Separator />
        <div className="space-y-1.5 text-sm">
          {receipt.subtotalCents !== undefined && (
            <TaxBreakdown
              subtotalCents={receipt.subtotalCents}
              taxes={receipt.taxes ?? []}
              discounts={receipt.discounts ?? []}
              className="pb-1"
            />
          )}
          <div className="flex justify-between text-base font-bold">
            <span>Total</span>
            <span className="tabular-nums">{formatKsh(receipt.totalCents)}</span>
          </div>
          <div className="flex justify-between">
            <span className="flex items-center gap-2"><Pay.icon className="size-4" />{Pay.label}</span>
            <span className="tabular-nums">{formatKsh(receipt.tenderedCents)}</span>
          </div>
          {receipt.changeCents > 0 && (
            <div className="flex justify-between text-muted-foreground">
              <span>Change</span>
              <span className="tabular-nums">{formatKsh(receipt.changeCents)}</span>
            </div>
          )}
          {receipt.mpesaReference && (
            <div className="flex justify-between text-muted-foreground">
              <span>M-Pesa code</span>
              <span>{receipt.mpesaReference}</span>
            </div>
          )}
        </div>

        {(refunds.length > 0 || original) && (
          <>
            <Separator />
            <div className="flex flex-wrap gap-2">
              {original && (
                <Badge variant="secondary" className="cursor-pointer" onClick={() => onOpen(original._id)}>
                  Refund of #{original.number}
                </Badge>
              )}
              {refunds.map((r) => (
                <Badge key={r._id} variant="destructive" className="cursor-pointer" onClick={() => onOpen(r._id)}>
                  Refund #{r.number} · {formatKsh(r.totalCents)}
                </Badge>
              ))}
            </div>
          </>
        )}
        {receipt.receiptFooter && (
          <>
            <Separator />
            <p className="whitespace-pre-line text-center text-sm text-muted-foreground">
              {receipt.receiptFooter}
            </p>
          </>
        )}
      </article>

      {refunding && (
        <RefundDialog receipt={receipt} refundedByLine={refundedByLine} onClose={() => setRefunding(false)} />
      )}
    </div>
  );
}
