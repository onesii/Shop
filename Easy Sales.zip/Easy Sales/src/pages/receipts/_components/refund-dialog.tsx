import { useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { formatKsh } from "@/lib/money.ts";
import { formatQty, formatQtyWithUnit, roundQty, sumLineTotals } from "@/convex/lib/quantity.ts";
import { computeTaxes } from "@/convex/lib/taxes.ts";

type Props = {
  receipt: Doc<"receipts">;
  refundedByLine: number[];
  onClose: () => void;
};

export default function RefundDialog({ receipt, refundedByLine, onClose }: Props) {
  const refund = useMutation(api.sales.receipts.refund);
  const remaining = receipt.lines.map((l, i) => roundQty(l.quantity - (refundedByLine[i] ?? 0)));
  const [quantities, setQuantities] = useState<number[]>(receipt.lines.map(() => 0));
  const [saving, setSaving] = useState(false);

  const subtotal = sumLineTotals(receipt.lines.map((l, i) => ({ priceCents: l.priceCents, quantity: quantities[i] })));
  const rules = (receipt.taxes ?? []).map(({ name, rateBps, type }) => ({ name, rateBps, type }));
  // Estimate shown to the cashier; the server settles exact rounding on full refunds
  const total = computeTaxes(subtotal, rules).totalCents;
  const setQty = (i: number, q: number) =>
    setQuantities((prev) => prev.map((x, j) => (j === i ? roundQty(Math.max(0, Math.min(remaining[i], q))) : x)));

  const submit = async () => {
    setSaving(true);
    try {
      await refund({ receiptId: receipt._id, quantities });
      toast.success(`Refunded ${formatKsh(total)}`);
      onClose();
    } catch (err) {
      const message =
        err instanceof ConvexError ? (err.data as { message?: string }).message : undefined;
      toast.error(message ?? "Refund failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Refund #{receipt.number}</DialogTitle>
          <DialogDescription>Choose how many of each item to refund.</DialogDescription>
        </DialogHeader>

        <div className="divide-y rounded-md border">
          {receipt.lines.map((line, i) => (
            <div key={i} className="flex items-center gap-3 px-3 py-2.5">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">
                  {line.name}
                  {line.variantName && <span className="text-muted-foreground"> ({line.variantName})</span>}
                </p>
                <p className="text-xs text-muted-foreground">
                  {remaining[i] === 0 ? "Fully refunded" : `${formatQtyWithUnit(remaining[i], line.unit)} available · ${formatKsh(line.priceCents)}${line.unit ? `/${line.unit}` : ""}`}
                </p>
              </div>
              <Button size="icon" variant="secondary" className="size-8" aria-label="Less" disabled={quantities[i] === 0} onClick={() => setQty(i, quantities[i] - 1)}>
                <Minus className="size-4" />
              </Button>
              <span className="w-6 text-center font-semibold tabular-nums">{formatQty(quantities[i])}</span>
              <Button size="icon" variant="secondary" className="size-8" aria-label="More" disabled={quantities[i] >= remaining[i]} onClick={() => setQty(i, quantities[i] + 1)}>
                <Plus className="size-4" />
              </Button>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            className="text-primary"
            onClick={() => setQuantities(remaining)}
          >
            Select all
          </Button>
          <span className="font-semibold tabular-nums">{formatKsh(total)}</span>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="destructive" disabled={total === 0 || saving} onClick={submit}>
            {saving ? "Refunding..." : `Refund ${formatKsh(total)}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
