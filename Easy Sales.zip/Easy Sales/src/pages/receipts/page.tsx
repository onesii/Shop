import { useSearchParams } from "react-router-dom";
import { usePaginatedQuery } from "convex/react";
import { format, isToday, isYesterday } from "date-fns";
import { ReceiptText } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import AppBar from "@/components/layout/app-bar.tsx";
import { formatKsh } from "@/lib/money.ts";
import { PAYMENT_METHODS } from "@/lib/payments.ts";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import ReceiptDetail from "./_components/receipt-detail.tsx";

function dayLabel(iso: string): string {
  const d = new Date(iso);
  if (isToday(d)) return "Today";
  if (isYesterday(d)) return "Yesterday";
  return format(d, "EEEE, d MMMM yyyy");
}

/** Groups receipts by local calendar day, preserving order. */
function groupByDay(receipts: Doc<"receipts">[]): { label: string; items: Doc<"receipts">[] }[] {
  const groups: { label: string; items: Doc<"receipts">[] }[] = [];
  for (const r of receipts) {
    const label = dayLabel(r.createdAt);
    const last = groups[groups.length - 1];
    if (last?.label === label) last.items.push(r);
    else groups.push({ label, items: [r] });
  }
  return groups;
}

export default function ReceiptsPage() {
  const [params, setParams] = useSearchParams();
  const selected = params.get("id") as Id<"receipts"> | null;
  const { results, status, loadMore } = usePaginatedQuery(
    api.sales.receipts.list,
    {},
    { initialNumItems: 50 },
  );

  const open = (id: Id<"receipts">) => setParams({ id });
  const close = () => setParams({});

  return (
    <>
      <AppBar title="Receipts" />
      <div className="flex min-h-0 flex-1">
        {/* List */}
        <section
          className={cn(
            "min-h-0 w-full overflow-y-auto border-r md:block md:w-96",
            selected && "hidden",
          )}
        >
          {status === "LoadingFirstPage" ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4 border-b px-4 py-3">
                <Skeleton className="size-6 rounded-full" />
                <Skeleton className="h-4 flex-1" />
              </div>
            ))
          ) : results.length === 0 && status === "Exhausted" ? (
            <Empty className="h-full">
              <EmptyHeader>
                <EmptyMedia variant="icon"><ReceiptText /></EmptyMedia>
                <EmptyTitle>No receipts yet</EmptyTitle>
                <EmptyDescription>Receipts appear here after you charge a sale.</EmptyDescription>
              </EmptyHeader>
            </Empty>
          ) : (
            <>
              {groupByDay(results).map((group) => (
                <div key={group.label}>
                  <p className="sticky top-0 z-10 bg-background px-4 pb-2 pt-4 text-sm font-semibold text-primary">
                    {group.label}
                  </p>
                  {group.items.map((r) => {
                    const Icon = PAYMENT_METHODS[r.paymentMethod].icon;
                    const isRefund = r.kind === "refund";
                    return (
                      <button
                        key={r._id}
                        type="button"
                        onClick={() => open(r._id)}
                        className={cn(
                          "flex w-full cursor-pointer items-center gap-4 border-b bg-card px-4 py-3 text-left transition-colors hover:bg-muted",
                          selected === r._id && "bg-accent",
                        )}
                      >
                        <Icon className="size-5 shrink-0 text-muted-foreground" />
                        <div className="min-w-0 flex-1">
                          <p className={cn("font-semibold tabular-nums", isRefund && "text-destructive")}>
                            {isRefund ? "-" : ""}
                            {formatKsh(r.totalCents)}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(r.createdAt), "h:mm a")}
                            {isRefund && " · Refund"}
                            {!isRefund && r.refundedCents > 0 && " · Refunded"}
                          </p>
                        </div>
                        <span className="text-sm text-muted-foreground">#{r.number}</span>
                      </button>
                    );
                  })}
                </div>
              ))}
              {(status === "CanLoadMore" || status === "LoadingMore") && (
                <div className="p-4">
                  <Button
                    variant="secondary"
                    className="w-full"
                    disabled={status === "LoadingMore"}
                    onClick={() => loadMore(50)}
                  >
                    {status === "LoadingMore" ? "Loading..." : "Load more"}
                  </Button>
                </div>
              )}
            </>
          )}
        </section>

        {/* Detail */}
        <section className={cn("min-h-0 flex-1 overflow-y-auto md:block", !selected && "hidden")}>
          {selected ? (
            <ReceiptDetail key={selected} id={selected} onBack={close} onOpen={open} />
          ) : (
            <Empty className="h-full">
              <EmptyHeader>
                <EmptyMedia variant="icon"><ReceiptText /></EmptyMedia>
                <EmptyTitle>Select a receipt</EmptyTitle>
                <EmptyDescription>Choose a receipt to see its details or issue a refund.</EmptyDescription>
              </EmptyHeader>
            </Empty>
          )}
        </section>
      </div>
    </>
  );
}
