import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import AppLayout from "./components/layout/app-layout.tsx";
import AuthCallback from "./pages/auth/Callback.tsx";
import Index from "./pages/Index.tsx";
import ItemsMenuPage from "./pages/items/page.tsx";
import ItemListPage from "./pages/items/list/page.tsx";
import CategoriesPage from "./pages/items/categories/page.tsx";
import DiscountsPage from "./pages/items/discounts/page.tsx";
import ModifiersPage from "./pages/items/modifiers/page.tsx";
import ModifierEditPage from "./pages/items/modifiers/edit/page.tsx";
import ChargePage from "./pages/charge/page.tsx";
import ReceiptsPage from "./pages/receipts/page.tsx";
import ShiftPage from "./pages/shift/page.tsx";
import SettingsMenuPage from "./pages/settings/page.tsx";
import TaxesSettingsPage from "./pages/settings/taxes/page.tsx";
import GeneralSettingsPage from "./pages/settings/general/page.tsx";
import ReceiptSettingsPage from "./pages/settings/receipt/page.tsx";
import PrintersPage from "./pages/settings/printers/page.tsx";
import PrinterEditPage from "./pages/settings/printers/edit/page.tsx";
import BackOfficeLayout from "./pages/back-office/_components/back-office-layout.tsx";
import SalesSummaryPage from "./pages/back-office/page.tsx";
import SalesByItemPage from "./pages/back-office/sales-by-item/page.tsx";
import SalesByCategoryPage from "./pages/back-office/sales-by-category/page.tsx";
import SalesByEmployeePage from "./pages/back-office/sales-by-employee/page.tsx";
import SalesByPaymentTypePage from "./pages/back-office/sales-by-payment-type/page.tsx";
import ReceiptsReportPage from "./pages/back-office/receipts/page.tsx";
import DiscountsReportPage from "./pages/back-office/discounts/page.tsx";
import ShiftsReportPage from "./pages/back-office/shifts/page.tsx";
import CustomersPage from "./pages/back-office/customers/page.tsx";
import InventoryPage from "./pages/back-office/inventory/page.tsx";
import PurchaseOrdersPage from "./pages/back-office/purchase-orders/page.tsx";
import PurchaseOrderPage from "./pages/back-office/purchase-orders/detail/page.tsx";
import SuppliersPage from "./pages/back-office/suppliers/page.tsx";
import InventoryCountsPage from "./pages/back-office/inventory-counts/page.tsx";
import InventoryCountPage from "./pages/back-office/inventory-counts/detail/page.tsx";
import InventoryHistoryPage from "./pages/back-office/inventory-history/page.tsx";
import InventoryValuationPage from "./pages/back-office/inventory-valuation/page.tsx";
import EmployeesPage from "./pages/back-office/employees/page.tsx";
import AccessRightsPage from "./pages/back-office/access-rights/page.tsx";
import TimecardsPage from "./pages/back-office/timecards/page.tsx";
import HoursWorkedPage from "./pages/back-office/hours-worked/page.tsx";
import RequirePermission from "./components/staff/require-permission.tsx";
import NotFound from "./pages/NotFound.tsx";
import JoinPage from "./pages/join/page.tsx";
import { useServiceWorker } from "@/hooks/use-service-worker.ts";

export default function App() {
  useServiceWorker();
  return (
    <DefaultProviders>
      <BrowserRouter>
        <Routes>
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/join/:token" element={<JoinPage />} />
          <Route element={<AppLayout />}>
            <Route path="/" element={<Index />} />
            <Route path="/items" element={<RequirePermission permission="items"><ItemsMenuPage /></RequirePermission>} />
            <Route path="/items/list" element={<RequirePermission permission="items"><ItemListPage /></RequirePermission>} />
            <Route path="/items/categories" element={<RequirePermission permission="items"><CategoriesPage /></RequirePermission>} />
            <Route path="/items/modifiers" element={<RequirePermission permission="items"><ModifiersPage /></RequirePermission>} />
            <Route path="/items/modifiers/:id" element={<RequirePermission permission="items"><ModifierEditPage /></RequirePermission>} />
            <Route path="/items/discounts" element={<RequirePermission permission="items"><DiscountsPage /></RequirePermission>} />
            <Route path="/charge" element={<ChargePage />} />
            <Route path="/receipts" element={<ReceiptsPage />} />
            <Route path="/shift" element={<ShiftPage />} />
            <Route path="/settings" element={<RequirePermission permission="settings"><SettingsMenuPage /></RequirePermission>} />
            <Route path="/settings/taxes" element={<RequirePermission permission="settings"><TaxesSettingsPage /></RequirePermission>} />
            <Route path="/settings/general" element={<RequirePermission permission="settings"><GeneralSettingsPage /></RequirePermission>} />
            <Route path="/settings/receipt" element={<RequirePermission permission="settings"><ReceiptSettingsPage /></RequirePermission>} />
            <Route path="/settings/printers" element={<RequirePermission permission="settings"><PrintersPage /></RequirePermission>} />
            <Route path="/settings/printers/:id" element={<RequirePermission permission="settings"><PrinterEditPage /></RequirePermission>} />
            <Route element={<BackOfficeLayout />}>
              <Route path="/back-office" element={<SalesSummaryPage />} />
              <Route path="/back-office/sales-by-item" element={<SalesByItemPage />} />
              <Route path="/back-office/sales-by-category" element={<SalesByCategoryPage />} />
              <Route path="/back-office/sales-by-employee" element={<SalesByEmployeePage />} />
              <Route path="/back-office/sales-by-payment-type" element={<SalesByPaymentTypePage />} />
              <Route path="/back-office/receipts" element={<ReceiptsReportPage />} />
              <Route path="/back-office/discounts" element={<DiscountsReportPage />} />
              <Route path="/back-office/shifts" element={<ShiftsReportPage />} />
              <Route path="/back-office/customers" element={<CustomersPage />} />
              <Route path="/back-office/inventory" element={<InventoryPage />} />
              <Route path="/back-office/purchase-orders" element={<PurchaseOrdersPage />} />
              <Route path="/back-office/purchase-orders/:id" element={<PurchaseOrderPage />} />
              <Route path="/back-office/suppliers" element={<SuppliersPage />} />
              <Route path="/back-office/inventory-counts" element={<InventoryCountsPage />} />
              <Route path="/back-office/inventory-counts/:id" element={<InventoryCountPage />} />
              <Route path="/back-office/inventory-history" element={<InventoryHistoryPage />} />
              <Route path="/back-office/inventory-valuation" element={<InventoryValuationPage />} />
              <Route path="/back-office/employees" element={<EmployeesPage />} />
              <Route path="/back-office/access-rights" element={<AccessRightsPage />} />
              <Route path="/back-office/timecards" element={<TimecardsPage />} />
              <Route path="/back-office/hours-worked" element={<HoursWorkedPage />} />
            </Route>
          </Route>
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </DefaultProviders>
  );
}
