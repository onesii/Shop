import { motion } from "motion/react";
import { ReceiptText, ShoppingBasket, List } from "lucide-react";
import { SignInButton } from "@/components/ui/signin.tsx";

const FEATURES = [
  { icon: ShoppingBasket, text: "Ring up sales in seconds" },
  { icon: List, text: "Manage items, prices and variants" },
  { icon: ReceiptText, text: "Track every ticket in KSh" },
];

export default function Landing() {
  return (
    <div className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-secondary px-6 text-secondary-foreground">
      <div className="pointer-events-none absolute -right-32 top-0 h-full w-[60%] skew-x-[-18deg] bg-primary/40" />
      <div className="pointer-events-none absolute -right-10 top-0 h-full w-[25%] skew-x-[-18deg] bg-white/5" />
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative w-full max-w-md space-y-8"
      >
        <div className="flex size-16 items-center justify-center rounded-2xl bg-white text-secondary shadow-lg">
          <ShoppingBasket className="size-8" />
        </div>
        <div className="space-y-3">
          <h1 className="text-balance text-4xl font-bold tracking-tight">
            Your shop counter, on any screen
          </h1>
          <p className="text-lg opacity-85">
            A fast point of sale for your business. Sign in to open your register.
          </p>
        </div>
        <ul className="space-y-3">
          {FEATURES.map((f, i) => (
            <motion.li
              key={f.text}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + i * 0.1, duration: 0.4, ease: "easeOut" }}
              className="flex items-center gap-3"
            >
              <f.icon className="size-5 opacity-80" />
              {f.text}
            </motion.li>
          ))}
        </ul>
        <SignInButton
          size="lg"
          signInText="Sign in to your register"
          className="h-12 w-full bg-white text-base font-semibold text-secondary hover:bg-white/90"
        />
      </motion.div>
    </div>
  );
}
