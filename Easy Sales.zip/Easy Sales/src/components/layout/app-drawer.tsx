import { NavLink } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import {
  BarChart3,
  Clock,
  Info,
  List,
  Lock,
  LogOut,
  ReceiptText,
  Settings,
  ShoppingBasket,
  type LucideIcon,
} from "lucide-react";
import type { Permission } from "@/convex/lib/access.ts";
import { useAuth, useUser } from "@/hooks/use-auth.ts";
import { useStaff } from "@/hooks/use-staff.tsx";
import { ROLE_LABELS } from "@/lib/staff.ts";
import { Separator } from "@/components/ui/separator.tsx";
import ClockButton from "@/components/staff/clock-button.tsx";
import { cn } from "@/lib/utils.ts";

type NavEntry = { label: string; icon: LucideIcon; to?: string; allowed?: (can: (p: Permission) => boolean) => boolean };

const MAIN_NAV: NavEntry[] = [
  { label: "Sales", icon: ShoppingBasket, to: "/" },
  { label: "Receipts", icon: ReceiptText, to: "/receipts" },
  { label: "Shift", icon: Clock, to: "/shift" },
  { label: "Items", icon: List, to: "/items", allowed: (can) => can("items") },
  { label: "Settings", icon: Settings, to: "/settings", allowed: (can) => can("settings") },
];

// Back office opens on the first page the employee may see
const BACK_OFFICE_PAGES: [Permission, string][] = [
  ["reports", "/back-office"],
  ["items", "/back-office/inventory"],
  ["employees", "/back-office/employees"],
  ["customers", "/back-office/customers"],
];

function secondaryNav(can: (p: Permission) => boolean): NavEntry[] {
  const backOffice = BACK_OFFICE_PAGES.find(([p]) => can(p));
  return [
    ...(backOffice ? [{ label: "Back office", icon: BarChart3, to: backOffice[1] }] : []),
    { label: "Support", icon: Info },
  ];
}

const rowClass =
  "flex w-full cursor-pointer items-center gap-8 px-6 py-3.5 text-sm font-medium transition-colors hover:bg-muted";

function NavRow({ entry, onNavigate }: { entry: NavEntry; onNavigate: () => void }) {
  const Icon = entry.icon;
  if (!entry.to) {
    return (
      <button
        type="button"
        className={cn(rowClass, "text-foreground")}
        onClick={() => toast("Coming soon in a future milestone!")}
      >
        <Icon className="size-5 text-muted-foreground" />
        {entry.label}
      </button>
    );
  }
  return (
    <NavLink
      to={entry.to}
      end={entry.to === "/"}
      onClick={onNavigate}
      className={({ isActive }) =>
        cn(rowClass, isActive ? "bg-muted text-primary" : "text-foreground")
      }
    >
      {({ isActive }) => (
        <>
          <Icon
            className={cn("size-5", isActive ? "text-primary" : "text-muted-foreground")}
          />
          {entry.label}
        </>
      )}
    </NavLink>
  );
}

export default function AppDrawer({ onNavigate }: { onNavigate: () => void }) {
  const user = useUser();
  const { signout } = useAuth();
  const staff = useStaff();
  const lock = useMutation(api.staff.session.lock);
  const settings = useQuery(api.settings.get, {});
  const profile = user?.profile;
  const visible = (e: NavEntry) => !e.allowed || e.allowed(staff.can);

  return (
    <div className="flex h-full flex-col">
      <div className="relative overflow-hidden bg-primary px-6 pb-6 pt-10 text-primary-foreground">
        {/* Diagonal sheen, as in the original app header */}
        <div className="pointer-events-none absolute -right-16 top-0 h-full w-40 skew-x-[-20deg] bg-white/10" />
        <p className="truncate pr-12 text-lg font-semibold">{staff.name}</p>
        <p className="pt-1 text-sm opacity-90">
          {[settings?.storeName, settings?.posName ?? "POS 1"].filter(Boolean).join(" · ")}
        </p>
        <p className="truncate text-sm opacity-90">
          {ROLE_LABELS[staff.role]}
          {staff.role === "owner" && profile?.email ? ` · ${profile.email}` : ""}
        </p>
        {staff.canLock ? (
          <button
            type="button"
            aria-label="Lock POS"
            title="Lock POS"
            onClick={() => {
              onNavigate();
              void lock({});
            }}
            className="absolute right-5 top-12 flex size-10 cursor-pointer items-center justify-center rounded-full bg-white/90 text-secondary transition hover:bg-white"
          >
            <Lock className="size-4" />
          </button>
        ) : (
          <button
            type="button"
            aria-label="Sign out"
            onClick={() => void signout()}
            className="absolute right-5 top-12 flex size-10 cursor-pointer items-center justify-center rounded-full bg-white/90 text-secondary transition hover:bg-white"
          >
            <LogOut className="size-4" />
          </button>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto py-2">
        {MAIN_NAV.filter(visible).map((e) => (
          <NavRow key={e.label} entry={e} onNavigate={onNavigate} />
        ))}
        <Separator className="my-2" />
        {secondaryNav(staff.can).map((e) => (
          <NavRow key={e.label} entry={e} onNavigate={onNavigate} />
        ))}
      </nav>

      <div className="border-t">
        <ClockButton />
      </div>
      <div className="border-t px-6 py-4 text-xs text-muted-foreground">v.1.0</div>
    </div>
  );
}
