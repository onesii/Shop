import { Outlet } from "react-router-dom";
import { Authenticated, AuthLoading, Unauthenticated, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { TicketProvider } from "@/hooks/use-ticket.tsx";
import { StaffProvider, useStaffSession } from "@/hooks/use-staff.tsx";
import PinLock from "@/components/staff/pin-lock.tsx";
import OfflineBanner from "@/components/offline/offline-banner.tsx";
import { OfflineSyncProvider } from "@/hooks/use-offline-sync.tsx";
import Landing from "./landing.tsx";

function LoadingScreen() {
  return (
    <div className="flex h-dvh flex-col">
      <Skeleton className="h-14 w-full rounded-none" />
      <div className="space-y-2 p-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    </div>
  );
}

/** Shows the PIN pad while locked, otherwise the app with the unlocked employee. */
function UnlockedApp() {
  const session = useStaffSession();
  const settings = useQuery(api.settings.get, {});
  if (session === undefined) return <LoadingScreen />;
  if (!session?.staff) return <PinLock storeName={settings?.storeName} />;
  const { staff, canLock } = session;
  const value = {
    name: staff.name,
    role: staff.role,
    permissions: staff.permissions,
    canLock,
    can: (p: (typeof staff.permissions)[number]) => staff.permissions.includes(p),
  };
  return (
    <StaffProvider value={value}>
      <TicketProvider>
        <OfflineSyncProvider>
          <div className="flex h-dvh flex-col bg-background">
            <OfflineBanner />
            <Outlet />
          </div>
        </OfflineSyncProvider>
      </TicketProvider>
    </StaffProvider>
  );
}

/** Gates all POS screens behind sign-in and the employee PIN, and provides the current sale. */
export default function AppLayout() {
  return (
    <>
      <AuthLoading>
        <LoadingScreen />
      </AuthLoading>
      <Unauthenticated>
        <Landing />
      </Unauthenticated>
      <Authenticated>
        <UnlockedApp />
      </Authenticated>
    </>
  );
}
