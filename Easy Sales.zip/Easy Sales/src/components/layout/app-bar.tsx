import { useState } from "react";
import { ArrowLeft, Menu } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetTitle,
} from "@/components/ui/sheet.tsx";
import AppDrawer from "./app-drawer.tsx";

type AppBarProps = {
  title: React.ReactNode;
  actions?: React.ReactNode;
  /** Shows a back arrow instead of the menu button (for sub-screens). */
  onBack?: () => void;
};

/** Green top bar with the menu button, shared by every screen. */
export default function AppBar({ title, actions, onBack }: AppBarProps) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 flex h-14 shrink-0 items-center gap-2 bg-secondary px-2 text-secondary-foreground shadow-md">
      <button
        type="button"
        aria-label={onBack ? "Back" : "Open menu"}
        onClick={onBack ?? (() => setOpen(true))}
        className="flex size-10 cursor-pointer items-center justify-center rounded-full transition hover:bg-white/10"
      >
        {onBack ? <ArrowLeft className="size-6" /> : <Menu className="size-6" />}
      </button>
      <div className="min-w-0 flex-1 truncate pl-2 text-lg font-semibold">{title}</div>
      <div className="flex items-center gap-1">{actions}</div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="w-[85vw] max-w-80 gap-0 p-0 [&>button]:hidden">
          <SheetTitle className="sr-only">Menu</SheetTitle>
          <SheetDescription className="sr-only">App navigation</SheetDescription>
          <AppDrawer onNavigate={() => setOpen(false)} />
        </SheetContent>
      </Sheet>
    </header>
  );
}

export function AppBarIconButton({
  label,
  children,
  onClick,
}: {
  label: string;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="flex size-10 cursor-pointer items-center justify-center rounded-full transition hover:bg-white/10"
    >
      {children}
    </button>
  );
}
