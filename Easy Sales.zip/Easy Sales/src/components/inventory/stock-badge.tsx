import { stockStatus, type StockStatus } from "@/convex/lib/stock.ts";
import { STATUS_LABELS } from "@/lib/stock.ts";
import { cn } from "@/lib/utils.ts";

type Props = {
  inStock: number;
  /** Either the low stock level, or a precomputed flag (e.g. summed variants) */
  lowStock?: number | null;
  isLow?: boolean;
  className?: string;
  showLabel?: boolean;
};

function statusOf({ inStock, lowStock = null, isLow }: Props): StockStatus {
  if (inStock <= 0) return "out";
  if (isLow !== undefined) return isLow ? "low" : "ok";
  return stockStatus(inStock, lowStock);
}

/** Stock count, coloured red when out and amber when low. */
export default function StockBadge(props: Props) {
  const { inStock, className, showLabel } = props;
  const status = statusOf(props);
  return (
    <span
      className={cn(
        "tabular-nums",
        status === "out" && "font-semibold text-destructive",
        status === "low" && "font-semibold text-amber-600 dark:text-amber-400",
        className,
      )}
    >
      {showLabel && status !== "ok" ? `${STATUS_LABELS[status]} · ${inStock}` : inStock}
    </span>
  );
}
