import { useMemo } from "react";
import { toast } from "sonner";
import { CheckCircle2, Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { useInstallPrompt } from "@/hooks/use-install-prompt.ts";
import { INSTALL_STEPS, detectPlatform } from "@/lib/install.ts";

type Props = { open: boolean; onOpenChange: (open: boolean) => void };

/** Explains how to put the POS on the home screen, with a one-tap install where the browser allows it. */
export default function InstallAppDialog({ open, onOpenChange }: Props) {
  const { canPrompt, installed, promptInstall } = useInstallPrompt();
  const inFrame = typeof window !== "undefined" && window.self !== window.top;
  const platform = useMemo(
    () => detectPlatform(navigator.userAgent, navigator.maxTouchPoints),
    [],
  );

  const handleInstall = async () => {
    try {
      const accepted = await promptInstall();
      if (accepted) {
        toast.success("App installed");
        onOpenChange(false);
      }
    } catch {
      toast.error("Couldn't start the install. Try the steps below.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Install app</DialogTitle>
          <DialogDescription>
            Add the register to your home screen so it opens full screen, like a normal app.
          </DialogDescription>
        </DialogHeader>

        {installed ? (
          <div className="flex items-center gap-3 rounded-md bg-accent p-4 text-accent-foreground">
            <CheckCircle2 className="size-5 shrink-0" />
            <p className="text-sm font-medium">The app is already installed on this device.</p>
          </div>
        ) : inFrame ? (
          <p className="rounded-md bg-muted p-4 text-sm text-muted-foreground">
            Installing only works on the published app. Open your app's web address on the tablet
            or phone, then come back to Settings and tap Install app.
          </p>
        ) : (
          <div className="space-y-5">
            {canPrompt && (
              <Button className="h-12 w-full text-base" onClick={handleInstall}>
                <Download className="size-5" />
                Install now
              </Button>
            )}
            <div className="space-y-3">
              {canPrompt && (
                <p className="text-sm text-muted-foreground">Or install it manually:</p>
              )}
              <ol className="space-y-3">
                {INSTALL_STEPS[platform].map((step, i) => (
                  <li key={step} className="flex gap-3 text-sm">
                    <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                      {i + 1}
                    </span>
                    <span className="pt-0.5">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
