import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { formatKsh } from "@/lib/money.ts";
import { itemUnit } from "@/convex/lib/quantity.ts";
import { ITEM_COLORS } from "@/lib/item-colors.ts";
import { cn } from "@/lib/utils.ts";

/** What the right side of an item row shows, matching the original app. */
export function itemPriceLabel(item: Doc<"items">): string {
  if (item.variants.length > 0) return `${item.variants.length} variants`;
  if (item.priceCents === null) return "–";
  const unit = itemUnit(item);
  return unit ? `${formatKsh(item.priceCents)}/${unit}` : formatKsh(item.priceCents);
}

export function ItemSwatch({ item, className }: { item: Doc<"items">; className?: string }) {
  return (
    <div
      className={cn(
        "flex size-10 shrink-0 items-center justify-center rounded-sm text-sm font-bold text-white",
        ITEM_COLORS[item.color],
        className,
      )}
    >
      {item.name.slice(0, 2).toUpperCase()}
    </div>
  );
}

type ItemRowProps = {
  item: Doc<"items">;
  onClick: () => void;
  trailing?: React.ReactNode;
};

export default function ItemRow({ item, onClick, trailing }: ItemRowProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full cursor-pointer items-center gap-4 border-b bg-card px-4 py-2.5 text-left transition-colors hover:bg-muted active:bg-accent"
    >
      <ItemSwatch item={item} />
      <span className="min-w-0 flex-1 truncate font-medium">{item.name}</span>
      <span className="shrink-0 text-sm text-muted-foreground">
        {trailing ?? itemPriceLabel(item)}
      </span>
    </button>
  );
}
