import { WEIGHT_UNITS, type WeightUnit } from "@/convex/lib/quantity.ts";
import { cn } from "@/lib/utils.ts";

type Props = { value: WeightUnit; onChange: (unit: WeightUnit) => void };

/** Compact kg / g toggle. */
export default function UnitSwitch({ value, onChange }: Props) {
  return (
    <div role="radiogroup" aria-label="Weight unit" className="flex shrink-0 rounded-sm border bg-background p-0.5">
      {WEIGHT_UNITS.map((u) => (
        <button
          key={u}
          type="button"
          role="radio"
          aria-checked={value === u}
          onClick={() => onChange(u)}
          className={cn(
            "min-w-11 cursor-pointer rounded-[3px] px-3 py-1.5 text-sm font-medium transition",
            value === u ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
          )}
        >
          {u}
        </button>
      ))}
    </div>
  );
}
