import { format } from "date-fns";
import { useOfflineSync } from "@/hooks/use-offline-sync.tsx";
import { removeQueuedSale } from "@/lib/offline/sales-queue.ts";
import { formatKsh } from "@/lib/money.ts";
import { PAYMENT_METHODS } from "@/lib/payments.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";

/** Offline sales the server refused (e.g. the shift was closed): retry or discard each one. */
export default function FailedSalesDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { failed, retry } = useOfflineSync();

  return (
    <Dialog open={open && failed.length > 0} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{"Sales that didn't sync"}</DialogTitle>
          <DialogDescription>
            Fix the problem (for example, open a shift) and tap Retry. Discard removes the sale for good.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[60dvh] space-y-3 overflow-y-auto">
          {failed.map((sale) => (
            <div key={sale.args.clientId} className="space-y-2 rounded-md border p-3">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-semibold tabular-nums">{formatKsh(sale.totalCents)}</span>
                <span className="text-xs text-muted-foreground">
                  {format(new Date(sale.args.soldAt), "d MMM, HH:mm")} · {PAYMENT_METHODS[sale.args.paymentMethod].label}
                </span>
              </div>
              <p className="truncate text-sm text-muted-foreground">
                {sale.args.lines.map((l) => l.name).join(", ")}
              </p>
              <p className="text-sm text-destructive">{sale.error}</p>
              <div className="flex justify-end gap-2">
                <Button size="sm" variant="ghost" onClick={() => removeQueuedSale(sale.args.clientId)}>
                  Discard
                </Button>
                <Button size="sm" onClick={() => retry(sale.args.clientId)}>
                  Retry
                </Button>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
