import { CloudOff, RefreshCw, TriangleAlert } from "lucide-react";
import { useQuery } from "convex/react";
import { useState } from "react";
import { api } from "@/convex/_generated/api.js";
import { useOfflineSync } from "@/hooks/use-offline-sync.tsx";
import FailedSalesDialog from "./failed-sales-dialog.tsx";

/**
 * Keeps the data the till needs subscribed for the whole session, so it stays
 * available when the connection drops and the cashier moves between screens.
 */
function KeepTillDataLoaded() {
  useQuery(api.settings.get, {});
  useQuery(api.catalog.discounts.list, {});
  useQuery(api.sales.shifts.current, {});
  useQuery(api.catalog.items.list, { search: "" });
  useQuery(api.catalog.categories.list, {});
  useQuery(api.inventory.stock.listAll, {});
  return null;
}

/** Thin bar under the app bar: offline notice, sales waiting to sync, failed syncs. */
export default function OfflineBanner() {
  const { online, pending, failed } = useOfflineSync();
  const [failedOpen, setFailedOpen] = useState(false);
  const waiting = pending.length;

  return (
    <>
      <KeepTillDataLoaded />
      {failed.length > 0 && (
        <button
          type="button"
          onClick={() => setFailedOpen(true)}
          className="flex w-full shrink-0 cursor-pointer items-center justify-center gap-2 bg-destructive px-3 py-1.5 text-sm font-medium text-white"
        >
          <TriangleAlert className="size-4" />
          {failed.length} offline {failed.length === 1 ? "sale" : "sales"} could not sync. Tap to review.
        </button>
      )}
      {!online ? (
        <div className="flex shrink-0 items-center justify-center gap-2 bg-foreground px-3 py-1.5 text-sm font-medium text-background">
          <CloudOff className="size-4" />
          {"You're offline. Sales are saved on this device"}
          {waiting > 0 && ` (${waiting} waiting)`}
        </div>
      ) : (
        waiting > 0 && (
          <div className="flex shrink-0 items-center justify-center gap-2 bg-accent px-3 py-1.5 text-sm font-medium text-accent-foreground">
            <RefreshCw className="size-4 animate-spin" />
            Syncing {waiting} offline {waiting === 1 ? "sale" : "sales"}
          </div>
        )
      )}
      <FailedSalesDialog open={failedOpen} onClose={() => setFailedOpen(false)} />
    </>
  );
}
