import type { ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { ShieldAlert } from "lucide-react";
import type { Permission } from "@/convex/lib/access.ts";
import { useStaff } from "@/hooks/use-staff.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";

/** Renders children only when the unlocked employee has the permission. */
export default function RequirePermission({
  permission,
  children,
}: {
  permission: Permission | ((can: (p: Permission) => boolean) => boolean);
  children: ReactNode;
}) {
  const { can } = useStaff();
  const navigate = useNavigate();
  const allowed = typeof permission === "function" ? permission(can) : can(permission);
  if (allowed) return <>{children}</>;
  return (
    <Empty className="h-full py-16">
      <EmptyHeader>
        <EmptyMedia variant="icon">
          <ShieldAlert />
        </EmptyMedia>
        <EmptyTitle>No access</EmptyTitle>
        <EmptyDescription>You don&apos;t have access to this screen. Ask the owner to change your access rights.</EmptyDescription>
      </EmptyHeader>
      <EmptyContent>
        <Button size="sm" onClick={() => navigate("/")}>
          Back to sales
        </Button>
      </EmptyContent>
    </Empty>
  );
}
