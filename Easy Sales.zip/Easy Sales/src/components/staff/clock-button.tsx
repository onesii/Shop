import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { formatDistanceToNowStrict } from "date-fns";
import { Timer } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { formatHours } from "@/convex/lib/timecards.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";

/** Clock in / out for the employee on the POS. */
export default function ClockButton() {
  const status = useQuery(api.staff.timecards.myStatus, {});
  const clockIn = useMutation(api.staff.timecards.clockIn);
  const clockOut = useMutation(api.staff.timecards.clockOut);
  const [busy, setBusy] = useState(false);
  if (!status) return null;
  const inSince = status.clockedInAt;

  const toggle = async () => {
    setBusy(true);
    try {
      if (inSince) {
        const { minutes } = await clockOut({});
        toast.success(`Clocked out. You worked ${formatHours(minutes)} hours.`);
      } else {
        await clockIn({});
        toast.success("Clocked in");
      }
    } catch (err) {
      toast.error(convexMessage(err, "Could not update your timecard"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center justify-between gap-3 px-6 py-3">
      <div className="min-w-0 text-sm">
        <p className="flex items-center gap-2 font-medium">
          <Timer className="size-4 text-muted-foreground" /> Timecard
        </p>
        <p className="truncate text-xs text-muted-foreground">
          {inSince ? `Clocked in ${formatDistanceToNowStrict(new Date(inSince))} ago` : "Not clocked in"}
        </p>
      </div>
      <Button size="sm" variant={inSince ? "secondary" : "default"} disabled={busy} onClick={() => void toggle()}>
        {inSince ? "Clock out" : "Clock in"}
      </Button>
    </div>
  );
}
