import { useEffect, useRef, useState } from "react";
import { useMutation } from "convex/react";
import { motion } from "motion/react";
import { Delete, LogOut, ShoppingBasket } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { useAuth } from "@/hooks/use-auth.ts";
import { convexMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import { Spinner } from "@/components/ui/spinner.tsx";

const PIN_LENGTH = 4;
const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "back"] as const;

/** Full-screen PIN pad shown when the POS is locked. */
export default function PinLock({ storeName }: { storeName?: string }) {
  const unlock = useMutation(api.staff.session.unlock);
  const { signout } = useAuth();
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [shake, setShake] = useState(0);

  // Guards against a second submit while the first is in flight
  const submitting = useRef(false);

  // Submits once the 4th digit is entered (from taps or the keyboard)
  useEffect(() => {
    if (pin.length !== PIN_LENGTH || submitting.current) return;
    submitting.current = true;
    setBusy(true);
    const run = async () => {
      try {
        const res = await unlock({ pin });
        if (res.ok) {
          toast.success(`Welcome, ${res.name}`);
          return;
        }
        setError(res.message);
        setShake((s) => s + 1);
        setPin("");
      } catch (err) {
        setError(convexMessage(err, "Could not unlock. Try again."));
        setPin("");
      } finally {
        submitting.current = false;
        setBusy(false);
      }
    };
    void run();
  }, [pin, unlock]);

  const press = (key: (typeof KEYS)[number]) => {
    if (key === "" || submitting.current) return;
    setError(null);
    if (key === "back") setPin((p) => p.slice(0, -1));
    else setPin((p) => (p + key).slice(0, PIN_LENGTH));
  };

  // Physical keyboards (desktop / tablet with keyboard) can type the PIN too
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (submitting.current) return;
      if (/^\d$/.test(e.key)) {
        setError(null);
        setPin((p) => (p + e.key).slice(0, PIN_LENGTH));
      }
      if (e.key === "Backspace") setPin((p) => p.slice(0, -1));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div
      className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-secondary px-6 text-secondary-foreground"
    >
      <div className="pointer-events-none absolute -right-32 top-0 h-full w-[55%] skew-x-[-18deg] bg-primary/35" />
      <div className="relative flex w-full max-w-xs flex-col items-center gap-6">
        <div className="flex size-14 items-center justify-center rounded-2xl bg-white text-secondary shadow-lg">
          <ShoppingBasket className="size-7" />
        </div>
        <div className="text-center">
          <p className="text-sm opacity-80">{storeName || "Point of sale"}</p>
          <h1 className="pt-1 text-2xl font-semibold">Enter your PIN</h1>
        </div>

        <motion.div
          key={shake}
          animate={shake ? { x: [0, -10, 10, -6, 6, 0] } : {}}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="flex gap-4"
          aria-label={`${pin.length} of ${PIN_LENGTH} digits entered`}
        >
          {Array.from({ length: PIN_LENGTH }).map((_, i) => (
            <span
              key={i}
              className={cn(
                "size-4 rounded-full border-2 border-white/80 transition-colors",
                i < pin.length && "bg-white",
              )}
            />
          ))}
        </motion.div>
        <p className="h-5 text-sm font-medium text-amber-200" role="alert">
          {busy ? <Spinner className="mx-auto" /> : error}
        </p>

        <div className="grid w-full grid-cols-3 gap-3">
          {KEYS.map((k, i) =>
            k === "" ? (
              <span key={i} />
            ) : (
              <button
                key={i}
                type="button"
                aria-label={k === "back" ? "Delete digit" : k}
                onClick={() => press(k)}
                disabled={busy}
                className="flex h-16 cursor-pointer items-center justify-center rounded-full bg-white/10 text-2xl font-medium transition hover:bg-white/20 active:bg-white/30 disabled:opacity-50"
              >
                {k === "back" ? <Delete className="size-6" /> : k}
              </button>
            ),
          )}
        </div>

        <button
          type="button"
          onClick={() => void signout()}
          className="flex cursor-pointer items-center gap-2 pt-2 text-sm opacity-80 transition hover:opacity-100"
        >
          <LogOut className="size-4" /> Sign out of this device
        </button>
      </div>
    </div>
  );
}
