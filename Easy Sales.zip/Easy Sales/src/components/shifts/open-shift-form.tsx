import { useState } from "react";
import { useMutation } from "convex/react";
import { Clock } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { parseToCents } from "@/lib/money.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";

/** Shown wherever a shift must be opened before selling, like Loyverse. */
export default function OpenShiftForm() {
  const open = useMutation(api.sales.shifts.open);
  const [cash, setCash] = useState("");
  const [saving, setSaving] = useState(false);
  const cents = parseToCents(cash) ?? 0;
  const invalid = Number.isNaN(cents) || cents < 0;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await open({ startingCashCents: cents });
      toast.success("Shift opened");
    } catch (err) {
      toast.error(convexMessage(err, "Could not open shift"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="mx-auto w-full max-w-sm space-y-6 px-4 py-12 text-center">
      <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-accent text-accent-foreground">
        <Clock className="size-8" />
      </div>
      <div>
        <h2 className="text-xl font-semibold">Shift is closed</h2>
        <p className="pt-1 text-sm text-muted-foreground">
          Open a shift to start making sales
        </p>
      </div>
      <div className="space-y-2 text-left">
        <Label htmlFor="starting-cash" className="text-muted-foreground">
          Amount of cash in drawer at the start of the shift
        </Label>
        <Input
          id="starting-cash"
          inputMode="decimal"
          value={cash}
          onChange={(e) => setCash(e.target.value)}
          placeholder="0.00"
          className="h-12 rounded-none border-0 border-b-2 border-primary px-0 text-2xl font-semibold shadow-none focus-visible:ring-0"
        />
        {invalid && <p className="text-sm text-destructive">Enter a valid amount</p>}
      </div>
      <Button
        type="submit"
        size="lg"
        disabled={saving || invalid}
        className="h-14 w-full rounded-sm text-base font-semibold uppercase"
      >
        {saving ? "Opening..." : "Open shift"}
      </Button>
    </form>
  );
}
