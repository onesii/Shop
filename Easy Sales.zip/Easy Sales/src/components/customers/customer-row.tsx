import { CircleUser } from "lucide-react";
import { cn } from "@/lib/utils.ts";

type Props = {
  name: string;
  detail?: string | null;
  right?: React.ReactNode;
  active?: boolean;
  onClick: () => void;
};

/** List row: icon on the left, divider below, like the rest of the app. */
export default function CustomerRow({ name, detail, right, active, onClick }: Props) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex w-full cursor-pointer items-center gap-4 border-b bg-card px-4 py-2.5 text-left transition-colors hover:bg-muted active:bg-accent",
        active && "bg-accent",
      )}
    >
      <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <CircleUser className="size-5" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-medium">{name}</span>
        {detail && <span className="block truncate text-sm text-muted-foreground">{detail}</span>}
      </span>
      {right && <span className="shrink-0 text-sm tabular-nums text-muted-foreground">{right}</span>}
    </button>
  );
}
