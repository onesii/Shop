import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { convexMessage } from "@/lib/errors.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";

type Props = {
  customer: Doc<"customers"> | null;
  /** Called with the saved customer's id and name */
  onSaved: (customer: { id: Id<"customers">; name: string }) => void;
  onCancel: () => void;
  /** Extra footer content on the left, e.g. a delete button */
  extra?: React.ReactNode;
};

const FIELDS = [
  { key: "name", label: "Name", placeholder: "Wanjiku Kamau", type: "text", inputMode: "text" },
  { key: "phone", label: "Phone", placeholder: "0712 345 678", type: "tel", inputMode: "tel" },
  { key: "email", label: "Email", placeholder: "wanjiku@example.com", type: "email", inputMode: "email" },
] as const;

type Values = { name: string; phone: string; email: string; note: string };

/** Create or edit a customer. Used at the POS and in the back office. */
export default function CustomerForm({ customer, onSaved, onCancel, extra }: Props) {
  const create = useMutation(api.customers.create);
  const update = useMutation(api.customers.update);
  const [values, setValues] = useState<Values>({
    name: customer?.name ?? "",
    phone: customer?.phone ?? "",
    email: customer?.email ?? "",
    note: customer?.note ?? "",
  });
  const [busy, setBusy] = useState(false);
  const set = (key: keyof Values, value: string) => setValues((v) => ({ ...v, [key]: value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!values.name.trim()) return toast.error("Customer name is required");
    setBusy(true);
    try {
      const id = customer ? customer._id : await create(values);
      if (customer) await update({ id: customer._id, ...values });
      toast.success(customer ? "Customer updated" : "Customer added");
      onSaved({ id, name: values.name.trim() });
    } catch (err) {
      toast.error(convexMessage(err, "Could not save customer"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      {FIELDS.map((f) => (
        <div key={f.key} className="space-y-2">
          <Label htmlFor={`customer-${f.key}`}>{f.label}</Label>
          <Input
            id={`customer-${f.key}`}
            type={f.type}
            inputMode={f.inputMode}
            autoFocus={f.key === "name"}
            maxLength={f.key === "name" ? 80 : 120}
            value={values[f.key]}
            onChange={(e) => set(f.key, e.target.value)}
            placeholder={f.placeholder}
          />
        </div>
      ))}
      <div className="space-y-2">
        <Label htmlFor="customer-note">Note</Label>
        <Textarea
          id="customer-note"
          rows={2}
          maxLength={500}
          value={values.note}
          onChange={(e) => set("note", e.target.value)}
          placeholder="Prefers M-Pesa"
        />
      </div>
      <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-between">
        {extra ?? <span />}
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" disabled={busy}>
            {busy ? "Saving..." : "Save"}
          </Button>
        </div>
      </div>
    </form>
  );
}
