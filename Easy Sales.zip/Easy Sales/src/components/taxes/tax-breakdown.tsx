import { formatKsh } from "@/lib/money.ts";
import { formatRate, type TaxLine } from "@/convex/lib/taxes.ts";
import type { DiscountLine } from "@/convex/lib/discounts.ts";
import { formatDiscountValue } from "@/lib/discounts.ts";
import { cn } from "@/lib/utils.ts";

type Props = {
  subtotalCents: number;
  taxes: TaxLine[];
  discounts?: DiscountLine[];
  className?: string;
};

/** Subtotal, discount and per-tax rows, shown above a total on tickets and receipts. */
export default function TaxBreakdown({ subtotalCents, taxes, discounts = [], className }: Props) {
  if (taxes.length === 0 && discounts.length === 0) return null;
  return (
    <div className={cn("space-y-1 text-sm text-muted-foreground", className)}>
      <div className="flex justify-between">
        <span>Subtotal</span>
        <span className="tabular-nums">{formatKsh(subtotalCents)}</span>
      </div>
      {discounts.map((d, i) => (
        <div key={`d${i}`} className="flex justify-between gap-4 text-primary">
          <span className="truncate">
            {d.name}
            {d.type === "percent" && ` ${formatDiscountValue(d.type, d.value)}`}
          </span>
          <span className="tabular-nums">-{formatKsh(d.amountCents)}</span>
        </div>
      ))}
      {taxes.map((t) => (
        <div key={t.name} className="flex justify-between gap-4">
          <span className="truncate">
            {t.name} {formatRate(t.rateBps)}
            {t.type === "included" && " (included)"}
          </span>
          <span className="tabular-nums">{formatKsh(t.amountCents)}</span>
        </div>
      ))}
    </div>
  );
}
