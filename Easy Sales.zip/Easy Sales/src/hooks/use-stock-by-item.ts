import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

export type ItemStock = { inStock: number; lowStock: number | null; isLow: boolean };

/** Stock per tracked item (variants summed; low if any variant is low). Undefined while loading. */
export function useStockByItem(): Map<Id<"items">, ItemStock> | undefined {
  const levels = useQuery(api.inventory.stock.listAll, {});
  if (levels === undefined) return undefined;
  const map = new Map<Id<"items">, ItemStock>();
  for (const l of levels) {
    const cur = map.get(l.itemId);
    if (cur) {
      cur.inStock += l.inStock;
      cur.isLow ||= l.isLow;
    } else {
      map.set(l.itemId, { inStock: l.inStock, lowStock: l.lowStock, isLow: l.isLow });
    }
  }
  return map;
}
