import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { computeTotals, type TicketTotals as Totals } from "@/convex/lib/discounts.ts";
import { useTicket } from "./use-ticket.tsx";

export type TicketTotals = Totals & {
  /** Applied discounts that still exist, in ticket order (ids for the charge mutation). */
  appliedDiscounts: Doc<"discounts">[];
  /** False until settings and discounts have loaded, so the total isn't final yet. */
  ready: boolean;
};

/** Current sale totals with discounts and the store's enabled taxes applied (mirrors the backend). */
export function useTicketTotals(): TicketTotals {
  const { totalCents: subtotalCents, discountIds } = useTicket();
  const settings = useQuery(api.settings.get, {});
  const allDiscounts = useQuery(api.catalog.discounts.list, discountIds.length > 0 ? {} : "skip");
  const byId = new Map<Id<"discounts">, Doc<"discounts">>((allDiscounts ?? []).map((d) => [d._id, d]));
  const appliedDiscounts = discountIds.flatMap((id) => byId.get(id) ?? []);
  const taxRules = (settings?.taxes ?? [])
    .filter((t) => t.enabled)
    .map(({ name, rateBps, type }) => ({ name, rateBps, type }));
  const totals = computeTotals(
    subtotalCents,
    appliedDiscounts.map(({ name, type, value }) => ({ name, type, value })),
    taxRules,
  );
  const discountsReady = discountIds.length === 0 || allDiscounts !== undefined;
  return { ...totals, appliedDiscounts, ready: settings !== undefined && discountsReady };
}
