import { useCallback, useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { printBill, printOrder, printReceipt } from "@/lib/printing/print.ts";
import { usePrinters } from "@/lib/printing/printers-store.ts";
import { orderTicketsFor, type GroupRef, type RoutableOrder } from "@/lib/printing/order-routing.ts";
import type { OrderTicket, PrintableBill, PrintableReceipt } from "@/lib/printing/receipt-layout.ts";

const showErrors = (errors: string[]) => errors.forEach((e) => toast.error("Could not print", { description: e }));

/** Prints a receipt on every printer set to print receipts on this device. */
export function usePrintReceipt() {
  const printers = usePrinters();
  const [printing, setPrinting] = useState(false);
  const receiptPrinters = printers.filter((p) => p.printReceipts);
  const autoPrinters = receiptPrinters.filter((p) => p.autoPrint);

  const print = useCallback(
    async (receipt: PrintableReceipt, auto = false) => {
      const targets = auto ? autoPrinters : receiptPrinters;
      if (auto && targets.length === 0) return;
      setPrinting(true);
      try {
        showErrors(await printReceipt(receipt, targets));
      } finally {
        setPrinting(false);
      }
    },
    [autoPrinters, receiptPrinters],
  );

  return { print, printing, hasAutoPrint: autoPrinters.length > 0 };
}

type OrderInput = Omit<OrderTicket, "lines"> & {
  lines: (OrderTicket["lines"][number] & { itemId: string })[];
};

/**
 * Sends an order ticket to the kitchen/bar printers ("Print orders" on). Printers in
 * printer groups only get the lines from their groups' categories.
 */
export function usePrintOrder() {
  const printers = usePrinters();
  const orderPrinters = printers.filter((p) => p.printOrders);
  const needsRouting = orderPrinters.some((p) => p.groupIds.length > 0);
  // Only loaded when a printer actually uses groups
  const groups = useQuery(api.printing.printerGroups.list, needsRouting ? {} : "skip");
  const items = useQuery(api.catalog.items.list, needsRouting ? {} : "skip");

  const categoryOf = useMemo(
    () => new Map<string, string | null>((items ?? []).map((i) => [i._id, i.categoryId])),
    [items],
  );

  const print = useCallback(
    async (order: OrderInput) => {
      if (orderPrinters.length === 0) return;
      const routable: RoutableOrder = {
        ...order,
        lines: order.lines.map(({ itemId, ...l }) => ({ ...l, categoryId: categoryOf.get(itemId) ?? null })),
      };
      const groupRefs: GroupRef[] = (groups ?? []).map((g) => ({ id: g._id, categoryIds: g.categoryIds }));
      showErrors(await printOrder((p) => orderTicketsFor(routable, p, groupRefs), orderPrinters));
    },
    [orderPrinters, groups, categoryOf],
  );

  return { printOrder: print, hasOrderPrinters: orderPrinters.length > 0 };
}

/** Prints the current ticket as a bill on the receipt printers. */
export function usePrintBill() {
  const printers = usePrinters();
  return useCallback(
    async (bill: PrintableBill) => showErrors(await printBill(bill, printers.filter((p) => p.printReceipts))),
    [printers],
  );
}
