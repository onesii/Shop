import { useSyncExternalStore } from "react";

// Chromium-only event; not in the standard DOM typings
type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type InstallState = { deferred: BeforeInstallPromptEvent | null; installed: boolean };

const isStandalone = () =>
  typeof window !== "undefined" &&
  (window.matchMedia("(display-mode: standalone)").matches ||
    ("standalone" in navigator && navigator.standalone === true));

let state: InstallState = { deferred: null, installed: isStandalone() };
const listeners = new Set<() => void>();
const setState = (next: Partial<InstallState>) => {
  state = { ...state, ...next };
  listeners.forEach((l) => l());
};

// Listen at module load: the browser fires this event once, often before React mounts
if (typeof window !== "undefined") {
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    setState({ deferred: e as BeforeInstallPromptEvent });
  });
  window.addEventListener("appinstalled", () => setState({ deferred: null, installed: true }));
}

const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => listeners.delete(l);
};

export function useInstallPrompt() {
  const { deferred, installed } = useSyncExternalStore(subscribe, () => state);
  // The App Builder preview is an iframe, where installing is impossible
  const inFrame = typeof window !== "undefined" && window.self !== window.top;

  const promptInstall = async (): Promise<boolean> => {
    if (!deferred) return false;
    await deferred.prompt();
    const { outcome } = await deferred.userChoice;
    setState({ deferred: null, installed: outcome === "accepted" });
    return outcome === "accepted";
  };

  return { canPrompt: deferred !== null, installed, available: !installed && !inFrame, promptInstall };
}
