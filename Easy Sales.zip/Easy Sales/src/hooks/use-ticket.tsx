import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import type { ItemColor } from "@/lib/item-colors.ts";
import { roundQty, sumLineTotals, type WeightUnit } from "@/convex/lib/quantity.ts";

export type TicketLine = {
  key: string;
  itemId: Id<"items">;
  name: string;
  variantName: string | null;
  priceCents: number;
  quantity: number;
  color: ItemColor;
  comment?: string;
  /** Weight items: the unit the quantity and price are in. */
  unit?: WeightUnit;
};

/** The saved open ticket the current sale was loaded from, if any. */
export type SavedTicketRef = {
  id: Id<"openTickets">;
  name: string;
  comment: string | null;
};

/** Customer on the current sale (name kept for display while offline). */
export type TicketCustomer = { id: Id<"customers">; name: string };

type AddLineInput = Omit<TicketLine, "key" | "quantity">;
/** Fields that can change when a ticket line is edited. */
export type LinePatch = Pick<TicketLine, "variantName" | "priceCents" | "quantity" | "comment" | "unit">;

type TicketContextValue = {
  lines: TicketLine[];
  saved: SavedTicketRef | null;
  /** Whole-ticket discounts, in the order they were applied. */
  discountIds: Id<"discounts">[];
  customer: TicketCustomer | null;
  setCustomer: (customer: TicketCustomer | null) => void;
  /** Sum of line prices, before discounts and taxes. */
  totalCents: number;
  itemCount: number;
  /** Adds the quantity (default 1) to a matching line, or adds a new line. */
  addLine: (input: AddLineInput, quantity?: number) => void;
  /** Edits a line; if it now matches another line, the two are merged. */
  updateLine: (key: string, patch: LinePatch) => void;
  setQuantity: (key: string, quantity: number) => void;
  removeLine: (key: string) => void;
  toggleDiscount: (id: Id<"discounts">) => void;
  /** Replace the current sale with a saved open ticket. */
  load: (ticket: Doc<"openTickets">) => void;
  clear: () => void;
};

type StoredState = {
  lines: TicketLine[];
  saved: SavedTicketRef | null;
  discountIds: Id<"discounts">[];
  customer: TicketCustomer | null;
};

const EMPTY_STATE: StoredState = { lines: [], saved: null, discountIds: [], customer: null };

const STORAGE_KEY = "pos-current-ticket";
const TicketContext = createContext<TicketContextValue | null>(null);

// Lines with a different comment stay separate, like the original app
function lineKey(input: AddLineInput): string {
  return `${input.itemId}|${input.variantName ?? ""}|${input.priceCents}|${input.comment ?? ""}|${input.unit ?? ""}`;
}

/** Adds `quantity` to the line with the same key, or appends a new line. */
function mergeLine(lines: TicketLine[], line: Omit<TicketLine, "key">): TicketLine[] {
  const key = lineKey(line);
  if (!lines.some((l) => l.key === key)) return [...lines, { ...line, key }];
  return lines.map((l) => (l.key === key ? { ...l, quantity: roundQty(l.quantity + line.quantity) } : l));
}

function loadState(): StoredState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : null;
    // Older versions stored just the array of lines
    if (Array.isArray(parsed)) return { ...EMPTY_STATE, lines: parsed as TicketLine[] };
    if (parsed && typeof parsed === "object" && "lines" in parsed) {
      return { ...EMPTY_STATE, ...(parsed as Partial<StoredState>) };
    }
  } catch {
    // Corrupt storage: start with an empty ticket
  }
  return EMPTY_STATE;
}

export function TicketProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<StoredState>(loadState);

  // Persist the open sale so a page refresh doesn't lose it
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const value = useMemo<TicketContextValue>(() => {
    const setLines = (update: (prev: TicketLine[]) => TicketLine[]) =>
      setState((s) => ({ ...s, lines: update(s.lines) }));
    const addLine = (input: AddLineInput, quantity = 1) =>
      setLines((prev) => mergeLine(prev, { ...input, comment: input.comment || undefined, quantity }));
    const updateLine = (key: string, patch: LinePatch) =>
      setLines((prev) => {
        const line = prev.find((l) => l.key === key);
        if (!line) return prev;
        const rest = prev.filter((l) => l.key !== key);
        const edited = { ...line, ...patch, comment: patch.comment?.trim() || undefined };
        // Keep the line in its place unless it merges into another one
        const index = prev.indexOf(line);
        const merged = mergeLine(rest, edited);
        if (merged.length === rest.length) return merged;
        const added = merged[merged.length - 1];
        return [...rest.slice(0, index), added, ...rest.slice(index)];
      });
    const removeLine = (key: string) => setLines((prev) => prev.filter((l) => l.key !== key));
    const setQuantity = (key: string, quantity: number) => {
      if (quantity <= 0) return removeLine(key);
      setLines((prev) => prev.map((l) => (l.key === key ? { ...l, quantity } : l)));
    };
    const toggleDiscount = (id: Id<"discounts">) =>
      setState((s) => ({
        ...s,
        discountIds: s.discountIds.includes(id)
          ? s.discountIds.filter((d) => d !== id)
          : [...s.discountIds, id],
      }));
    const load = (ticket: Doc<"openTickets">) =>
      setState({
        lines: ticket.lines.map((l) => ({ ...l, key: lineKey(l) })),
        saved: { id: ticket._id, name: ticket.name, comment: ticket.comment },
        discountIds: ticket.discountIds ?? [],
        customer:
          ticket.customerId && ticket.customerName
            ? { id: ticket.customerId, name: ticket.customerName }
            : null,
      });
    const { lines, saved, discountIds, customer } = state;
    return {
      lines,
      saved,
      discountIds,
      customer,
      setCustomer: (c: TicketCustomer | null) => setState((s) => ({ ...s, customer: c })),
      totalCents: sumLineTotals(lines),
      // Number of lines with a whole count each, so 2.5 kg counts as one item
      itemCount: lines.reduce((s, l) => s + (Number.isInteger(l.quantity) ? l.quantity : 1), 0),
      addLine,
      updateLine,
      setQuantity,
      removeLine,
      toggleDiscount,
      load,
      clear: () => setState(EMPTY_STATE),
    };
  }, [state]);

  return <TicketContext.Provider value={value}>{children}</TicketContext.Provider>;
}

export function useTicket(): TicketContextValue {
  const ctx = useContext(TicketContext);
  if (!ctx) throw new Error("useTicket must be used inside TicketProvider");
  return ctx;
}

/** Strips client-only fields so lines match the backend validator. */
export function toTicketLines(lines: TicketLine[]) {
  return lines.map(({ itemId, name, variantName, priceCents, quantity, color, comment, unit }) => ({
    itemId,
    name,
    variantName,
    priceCents,
    quantity,
    color,
    ...(comment ? { comment } : {}),
    ...(unit ? { unit } : {}),
  }));
}
