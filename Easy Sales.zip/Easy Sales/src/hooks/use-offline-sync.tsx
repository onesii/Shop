import { createContext, useCallback, useContext, useEffect, useRef, useSyncExternalStore, type ReactNode } from "react";
import { useConvex, useConvexConnectionState } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { convexMessage } from "@/lib/errors.ts";
import { CHARGE_TIMEOUT_MS, withTimeout } from "@/lib/offline/timeout.ts";
import {
  getQueuedSales,
  removeQueuedSale,
  setQueuedSaleError,
  useQueuedSales,
  type ChargeArgs,
  type QueuedSale,
} from "@/lib/offline/sales-queue.ts";

function subscribeBrowserOnline(cb: () => void) {
  window.addEventListener("online", cb);
  window.addEventListener("offline", cb);
  return () => {
    window.removeEventListener("online", cb);
    window.removeEventListener("offline", cb);
  };
}

/** True when the browser has a network and the live connection to the server is up. */
export function useIsOnline(): boolean {
  const browserOnline = useSyncExternalStore(subscribeBrowserOnline, () => navigator.onLine, () => true);
  const { isWebSocketConnected, hasEverConnected } = useConvexConnectionState();
  // Before the first connection, trust the browser so the app doesn't flash "offline"
  return browserOnline && (isWebSocketConnected || !hasEverConnected);
}

type OfflineSyncValue = {
  online: boolean;
  /** Sales waiting to be sent (not counting failed ones). */
  pending: QueuedSale[];
  /** Sales the server refused; the cashier retries or discards them. */
  failed: QueuedSale[];
  syncNow: () => void;
  retry: (clientId: string) => void;
};

const OfflineSyncContext = createContext<OfflineSyncValue | null>(null);

/** Sends sales made offline to the server, oldest first, whenever the app is online. */
export function OfflineSyncProvider({ children }: { children: ReactNode }) {
  const convex = useConvex();
  const online = useIsOnline();
  const queue = useQueuedSales();
  const running = useRef(false);

  const sync = useCallback(async () => {
    if (running.current) return;
    running.current = true;
    let synced = 0;
    try {
      for (const sale of getQueuedSales()) {
        if (sale.error) continue;
        try {
          await withTimeout(convex.mutation(api.sales.receipts.charge, sale.args as ChargeArgs), CHARGE_TIMEOUT_MS);
          removeQueuedSale(sale.args.clientId);
          synced++;
        } catch (err) {
          // Connection trouble: stop and try again when back online
          if (!(err instanceof ConvexError)) break;
          setQueuedSaleError(sale.args.clientId, convexMessage(err, "The sale could not be saved"));
        }
      }
    } finally {
      running.current = false;
    }
    if (synced > 0) toast.success(`${synced} offline ${synced === 1 ? "sale" : "sales"} synced`);
  }, [convex]);

  const waiting = queue.filter((s) => !s.error);
  const failed = queue.filter((s) => s.error);

  // Sync when the connection comes back, and when a sale is queued while online
  useEffect(() => {
    if (online && waiting.length > 0) void sync();
  }, [online, waiting.length, sync]);

  const value: OfflineSyncValue = {
    online,
    pending: waiting,
    failed,
    syncNow: () => void sync(),
    retry: (clientId) => setQueuedSaleError(clientId, null),
  };

  return <OfflineSyncContext.Provider value={value}>{children}</OfflineSyncContext.Provider>;
}

export function useOfflineSync(): OfflineSyncValue {
  const ctx = useContext(OfflineSyncContext);
  if (!ctx) throw new Error("useOfflineSync must be used inside OfflineSyncProvider");
  return ctx;
}
