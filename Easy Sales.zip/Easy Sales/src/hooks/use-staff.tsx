import { createContext, useContext, type ReactNode } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Permission } from "@/convex/lib/access.ts";

type StaffState = {
  name: string;
  role: "owner" | "manager" | "cashier";
  permissions: Permission[];
  /** The store has staff, so the POS can be locked */
  canLock: boolean;
  can: (p: Permission) => boolean;
};

const StaffContext = createContext<StaffState | null>(null);

export function StaffProvider({ value, children }: { value: StaffState; children: ReactNode }) {
  return <StaffContext.Provider value={value}>{children}</StaffContext.Provider>;
}

/** The employee unlocked on the POS. Only usable inside the unlocked app. */
export function useStaff(): StaffState {
  const ctx = useContext(StaffContext);
  if (!ctx) throw new Error("useStaff must be used inside StaffProvider");
  return ctx;
}

/** Raw session query, used by the layout to decide between lock screen and app. */
export function useStaffSession() {
  return useQuery(api.staff.session.current, {});
}
